"""Read-only discovery of desktop apps outside APT and Flatpak.

Many programs have no package record: AppImages, Wine programs, Waydroid Android apps,
Snap apps, and manual installs. Most of them still ship a .desktop launcher, so this
provider reads launchers, never executes anything, and classifies each one by source.

Classification is evidence, not proof. An entry is labelled from its Exec line and from
dpkg's file lists. Entries that match neither are reported as "manual / tidak dikenal".
"""
from __future__ import annotations

import os
import re
import shlex
from pathlib import Path

from .domain import InstalledApplication
from .providers import ProviderResult

MAX_DESKTOP_FILES = 2000
MAX_DESKTOP_BYTES = 64 * 1024
DPKG_INFO_DIR = Path("/var/lib/dpkg/info")
FLATPAK_EXPORT_MARKERS = ("/flatpak/exports/", "/.local/share/flatpak/")
SNAP_MARKER = "/snapd/desktop/"

SOURCE_APT = "APT / dpkg"
SOURCE_APPIMAGE = "AppImage"
SOURCE_WINE = "Wine"
SOURCE_WAYDROID = "Waydroid"
SOURCE_SNAP = "Snap"
SOURCE_MANUAL = "Manual / tidak dikenal"

_WINE_TOKENS = re.compile(r"(^|[\s/])(wine|wine64|wine-stable|wine-staging|proton|lutris|bottles)(\s|$|/)")


def _split_exec(exec_line: str) -> list[str]:
    try:
        return shlex.split(exec_line)
    except ValueError:
        return exec_line.split()


def parse_desktop_entry(text: str) -> dict[str, str]:
    """Read the [Desktop Entry] group only. Localised keys are ignored for matching."""
    fields: dict[str, str] = {}
    in_group = False
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("["):
            in_group = line == "[Desktop Entry]"
            continue
        if not in_group or "=" not in line:
            continue
        key, value = line.split("=", 1)
        if "[" in key:  # e.g. Name[id]
            continue
        fields.setdefault(key.strip(), value.strip())
    return fields


def classify_source(
    desktop_path: str,
    fields: dict[str, str],
    dpkg_owned: set[str],
) -> str | None:
    """Return the source label, or None when APT owns the launcher (deduplicated elsewhere)."""
    if desktop_path in dpkg_owned:
        return SOURCE_APT
    if any(marker in desktop_path for marker in FLATPAK_EXPORT_MARKERS):
        return None  # reported by the Flatpak provider
    if SNAP_MARKER in desktop_path:
        return SOURCE_SNAP
    exec_line = fields.get("Exec", "") or fields.get("TryExec", "")
    lowered = exec_line.casefold()
    if ".appimage" in lowered:
        return SOURCE_APPIMAGE
    if "waydroid" in lowered:
        return SOURCE_WAYDROID
    if _WINE_TOKENS.search(lowered) or "/wine/" in desktop_path.casefold():
        return SOURCE_WINE
    if "snap run" in lowered or "/snap/" in lowered:
        return SOURCE_SNAP
    return SOURCE_MANUAL


def executable_of(fields: dict[str, str]) -> str:
    """The program that Exec really runs, skipping `env` and VAR=value prefixes. For display only."""
    words = _split_exec(fields.get("Exec", "") or fields.get("TryExec", ""))
    for word in words:
        if word == "env" or ("=" in word and not word.startswith("/")):
            continue
        return word
    return ""


def load_dpkg_owned_paths(info_dir: Path = DPKG_INFO_DIR) -> set[str]:
    """Every file path listed in dpkg's .list files. Read-only; bounded by the local database."""
    owned: set[str] = set()
    try:
        lists = list(info_dir.glob("*.list"))
    except OSError:
        return owned
    for listing in lists:
        try:
            with open(listing, encoding="utf-8", errors="replace") as handle:
                for line in handle:
                    stripped = line.rstrip("\n")
                    if stripped.endswith(".desktop"):
                        owned.add(stripped)
        except OSError:
            continue
    return owned


def default_applications_dirs() -> list[Path]:
    dirs: list[Path] = []
    data_home = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    dirs.append(Path(data_home) / "applications")
    data_dirs = os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share"
    dirs.extend(Path(item) / "applications" for item in data_dirs.split(":") if item)
    dirs.append(Path("/var/lib/snapd/desktop/applications"))
    seen: set[Path] = set()
    unique: list[Path] = []
    for item in dirs:
        if item not in seen:
            seen.add(item)
            unique.append(item)
    return unique


def scan_desktop_entries(
    directories: list[Path] | None = None,
    dpkg_owned: set[str] | None = None,
) -> tuple[list[InstalledApplication], list[str]]:
    """Walk the launcher directories. Returns applications and diagnostics. Never executes."""
    owned = load_dpkg_owned_paths() if dpkg_owned is None else dpkg_owned
    applications: list[InstalledApplication] = []
    diagnostics: list[str] = []
    seen_ids: set[str] = set()
    scanned = 0
    for directory in (default_applications_dirs() if directories is None else directories):
        try:
            entries = sorted(directory.rglob("*.desktop"))
        except OSError:
            continue
        for entry in entries:
            if scanned >= MAX_DESKTOP_FILES:
                diagnostics.append(f"Pemindaian launcher dihentikan setelah {MAX_DESKTOP_FILES} berkas.")
                return applications, diagnostics
            scanned += 1
            try:
                if entry.stat().st_size > MAX_DESKTOP_BYTES:
                    continue
                text = entry.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            fields = parse_desktop_entry(text)
            if fields.get("Type", "Application") != "Application":
                continue
            identifier = entry.name
            if identifier in seen_ids:
                continue  # a user copy overrides a system copy with the same id
            source = classify_source(str(entry), fields, owned)
            if source is None or source == SOURCE_APT:
                continue
            seen_ids.add(identifier)
            name = fields.get("Name", identifier.removesuffix(".desktop"))
            applications.append(InstalledApplication(
                name=name,
                version="",
                source=source,
                identifier=identifier,
                origin=executable_of(fields),
                description=fields.get("Comment", ""),
            ))
    return applications, diagnostics


class DesktopEntryProvider:
    """Inventory non-package desktop apps. Registered explicitly; read-only."""

    provider_id = "desktop-entries"
    display_name = "Launcher desktop (AppImage, Wine, Waydroid, manual)"

    def collect(self) -> ProviderResult:
        applications, diagnostics = scan_desktop_entries()
        return ProviderResult(tuple(applications), tuple(diagnostics))
