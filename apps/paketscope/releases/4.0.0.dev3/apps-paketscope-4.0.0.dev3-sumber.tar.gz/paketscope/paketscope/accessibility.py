"""Accessibility settings for PaketScope.

Design rules, enforced by tests:
- Colour is never the only signal. Every status has a text label and a symbol.
- Text on background meets WCAG 2.x contrast 4.5:1; non-text status colours meet 3:1.
- Every alert is visual and textual. The app plays no sound, so deaf users lose nothing.
- Settings are stored locally in the user's config directory. Nothing is sent anywhere.
"""
from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path

PALETTE_STANDARD = "standar"
PALETTE_COLOUR_VISION = "ramah-buta-warna"
PALETTE_HIGH_CONTRAST = "kontras-tinggi"
PALETTES = (PALETTE_STANDARD, PALETTE_COLOUR_VISION, PALETTE_HIGH_CONTRAST)

MIN_TEXT_SCALE = 1.0
MAX_TEXT_SCALE = 2.0

STATE_INSTALLED = "terpasang"
STATE_UPGRADABLE = "perlu pembaruan"
STATE_HELD = "ditahan"
STATE_UNKNOWN = "tidak diketahui"
STATES = (STATE_INSTALLED, STATE_UPGRADABLE, STATE_HELD, STATE_UNKNOWN)

# Symbols are shown with every state, so meaning does not depend on colour.
STATE_SYMBOLS = {
    STATE_INSTALLED: "✔",
    STATE_UPGRADABLE: "▲",
    STATE_HELD: "■",
    STATE_UNKNOWN: "?",
}

# Colours are checked by tests against WCAG contrast before use.
PALETTE_COLOURS: dict[str, dict[str, str]] = {
    PALETTE_STANDARD: {
        "background": "#FFFFFF", "text": "#111111",
        STATE_INSTALLED: "#2E7D32", STATE_UPGRADABLE: "#A65C00",
        STATE_HELD: "#9C3D7A", STATE_UNKNOWN: "#555555",
    },
    PALETTE_COLOUR_VISION: {
        "background": "#FFFFFF", "text": "#111111",
        STATE_INSTALLED: "#0072B2", STATE_UPGRADABLE: "#A65C00",
        STATE_HELD: "#9C3D7A", STATE_UNKNOWN: "#555555",
    },
    PALETTE_HIGH_CONTRAST: {
        "background": "#000000", "text": "#FFFFFF",
        STATE_INSTALLED: "#00FFFF", STATE_UPGRADABLE: "#FFFF00",
        STATE_HELD: "#FF66FF", STATE_UNKNOWN: "#CCCCCC",
    },
}

SETTINGS_FILE_NAME = "accessibility.json"


def _linear(channel: int) -> float:
    value = channel / 255
    return value / 12.92 if value <= 0.03928 else ((value + 0.055) / 1.055) ** 2.4


def relative_luminance(hex_colour: str) -> float:
    red, green, blue = (int(hex_colour[i:i + 2], 16) for i in (1, 3, 5))
    return 0.2126 * _linear(red) + 0.7152 * _linear(green) + 0.0722 * _linear(blue)


def contrast_ratio(first: str, second: str) -> float:
    light, dark = sorted((relative_luminance(first), relative_luminance(second)), reverse=True)
    return (light + 0.05) / (dark + 0.05)


@dataclass(frozen=True, slots=True)
class AccessibilitySettings:
    palette: str = PALETTE_STANDARD
    text_scale: float = 1.0
    reduce_motion: bool = False
    keyboard_hints: bool = True
    onboarding_completed: bool = False
    onboarding_skipped: bool = False
    extra: dict = field(default_factory=dict)

    def normalized(self) -> AccessibilitySettings:
        palette = self.palette if self.palette in PALETTES else PALETTE_STANDARD
        scale = min(MAX_TEXT_SCALE, max(MIN_TEXT_SCALE, float(self.text_scale)))
        return AccessibilitySettings(
            palette=palette,
            text_scale=round(scale, 2),
            reduce_motion=bool(self.reduce_motion),
            keyboard_hints=bool(self.keyboard_hints),
            onboarding_completed=bool(self.onboarding_completed),
            onboarding_skipped=bool(self.onboarding_skipped),
        )


def state_label(state: str) -> str:
    """Text plus symbol. This is what a colour-blind or screen-reader user reads."""
    symbol = STATE_SYMBOLS.get(state, STATE_SYMBOLS[STATE_UNKNOWN])
    label = state if state in STATES else STATE_UNKNOWN
    return f"{symbol} {label}"


def palette_for(settings: AccessibilitySettings) -> dict[str, str]:
    return dict(PALETTE_COLOURS[settings.normalized().palette])


def default_settings_path() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return Path(base) / "paketscope" / SETTINGS_FILE_NAME


def load_settings(path: Path | None = None) -> AccessibilitySettings:
    target = path or default_settings_path()
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return AccessibilitySettings()
    if not isinstance(data, dict):
        return AccessibilitySettings()
    known = {key: data[key] for key in asdict(AccessibilitySettings()) if key in data and key != "extra"}
    try:
        return AccessibilitySettings(**known).normalized()
    except (TypeError, ValueError):
        return AccessibilitySettings()


def save_settings(settings: AccessibilitySettings, path: Path | None = None) -> None:
    target = path or default_settings_path()
    payload = asdict(settings.normalized())
    payload.pop("extra", None)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
