"""First-run tutorial dialog. It explains, offers accessibility choices, and can be skipped.

Every step has a Lewati (skip) button. Nothing here grants a permission or changes the
system. The choices written at the end are only display preferences, stored locally.
"""
from __future__ import annotations

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from .. import accessibility as A
from .. import onboarding as O

PALETTE_LABELS = {
    A.PALETTE_STANDARD: "Standar",
    A.PALETTE_COLOUR_VISION: "Ramah buta warna (biru dan oranye)",
    A.PALETTE_HIGH_CONTRAST: "Kontras tinggi (hitam dan kuning)",
}
BASE_POINT_SIZE = 10.0


def scaled_point_size(scale: float, base: float = BASE_POINT_SIZE) -> float:
    """Text size for a chosen scale, clamped to the supported range. Pure, so it is testable."""
    bounded = min(A.MAX_TEXT_SCALE, max(A.MIN_TEXT_SCALE, float(scale)))
    return round(base * bounded, 2)


class OnboardingDialog(QDialog):
    def __init__(self, settings: A.AccessibilitySettings, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Selamat datang di PaketScope")
        self.setModal(True)
        self._settings = settings.normalized()
        self._index = 0

        self._title = QLabel()
        self._title.setWordWrap(True)
        self._title.setAccessibleName("Judul langkah tutorial")
        self._body = QLabel()
        self._body.setWordWrap(True)
        self._body.setAccessibleName("Isi langkah tutorial")
        self._progress = QLabel()
        self._progress.setAccessibleName("Posisi langkah")

        self._form = QFormLayout()
        self._palette = QComboBox()
        self._palette.setAccessibleName("Palet warna")
        for key in A.PALETTES:
            self._palette.addItem(PALETTE_LABELS[key], key)
        self._palette.setCurrentIndex(A.PALETTES.index(self._settings.palette))
        self._scale = QDoubleSpinBox()
        self._scale.setAccessibleName("Ukuran teks")
        self._scale.setRange(A.MIN_TEXT_SCALE, A.MAX_TEXT_SCALE)
        self._scale.setSingleStep(0.1)
        self._scale.setValue(self._settings.text_scale)
        self._motion = QCheckBox("Kurangi animasi")
        self._motion.setAccessibleName("Kurangi animasi")
        self._motion.setChecked(self._settings.reduce_motion)
        self._form.addRow("Palet warna", self._palette)
        self._form.addRow("Ukuran teks", self._scale)
        self._form.addRow("", self._motion)
        self._options = QWidget()
        self._options.setLayout(self._form)

        self._skip = QPushButton("Lewati tutorial")
        self._skip.setAccessibleName("Lewati tutorial")
        self._back = QPushButton("Kembali")
        self._back.setAccessibleName("Kembali ke langkah sebelumnya")
        self._next = QPushButton("Berikutnya")
        self._next.setAccessibleName("Langkah berikutnya")
        self._skip.clicked.connect(self._on_skip)
        self._back.clicked.connect(self._on_back)
        self._next.clicked.connect(self._on_next)

        buttons = QHBoxLayout()
        buttons.addWidget(self._skip)
        buttons.addStretch(1)
        buttons.addWidget(self._back)
        buttons.addWidget(self._next)

        layout = QVBoxLayout(self)
        layout.addWidget(self._title)
        layout.addWidget(self._body)
        layout.addWidget(self._options)
        layout.addWidget(self._progress)
        layout.addLayout(buttons)
        self.setMinimumWidth(480)
        self._render()

    def _render(self) -> None:
        step = O.step_at(self._index)
        self._title.setText(f"<b>{step.title}</b>")
        self._body.setText(step.body)
        self._progress.setText(f"Langkah {self._index + 1} dari {len(O.STEPS)}")
        self._options.setVisible(step.key == "aksesibilitas")
        self._back.setEnabled(self._index > 0)
        self._next.setText("Selesai" if O.is_last(self._index) else "Berikutnya")

    def _collect(self) -> A.AccessibilitySettings:
        return A.AccessibilitySettings(
            palette=self._palette.currentData() or A.PALETTE_STANDARD,
            text_scale=self._scale.value(),
            reduce_motion=self._motion.isChecked(),
            keyboard_hints=self._settings.keyboard_hints,
            onboarding_completed=False,
            onboarding_skipped=False,
        ).normalized()

    def _on_skip(self) -> None:
        self.result_settings = O.skip(self._collect())
        self.accept()

    def _on_back(self) -> None:
        self._index = O.previous_index(self._index)
        self._render()

    def _on_next(self) -> None:
        if O.is_last(self._index):
            self.result_settings = O.finish(self._collect())
            self.accept()
            return
        self._index = O.next_index(self._index)
        self._render()

    def current_step_key(self) -> str:
        return O.step_at(self._index).key

    def go_to(self, index: int) -> None:
        self._index = max(0, min(index, len(O.STEPS) - 1))
        self._render()
