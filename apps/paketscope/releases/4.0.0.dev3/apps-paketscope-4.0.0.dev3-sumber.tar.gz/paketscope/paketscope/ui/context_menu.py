"""Right-click menu definition for an application row.

Kept free of Qt so the availability rules can be tested. The main window maps each key
to an existing action. Removal never bypasses the preview and confirmation flow.
"""
from __future__ import annotations

from dataclasses import dataclass

APT_SOURCE = "APT / dpkg"
NON_APT_REASON = "Hanya tersedia untuk paket APT/dpkg. Aplikasi lain tetap bisa diinspeksi."


@dataclass(frozen=True, slots=True)
class MenuItem:
    key: str
    label: str
    enabled: bool
    reason: str = ""


def application_menu_items(source: str) -> tuple[MenuItem, ...]:
    inspect = MenuItem("inspect", "Inspeksi detail…", True)
    if source == APT_SOURCE:
        return (
            inspect,
            MenuItem("remove", "Copot paket…", True),
            MenuItem("purge", "Copot beserta konfigurasi (purge)…", True),
        )
    return (
        inspect,
        MenuItem("remove", "Copot paket…", False, NON_APT_REASON),
        MenuItem("purge", "Copot beserta konfigurasi (purge)…", False, NON_APT_REASON),
    )
