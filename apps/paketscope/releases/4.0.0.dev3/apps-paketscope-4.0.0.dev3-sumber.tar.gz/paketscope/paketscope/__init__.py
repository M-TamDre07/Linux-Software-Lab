"""PaketScope desktop application."""

__version__ = "4.0.0.dev3"
