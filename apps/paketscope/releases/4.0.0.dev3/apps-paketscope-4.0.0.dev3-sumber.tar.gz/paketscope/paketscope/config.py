"""Versioned configuration for PaketScope.

Rules:
- The file has a schema_version. Older files are migrated, unknown newer versions are
  not overwritten.
- Every value is validated against its type and range. An invalid value falls back to
  its default and is reported, never silently accepted.
- Writes are atomic: a temporary file in the same folder is written, then renamed. A crash
  never leaves a half-written file.
- A file that cannot be parsed is moved aside to *.corrupt-<timestamp> so the user can
  inspect it. It is never deleted.
- Preferences only. Nothing here is sent anywhere, and no device identifier is stored.
"""
from __future__ import annotations

import json
import os
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

SCHEMA_VERSION = 2
CONFIG_FILE_NAME = "config.json"


def default_settings_file() -> Path:
    """User config file. Local only; nothing is sent anywhere."""
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return Path(base) / "paketscope" / CONFIG_FILE_NAME

# key: (default, type, allowed values or None)
SCHEMA: dict[str, tuple[Any, type, tuple | None]] = {
    "update_check_enabled": (True, bool, None),
    "malware_scan_enabled": (False, bool, None),
    "scan_timeout_seconds": (60, int, None),
    "integrity_check_on_start": (True, bool, None),
    "log_retention_days": (30, int, None),
    "autopilot_enabled": (False, bool, None),
    "autopilot_interval_hours": (24, int, None),
}
INT_RANGES = {"scan_timeout_seconds": (5, 600), "log_retention_days": (1, 365), "autopilot_interval_hours": (1, 168)}


@dataclass(frozen=True, slots=True)
class ConfigLoadResult:
    values: dict[str, Any]
    warnings: tuple[str, ...] = ()
    quarantined: str = ""
    migrated_from: int = 0


def default_values() -> dict[str, Any]:
    return {key: default for key, (default, _kind, _allowed) in SCHEMA.items()}


def _validate(key: str, value: Any) -> tuple[Any, str]:
    default, kind, allowed = SCHEMA[key]
    if kind is bool:
        if isinstance(value, bool):
            return value, ""
        return default, f"{key}: harus true atau false; memakai default."
    if kind is int:
        if isinstance(value, bool) or not isinstance(value, int):
            return default, f"{key}: harus bilangan bulat; memakai default."
        low, high = INT_RANGES.get(key, (value, value))
        if not low <= value <= high:
            return default, f"{key}: di luar rentang {low}-{high}; memakai default."
        return value, ""
    if allowed is not None and value not in allowed:
        return default, f"{key}: nilai tidak dikenal; memakai default."
    return value, ""


def _migrate(data: dict[str, Any], version: int) -> dict[str, Any]:
    """Version 1 had no schema field and kept only update_check_enabled. Add the new keys."""
    if version < 2:
        data.setdefault("malware_scan_enabled", False)
        data.setdefault("scan_timeout_seconds", 60)
        data.setdefault("integrity_check_on_start", True)
        data.setdefault("log_retention_days", 30)
    return data


def load_config(path: Path) -> ConfigLoadResult:
    values = default_values()
    if not path.exists():
        return ConfigLoadResult(values=values)
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise TypeError("bukan objek JSON")
    except (OSError, ValueError, TypeError) as exc:
        moved = path.with_name(f"{path.name}.corrupt-{int(time.time())}")
        try:
            path.rename(moved)
            quarantined = str(moved)
        except OSError:
            quarantined = ""
        return ConfigLoadResult(
            values=values,
            warnings=(f"Berkas pengaturan tidak terbaca ({exc.__class__.__name__}); memakai default.",),
            quarantined=quarantined,
        )
    version = raw.get("schema_version", 1)
    if not isinstance(version, int) or version > SCHEMA_VERSION:
        return ConfigLoadResult(
            values=values,
            warnings=("Berkas pengaturan berasal dari versi yang lebih baru; tidak ditimpa.",),
        )
    raw = _migrate(raw, version)
    warnings: list[str] = []
    for key in SCHEMA:
        if key in raw:
            values[key], note = _validate(key, raw[key])
            if note:
                warnings.append(note)
    return ConfigLoadResult(
        values=values,
        warnings=tuple(warnings),
        migrated_from=version if version < SCHEMA_VERSION else 0,
    )


def save_config(path: Path, values: dict[str, Any]) -> None:
    """Atomic write: temporary file in the same directory, flushed, then renamed over the target."""
    clean = {}
    for key in SCHEMA:
        clean[key], _note = _validate(key, values.get(key, SCHEMA[key][0]))
    payload = {"schema_version": SCHEMA_VERSION, **clean}
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, temp_name = tempfile.mkstemp(prefix=".config-", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(handle, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except OSError:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def update_value(path: Path, key: str, value: Any) -> dict[str, Any]:
    """Change one value safely: load, validate, save atomically."""
    if key not in SCHEMA:
        raise KeyError(f"Pengaturan tidak dikenal: {key}")
    current = load_config(path).values
    current[key], _note = _validate(key, value)
    save_config(path, current)
    return current
