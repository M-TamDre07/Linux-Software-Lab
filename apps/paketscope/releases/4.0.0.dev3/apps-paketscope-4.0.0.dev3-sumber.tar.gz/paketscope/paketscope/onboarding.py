"""First-run tutorial rules.

The tutorial explains. It never grants a permission and never changes the system.
Any step can be skipped. Choosing to skip, or finishing, is remembered locally so the
tutorial does not return on the next start. It can be replayed from the Help menu.
"""
from __future__ import annotations

from dataclasses import dataclass, replace

from .accessibility import AccessibilitySettings


@dataclass(frozen=True, slots=True)
class TutorialStep:
    key: str
    title: str
    body: str


STEPS: tuple[TutorialStep, ...] = (
    TutorialStep(
        "selamat-datang",
        "Selamat datang di PaketScope",
        "PaketScope menampilkan aplikasi dan paket yang terpasang di komputer Anda, lengkap dengan "
        "asal dan keterangannya. Anda bisa melewati tutorial ini kapan saja.",
    ),
    TutorialStep(
        "apa-yang-dilakukan",
        "Apa yang dilakukan PaketScope",
        "Inventori dan detail hanya membaca informasi di komputer Anda. PaketScope tidak mengirim "
        "data apa pun ke pengembang dan tidak memantau aplikasi lain.",
    ),
    TutorialStep(
        "keamanan",
        "Perubahan selalu ditinjau dulu",
        "Memasang, menghapus, atau mem-purge paket membutuhkan kata sandi administrator. "
        "PaketScope selalu menunjukkan rencana perubahan dan meminta konfirmasi sebelum "
        "apa pun diubah.",
    ),
    TutorialStep(
        "aksesibilitas",
        "Sesuaikan tampilan (opsional)",
        "Pilih palet warna yang ramah untuk buta warna, ukuran teks, dan kurangi animasi. "
        "Lewati langkah ini untuk memakai pengaturan standar.",
    ),
    TutorialStep(
        "selesai",
        "Siap digunakan",
        "Anda bisa membuka tutorial ini lagi dari menu Bantuan. Selamat menggunakan PaketScope.",
    ),
)


def step_at(index: int) -> TutorialStep:
    return STEPS[max(0, min(index, len(STEPS) - 1))]


def next_index(index: int) -> int:
    return min(index + 1, len(STEPS) - 1)


def previous_index(index: int) -> int:
    return max(index - 1, 0)


def is_last(index: int) -> bool:
    return index >= len(STEPS) - 1


def should_show(settings: AccessibilitySettings) -> bool:
    return not settings.onboarding_completed


def skip(settings: AccessibilitySettings) -> AccessibilitySettings:
    """Skip the whole tutorial and remember the choice."""
    return replace(settings, onboarding_completed=True, onboarding_skipped=True).normalized()


def finish(settings: AccessibilitySettings) -> AccessibilitySettings:
    """Complete the tutorial normally and remember that it was seen."""
    return replace(settings, onboarding_completed=True, onboarding_skipped=False).normalized()


def replay(settings: AccessibilitySettings) -> AccessibilitySettings:
    """Show the tutorial again, from the Help menu. Keeps the other settings."""
    return replace(settings, onboarding_completed=False, onboarding_skipped=False).normalized()
