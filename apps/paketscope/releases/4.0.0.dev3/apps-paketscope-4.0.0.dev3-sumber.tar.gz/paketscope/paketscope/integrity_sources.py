"""Integrity of where packages come from. Read-only; nothing is installed or changed.

Two checks:
- APT source audit: which repositories are configured, whether they are signed
  (signed-by), and which are forced without verification ([trusted=yes]).
- Local .deb verification: SHA-256 of a package file against a checksum the user has
  obtained from a trusted place.

A signed repository proves the index came from its key holder. It does not prove the
software inside is safe. Say so in the UI, never imply more.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from pathlib import Path

APT_SOURCES_LIST = Path("/etc/apt/sources.list")
APT_SOURCES_DIR = Path("/etc/apt/sources.list.d")
OFFICIAL_HOST_MARKERS = (
    "deb.debian.org", "ftp.debian.org", "security.debian.org",
    "archive.ubuntu.com", "security.ubuntu.com", "packages.linuxmint.com", "http.kali.org",
)
MAX_SOURCE_BYTES = 64 * 1024

SEVERITY_HIGH = "tinggi"
SEVERITY_MEDIUM = "sedang"
SEVERITY_INFO = "info"


@dataclass(frozen=True, slots=True)
class AptSource:
    origin_file: str
    uri: str
    suite: str
    components: tuple[str, ...]
    signed_by: str
    trusted_forced: bool
    official: bool


@dataclass(frozen=True, slots=True)
class SourceFinding:
    severity: str
    title: str
    detail: str


def _official(uri: str) -> bool:
    lowered = uri.casefold()
    return any(marker in lowered for marker in OFFICIAL_HOST_MARKERS)


def parse_one_line(text: str, origin_file: str) -> list[AptSource]:
    """Parse classic `deb [options] uri suite components` lines."""
    sources: list[AptSource] = []
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line or not line.startswith(("deb ", "deb-src ")):
            continue
        options: dict[str, str] = {}
        if "[" in line and "]" in line:
            head, rest = line.split("[", 1)
            opts, tail = rest.split("]", 1)
            for item in opts.split():
                if "=" in item:
                    key, value = item.split("=", 1)
                    options[key.strip().casefold()] = value.strip()
            line = head.strip() + " " + tail.strip()
        parts = line.split()
        if len(parts) < 3:
            continue
        uri, suite = parts[1], parts[2]
        components = tuple(parts[3:])
        sources.append(AptSource(
            origin_file=origin_file,
            uri=uri,
            suite=suite,
            components=components,
            signed_by=options.get("signed-by", ""),
            trusted_forced=options.get("trusted", "").casefold() == "yes",
            official=_official(uri),
        ))
    return sources


def parse_deb822(text: str, origin_file: str) -> list[AptSource]:
    """Parse .sources (deb822) stanzas. Each stanza may list several URIs and suites."""
    sources: list[AptSource] = []
    for stanza in re.split(r"\n\s*\n", text):
        fields: dict[str, str] = {}
        for line in stanza.splitlines():
            if ":" in line and not line.startswith((" ", "\t")):
                key, value = line.split(":", 1)
                fields[key.strip().casefold()] = value.strip()
        if fields.get("enabled", "yes").casefold() == "no":
            continue
        types = fields.get("types", "")
        if "deb" not in types.split():
            continue
        uris = fields.get("uris", "").split()
        suites = fields.get("suites", "").split()
        components = tuple(fields.get("components", "").split())
        signed_by = fields.get("signed-by", "")
        trusted_forced = fields.get("trusted", "").casefold() == "yes"
        for uri in uris:
            for suite in suites or [""]:
                sources.append(AptSource(
                    origin_file=origin_file,
                    uri=uri,
                    suite=suite,
                    components=components,
                    signed_by=signed_by,
                    trusted_forced=trusted_forced,
                    official=_official(uri),
                ))
    return sources


def read_configured_sources(
    list_file: Path = APT_SOURCES_LIST,
    sources_dir: Path = APT_SOURCES_DIR,
) -> tuple[list[AptSource], list[str]]:
    sources: list[AptSource] = []
    diagnostics: list[str] = []
    candidates: list[Path] = []
    if list_file.is_file():
        candidates.append(list_file)
    try:
        candidates.extend(sorted(sources_dir.iterdir()))
    except OSError:
        diagnostics.append("Folder sumber APT tidak dapat dibaca.")
    for path in candidates:
        if not path.is_file():
            continue
        try:
            if path.stat().st_size > MAX_SOURCE_BYTES:
                diagnostics.append(f"{path.name} dilewati karena terlalu besar.")
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            diagnostics.append(f"{path.name} tidak dapat dibaca.")
            continue
        if path.suffix == ".sources":
            sources.extend(parse_deb822(text, path.name))
        else:
            sources.extend(parse_one_line(text, path.name))
    return sources, diagnostics


def audit_sources(sources: list[AptSource]) -> list[SourceFinding]:
    findings: list[SourceFinding] = []
    for source in sources:
        label = f"{source.uri} ({source.suite or 'tanpa suite'}) dari {source.origin_file}"
        if source.trusted_forced:
            findings.append(SourceFinding(
                SEVERITY_HIGH, "Sumber tanpa verifikasi tanda tangan",
                f"{label} memakai trusted=yes. Paket dari sumber ini tidak diverifikasi. Hapus opsi itu "
                "dan pasang kunci sumber dengan signed-by.",
            ))
        elif not source.signed_by and not source.official:
            findings.append(SourceFinding(
                SEVERITY_MEDIUM, "Sumber pihak ketiga tanpa signed-by",
                f"{label} tidak menyatakan kunci penandatangan (signed-by). Verifikasi kunci repositori itu "
                "secara manual sebelum memasang paket darinya.",
            ))
    if not findings and sources:
        findings.append(SourceFinding(
            SEVERITY_INFO, "Semua sumber terverifikasi",
            "Tidak ada sumber yang dipaksa tanpa verifikasi. Sumber resmi memakai kunci distribusi.",
        ))
    order = {SEVERITY_HIGH: 0, SEVERITY_MEDIUM: 1, SEVERITY_INFO: 2}
    return sorted(findings, key=lambda item: order[item.severity])


def sha256_of_file(path: Path, chunk: int = 1 << 20) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(chunk), b""):
            digest.update(block)
    return digest.hexdigest()


def verify_deb_file(path: Path, expected_sha256: str) -> tuple[bool, str]:
    """Compare a local .deb with a checksum the user obtained from a trusted place."""
    expected = expected_sha256.strip().casefold()
    if not re.fullmatch(r"[0-9a-f]{64}", expected):
        return False, "Checksum yang diharapkan harus 64 karakter heksadesimal."
    try:
        actual = sha256_of_file(path)
    except OSError as exc:
        return False, f"Berkas tidak dapat dibaca: {exc.strerror or exc}."
    if actual == expected:
        return True, "Checksum SHA-256 cocok dengan nilai yang diharapkan."
    return False, "Checksum SHA-256 TIDAK cocok. Jangan pasang berkas ini."
