"""Detect where PaketScope runs: a Flatpak sandbox, a container, or the host.

Reads marker files only. The result decides which features can work. Inside a Flatpak
sandbox the APT helper and host package operations are not available, and the app says
so instead of failing silently.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

FLATPAK_MARKER = Path("/.flatpak-info")
CONTAINER_MARKERS = (Path("/run/.containerenv"), Path("/.dockerenv"))


@dataclass(frozen=True, slots=True)
class RuntimeEnvironment:
    kind: str  # "host" | "flatpak" | "container"
    apt_operations: bool
    inventory_apt: bool
    note: str


def detect(flatpak_marker: Path = FLATPAK_MARKER, container_markers=CONTAINER_MARKERS) -> RuntimeEnvironment:
    if flatpak_marker.exists():
        return RuntimeEnvironment(
            kind="flatpak",
            apt_operations=False,
            inventory_apt=False,
            note=("Berjalan di dalam Flatpak. Operasi APT dan helper root tidak tersedia; "
                  "inventori Flatpak dan launcher tetap bisa dilihat."),
        )
    if any(marker.exists() for marker in container_markers):
        return RuntimeEnvironment(
            kind="container",
            apt_operations=True,
            inventory_apt=True,
            note="Berjalan di dalam kontainer. Pastikan paket dan helper terpasang di kontainer itu.",
        )
    return RuntimeEnvironment(kind="host", apt_operations=True, inventory_apt=True, note="")
