"""User-triggered update checks; these functions never install anything."""
from __future__ import annotations

from dataclasses import dataclass

from .commands import CommandTimedOut, CommandUnavailable, run_command


@dataclass(frozen=True, slots=True)
class UpdateCheckResult:
    apt_updates: tuple[str, ...]
    flatpak_updates: tuple[str, ...]
    diagnostics: tuple[str, ...]


def check_updates() -> UpdateCheckResult:
    apt_updates = []
    flatpak_updates = []
    diagnostics = []

    try:
        result = run_command(["apt", "list", "--upgradable"], timeout=20.0)
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                line = line.strip()
                if line and not line.casefold().startswith("listing...") and "/" in line:
                    apt_updates.append(line.split("/", 1)[0])
        else:
            diagnostics.append("Pemeriksaan APT gagal (kode " + str(result.returncode) + ").")
    except (CommandUnavailable, CommandTimedOut) as exc:
        diagnostics.append("APT: " + str(exc))

    try:
        # This may contact configured Flatpak remotes; only run after an explicit user action.
        result = run_command([
            "flatpak", "remote-ls", "--updates", "--app", "--columns=application,name",
        ], timeout=45.0)
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                columns = line.split("\t")
                if columns and columns[0].strip():
                    flatpak_updates.append(columns[0].strip())
        else:
            details = result.stderr.strip().splitlines()
            diagnostics.append("Pemeriksaan Flatpak tidak selesai: " + (details[-1][:180] if details else "perintah gagal."))
    except (CommandUnavailable, CommandTimedOut) as exc:
        diagnostics.append("Flatpak: " + str(exc))

    return UpdateCheckResult(
        apt_updates=tuple(dict.fromkeys(apt_updates)),
        flatpak_updates=tuple(dict.fromkeys(flatpak_updates)),
        diagnostics=tuple(diagnostics),
    )


@dataclass(frozen=True, slots=True)
class SelfUpdateStatus:
    installed: str
    candidate: str
    state: str  # "terbaru" | "ada pembaruan" | "tidak diketahui"
    detail: str


def self_update_status(package: str = "paketscope") -> SelfUpdateStatus:
    """Tell the user whether a newer PaketScope is in their APT index. Read-only, no root, no network.

    It only reads the local APT index that the system already trusts. Nothing is sent anywhere,
    and no device identifier is used.
    """
    try:
        installed_result = run_command(["dpkg-query", "-W", "-f=${Version}", package], timeout=10.0)
        policy_result = run_command(["apt-cache", "policy", package], timeout=20.0)
    except (CommandUnavailable, CommandTimedOut) as exc:
        return SelfUpdateStatus("", "", "tidak diketahui", f"Perintah tidak tersedia: {exc}")
    installed = installed_result.stdout.strip() if installed_result.returncode == 0 else ""
    candidate = ""
    for line in policy_result.stdout.splitlines():
        stripped = line.strip()
        if stripped.startswith("Candidate:"):
            candidate = stripped.split(":", 1)[1].strip()
            break
    if not installed:
        return SelfUpdateStatus("", candidate, "tidak diketahui", "PaketScope tidak terpasang dari paket Debian.")
    if not candidate or candidate == "(none)":
        return SelfUpdateStatus(installed, "", "tidak diketahui",
                                "Indeks APT lokal tidak memuat PaketScope. Jalankan pembaruan indeks dari sistem Anda.")
    newer = run_command(["dpkg", "--compare-versions", candidate, "gt", installed], timeout=10.0)
    if newer.returncode == 0:
        return SelfUpdateStatus(installed, candidate, "ada pembaruan",
                                f"Versi {candidate} tersedia. Pasang lewat APT; versi lama tidak dihapus.")
    return SelfUpdateStatus(installed, candidate, "terbaru", "PaketScope sudah versi terbaru di indeks lokal.")
