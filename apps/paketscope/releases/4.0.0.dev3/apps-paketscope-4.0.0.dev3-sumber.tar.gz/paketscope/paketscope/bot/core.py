"""Assistant core: plans, checks every step against the fixed policy, runs allowed tools, and
writes a local audit line for each decision. Nothing leaves the machine.

Trust boundaries enforced here:
- A planner's output is untrusted. Unknown tool names and bad arguments are refused.
- A tool's output is data. It is returned to the user and never changes a policy decision.
- The registry and the policy table are constants. The core has no method that edits them.
"""
from __future__ import annotations

import json
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .policy import Decision, Risk, decide
from .tools import TOOLS, Tool, ToolArgumentError

AUDIT_LINE_LIMIT = 500
MAX_OUTPUT_CHARS = 4000


@dataclass(frozen=True, slots=True)
class PlannedCall:
    tool: str
    arguments: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class StepResult:
    tool: str
    decision: str
    executed: bool
    output: str
    reason: str


@dataclass(frozen=True, slots=True)
class Reply:
    text: str
    steps: tuple[StepResult, ...]


class Assistant:
    def __init__(
        self,
        planner,
        audit_path: Path,
        confirm: Callable[[str, dict[str, Any]], bool] | None = None,
        registry: dict[str, Tool] | None = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self._planner = planner
        self._audit_path = audit_path
        self._confirm = confirm or (lambda _tool, _args: False)
        self._registry = TOOLS if registry is None else registry
        self._clock = clock

    def handle(self, message: str, *, autopilot: bool = False, planned: list[PlannedCall] | None = None) -> Reply:
        calls = planned if planned is not None else self._planner.plan(message)
        steps = tuple(self._step(call, autopilot=autopilot) for call in calls)
        if not steps:
            text = "Saya belum menemukan alat yang cocok untuk permintaan ini. Coba tulis lebih spesifik."
        else:
            text = "\n".join(f"{step.tool}: {step.output if step.executed else step.reason}" for step in steps)
        return Reply(text=text, steps=steps)

    def _step(self, call: PlannedCall, *, autopilot: bool) -> StepResult:
        tool = self._registry.get(call.tool)
        if tool is None:
            self._audit(call.tool, Risk.READ, "tolak", False)
            return StepResult(call.tool, Decision.DENY.value, False, "", "Alat tidak dikenal.")
        if autopilot and not tool.autopilot_ok:
            self._audit(tool.name, tool.risk, "lewati-autopilot", False)
            return StepResult(tool.name, Decision.DENY.value, False, "", "Tidak boleh dijalankan otomatis.")
        try:
            arguments = tool.validate(call.arguments)
        except ToolArgumentError as exc:
            self._audit(tool.name, tool.risk, "argumen-salah", False)
            return StepResult(tool.name, Decision.DENY.value, False, "", str(exc))

        verdict = decide(tool.risk, autopilot=autopilot)
        if verdict.decision is Decision.CONFIRM:
            approved = bool(self._confirm(tool.name, arguments))
            verdict = decide(tool.risk, autopilot=autopilot, user_confirmed=approved)
        if verdict.decision is not Decision.ALLOW:
            self._audit(tool.name, tool.risk, verdict.decision.value, False)
            return StepResult(tool.name, verdict.decision.value, False, "", verdict.reason)

        try:
            raw = tool.run(**arguments)
        except Exception as exc:  # noqa: BLE001 - containment: any tool failure is reported, never fatal
            self._audit(tool.name, tool.risk, "galat", False)
            return StepResult(tool.name, Decision.ALLOW.value, False, "", f"Galat: {type(exc).__name__}.")
        self._audit(tool.name, tool.risk, Decision.ALLOW.value, True)
        return StepResult(tool.name, Decision.ALLOW.value, True, _as_text(raw), "")

    def _audit(self, tool: str, risk: Risk, outcome: str, executed: bool) -> None:
        """One line per decision. Outputs and arguments are not stored."""
        record = {"waktu": int(self._clock()), "alat": tool, "risiko": risk.value,
                  "keputusan": outcome, "dijalankan": executed}
        try:
            self._audit_path.parent.mkdir(parents=True, exist_ok=True)
            lines = []
            if self._audit_path.exists():
                lines = self._audit_path.read_text(encoding="utf-8").splitlines()[-(AUDIT_LINE_LIMIT - 1):]
            lines.append(json.dumps(record, ensure_ascii=False))
            self._audit_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        except OSError:
            pass


def _as_text(raw: Any) -> str:
    try:
        text = json.dumps(raw, ensure_ascii=False, indent=2, default=str)
    except (TypeError, ValueError):
        text = str(raw)
    return text[:MAX_OUTPUT_CHARS]
