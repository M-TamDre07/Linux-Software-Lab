"""Rules-based planner for the first version of the assistant.

It turns a message into tool calls with fixed keyword rules. It never calls anything itself.
A future language-model planner would replace only this class. Its output would still pass
through the same validation and policy in core.py.
"""
from __future__ import annotations

from .core import PlannedCall

RULES: tuple[tuple[tuple[str, ...], str], ...] = (
    (("lingkungan", "flatpak", "kontainer", "container"), "status_runtime"),
    (("sumber", "repositori", "signed", "kunci"), "audit_sumber_apt"),
    (("pembaruan", "update", "versi terbaru"), "cek_pembaruan"),
    (("pengaturan", "konfigurasi", "setting"), "baca_pengaturan"),
    (("pasang paket", "install paket"), "pasang_paket"),
    (("copot paket", "hapus paket", "uninstall"), "copot_paket"),
)


class RulesPlanner:
    def plan(self, message: str) -> list[PlannedCall]:
        lowered = message.casefold()
        calls: list[PlannedCall] = []
        for keywords, tool in RULES:
            if any(word in lowered for word in keywords):
                if tool in ("pasang_paket", "copot_paket"):
                    calls.append(PlannedCall(tool, {"nama": "(diminta pengguna)"}))
                else:
                    calls.append(PlannedCall(tool, {}))
        return calls
