"""Local assistant for PaketScope: a rules-based planner, a fixed policy, a tool registry,
local audit, and optional read-only autopilot. No network access in this package."""
