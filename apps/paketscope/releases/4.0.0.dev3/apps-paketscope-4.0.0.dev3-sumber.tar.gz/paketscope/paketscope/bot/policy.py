"""Static policy for the local assistant bot.

The table below is the only source of permission. It is a constant, not configuration:
no setting, no tool output, and no model output can widen it. A bot that could grant
itself permissions would defeat every other safeguard.

Risk classes:
- READ: reads local information only. Allowed in chat and in autopilot.
- LOCAL_CHANGE: changes a PaketScope preference. Needs the user's confirmation every time.
  Never run by autopilot.
- EXTERNAL: downloads or installs third-party material. Needs a verified checksum and the
  user's explicit approval. Never run by autopilot.
- PRIVILEGED: changes the system (install, remove, purge, root). Denied to the bot entirely.
  Those actions stay in the normal interface with human confirmation.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Risk(str, Enum):
    READ = "baca"
    LOCAL_CHANGE = "ubah-pengaturan"
    EXTERNAL = "eksternal"
    PRIVILEGED = "istimewa"


class Decision(str, Enum):
    ALLOW = "izinkan"
    CONFIRM = "minta-konfirmasi"
    DENY = "tolak"


# Fixed table: risk class -> (in chat, in autopilot).
_RULES: dict[Risk, tuple[Decision, Decision]] = {
    Risk.READ: (Decision.ALLOW, Decision.ALLOW),
    Risk.LOCAL_CHANGE: (Decision.CONFIRM, Decision.DENY),
    Risk.EXTERNAL: (Decision.CONFIRM, Decision.DENY),
    Risk.PRIVILEGED: (Decision.DENY, Decision.DENY),
}


@dataclass(frozen=True, slots=True)
class PolicyDecision:
    decision: Decision
    reason: str


def decide(risk: Risk, *, autopilot: bool, user_confirmed: bool = False, checksum_verified: bool = False) -> PolicyDecision:
    """Return what the bot may do. Confirmation or verification can only satisfy a CONFIRM."""
    chat_rule, autopilot_rule = _RULES[risk]
    rule = autopilot_rule if autopilot else chat_rule
    if rule is Decision.ALLOW:
        return PolicyDecision(Decision.ALLOW, "Pembacaan lokal, boleh dijalankan.")
    if rule is Decision.DENY:
        if risk is Risk.PRIVILEGED:
            return PolicyDecision(Decision.DENY, "Aksi sistem tidak bisa dijalankan oleh bot. Gunakan antarmuka dengan konfirmasi.")
        if autopilot:
            return PolicyDecision(Decision.DENY, "Autopilot hanya boleh membaca dan merekomendasikan.")
        return PolicyDecision(Decision.DENY, "Ditolak.")
    # CONFIRM
    if risk is Risk.EXTERNAL and not checksum_verified:
        return PolicyDecision(Decision.DENY, "Sumber eksternal tanpa checksum terverifikasi tidak boleh dipakai.")
    if user_confirmed:
        return PolicyDecision(Decision.ALLOW, "Disetujui pengguna untuk aksi ini.")
    return PolicyDecision(Decision.CONFIRM, "Perlu persetujuan pengguna untuk setiap aksi seperti ini.")
