# Kontainer untuk asisten lokal

Status: **spesifikasi, belum dijalankan.** Tidak ada kontainer yang dibuat di sistem pengembangan.

Tujuan: memisahkan asisten dan model lokal dari sistem utama dan dari jaringan.

- `bot-sandbox.json`: kebijakan kontainer. Tes memastikan tidak ada jaringan keluar, tidak ada
  capability, tidak ada akses ke jalur host yang sensitif, dan model hanya dibaca.
- `paketscope-bot.nspawn`: contoh untuk systemd-nspawn. Tidak dijalankan oleh aplikasi.

Yang belum ada: pembuatan rootfs, pengujian pemasangan model pihak ketiga di dalam kontainer,
dan integrasi dengan sandbox Flatpak. Semuanya membutuhkan persetujuan pemilik per langkah.
