"""Autopilot: periodic read-only checks that produce recommendations. It never changes anything.

It runs only tools marked autopilot_ok, and only when the configured interval has passed.
Its output is a short list of recommendations stored locally for the user to read.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .core import Assistant, PlannedCall
from .tools import TOOLS

RECOMMENDATIONS_LIMIT = 50
MAX_TEXT = 300


@dataclass(frozen=True, slots=True)
class AutopilotRun:
    ran: bool
    reason: str
    recommendations: tuple[str, ...]


def _due(state: dict[str, Any], now: float, interval_hours: int) -> bool:
    last = state.get("terakhir", 0)
    return now - float(last) >= interval_hours * 3600


def run_autopilot(assistant: Assistant, *, enabled: bool, interval_hours: int, state_path: Path, now: float) -> AutopilotRun:
    if not enabled:
        return AutopilotRun(False, "Autopilot nonaktif. Aktifkan di pengaturan jika Anda mau.", ())
    state = _read_state(state_path)
    if not _due(state, now, interval_hours):
        return AutopilotRun(False, "Belum waktunya pengecekan berikutnya.", tuple(state.get("rekomendasi", [])))
    reply = assistant.handle("", autopilot=True, planned=_read_only_plan())
    recommendations = _recommendations(reply)
    _write_state(state_path, {"terakhir": now, "rekomendasi": recommendations[-RECOMMENDATIONS_LIMIT:]})
    return AutopilotRun(True, "Pengecekan otomatis selesai.", tuple(recommendations))


def _read_only_plan():
    return [PlannedCall(name) for name, tool in TOOLS.items() if tool.autopilot_ok]


def _recommendations(reply) -> list[str]:
    out: list[str] = []
    for step in reply.steps:
        if not step.executed:
            continue
        lowered = step.output.casefold()
        if step.tool == "audit_sumber_apt" and '"tinggi"' in lowered:
            out.append("Ada sumber APT tanpa verifikasi tanda tangan. Tinjau di menu Sumber.")
        elif step.tool == "cek_pembaruan" and '"ada pembaruan"' in lowered:
            out.append("Pembaruan PaketScope tersedia di indeks APT lokal.")
    return [item[:MAX_TEXT] for item in out]


def _read_state(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_state(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
