"""Local model registry. A third-party model runs only when its checksum matches and the user
approved it explicitly. Nothing is downloaded here; this module only verifies local files.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from ..integrity_sources import sha256_of_file

SOURCES_ALLOWED = ("lokal", "pihak-ketiga")


@dataclass(frozen=True, slots=True)
class ModelEntry:
    name: str
    source: str
    sha256: str
    license: str
    approved_by_user: bool = False


def verify_model(path: Path, entry: ModelEntry) -> tuple[bool, str]:
    if entry.source not in SOURCES_ALLOWED:
        return False, "Sumber model tidak dikenal."
    if not entry.approved_by_user:
        return False, "Model belum disetujui pengguna."
    if not entry.license.strip():
        return False, "Lisensi model wajib dicatat."
    try:
        actual = sha256_of_file(path)
    except OSError:
        return False, "Berkas model tidak dapat dibaca."
    if actual != entry.sha256.casefold():
        return False, "Checksum model tidak cocok. Jangan jalankan model ini."
    return True, "Model terverifikasi dan disetujui."


def load_registry(path: Path) -> list[ModelEntry]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    entries: list[ModelEntry] = []
    for item in raw if isinstance(raw, list) else []:
        try:
            entries.append(ModelEntry(**{k: item[k] for k in asdict(ModelEntry("", "", "", "")) if k in item}))
        except (TypeError, KeyError):
            continue
    return entries
