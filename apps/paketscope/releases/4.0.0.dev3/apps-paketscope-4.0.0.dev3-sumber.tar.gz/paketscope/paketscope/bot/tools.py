"""Fixed tool catalogue for the local assistant. Nothing here is loaded from elsewhere."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .policy import Risk


class ToolArgumentError(ValueError):
    pass


class PrivilegedToolError(RuntimeError):
    """Raised if a privileged tool is ever reached. It must never be."""


@dataclass(frozen=True, slots=True)
class Tool:
    name: str
    risk: Risk
    description: str
    params: dict[str, type]
    run: Callable[..., Any]
    autopilot_ok: bool = False

    def validate(self, arguments: dict[str, Any]) -> dict[str, Any]:
        unknown = set(arguments) - set(self.params)
        if unknown:
            raise ToolArgumentError(f"Argumen tidak dikenal untuk {self.name}: {sorted(unknown)}")
        missing = set(self.params) - set(arguments)
        if missing:
            raise ToolArgumentError(f"Argumen wajib hilang untuk {self.name}: {sorted(missing)}")
        for key, kind in self.params.items():
            value = arguments[key]
            if kind is bool and not isinstance(value, bool):
                raise ToolArgumentError(f"{key} harus true atau false")
            if kind is int and (isinstance(value, bool) or not isinstance(value, int)):
                raise ToolArgumentError(f"{key} harus bilangan bulat")
            if kind is str and not isinstance(value, str):
                raise ToolArgumentError(f"{key} harus teks")
            if kind is Path and not isinstance(value, (str, Path)):
                raise ToolArgumentError(f"{key} harus jalur berkas")
            if kind is list and not isinstance(value, list):
                raise ToolArgumentError(f"{key} harus daftar")
        converted: dict[str, Any] = {}
        for key, value in arguments.items():
            converted[key] = Path(value) if self.params[key] is Path else value
        return converted


def _runtime_status() -> dict[str, Any]:
    from ..runtime_env import detect
    env = detect()
    return {"kind": env.kind, "apt_operations": env.apt_operations, "note": env.note}


def _audit_sources() -> dict[str, Any]:
    from ..integrity_sources import audit_sources, read_configured_sources
    sources, diagnostics = read_configured_sources()
    findings = audit_sources(sources)
    return {
        "jumlah_sumber": len(sources),
        "temuan": [{"tingkat": f.severity, "judul": f.title} for f in findings],
        "diagnostik": list(diagnostics),
    }


def _verify_deb(path: Path, sha256: str) -> dict[str, Any]:
    from ..integrity_sources import verify_deb_file
    ok, message = verify_deb_file(path, sha256)
    return {"cocok": ok, "keterangan": message}


def _self_update() -> dict[str, Any]:
    from ..updates import self_update_status
    status = self_update_status()
    return {"status": status.state, "terpasang": status.installed, "kandidat": status.candidate, "keterangan": status.detail}


def _read_config() -> dict[str, Any]:
    from ..config import default_settings_file, load_config
    result = load_config(default_settings_file())
    return {"nilai": result.values, "peringatan": list(result.warnings)}


def _change_config(key: str, value: Any) -> dict[str, Any]:
    from ..config import default_settings_file, update_value
    updated = update_value(default_settings_file(), key, value)
    return {"nilai": updated}


def _scan_files(paths: list[str]) -> dict[str, Any]:
    from ..malware_scan import scan_files
    report = scan_files([Path(str(item)) for item in paths])
    return {
        "scanner_tersedia": report.scanner_available,
        "hasil": [{"jalur": r.path, "verdict": r.verdict, "detail": r.detail} for r in report.results],
        "catatan": list(report.notes),
    }


def _privileged_denied(**_: Any) -> None:
    raise PrivilegedToolError("Aksi sistem tidak boleh dijalankan oleh bot.")


TOOLS: dict[str, Tool] = {tool.name: tool for tool in (
    Tool("status_runtime", Risk.READ, "Lihat apakah PaketScope berjalan di host, Flatpak, atau kontainer.",
         {}, _runtime_status, autopilot_ok=True),
    Tool("audit_sumber_apt", Risk.READ, "Periksa sumber APT: signed-by dan trusted=yes.",
         {}, _audit_sources, autopilot_ok=True),
    Tool("verifikasi_deb", Risk.READ, "Cocokkan checksum SHA-256 sebuah berkas .deb.",
         {"path": Path, "sha256": str}, _verify_deb),
    Tool("cek_pembaruan", Risk.READ, "Lihat apakah PaketScope punya pembaruan di indeks APT lokal.",
         {}, _self_update, autopilot_ok=True),
    Tool("baca_pengaturan", Risk.READ, "Baca pengaturan PaketScope.",
         {}, _read_config, autopilot_ok=True),
    Tool("pindai_berkas", Risk.READ, "Pindai berkas yang dipilih pengguna dengan ClamAV. Tidak dijalankan otomatis.",
         {"paths": list}, _scan_files, autopilot_ok=False),
    Tool("ubah_pengaturan", Risk.LOCAL_CHANGE, "Ubah satu pengaturan PaketScope.",
         {"key": str, "value": object}, _change_config),
    Tool("pasang_paket", Risk.PRIVILEGED, "Pasang paket sistem. Dinonaktifkan untuk bot.",
         {"nama": str}, _privileged_denied),
    Tool("copot_paket", Risk.PRIVILEGED, "Copot paket sistem. Dinonaktifkan untuk bot.",
         {"nama": str}, _privileged_denied),
)}
