"""Application entry point for PaketScope."""
from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import QTimer
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

from . import __version__
from .ui.main_window import MainWindow


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("PaketScope")
    app.setApplicationVersion(__version__)
    icon_path = Path(__file__).resolve().parent / "assets" / "paketscope.svg"
    if icon_path.is_file():
        app.setWindowIcon(QIcon(str(icon_path)))
    app.setStyle("Fusion")

    from .ui.theme import APP_QSS
    app.setStyleSheet(APP_QSS)

    from . import accessibility as acc
    from . import onboarding as onb
    from .ui.onboarding_dialog import OnboardingDialog, scaled_point_size

    settings = acc.load_settings()
    font = app.font()
    font.setPointSizeF(scaled_point_size(settings.text_scale, base=font.pointSizeF() or 10.0))
    app.setFont(font)

    if onb.should_show(settings):
        # Shown before the main window. Closing it without a choice keeps it for next start.
        dialog = OnboardingDialog(settings)
        if dialog.exec() == OnboardingDialog.DialogCode.Accepted:
            acc.save_settings(dialog.result_settings)
            settings = dialog.result_settings
            font.setPointSizeF(scaled_point_size(settings.text_scale, base=font.pointSizeF() or 10.0))
            app.setFont(font)

    window = MainWindow()
    window.show()
    QTimer.singleShot(100, window.refresh_inventory)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
