"""Intrusion and tamper detection for PaketScope.

This module only detects and refuses. It never grants privilege, never widens the
helper's scope, and never sends data anywhere. Every check is read-only.

Checks:
- Helper integrity before elevation: the helper must match the checksum dpkg recorded
  at install time, be a regular root-owned file, and not be writable by group or others.
  Otherwise elevation is refused.
- Environment injection: loader and interpreter variables that can run attacker code.
- Debugger attachment: a tracer attached to this process.
- Unexpected network sockets: this app has no network feature, so an open INET socket
  is reported. Unix sockets (display server, D-Bus) are normal and ignored.
- Self-integrity: dpkg -V on the paketscope package itself.
- Refusal burst: many refused privileged requests in a short window is reported.

Limits, stated plainly: dpkg records MD5, not a signature. This detects accidental and
naive tampering, not a determined attacker who also controls the root account.
"""
from __future__ import annotations

import hashlib
import json
import os
import stat
import time
from dataclasses import dataclass
from pathlib import Path

HELPER_RELATIVE_PATH = "usr/libexec/paketscope/paketscope-apt-helper"
MD5SUMS_PATH = Path("/var/lib/dpkg/info/paketscope.md5sums")
SUSPICIOUS_ENVIRONMENT = (
    "LD_PRELOAD", "LD_AUDIT", "LD_LIBRARY_PATH", "PYTHONSTARTUP", "PYTHONINSPECT",
)
REFUSAL_WINDOW_SECONDS = 600
REFUSAL_BURST_THRESHOLD = 5
REFUSAL_LOG_LIMIT = 200

SEVERITY_HIGH = "tinggi"
SEVERITY_MEDIUM = "sedang"
SEVERITY_INFO = "info"


class ElevationRefused(RuntimeError):
    """Raised when the helper cannot be trusted, so no privilege is requested."""


@dataclass(frozen=True, slots=True)
class SecurityFinding:
    severity: str
    code: str
    title: str
    detail: str


def md5_of(path: Path) -> str:
    digest = hashlib.md5()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def expected_md5(md5sums_text: str, relative_path: str) -> str | None:
    for line in md5sums_text.splitlines():
        parts = line.split(None, 1)
        if len(parts) == 2 and parts[1].strip() == relative_path:
            return parts[0].strip().casefold()
    return None


def verify_helper_before_elevation(
    helper_path: Path,
    md5sums_path: Path = MD5SUMS_PATH,
) -> None:
    """Raise ElevationRefused unless the helper is exactly the one dpkg installed."""
    try:
        info = os.lstat(helper_path)
    except OSError as exc:
        raise ElevationRefused("Helper tidak ditemukan; operasi dibatalkan.") from exc
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
        raise ElevationRefused("Helper bukan berkas biasa; operasi dibatalkan.")
    if info.st_uid != 0 or info.st_mode & 0o022:
        raise ElevationRefused("Helper tidak dimiliki root atau bisa ditulis grup/lain; operasi dibatalkan.")
    try:
        sums = md5sums_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ElevationRefused(
            "Basis verifikasi (md5sums dpkg) tidak tersedia; operasi dibatalkan."
        ) from exc
    expected = expected_md5(sums, HELPER_RELATIVE_PATH)
    if expected is None:
        raise ElevationRefused("Helper tidak tercatat di md5sums dpkg; operasi dibatalkan.")
    if md5_of(helper_path) != expected:
        raise ElevationRefused(
            "Checksum helper tidak cocok dengan catatan dpkg; kemungkinan dimodifikasi. "
            "Operasi dibatalkan."
        )


def check_environment(environ: dict[str, str]) -> list[SecurityFinding]:
    findings: list[SecurityFinding] = []
    for name in SUSPICIOUS_ENVIRONMENT:
        if environ.get(name):
            findings.append(SecurityFinding(
                SEVERITY_HIGH if name in ("LD_PRELOAD", "LD_AUDIT") else SEVERITY_MEDIUM,
                f"env-{name.lower()}",
                f"Variabel lingkungan {name} aktif",
                "Variabel ini bisa menyuntikkan kode ke proses PaketScope. Jalankan dari "
                "lingkungan yang bersih dan periksa dari mana variabel ini berasal.",
            ))
    return findings


def check_tracer(status_text: str) -> list[SecurityFinding]:
    for line in status_text.splitlines():
        if line.startswith("TracerPid:"):
            value = line.split(":", 1)[1].strip()
            if value.isdigit() and int(value) != 0:
                return [SecurityFinding(
                    SEVERITY_HIGH, "tracer-attached",
                    "Proses PaketScope sedang di-debug",
                    f"Proses pelacak (PID {value}) terpasang pada PaketScope.",
                )]
    return []


def _inet_inodes(net_tables: list[str]) -> set[str]:
    inodes: set[str] = set()
    for table in net_tables:
        try:
            lines = Path(table).read_text(encoding="utf-8").splitlines()[1:]
        except OSError:
            continue
        for line in lines:
            fields = line.split()
            if len(fields) > 9 and fields[9].isdigit():
                inodes.add(fields[9])
    return inodes


def check_network_sockets(fd_links: dict[str, str], net_tables: list[str]) -> list[SecurityFinding]:
    """fd_links maps fd name -> readlink target. Only INET sockets matter here."""
    inet = _inet_inodes(net_tables)
    open_inet = []
    for fd, target in fd_links.items():
        if target.startswith("socket:[") and target[len("socket:["):-1] in inet:
            open_inet.append(fd)
    if not open_inet:
        return []
    return [SecurityFinding(
        SEVERITY_HIGH, "unexpected-network",
        "Aplikasi membuka koneksi jaringan",
        f"{len(open_inet)} socket jaringan terbuka. PaketScope tidak punya fitur jaringan; "
        "periksa proses ini dengan hati-hati.",
    )]


def read_proc_fd_links() -> dict[str, str]:
    links: dict[str, str] = {}
    try:
        names = os.listdir("/proc/self/fd")
    except OSError:
        return links
    for name in names:
        try:
            links[name] = os.readlink(f"/proc/self/fd/{name}")
        except OSError:
            continue
    return links


def self_integrity_findings() -> list[SecurityFinding]:
    """dpkg -V on the paketscope package. Reuses the integrity layer; read-only."""
    from .integrity import verify_installed_package

    try:
        report = verify_installed_package("paketscope")
    except (OSError, ValueError, RuntimeError):
        # Detection must never crash the application; an unverifiable self-check reports nothing.
        return []
    if report.verdict == "ada perubahan":
        return [SecurityFinding(
            SEVERITY_HIGH, "self-modified",
            "File PaketScope berubah dari paket resmi",
            "dpkg -V menemukan file aplikasi yang tidak cocok dengan paket terpasang. "
            "Pasang ulang dari sumber resmi sebelum digunakan.",
        )]
    return []


def default_refusal_state() -> Path:
    """Local state file in the user's XDG state directory. Nothing leaves the machine."""
    base = os.environ.get("XDG_STATE_HOME") or str(Path.home() / ".local" / "state")
    return Path(base) / "paketscope" / "refusals.json"


def record_refusal(state_path: Path, now: float | None = None) -> None:
    """Append a refusal timestamp to a bounded local state file. Never sent anywhere."""
    moment = time.time() if now is None else now
    try:
        data = json.loads(state_path.read_text(encoding="utf-8"))
        stamps = [float(item) for item in data.get("refusals", [])]
    except (OSError, ValueError, TypeError, AttributeError):
        stamps = []
    stamps = [item for item in stamps if moment - item <= REFUSAL_WINDOW_SECONDS]
    stamps.append(moment)
    stamps = stamps[-REFUSAL_LOG_LIMIT:]
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(json.dumps({"refusals": stamps}), encoding="utf-8")


def refusal_burst_findings(state_path: Path, now: float | None = None) -> list[SecurityFinding]:
    moment = time.time() if now is None else now
    try:
        data = json.loads(state_path.read_text(encoding="utf-8"))
        stamps = [float(item) for item in data.get("refusals", [])]
    except (OSError, ValueError, TypeError, AttributeError):
        return []
    recent = [item for item in stamps if moment - item <= REFUSAL_WINDOW_SECONDS]
    if len(recent) < REFUSAL_BURST_THRESHOLD:
        return []
    return [SecurityFinding(
        SEVERITY_MEDIUM, "refusal-burst",
        "Banyak permintaan istimewa ditolak",
        f"{len(recent)} permintaan ditolak dalam {REFUSAL_WINDOW_SECONDS // 60} menit terakhir. "
        "Ini bisa berarti ada pihak yang mencoba menjalankan aksi tanpa izin.",
    )]


def run_startup_checks(
    environ: dict[str, str] | None = None,
    status_path: Path = Path("/proc/self/status"),
    net_tables: tuple[str, ...] = ("/proc/net/tcp", "/proc/net/tcp6", "/proc/net/udp", "/proc/net/udp6"),
    refusal_state: Path | None = None,
) -> tuple[SecurityFinding, ...]:
    findings: list[SecurityFinding] = []
    findings.extend(check_environment(dict(os.environ) if environ is None else environ))
    try:
        findings.extend(check_tracer(status_path.read_text(encoding="utf-8")))
    except OSError:
        pass
    findings.extend(check_network_sockets(read_proc_fd_links(), list(net_tables)))
    findings.extend(self_integrity_findings())
    if refusal_state is not None:
        findings.extend(refusal_burst_findings(refusal_state))
    order = {SEVERITY_HIGH: 0, SEVERITY_MEDIUM: 1, SEVERITY_INFO: 2}
    return tuple(sorted(findings, key=lambda item: order.get(item.severity, 9)))
