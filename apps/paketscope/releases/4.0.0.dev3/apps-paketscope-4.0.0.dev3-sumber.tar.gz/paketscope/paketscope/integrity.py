"""Read-only integrity and compatibility checks for installed APT packages.

Nothing here changes the system or needs root. Results describe what the local dpkg
database and APT index say. They are evidence to inspect, not a guarantee.

What `dpkg -V` proves: installed files match the checksums dpkg recorded at install time.
It does NOT prove the package came from a trusted source, and it cannot detect a
compromised package that was installed that way from the start.
"""
from __future__ import annotations

import fnmatch
import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from .commands import CommandTimedOut, CommandUnavailable, run_command

MAX_LISTED_FILES = 40
# dpkg -V prints: 9 attribute characters, an optional type letter (c = conffile), a space, a path.
VERIFY_LINE_RE = re.compile(r"^(?P<flags>[\S.?]{9})\s+(?:(?P<kind>[a-z])\s+)?(?P<path>/\S.*)$")
OFFICIAL_ORIGIN_MARKERS = (
    "deb.debian.org", "debian", "archive.ubuntu.com", "ubuntu",
    "packages.linuxmint.com", "linux mint", "linuxmint", "kali.org", "kali",
)
KNOWN_CODENAMES = (
    # Debian and Ubuntu
    "trixie", "bookworm", "bullseye", "forky", "sid", "noble", "jammy", "plucky", "questing", "oracular",
    # Linux Mint (its own suite names) and LMDE (Debian-based)
    "wilma", "xia", "virginia", "vera", "vanessa", "victoria", "uma", "gigi",
    # Kali is rolling; its suite is named kali-rolling
    "kali-rolling", "kali-dev",
)
CODENAME_RE = re.compile(r"\b(" + "|".join(re.escape(name) for name in KNOWN_CODENAMES) + r")\b")


@dataclass(frozen=True, slots=True)
class ChangedFile:
    path: str
    reason: str  # "berubah" | "hilang" | "konfigurasi diubah pengguna"


@dataclass(frozen=True, slots=True)
class IntegrityReport:
    package: str
    verdict: str  # "cocok" | "ada perubahan" | "tidak dapat diverifikasi"
    checked_files: int
    changed: tuple[ChangedFile, ...] = ()
    omitted_changes: int = 0
    note: str = ""


@dataclass(frozen=True, slots=True)
class CompatibilityCheck:
    label: str
    status: str  # "cocok" | "tidak cocok" | "tidak diketahui"
    detail: str


@dataclass(frozen=True, slots=True)
class HostProfile:
    architecture: str
    codename: str
    # Derivatives (Mint, LMDE, Kali) also expose their base release, e.g. UBUNTU_CODENAME.
    aliases: tuple[str, ...] = ()


def parse_verify_output(output: str) -> tuple[list[ChangedFile], int]:
    """Parse `dpkg -V` lines. Returns (changed files, count of missing-file lines)."""
    changed: list[ChangedFile] = []
    missing = 0
    for raw in output.splitlines():
        line = raw.rstrip()
        if not line:
            continue
        if line.startswith("missing"):
            path = line.split(None, 1)[1] if len(line.split(None, 1)) == 2 else "(tidak diketahui)"
            changed.append(ChangedFile(path=path, reason="hilang"))
            missing += 1
            continue
        match = VERIFY_LINE_RE.match(line)
        if not match:
            continue
        flags = match.group("flags")
        if set(flags) <= {"."}:
            continue
        reason = "konfigurasi diubah pengguna" if match.group("kind") == "c" else "berubah"
        changed.append(ChangedFile(path=match.group("path"), reason=reason))
    return changed, missing


DPKG_CONFIG_FILES = ("/etc/dpkg/dpkg.cfg",)
DPKG_CONFIG_DIR = "/etc/dpkg/dpkg.cfg.d"
POLICY_EXCLUDED_REASON = "dikecualikan kebijakan dpkg"


def parse_path_policy(text: str) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Read path-exclude and path-include patterns from dpkg configuration text."""
    excludes: list[str] = []
    includes: list[str] = []
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith("path-exclude="):
            excludes.append(line.split("=", 1)[1].strip())
        elif line.startswith("path-include="):
            includes.append(line.split("=", 1)[1].strip())
    return tuple(excludes), tuple(includes)


def load_path_policy() -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Read dpkg path policy from /etc/dpkg. Read-only; missing files are simply ignored."""
    excludes: list[str] = []
    includes: list[str] = []
    sources = [Path(name) for name in DPKG_CONFIG_FILES]
    try:
        sources.extend(sorted(Path(DPKG_CONFIG_DIR).iterdir()))
    except OSError:
        pass
    for source in sources:
        try:
            text = source.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        found_excludes, found_includes = parse_path_policy(text)
        excludes.extend(found_excludes)
        includes.extend(found_includes)
    return tuple(excludes), tuple(includes)


def is_policy_excluded(path: str, excludes: tuple[str, ...], includes: tuple[str, ...]) -> bool:
    """dpkg semantics: an include pattern rescues a path that an exclude pattern matches."""
    if not any(fnmatch.fnmatchcase(path, pattern) for pattern in excludes):
        return False
    return not any(fnmatch.fnmatchcase(path, pattern) for pattern in includes)


def _count_listed_files(package: str) -> int | None:
    try:
        result = run_command(["dpkg-query", "-L", package], timeout=20.0)
    except (CommandUnavailable, CommandTimedOut):
        return None
    if result.returncode != 0:
        return None
    return sum(1 for line in result.stdout.splitlines() if line.startswith("/"))


def verify_installed_package(package: str) -> IntegrityReport:
    """Run dpkg -V for one package and summarize it. Read-only."""
    try:
        result = run_command(["dpkg", "-V", package], timeout=120.0)
    except (CommandUnavailable, CommandTimedOut):
        return IntegrityReport(
            package=package,
            verdict="tidak dapat diverifikasi",
            checked_files=0,
            note="Perintah dpkg -V tidak tersedia atau melewati batas waktu.",
        )
    changed, _missing = parse_verify_output(result.stdout or "")
    excludes, includes = load_path_policy()
    changed = [
        ChangedFile(item.path, POLICY_EXCLUDED_REASON)
        if item.reason == "hilang" and is_policy_excluded(item.path, excludes, includes)
        else item
        for item in changed
    ]
    checked = _count_listed_files(package) or 0
    if result.returncode not in (0, 1) and not changed:
        return IntegrityReport(
            package=package,
            verdict="tidak dapat diverifikasi",
            checked_files=checked,
            note="dpkg -V mengembalikan galat; sebagian file mungkin tidak dapat dibaca.",
        )
    shown = tuple(changed[:MAX_LISTED_FILES])
    omitted = max(0, len(changed) - MAX_LISTED_FILES)
    # Only content/mode changes and missing files outside dpkg's own path policy count.
    benign = {"konfigurasi diubah pengguna", POLICY_EXCLUDED_REASON}
    real_changes = [item for item in changed if item.reason not in benign]
    if not changed:
        verdict = "cocok"
        note = "Semua file yang tercatat di database dpkg cocok dengan checksum saat pemasangan."
    elif real_changes:
        verdict = "ada perubahan"
        note = (
            "Beberapa file tidak lagi cocok dengan checksum saat pemasangan. Ini bisa karena "
            "pembaruan manual, konfigurasi, atau modifikasi yang tidak diinginkan."
        )
    elif any(item.reason == "konfigurasi diubah pengguna" for item in changed):
        verdict = "cocok"
        note = "Hanya file konfigurasi yang diubah pengguna; ini normal dan bukan tanda bahaya."
    else:
        verdict = "cocok"
        note = (
            "Sebagian file tidak dipasang karena kebijakan dpkg (path-exclude), misalnya dokumentasi "
            "atau halaman man. Ini normal dan bukan tanda bahaya."
        )
    return IntegrityReport(
        package=package,
        verdict=verdict,
        checked_files=checked,
        changed=shown,
        omitted_changes=omitted,
        note=note,
    )


def classify_origin(origin_text: str) -> str:
    """Describe how much the origin can be trusted, from the APT origin text only."""
    text = (origin_text or "").casefold()
    if not text or text.startswith("tidak dapat"):
        return "tidak dapat diverifikasi: asal tidak ditemukan di indeks APT lokal"
    if any(marker in text for marker in OFFICIAL_ORIGIN_MARKERS):
        return "arsip resmi distribusi (indeks ditandatangani kunci arsip distribusi)"
    return "repositori pihak ketiga: verifikasi kunci repositori secara manual"


def compatibility_checks(
    package_architecture: str,
    origin_text: str,
    host: HostProfile,
) -> tuple[CompatibilityCheck, ...]:
    checks: list[CompatibilityCheck] = []
    arch = (package_architecture or "").strip()
    if not arch:
        checks.append(CompatibilityCheck("Arsitektur", "tidak diketahui", "Metadata arsitektur tidak tersedia."))
    elif arch in ("all", host.architecture):
        checks.append(CompatibilityCheck("Arsitektur", "cocok", f"Paket {arch}, sistem {host.architecture}."))
    else:
        checks.append(CompatibilityCheck(
            "Arsitektur", "tidak cocok", f"Paket {arch} tidak sesuai dengan sistem {host.architecture}."
        ))

    origin_codename = ""
    match = CODENAME_RE.search((origin_text or "").casefold())
    if match:
        origin_codename = match.group(1)
    host_names = {name for name in (host.codename, *host.aliases) if name}
    if not origin_codename:
        checks.append(CompatibilityCheck(
            "Rilis distribusi", "tidak diketahui", "Asal tidak menyebut nama rilis (codename) yang dikenali."
        ))
    elif not host_names:
        checks.append(CompatibilityCheck(
            "Rilis distribusi", "tidak diketahui", "Codename sistem tidak dapat dibaca dari /etc/os-release."
        ))
    elif origin_codename in host_names:
        checks.append(CompatibilityCheck(
            "Rilis distribusi", "cocok",
            f"Asal {origin_codename} sesuai dengan sistem ({', '.join(sorted(host_names))}).",
        ))
    else:
        checks.append(CompatibilityCheck(
            "Rilis distribusi", "tidak cocok",
            f"Asal {origin_codename} berbeda dengan sistem ({', '.join(sorted(host_names))}); "
            "paket bisa tetap berjalan, tetapi tidak diuji untuk rilis ini.",
        ))
    checks.append(CompatibilityCheck(
        "Dependensi", "cocok",
        "Paket sudah terpasang, sehingga dependensinya terpenuhi pada saat pemasangan. "
        "Bukti terbaru ada di simulasi APT.",
    ))
    return tuple(checks)


def read_host_profile() -> HostProfile:
    """Architecture from dpkg, release codename from os-release. Both read-only."""
    architecture = "unknown"
    try:
        result = run_command(["dpkg", "--print-architecture"], timeout=10.0)
        if result.returncode == 0 and result.stdout.strip():
            architecture = result.stdout.strip()
    except (CommandUnavailable, CommandTimedOut):
        pass
    values: dict[str, str] = {}
    try:
        with open("/etc/os-release", encoding="utf-8") as handle:
            for line in handle:
                if "=" in line and line.split("=", 1)[0] in ("VERSION_CODENAME", "UBUNTU_CODENAME", "DEBIAN_CODENAME"):
                    key, value = line.split("=", 1)
                    values[key] = value.strip().strip('"')
    except OSError:
        pass
    aliases = tuple(value for key, value in (("UBUNTU_CODENAME", values.get("UBUNTU_CODENAME", "")),
                                              ("DEBIAN_CODENAME", values.get("DEBIAN_CODENAME", "")))
                    if value)
    return HostProfile(architecture=architecture, codename=values.get("VERSION_CODENAME", ""), aliases=aliases)


def installed_size_kib(fields: dict[str, str]) -> str:
    value = fields.get("Installed-Size", "").strip()
    if not value.isdigit():
        return "tidak tersedia"
    kib = int(value)
    if kib >= 1024:
        return f"{kib / 1024:.1f} MiB"
    return f"{kib} KiB"


def install_time_hint(package: str) -> str:
    """Approximate install time from the dpkg file list. It is a hint, not a record."""
    path = f"/var/lib/dpkg/info/{package}.list"
    try:
        stamp = os.stat(path).st_mtime
    except OSError:
        return "tidak tersedia"
    return "perkiraan " + datetime.fromtimestamp(stamp, tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


def apt_index_age() -> str:
    """Age of the local APT package index, so users know how fresh the info is."""
    try:
        stamp = os.stat("/var/lib/apt/lists").st_mtime
    except OSError:
        return "tidak tersedia"
    return "terakhir diperbarui " + datetime.fromtimestamp(stamp, tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


def depends_summary(depends_field: str) -> tuple[str, ...]:
    """Split a Depends field into readable clauses, bounded to keep the dialog compact."""
    if not depends_field.strip():
        return ()
    clauses = [part.strip() for part in depends_field.split(",") if part.strip()]
    return tuple(clauses[:30])


@dataclass(frozen=True, slots=True)
class ExtraInfo:
    installed_size: str = "tidak tersedia"
    install_time: str = "tidak tersedia"
    index_age: str = "tidak tersedia"
    depends: tuple[str, ...] = field(default_factory=tuple)
