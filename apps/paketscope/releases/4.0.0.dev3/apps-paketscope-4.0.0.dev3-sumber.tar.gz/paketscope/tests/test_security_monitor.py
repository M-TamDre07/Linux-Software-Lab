import hashlib
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from paketscope import package_manager as pm
from paketscope import security_monitor as sm
from paketscope.commands import CommandResult

FIXTURE_PARENT = "/var/lib"
ROOT_ONLY = unittest.skipUnless(os.geteuid() == 0, "requires root: ownership semantics")


def _md5(data: bytes) -> str:
    return hashlib.md5(data).hexdigest()


@ROOT_ONLY
class HelperIntegrityTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.mkdtemp(prefix="paketscope-sec-", dir=FIXTURE_PARENT)
        self.addCleanup(lambda: shutil.rmtree(self._tmp, ignore_errors=True))
        self.base = Path(self._tmp).resolve()
        os.chmod(self.base, 0o755)
        self.helper = self.base / "helper"
        self.helper.write_bytes(b"#!/usr/bin/python3 -I\nprint('ok')\n")
        os.chmod(self.helper, 0o755)
        self.sums = self.base / "paketscope.md5sums"

    def _record(self, content=None):
        data = self.helper.read_bytes() if content is None else content
        self.sums.write_text(f"{_md5(data)}  {sm.HELPER_RELATIVE_PATH}\n", encoding="utf-8")

    def test_matching_recorded_checksum_is_accepted(self):
        self._record()
        sm.verify_helper_before_elevation(self.helper, self.sums)

    def test_modified_helper_is_refused(self):
        self._record(b"original bytes")
        with self.assertRaisesRegex(sm.ElevationRefused, "tidak cocok"):
            sm.verify_helper_before_elevation(self.helper, self.sums)

    def test_missing_helper_is_refused(self):
        self._record()
        with self.assertRaisesRegex(sm.ElevationRefused, "tidak ditemukan"):
            sm.verify_helper_before_elevation(self.base / "absent", self.sums)

    def test_symlinked_helper_is_refused(self):
        self._record()
        link = self.base / "link"
        os.symlink(self.helper, link)
        with self.assertRaisesRegex(sm.ElevationRefused, "bukan berkas biasa"):
            sm.verify_helper_before_elevation(link, self.sums)

    def test_group_or_world_writable_helper_is_refused(self):
        self._record()
        os.chmod(self.helper, 0o775)
        with self.assertRaisesRegex(sm.ElevationRefused, "bisa ditulis grup/lain"):
            sm.verify_helper_before_elevation(self.helper, self.sums)

    def test_missing_checksum_baseline_is_refused(self):
        with self.assertRaisesRegex(sm.ElevationRefused, "tidak tersedia"):
            sm.verify_helper_before_elevation(self.helper, self.base / "none.md5sums")

    def test_helper_not_listed_in_baseline_is_refused(self):
        self.sums.write_text(f"{_md5(b'x')}  usr/bin/other\n", encoding="utf-8")
        with self.assertRaisesRegex(sm.ElevationRefused, "tidak tercatat"):
            sm.verify_helper_before_elevation(self.helper, self.sums)


class ChecksumParsingTests(unittest.TestCase):
    def test_expected_md5_matches_the_exact_relative_path(self):
        text = f"{'a' * 32}  usr/libexec/paketscope/paketscope-apt-helper\n{'b' * 32}  usr/bin/x\n"
        self.assertEqual(sm.expected_md5(text, sm.HELPER_RELATIVE_PATH), "a" * 32)
        self.assertIsNone(sm.expected_md5(text, "usr/libexec/other"))


class EnvironmentAndDebuggerTests(unittest.TestCase):
    def test_loader_injection_is_high_and_interpreter_hooks_are_medium(self):
        findings = sm.check_environment({"LD_PRELOAD": "/tmp/x.so", "PYTHONSTARTUP": "/tmp/s.py"})
        severities = {f.code: f.severity for f in findings}
        self.assertEqual(severities["env-ld_preload"], sm.SEVERITY_HIGH)
        self.assertEqual(severities["env-pythonstartup"], sm.SEVERITY_MEDIUM)

    def test_clean_environment_produces_no_findings(self):
        self.assertEqual(sm.check_environment({"PATH": "/usr/bin", "HOME": "/home/x"}), [])

    def test_tracer_attached_is_reported_and_zero_is_not(self):
        self.assertEqual(sm.check_tracer("Name:\tpaketscope\nTracerPid:\t0\n"), [])
        attached = sm.check_tracer("Name:\tpaketscope\nTracerPid:\t4321\n")
        self.assertEqual(attached[0].code, "tracer-attached")


class NetworkSocketTests(unittest.TestCase):
    def _tables(self, tmp, inode):
        table = tmp / "tcp"
        table.write_text(
            "  sl  local_address rem_address   st ... inode\n"
            f"   0: 0100007F:0050 00000000:0000 0A 00000000:00000000 00:00000000 00000000  1000 0 {inode} 1 0\n",
            encoding="utf-8",
        )
        return str(table)

    def test_open_inet_socket_is_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            tables = self._tables(Path(tmp), 555)
            findings = sm.check_network_sockets({"5": "socket:[555]"}, [tables])
        self.assertEqual(findings[0].code, "unexpected-network")

    def test_unix_sockets_used_by_the_display_server_are_ignored(self):
        with tempfile.TemporaryDirectory() as tmp:
            tables = self._tables(Path(tmp), 555)
            self.assertEqual(sm.check_network_sockets({"3": "socket:[999]"}, [tables]), [])

    def test_regular_files_are_ignored(self):
        self.assertEqual(sm.check_network_sockets({"4": "/usr/share/x"}, []), [])


class RefusalBurstTests(unittest.TestCase):
    def test_few_refusals_are_not_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            state = Path(tmp) / "refusals.json"
            for i in range(sm.REFUSAL_BURST_THRESHOLD - 1):
                sm.record_refusal(state, now=1000.0 + i)
            self.assertEqual(sm.refusal_burst_findings(state, now=1010.0), [])

    def test_burst_inside_the_window_is_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            state = Path(tmp) / "refusals.json"
            for i in range(sm.REFUSAL_BURST_THRESHOLD):
                sm.record_refusal(state, now=1000.0 + i)
            findings = sm.refusal_burst_findings(state, now=1010.0)
        self.assertEqual(findings[0].code, "refusal-burst")

    def test_old_refusals_fall_out_of_the_window(self):
        with tempfile.TemporaryDirectory() as tmp:
            state = Path(tmp) / "refusals.json"
            for i in range(sm.REFUSAL_BURST_THRESHOLD):
                sm.record_refusal(state, now=1000.0 + i)
            later = 1000.0 + sm.REFUSAL_WINDOW_SECONDS + 100
            self.assertEqual(sm.refusal_burst_findings(state, now=later), [])

    def test_state_file_is_bounded(self):
        with tempfile.TemporaryDirectory() as tmp:
            state = Path(tmp) / "refusals.json"
            for i in range(sm.REFUSAL_LOG_LIMIT + 50):
                sm.record_refusal(state, now=1000.0 + i * 0.001)
            import json
            self.assertLessEqual(len(json.loads(state.read_text())["refusals"]), sm.REFUSAL_LOG_LIMIT)

    def test_state_path_follows_xdg_state_home(self):
        with mock.patch.dict(os.environ, {"XDG_STATE_HOME": "/tmp/xdgstate"}):
            self.assertEqual(sm.default_refusal_state(), Path("/tmp/xdgstate/paketscope/refusals.json"))


class StartupAggregationTests(unittest.TestCase):
    def test_findings_are_sorted_most_severe_first(self):
        with mock.patch.object(sm, "self_integrity_findings", return_value=[]), \
             mock.patch.object(sm, "read_proc_fd_links", return_value={}):
            findings = sm.run_startup_checks(
                environ={"PYTHONSTARTUP": "/x", "LD_PRELOAD": "/y.so"},
                status_path=Path("/nonexistent"),
                net_tables=(),
            )
        self.assertEqual(findings[0].severity, sm.SEVERITY_HIGH)

    def test_clean_start_reports_nothing(self):
        with mock.patch.object(sm, "self_integrity_findings", return_value=[]), \
             mock.patch.object(sm, "read_proc_fd_links", return_value={}):
            self.assertEqual(sm.run_startup_checks(environ={}, status_path=Path("/nonexistent"), net_tables=()), ())


class ElevationGuaranteeTests(unittest.TestCase):
    """A failed guard must stop the operation before pkexec is ever started."""

    def test_refused_guard_never_reaches_pkexec_and_is_counted(self):
        simulation = CommandResult(argv=("sim",), returncode=0, stdout="Inst hello (2.10)\n", stderr="")
        calls = []

        def fake_run(argv, timeout=20.0):
            calls.append(list(argv))
            return simulation

        def refusing_guard(path):
            raise sm.ElevationRefused("Checksum helper tidak cocok; operasi dibatalkan.")

        with tempfile.TemporaryDirectory() as tmp:
            state = Path(tmp) / "refusals.json"
            with mock.patch.object(pm, "run_command", side_effect=fake_run):
                approved = pm.preview_apt_action("install", "hello")
            with mock.patch.object(pm, "run_command", side_effect=fake_run), \
                 mock.patch.object(pm, "HELPER_GUARD", refusing_guard), \
                 mock.patch.object(pm, "default_refusal_state", return_value=state), \
                 self.assertRaisesRegex(pm.PackageOperationError, "tidak cocok"):
                pm.apply_apt_action("install", "hello", approved_preview=approved)
            self.assertTrue(state.exists())
        self.assertFalse(any(argv and argv[0] == "pkexec" for argv in calls))


if __name__ == "__main__":
    unittest.main()
