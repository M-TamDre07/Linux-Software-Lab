import json
import tempfile
import unittest
from pathlib import Path

from paketscope import accessibility as A
from paketscope import onboarding as O


class ContrastTests(unittest.TestCase):
    def test_black_on_white_is_the_maximum_ratio(self):
        self.assertAlmostEqual(A.contrast_ratio("#000000", "#FFFFFF"), 21.0, places=1)

    def test_every_palette_text_meets_wcag_aa_text_contrast(self):
        for name in A.PALETTES:
            colours = A.PALETTE_COLOURS[name]
            with self.subTest(palette=name):
                self.assertGreaterEqual(A.contrast_ratio(colours["text"], colours["background"]), 4.5)

    def test_every_state_colour_meets_the_non_text_contrast_minimum(self):
        for name in A.PALETTES:
            colours = A.PALETTE_COLOURS[name]
            for state in A.STATES:
                with self.subTest(palette=name, state=state):
                    ratio = A.contrast_ratio(colours[state], colours["background"])
                    self.assertGreaterEqual(ratio, 3.0, f"{ratio:.2f} is below 3:1")

    def test_every_palette_defines_every_state(self):
        for name in A.PALETTES:
            for state in A.STATES:
                self.assertIn(state, A.PALETTE_COLOURS[name])


class ColourIsNeverTheOnlySignalTests(unittest.TestCase):
    def test_every_state_has_a_distinct_symbol(self):
        symbols = [A.STATE_SYMBOLS[state] for state in A.STATES]
        self.assertEqual(len(symbols), len(set(symbols)))

    def test_state_label_carries_symbol_and_text(self):
        for state in A.STATES:
            with self.subTest(state=state):
                label = A.state_label(state)
                self.assertIn(A.STATE_SYMBOLS[state], label)
                self.assertIn(state, label)

    def test_unknown_state_falls_back_to_unknown_label(self):
        self.assertEqual(A.state_label("tidak-ada"), A.state_label(A.STATE_UNKNOWN))


class SettingsBoundsAndStorageTests(unittest.TestCase):
    def test_unknown_palette_falls_back_to_standard(self):
        self.assertEqual(A.AccessibilitySettings(palette="neon").normalized().palette, A.PALETTE_STANDARD)

    def test_text_scale_is_clamped_to_the_supported_range(self):
        self.assertEqual(A.AccessibilitySettings(text_scale=0.1).normalized().text_scale, A.MIN_TEXT_SCALE)
        self.assertEqual(A.AccessibilitySettings(text_scale=9).normalized().text_scale, A.MAX_TEXT_SCALE)

    def test_round_trip_through_a_local_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "accessibility.json"
            original = A.AccessibilitySettings(palette=A.PALETTE_COLOUR_VISION, text_scale=1.5, reduce_motion=True)
            A.save_settings(original, path)
            loaded = A.load_settings(path)
        self.assertEqual(loaded.palette, A.PALETTE_COLOUR_VISION)
        self.assertEqual(loaded.text_scale, 1.5)
        self.assertTrue(loaded.reduce_motion)

    def test_corrupt_or_non_object_files_fall_back_to_defaults(self):
        with tempfile.TemporaryDirectory() as tmp:
            bad = Path(tmp) / "bad.json"
            bad.write_text("{not json", encoding="utf-8")
            self.assertEqual(A.load_settings(bad), A.AccessibilitySettings())
            listy = Path(tmp) / "list.json"
            listy.write_text("[1, 2]", encoding="utf-8")
            self.assertEqual(A.load_settings(listy), A.AccessibilitySettings())

    def test_unknown_keys_in_a_file_are_ignored(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "a.json"
            path.write_text(json.dumps({"palette": A.PALETTE_HIGH_CONTRAST, "telemetry": True}), encoding="utf-8")
            loaded = A.load_settings(path)
        self.assertEqual(loaded.palette, A.PALETTE_HIGH_CONTRAST)
        self.assertFalse(hasattr(loaded, "telemetry"))

    def test_settings_file_lives_in_the_user_config_directory(self):
        import os
        from unittest import mock
        with mock.patch.dict(os.environ, {"XDG_CONFIG_HOME": "/tmp/xdgconf"}):
            self.assertEqual(A.default_settings_path(), Path("/tmp/xdgconf/paketscope/accessibility.json"))


class OnboardingTests(unittest.TestCase):
    def test_tutorial_has_five_fixed_steps_and_each_has_text(self):
        self.assertEqual(len(O.STEPS), 5)
        for step in O.STEPS:
            with self.subTest(step=step.key):
                self.assertTrue(step.title)
                self.assertTrue(step.body)

    def test_navigation_is_bounded_at_both_ends(self):
        self.assertEqual(O.previous_index(0), 0)
        self.assertEqual(O.next_index(len(O.STEPS) - 1), len(O.STEPS) - 1)
        self.assertTrue(O.is_last(len(O.STEPS) - 1))
        self.assertFalse(O.is_last(0))

    def test_a_new_user_sees_the_tutorial_and_a_skipping_user_does_not(self):
        fresh = A.AccessibilitySettings()
        self.assertTrue(O.should_show(fresh))
        skipped = O.skip(fresh)
        self.assertFalse(O.should_show(skipped))
        self.assertTrue(skipped.onboarding_skipped)

    def test_finish_marks_seen_without_the_skip_flag(self):
        done = O.finish(A.AccessibilitySettings())
        self.assertTrue(done.onboarding_completed)
        self.assertFalse(done.onboarding_skipped)

    def test_replay_shows_the_tutorial_again_and_keeps_other_choices(self):
        chosen = A.AccessibilitySettings(palette=A.PALETTE_HIGH_CONTRAST, text_scale=1.5, onboarding_completed=True)
        again = O.replay(chosen)
        self.assertTrue(O.should_show(again))
        self.assertEqual(again.palette, A.PALETTE_HIGH_CONTRAST)
        self.assertEqual(again.text_scale, 1.5)

    def test_tutorial_never_grants_a_permission(self):
        for step in O.STEPS:
            self.assertNotIn("akses root", step.body.lower())


class NoSoundTests(unittest.TestCase):
    """Deaf or hard-of-hearing users must lose nothing. The app must not depend on audio."""

    def test_the_package_imports_no_audio_library(self):
        forbidden = ("QtMultimedia", "QSound", "winsound", "playsound", "simpleaudio", "pygame")
        root = Path(A.__file__).resolve().parent
        for source in root.rglob("*.py"):
            text = source.read_text(encoding="utf-8")
            for name in forbidden:
                with self.subTest(file=str(source.name), library=name):
                    self.assertNotIn(name, text)


if __name__ == "__main__":
    unittest.main()
