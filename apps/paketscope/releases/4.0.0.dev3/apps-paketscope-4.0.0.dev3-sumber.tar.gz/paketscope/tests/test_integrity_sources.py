import hashlib
import tempfile
import unittest
from pathlib import Path

from paketscope import integrity_sources as S


class OneLineParsingTests(unittest.TestCase):
    def test_signed_official_source_is_parsed_and_not_flagged(self):
        text = "deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] http://deb.debian.org/debian trixie main contrib\n"
        sources = S.parse_one_line(text, "debian.list")
        self.assertEqual(len(sources), 1)
        self.assertTrue(sources[0].official)
        self.assertEqual(sources[0].signed_by, "/usr/share/keyrings/debian-archive-keyring.gpg")
        self.assertEqual(S.audit_sources(sources)[0].severity, S.SEVERITY_INFO)

    def test_trusted_yes_is_a_high_severity_finding(self):
        text = "deb [trusted=yes] https://repo.example.org stable main\n"
        findings = S.audit_sources(S.parse_one_line(text, "x.list"))
        self.assertEqual(findings[0].severity, S.SEVERITY_HIGH)
        self.assertIn("trusted=yes", findings[0].detail)

    def test_third_party_without_signed_by_is_medium(self):
        text = "deb https://repo.example.org stable main\n"
        findings = S.audit_sources(S.parse_one_line(text, "x.list"))
        self.assertEqual(findings[0].severity, S.SEVERITY_MEDIUM)

    def test_comments_and_source_lines_are_ignored(self):
        text = "# comment\ndeb-src http://deb.debian.org/debian trixie main\n\nnot a source\n"
        self.assertEqual(len(S.parse_one_line(text, "x.list")), 1)


class Deb822ParsingTests(unittest.TestCase):
    def test_stanza_with_multiple_uris_and_suites_expands(self):
        text = (
            "Types: deb\nURIs: http://deb.debian.org/debian\nSuites: trixie trixie-updates\n"
            "Components: main\nSigned-By: /usr/share/keyrings/x.gpg\n"
        )
        sources = S.parse_deb822(text, "debian.sources")
        self.assertEqual([s.suite for s in sources], ["trixie", "trixie-updates"])
        self.assertTrue(all(s.signed_by for s in sources))

    def test_disabled_stanza_is_skipped(self):
        text = "Enabled: no\nTypes: deb\nURIs: https://x\nSuites: stable\nComponents: main\n"
        self.assertEqual(S.parse_deb822(text, "x.sources"), [])

    def test_trusted_yes_in_deb822_is_detected(self):
        text = "Types: deb\nURIs: https://repo.example.org\nSuites: stable\nComponents: main\nTrusted: yes\n"
        findings = S.audit_sources(S.parse_deb822(text, "x.sources"))
        self.assertEqual(findings[0].severity, S.SEVERITY_HIGH)


class ReadingFilesTests(unittest.TestCase):
    def test_reads_list_and_sources_directory_and_reports_unreadable_dir(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            (base / "sources.list").write_text("deb https://a stable main\n", encoding="utf-8")
            folder = base / "list.d"
            folder.mkdir()
            (folder / "x.sources").write_text("Types: deb\nURIs: https://b\nSuites: s\nComponents: main\n", encoding="utf-8")
            sources, diagnostics = S.read_configured_sources(base / "sources.list", folder)
            self.assertEqual(len(sources), 2)
            self.assertEqual(diagnostics, [])
            _, missing = S.read_configured_sources(base / "none", base / "absent-dir")
            self.assertTrue(missing)


class DebVerificationTests(unittest.TestCase):
    def test_matching_checksum_is_accepted(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "x.deb"
            path.write_bytes(b"package bytes")
            expected = hashlib.sha256(b"package bytes").hexdigest()
            ok, message = S.verify_deb_file(path, expected)
        self.assertTrue(ok)
        self.assertIn("cocok", message)

    def test_mismatched_checksum_is_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "x.deb"
            path.write_bytes(b"tampered")
            ok, message = S.verify_deb_file(path, hashlib.sha256(b"original").hexdigest())
        self.assertFalse(ok)
        self.assertIn("TIDAK cocok", message)

    def test_malformed_expected_value_is_rejected_before_hashing(self):
        ok, message = S.verify_deb_file(Path("/nonexistent"), "not-a-hash")
        self.assertFalse(ok)
        self.assertIn("64 karakter", message)

    def test_missing_file_reports_an_error_instead_of_crashing(self):
        ok, message = S.verify_deb_file(Path("/definitely/absent.deb"), "a" * 64)
        self.assertFalse(ok)
        self.assertIn("tidak dapat dibaca", message)


if __name__ == "__main__":
    unittest.main()
