import importlib.machinery
import importlib.util
import subprocess
import unittest
from pathlib import Path
from unittest import mock

HELPER_PATH = Path(__file__).resolve().parents[1] / "packaging" / "helpers" / "paketscope-apt-helper"
_loader = importlib.machinery.SourceFileLoader("paketscope_apt_helper_policy", str(HELPER_PATH))
_spec = importlib.util.spec_from_loader("paketscope_apt_helper_policy", _loader)
helper = importlib.util.module_from_spec(_spec)
_loader.exec_module(helper)


def _completed(stdout="", stderr="", returncode=0):
    return subprocess.CompletedProcess(args=[], returncode=returncode, stdout=stdout, stderr=stderr)


class FakeApt:
    """Records every command. Simulation output and dpkg metadata are supplied by the test."""

    def __init__(self, simulation="", simulation_code=0, metadata="", real_code=0, real_stdout=""):
        self.simulation = simulation
        self.simulation_code = simulation_code
        self.metadata = metadata
        self.real_code = real_code
        self.real_stdout = real_stdout
        self.calls = []

    def __call__(self, command, **kwargs):
        self.calls.append(command)
        if command[0] == helper.DPKG_QUERY:
            return _completed(self.metadata)
        if "--simulate" in command:
            return _completed(self.simulation, returncode=self.simulation_code)
        return _completed(self.real_stdout, returncode=self.real_code)

    def real_apt_ran(self):
        return any(c[0] == helper.APT_GET and "--simulate" not in c for c in self.calls)


class RemovalPolicyTests(unittest.TestCase):
    def test_removed_packages_parses_remv_lines_including_arch_qualifier(self):
        output = "Inst x (1.0)\nRemv firefox [1.0]\nRemv libfoo:amd64 [2.0]\nConf y\n"
        self.assertEqual(helper.removed_packages(output), ["firefox", "libfoo:amd64"])

    def test_protected_core_packages_are_refused_even_when_metadata_looks_optional(self):
        # Even if dpkg metadata claims apt is optional, the fixed core list still refuses it.
        with self.assertRaisesRegex(helper.PolicyRefusal, "paket inti"):
            helper.check_removals(["apt"], {"apt": (False, "optional")})

    def test_essential_packages_are_refused(self):
        with self.assertRaisesRegex(helper.PolicyRefusal, "Essential"):
            helper.check_removals(["tar"], {"tar": (True, "required")})

    def test_required_and_important_priorities_are_refused(self):
        for priority in ("required", "important"):
            with self.subTest(priority=priority), self.assertRaisesRegex(helper.PolicyRefusal, "prioritas"):
                helper.check_removals(["somepkg"], {"somepkg": (False, priority)})

    def test_optional_and_extra_packages_may_be_removed(self):
        helper.check_removals(["firefox"], {"firefox": (False, "optional")})
        helper.check_removals(["extra"], {"extra": (False, "extra")})

    def test_unverifiable_metadata_is_refused(self):
        with self.assertRaisesRegex(helper.PolicyRefusal, "tidak dapat diverifikasi"):
            helper.check_removals(["mystery"], {})

    def test_removal_count_limit_is_enforced(self):
        names = [f"pkg{i}" for i in range(helper.MAX_REMOVALS + 1)]
        meta = {n: (False, "optional") for n in names}
        with self.assertRaisesRegex(helper.PolicyRefusal, "batas"):
            helper.check_removals(names, meta)

    def test_parse_priorities_keys_by_base_name(self):
        mapping = helper.parse_priorities("libfoo\tno\toptional\ntar\tyes\trequired\n")
        self.assertEqual(mapping["libfoo"], (False, "optional"))
        self.assertEqual(mapping["tar"], (True, "required"))


class DecisionFlowTests(unittest.TestCase):
    def setUp(self):
        self.logged = []
        self.log = self.logged.append

    def _run(self, arguments, fake):
        import contextlib
        import io
        err = io.StringIO()
        with mock.patch.object(helper.os, "geteuid", return_value=0), \
             contextlib.redirect_stderr(err), contextlib.redirect_stdout(io.StringIO()):
            code = helper.main(arguments, runner=fake, log=self.log)
        return code, err.getvalue()

    def test_install_without_removals_runs_apt_once_for_real(self):
        fake = FakeApt(simulation="Inst hello (2.10)\n", real_stdout="done\n")
        code, _ = self._run(["install", "hello"], fake)
        self.assertEqual(code, 0)
        self.assertTrue(fake.real_apt_ran())

    def test_install_that_would_remove_anything_is_refused_before_apt_runs(self):
        fake = FakeApt(simulation="Remv other [1.0]\nInst hello (2.10)\n")
        code, err = self._run(["install", "hello"], fake)
        self.assertEqual(code, helper.EXIT_POLICY)
        self.assertFalse(fake.real_apt_ran())
        self.assertIn("instalasi tidak boleh", err)

    def test_removing_a_protected_package_is_refused_and_apt_never_runs_for_real(self):
        fake = FakeApt(simulation="Remv bash [5.2]\n", metadata="bash\tno\trequired\n")
        code, err = self._run(["remove", "bash"], fake)
        self.assertEqual(code, helper.EXIT_POLICY)
        self.assertFalse(fake.real_apt_ran())
        self.assertIn("paket inti", err)

    def test_removing_an_optional_package_runs_apt_for_real(self):
        fake = FakeApt(simulation="Remv hello [2.10]\n", metadata="hello\tno\toptional\n", real_stdout="ok\n")
        code, _ = self._run(["remove", "hello"], fake)
        self.assertEqual(code, 0)
        self.assertTrue(fake.real_apt_ran())

    def test_failed_simulation_is_propagated_and_nothing_is_changed(self):
        fake = FakeApt(simulation="", simulation_code=100)
        code, _ = self._run(["remove", "hello"], fake)
        self.assertEqual(code, 100)
        self.assertFalse(fake.real_apt_ran())

    def test_unverifiable_removal_is_refused_end_to_end(self):
        fake = FakeApt(simulation="Remv mystery [1.0]\n", metadata="")
        code, _ = self._run(["remove", "mystery"], fake)
        self.assertEqual(code, helper.EXIT_POLICY)
        self.assertFalse(fake.real_apt_ran())


class AuditTests(unittest.TestCase):
    def setUp(self):
        self.logged = []
        self.log = self.logged.append

    def _run(self, arguments, fake):
        import contextlib
        import io
        with mock.patch.object(helper.os, "geteuid", return_value=0), \
             contextlib.redirect_stderr(io.StringIO()), contextlib.redirect_stdout(io.StringIO()):
            return helper.main(arguments, runner=fake, log=self.log)

    def test_accepted_request_is_logged_once_with_counts_only(self):
        fake = FakeApt(simulation="Inst hello (2.10)\n", real_stdout="SECRET-APT-OUTPUT\n")
        self._run(["install", "hello"], fake)
        self.assertEqual(len(self.logged), 1)
        line = self.logged[0]
        self.assertIn("decision=accepted", line)
        self.assertIn("action=install", line)
        self.assertIn("package=hello", line)
        self.assertIn("removals=0", line)
        self.assertNotIn("SECRET-APT-OUTPUT", line)

    def test_refused_request_is_logged_with_reason(self):
        fake = FakeApt(simulation="Remv bash [5.2]\n", metadata="bash\tno\trequired\n")
        self._run(["remove", "bash"], fake)
        self.assertEqual(len(self.logged), 1)
        self.assertIn("decision=refused", self.logged[0])
        self.assertIn("policy:", self.logged[0])

    def test_validation_refusal_is_logged_and_sanitized(self):
        fake = FakeApt()
        self._run(["install", "-oX=evil\nnewline"], fake)
        self.assertEqual(len(self.logged), 1)
        line = self.logged[0]
        self.assertIn("decision=refused", line)
        # Text is allowed to appear, but a log line must never be split by a control character.
        self.assertNotIn("\n", line)
        self.assertEqual(len(line.splitlines()), 1)

    def test_log_fields_are_bounded(self):
        long_name = "a" * 500
        self.assertLessEqual(len(helper._field(long_name)), helper.LOG_FIELD_LIMIT)

    def test_field_sanitizer_replaces_separators_and_control_characters(self):
        self.assertEqual(helper._field("ok name"), "ok?name")
        self.assertNotIn("\t", helper._field("a\tb"))

    def test_detail_keeps_key_value_pairs_intact(self):
        self.assertEqual(helper._detail("removals=0"), "removals=0")
        self.assertEqual(helper._detail("a\nb"), "a b")


if __name__ == "__main__":
    unittest.main()
