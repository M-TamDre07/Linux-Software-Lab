import json
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "flatpak" / "io.github.mtamdre07.paketscope.json"
METAINFO = ROOT / "packaging" / "io.github.mtamdre07.paketscope.metainfo.xml"
DESKTOP = ROOT / "packaging" / "paketscope.desktop"
LAUNCHER = ROOT / "packaging" / "paketscope-launcher"

FORBIDDEN_ARGS = (
    "--share=network",          # the app must not send data out
    "--filesystem=host",        # no blanket host filesystem access
    "--filesystem=home",
    "--system-bus",
    "--talk-name=org.freedesktop.PolicyKit1",
    "--talk-name=org.freedesktop.PackageKit",
    "--allow=devel",
)


class FlatpakFoundationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))

    def test_manifest_has_required_top_level_fields(self):
        for key in ("app-id", "runtime", "runtime-version", "sdk", "command", "finish-args", "modules"):
            self.assertIn(key, self.manifest)

    def test_app_id_matches_the_appstream_component_id(self):
        root = ET.parse(METAINFO).getroot()
        self.assertEqual(root.findtext("id"), self.manifest["app-id"])

    def test_launchable_desktop_file_exists_in_the_packaging_tree(self):
        root = ET.parse(METAINFO).getroot()
        launchable = root.find("launchable[@type='desktop-id']")
        self.assertIsNotNone(launchable)
        self.assertEqual(launchable.text, DESKTOP.name)
        self.assertTrue(DESKTOP.is_file())

    def test_command_matches_the_shipped_launcher(self):
        self.assertEqual(self.manifest["command"], "paketscope")
        self.assertTrue(LAUNCHER.is_file())

    def test_no_forbidden_permission_is_requested(self):
        args = self.manifest["finish-args"]
        for forbidden in FORBIDDEN_ARGS:
            with self.subTest(argument=forbidden):
                self.assertFalse(any(arg.startswith(forbidden) for arg in args))

    def test_network_is_never_granted(self):
        self.assertFalse(any("network" in arg for arg in self.manifest["finish-args"]))

    def test_sources_are_local_placeholders_not_remote_unverified_downloads(self):
        for module in self.manifest["modules"]:
            for source in module["sources"]:
                self.assertEqual(source["type"], "dir", "Ganti dengan arsip ber-sha256 sebelum Flathub.")


if __name__ == "__main__":
    unittest.main()
