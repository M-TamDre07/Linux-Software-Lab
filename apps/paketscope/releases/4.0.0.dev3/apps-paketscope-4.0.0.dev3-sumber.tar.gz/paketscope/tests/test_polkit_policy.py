import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

from paketscope import package_manager, system_inspector

ROOT = Path(__file__).resolve().parents[1]
POLICY = ROOT / "packaging" / "polkit" / "io.github.mtamdre07.paketscope.policy"
APT_ACTION = "io.github.mtamdre07.paketscope.apt-change"
INSPECT_ACTION = "io.github.mtamdre07.paketscope.inspect"


def _actions():
    return {action.get("id"): action for action in ET.parse(POLICY).getroot().findall("action")}


class PolkitPolicyTests(unittest.TestCase):
    def test_policy_defines_exactly_the_two_expected_actions(self):
        self.assertEqual(set(_actions()), {APT_ACTION, INSPECT_ACTION})

    def test_each_action_is_bound_to_one_helper_program_through_exec_path(self):
        actions = _actions()
        apt_path = actions[APT_ACTION].find("annotate[@key='org.freedesktop.policykit.exec.path']").text
        inspect_path = actions[INSPECT_ACTION].find("annotate[@key='org.freedesktop.policykit.exec.path']").text
        self.assertEqual(apt_path, package_manager.APT_HELPER_PATH)
        self.assertEqual(inspect_path, str(system_inspector.TRUSTED_HELPER))

    def test_no_action_uses_auth_admin_keep_or_allows_any_program(self):
        for action_id, action in _actions().items():
            with self.subTest(action=action_id):
                for tag in ("allow_any", "allow_inactive", "allow_active"):
                    value = action.find(f"defaults/{tag}").text
                    self.assertEqual(value, "auth_admin")
                    self.assertNotIn("keep", value)
                self.assertIsNotNone(action.find("annotate[@key='org.freedesktop.policykit.exec.path']"))

    def test_gui_execution_is_disabled_for_both_actions(self):
        for action_id, action in _actions().items():
            with self.subTest(action=action_id):
                self.assertEqual(
                    action.find("annotate[@key='org.freedesktop.policykit.exec.allow_gui']").text, "false"
                )

    def test_policy_paths_are_the_installed_helper_files(self):
        install_rules = (ROOT / "debian" / "rules").read_text(encoding="utf-8")
        self.assertIn("usr/libexec/paketscope/paketscope-apt-helper", install_rules)
        self.assertIn("usr/libexec/paketscope/paketscope-inspect-helper", install_rules)
        self.assertIn("packaging/polkit/io.github.mtamdre07.paketscope.policy", install_rules)
        self.assertIn("/usr/share/polkit-1/actions/", install_rules)

    def test_helper_source_files_exist_where_the_packaging_expects_them(self):
        self.assertTrue((ROOT / "packaging" / "helpers" / "paketscope-apt-helper").is_file())
        self.assertTrue((ROOT / "paketscope" / "admin_helper.py").is_file())
        first_line = (ROOT / "paketscope" / "admin_helper.py").read_text(encoding="utf-8").splitlines()[0]
        self.assertEqual(first_line, "#!/usr/bin/python3 -I")


if __name__ == "__main__":
    unittest.main()
