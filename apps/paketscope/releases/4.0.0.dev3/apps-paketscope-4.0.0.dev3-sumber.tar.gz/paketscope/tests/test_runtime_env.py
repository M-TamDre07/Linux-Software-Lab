import tempfile
import unittest
from pathlib import Path

from paketscope import runtime_env as R


class RuntimeDetectionTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.base = Path(self._tmp.name)

    def test_plain_host_has_all_apt_features(self):
        env = R.detect(self.base / "no-flatpak", (self.base / "no-container",))
        self.assertEqual(env.kind, "host")
        self.assertTrue(env.apt_operations)

    def test_flatpak_marker_disables_apt_features_and_explains_why(self):
        marker = self.base / ".flatpak-info"
        marker.write_text("[Application]\n", encoding="utf-8")
        env = R.detect(marker, ())
        self.assertEqual(env.kind, "flatpak")
        self.assertFalse(env.apt_operations)
        self.assertFalse(env.inventory_apt)
        self.assertIn("Flatpak", env.note)

    def test_container_marker_keeps_apt_but_notes_the_container(self):
        marker = self.base / ".containerenv"
        marker.write_text("", encoding="utf-8")
        env = R.detect(self.base / "no-flatpak", (marker,))
        self.assertEqual(env.kind, "container")
        self.assertTrue(env.apt_operations)
        self.assertIn("kontainer", env.note)

    def test_flatpak_takes_precedence_over_container_markers(self):
        flat = self.base / ".flatpak-info"
        flat.write_text("x", encoding="utf-8")
        cont = self.base / ".containerenv"
        cont.write_text("", encoding="utf-8")
        self.assertEqual(R.detect(flat, (cont,)).kind, "flatpak")


if __name__ == "__main__":
    unittest.main()
