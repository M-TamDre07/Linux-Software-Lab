import unittest
from unittest import mock

from paketscope import integrity as I
from paketscope.application_details import ApplicationDetails
from paketscope.commands import CommandResult, CommandTimedOut, CommandUnavailable


def _result(stdout="", returncode=0, stderr=""):
    return CommandResult(argv=("fake",), returncode=returncode, stdout=stdout, stderr=stderr)


class VerifyParsingTests(unittest.TestCase):
    def test_changed_binary_is_reported_as_changed(self):
        changed, missing = I.parse_verify_output("??5?????? /usr/bin/tool\n")
        self.assertEqual(changed, [I.ChangedFile("/usr/bin/tool", "berubah")])
        self.assertEqual(missing, 0)

    def test_conffile_edit_is_separated_from_real_changes(self):
        changed, _ = I.parse_verify_output("??5?????? c /etc/tool.conf\n")
        self.assertEqual(changed[0].reason, "konfigurasi diubah pengguna")

    def test_missing_file_is_counted_and_listed(self):
        changed, missing = I.parse_verify_output("missing   /usr/share/doc/x\n")
        self.assertEqual(missing, 1)
        self.assertEqual(changed[0].reason, "hilang")

    def test_all_dot_flags_mean_unchanged_and_are_skipped(self):
        changed, missing = I.parse_verify_output(".........  /usr/bin/ok\n")
        self.assertEqual(changed, [])
        self.assertEqual(missing, 0)

    def test_malformed_and_blank_lines_are_ignored(self):
        changed, _ = I.parse_verify_output("\nnot a verify line\n")
        self.assertEqual(changed, [])


class VerifyPackageTests(unittest.TestCase):
    def test_clean_package_is_cocok(self):
        with mock.patch.object(I, "run_command", side_effect=[_result(""), _result("/usr/bin/a\n/usr/bin/b\n")]):
            report = I.verify_installed_package("tool")
        self.assertEqual(report.verdict, "cocok")
        self.assertEqual(report.checked_files, 2)

    def test_real_modification_is_ada_perubahan(self):
        with mock.patch.object(I, "run_command", side_effect=[_result("??5?????? /usr/bin/a\n", 1), _result("/usr/bin/a\n")]):
            report = I.verify_installed_package("tool")
        self.assertEqual(report.verdict, "ada perubahan")
        self.assertEqual(len(report.changed), 1)

    def test_only_conffile_edits_stay_cocok_with_an_explanation(self):
        with mock.patch.object(I, "run_command", side_effect=[_result("??5?????? c /etc/t.conf\n", 1), _result("/etc/t.conf\n")]):
            report = I.verify_installed_package("tool")
        self.assertEqual(report.verdict, "cocok")
        self.assertIn("normal", report.note)

    def test_dpkg_unavailable_is_unverifiable_not_ok(self):
        with mock.patch.object(I, "run_command", side_effect=CommandUnavailable("no dpkg")):
            report = I.verify_installed_package("tool")
        self.assertEqual(report.verdict, "tidak dapat diverifikasi")

    def test_dpkg_error_without_findings_is_unverifiable(self):
        with mock.patch.object(I, "run_command", side_effect=[_result("", 2, "E: broken"), _result("")]):
            report = I.verify_installed_package("tool")
        self.assertEqual(report.verdict, "tidak dapat diverifikasi")

    def test_timeout_is_unverifiable(self):
        with mock.patch.object(I, "run_command", side_effect=CommandTimedOut("slow")):
            self.assertEqual(I.verify_installed_package("tool").verdict, "tidak dapat diverifikasi")

    def test_long_change_lists_are_bounded(self):
        many = "".join(f"??5?????? /usr/bin/f{i}\n" for i in range(I.MAX_LISTED_FILES + 5))
        with mock.patch.object(I, "run_command", side_effect=[_result(many, 1), _result("")]):
            report = I.verify_installed_package("tool")
        self.assertEqual(len(report.changed), I.MAX_LISTED_FILES)
        self.assertEqual(report.omitted_changes, 5)


class PathPolicyTests(unittest.TestCase):
    def test_path_exclude_and_include_are_parsed_from_config_text(self):
        text = "path-exclude=/usr/share/doc/*\npath-include=/usr/share/doc/*/copyright\n# note\n"
        excludes, includes = I.parse_path_policy(text)
        self.assertEqual(excludes, ("/usr/share/doc/*",))
        self.assertEqual(includes, ("/usr/share/doc/*/copyright",))

    def test_excluded_path_is_excluded_unless_an_include_rescues_it(self):
        excludes = ("/usr/share/doc/*",)
        includes = ("/usr/share/doc/*/copyright",)
        self.assertTrue(I.is_policy_excluded("/usr/share/doc/bash/NEWS.gz", excludes, includes))
        self.assertFalse(I.is_policy_excluded("/usr/share/doc/bash/copyright", excludes, includes))
        self.assertFalse(I.is_policy_excluded("/usr/bin/bash", excludes, includes))

    def test_missing_file_under_policy_exclusion_does_not_flip_the_verdict(self):
        verify = "missing     /usr/share/doc/tool/NEWS.gz\n"
        with mock.patch.object(I, "run_command", side_effect=[_result(verify, 1), _result("/usr/bin/tool\n")]), \
             mock.patch.object(I, "load_path_policy", return_value=(("/usr/share/doc/*",), ())):
            report = I.verify_installed_package("tool")
        self.assertEqual(report.verdict, "cocok")
        self.assertEqual(report.changed[0].reason, I.POLICY_EXCLUDED_REASON)

    def test_missing_binary_outside_policy_is_a_real_problem(self):
        verify = "missing     /usr/bin/tool\n"
        with mock.patch.object(I, "run_command", side_effect=[_result(verify, 1), _result("/usr/bin/tool\n")]), \
             mock.patch.object(I, "load_path_policy", return_value=(("/usr/share/doc/*",), ())):
            report = I.verify_installed_package("tool")
        self.assertEqual(report.verdict, "ada perubahan")
        self.assertEqual(report.changed[0].reason, "hilang")


class OriginAndCompatibilityTests(unittest.TestCase):
    def test_official_origin_is_recognised(self):
        self.assertTrue(I.classify_origin("http://deb.debian.org/debian trixie/main").startswith("arsip resmi"))

    def test_third_party_origin_asks_for_manual_key_verification(self):
        self.assertIn("pihak ketiga", I.classify_origin("https://repo.example.org stable/main"))

    def test_missing_origin_is_not_guessed(self):
        self.assertTrue(I.classify_origin("").startswith("tidak dapat diverifikasi"))

    def test_architecture_match_and_mismatch(self):
        host = I.HostProfile(architecture="amd64", codename="trixie")
        ok = I.compatibility_checks("amd64", "deb.debian.org trixie", host)
        self.assertEqual(ok[0].status, "cocok")
        other = I.compatibility_checks("arm64", "deb.debian.org trixie", host)
        self.assertEqual(other[0].status, "tidak cocok")
        allarch = I.compatibility_checks("all", "deb.debian.org trixie", host)
        self.assertEqual(allarch[0].status, "cocok")

    def test_unknown_architecture_is_reported_unknown(self):
        host = I.HostProfile(architecture="amd64", codename="trixie")
        self.assertEqual(I.compatibility_checks("", "x", host)[0].status, "tidak diketahui")

    def test_release_match_mismatch_and_unknown(self):
        host = I.HostProfile(architecture="amd64", codename="trixie")
        self.assertEqual(I.compatibility_checks("all", "deb.debian.org trixie/main", host)[1].status, "cocok")
        self.assertEqual(I.compatibility_checks("all", "deb.debian.org bookworm/main", host)[1].status, "tidak cocok")
        self.assertEqual(I.compatibility_checks("all", "repo.example.org stable", host)[1].status, "tidak diketahui")
        no_host = I.HostProfile(architecture="amd64", codename="")
        self.assertEqual(I.compatibility_checks("all", "deb.debian.org trixie", no_host)[1].status, "tidak diketahui")


class HostAndSmallHelpersTests(unittest.TestCase):
    def test_host_profile_reads_architecture_and_codename(self):
        with mock.patch.object(I, "run_command", return_value=_result("amd64\n")), \
             mock.patch("builtins.open", mock.mock_open(read_data='ID=debian\nVERSION_CODENAME=trixie\n')):
            host = I.read_host_profile()
        self.assertEqual(host, I.HostProfile(architecture="amd64", codename="trixie"))

    def test_host_profile_survives_missing_tools(self):
        with mock.patch.object(I, "run_command", side_effect=CommandUnavailable("no dpkg")), \
             mock.patch("builtins.open", side_effect=OSError("no file")):
            host = I.read_host_profile()
        self.assertEqual(host, I.HostProfile(architecture="unknown", codename=""))

    def test_installed_size_is_formatted_or_marked_unavailable(self):
        self.assertEqual(I.installed_size_kib({"Installed-Size": "512"}), "512 KiB")
        self.assertEqual(I.installed_size_kib({"Installed-Size": "2048"}), "2.0 MiB")
        self.assertEqual(I.installed_size_kib({}), "tidak tersedia")
        self.assertEqual(I.installed_size_kib({"Installed-Size": "abc"}), "tidak tersedia")

    def test_depends_are_split_and_bounded(self):
        self.assertEqual(I.depends_summary("libc6 (>= 2.34), tar"), ("libc6 (>= 2.34)", "tar"))
        self.assertEqual(I.depends_summary(""), ())
        self.assertEqual(len(I.depends_summary(", ".join(f"p{i}" for i in range(50)))), 30)

    def test_install_time_hint_is_unavailable_for_unknown_package(self):
        self.assertEqual(I.install_time_hint("definitely-not-a-package-xyz"), "tidak tersedia")


class ReportRenderingTests(unittest.TestCase):
    def _details(self, **kwargs):
        base = {
            "name": "tool", "identifier": "tool", "version": "1.0", "manager": "APT / dpkg",
            "package_kind": "aplikasi", "origin": "deb.debian.org trixie", "origin_note": "note",
            "description": "desc",
        }
        base.update(kwargs)
        return ApplicationDetails(**base)

    def test_report_includes_integrity_compatibility_and_extra_sections(self):
        text = self._details(
            integrity=I.IntegrityReport(package="tool", verdict="ada perubahan", checked_files=3,
                                         changed=(I.ChangedFile("/usr/bin/tool", "berubah"),),
                                         note="Beberapa file berubah."),
            compatibility=(I.CompatibilityCheck("Arsitektur", "cocok", "amd64"),),
            extra=I.ExtraInfo(installed_size="1.0 MiB", install_time="perkiraan x", index_age="y",
                              depends=("libc6",)),
        ).to_text()
        for header in ("INTEGRITAS FILE", "KOMPATIBILITAS DAN ASAL", "INFORMASI TAMBAHAN"):
            self.assertIn(header, text)
        self.assertIn("[berubah] /usr/bin/tool", text)
        self.assertIn("sama dengan saat pemasangan", text)

    def test_report_without_new_data_keeps_the_old_layout(self):
        text = self._details().to_text()
        self.assertNotIn("INTEGRITAS FILE", text)
        self.assertNotIn("KOMPATIBILITAS DAN ASAL", text)


if __name__ == "__main__":
    unittest.main()


class DerivativeCompatibilityTests(unittest.TestCase):
    """Linux Mint, LMDE, and Kali expose their own suite names and base-release aliases."""

    def test_linux_mint_origin_matches_its_own_codename(self):
        host = I.HostProfile(architecture="amd64", codename="wilma", aliases=("noble",))
        check = I.compatibility_checks("all", "packages.linuxmint.com wilma/main", host)[1]
        self.assertEqual(check.status, "cocok")

    def test_mint_package_from_the_ubuntu_base_matches_the_base_alias(self):
        host = I.HostProfile(architecture="amd64", codename="wilma", aliases=("noble",))
        check = I.compatibility_checks("all", "archive.ubuntu.com noble/main", host)[1]
        self.assertEqual(check.status, "cocok")

    def test_lmde_origin_matches_its_debian_base_alias(self):
        host = I.HostProfile(architecture="amd64", codename="gigi", aliases=("trixie",))
        check = I.compatibility_checks("all", "deb.debian.org trixie/main", host)[1]
        self.assertEqual(check.status, "cocok")

    def test_kali_rolling_origin_matches_kali_host(self):
        host = I.HostProfile(architecture="amd64", codename="kali-rolling")
        check = I.compatibility_checks("all", "http.kali.org kali-rolling/main", host)[1]
        self.assertEqual(check.status, "cocok")

    def test_a_different_release_is_still_reported_as_not_matching(self):
        host = I.HostProfile(architecture="amd64", codename="wilma", aliases=("noble",))
        check = I.compatibility_checks("all", "archive.ubuntu.com jammy/main", host)[1]
        self.assertEqual(check.status, "tidak cocok")

    def test_mint_and_kali_repositories_are_recognised_as_official_not_third_party(self):
        self.assertTrue(I.classify_origin("packages.linuxmint.com wilma/main").startswith("arsip resmi"))
        self.assertTrue(I.classify_origin("http.kali.org kali-rolling/main").startswith("arsip resmi"))

    def test_host_profile_reads_base_aliases_from_os_release(self):
        text = 'VERSION_CODENAME=wilma\nUBUNTU_CODENAME=noble\n'
        with mock.patch.object(I, "run_command", return_value=_result("amd64\n")), \
             mock.patch("builtins.open", mock.mock_open(read_data=text)):
            host = I.read_host_profile()
        self.assertEqual(host.codename, "wilma")
        self.assertEqual(host.aliases, ("noble",))
