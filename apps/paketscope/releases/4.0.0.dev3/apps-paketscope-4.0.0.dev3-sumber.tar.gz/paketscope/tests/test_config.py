import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from paketscope import config as C


class ConfigTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = Path(self._tmp.name) / "paketscope" / C.CONFIG_FILE_NAME

    def test_missing_file_gives_defaults_without_warnings(self):
        result = C.load_config(self.path)
        self.assertEqual(result.values, C.default_values())
        self.assertEqual(result.warnings, ())

    def test_defaults_keep_risky_features_off(self):
        values = C.default_values()
        self.assertFalse(values["malware_scan_enabled"])
        self.assertTrue(values["update_check_enabled"])

    def test_invalid_values_fall_back_to_defaults_and_are_reported(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text(json.dumps({"schema_version": 2, "scan_timeout_seconds": 99999,
                                         "malware_scan_enabled": "yes"}), encoding="utf-8")
        result = C.load_config(self.path)
        self.assertEqual(result.values["scan_timeout_seconds"], 60)
        self.assertFalse(result.values["malware_scan_enabled"])
        self.assertEqual(len(result.warnings), 2)

    def test_boolean_is_not_accepted_as_an_integer(self):
        value, note = C._validate("scan_timeout_seconds", True)
        self.assertEqual(value, 60)
        self.assertTrue(note)

    def test_version_one_file_is_migrated_and_reported(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text(json.dumps({"update_check_enabled": False}), encoding="utf-8")
        result = C.load_config(self.path)
        self.assertFalse(result.values["update_check_enabled"])
        self.assertEqual(result.values["log_retention_days"], 30)
        self.assertEqual(result.migrated_from, 1)

    def test_newer_schema_is_never_overwritten(self):
        self.path.parent.mkdir(parents=True)
        original = json.dumps({"schema_version": 99, "x": 1})
        self.path.write_text(original, encoding="utf-8")
        result = C.load_config(self.path)
        self.assertTrue(any("lebih baru" in item for item in result.warnings))
        self.assertEqual(self.path.read_text(encoding="utf-8"), original)

    def test_corrupt_file_is_quarantined_not_deleted(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text("{ broken", encoding="utf-8")
        result = C.load_config(self.path)
        self.assertFalse(self.path.exists())
        self.assertTrue(result.quarantined)
        self.assertEqual(Path(result.quarantined).read_text(encoding="utf-8"), "{ broken")
        self.assertEqual(result.values, C.default_values())

    def test_save_is_atomic_and_leaves_no_temporary_files(self):
        C.save_config(self.path, {"scan_timeout_seconds": 120})
        leftovers = [p for p in self.path.parent.iterdir() if p.suffix == ".tmp"]
        self.assertEqual(leftovers, [])
        self.assertEqual(json.loads(self.path.read_text(encoding="utf-8"))["scan_timeout_seconds"], 120)

    def test_failed_write_keeps_the_previous_file_intact(self):
        C.save_config(self.path, {"log_retention_days": 7})
        before = self.path.read_text(encoding="utf-8")
        with mock.patch("paketscope.config.os.replace", side_effect=OSError("disk full")), \
             self.assertRaises(OSError):
            C.save_config(self.path, {"log_retention_days": 90})
        self.assertEqual(self.path.read_text(encoding="utf-8"), before)
        self.assertEqual([p for p in self.path.parent.iterdir() if p.suffix == ".tmp"], [])

    def test_update_value_changes_one_key_only(self):
        C.save_config(self.path, {"log_retention_days": 7, "malware_scan_enabled": False})
        C.update_value(self.path, "malware_scan_enabled", True)
        values = C.load_config(self.path).values
        self.assertTrue(values["malware_scan_enabled"])
        self.assertEqual(values["log_retention_days"], 7)

    def test_unknown_key_cannot_be_written(self):
        with self.assertRaises(KeyError):
            C.update_value(self.path, "telemetry", True)

    def test_saved_file_contains_no_identifier_fields(self):
        C.save_config(self.path, C.default_values())
        keys = set(json.loads(self.path.read_text(encoding="utf-8")))
        self.assertTrue(keys <= set(C.SCHEMA) | {"schema_version"})


if __name__ == "__main__":
    unittest.main()
