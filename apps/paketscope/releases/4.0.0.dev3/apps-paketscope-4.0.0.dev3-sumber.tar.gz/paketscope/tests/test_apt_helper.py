import importlib.machinery
import importlib.util
import subprocess
import unittest
from pathlib import Path
from unittest import mock

HELPER_PATH = Path(__file__).resolve().parents[1] / "packaging" / "helpers" / "paketscope-apt-helper"
_loader = importlib.machinery.SourceFileLoader("paketscope_apt_helper", str(HELPER_PATH))
_spec = importlib.util.spec_from_loader("paketscope_apt_helper", _loader)
helper = importlib.util.module_from_spec(_spec)
_loader.exec_module(helper)


class BuildCommandTests(unittest.TestCase):
    def test_install_uses_fixed_argv_with_no_remove(self):
        self.assertEqual(
            helper.build_command(["install", "firefox"]),
            ["/usr/bin/apt-get", "--assume-yes", "-o", "Dpkg::Use-Pty=0",
             "--no-install-recommends", "--no-remove", "install", "firefox"],
        )

    def test_remove_and_purge_never_add_no_remove(self):
        for action in ("remove", "purge"):
            with self.subTest(action=action):
                command = helper.build_command([action, "firefox"])
                self.assertNotIn("--no-remove", command)
                self.assertEqual(command[-2:], [action, "firefox"])

    def test_valid_debian_name_bash_is_not_a_security_rule(self):
        # "bash" is a legal Debian package name; the helper must not block it by name.
        self.assertEqual(helper.build_command(["remove", "bash"])[-1], "bash")

    def test_architecture_qualified_name_is_allowed(self):
        self.assertEqual(helper.build_command(["remove", "libc6:amd64"])[-1], "libc6:amd64")

    def test_wrong_argument_count_is_refused(self):
        for arguments in ([], ["install"], ["install", "a", "b"]):
            with self.subTest(arguments=arguments), self.assertRaises(helper.HelperError):
                helper.build_command(arguments)

    def test_unknown_action_is_refused(self):
        for action in ("upgrade", "update", "autoremove", "Install"):
            with self.subTest(action=action), self.assertRaises(helper.HelperError):
                helper.build_command([action, "firefox"])

    def test_option_injection_through_package_name_is_refused(self):
        # A leading dash would make the package name an apt-get option.
        for name in ("-oAPT::Update::Post-Invoke=id", "--allow-downgrades", "-y"):
            with self.subTest(name=name), self.assertRaises(helper.HelperError):
                helper.build_command(["install", name])

    def test_invalid_names_are_refused(self):
        for name in ("", "../etc", "a;rm", "Firefox", "firefox$(id)", "a b", "x" * 300 + "/"):
            with self.subTest(name=name), self.assertRaises(helper.HelperError):
                helper.build_command(["install", name])


class MainTests(unittest.TestCase):
    def test_non_root_is_refused_before_anything_runs(self):
        with mock.patch.object(helper.os, "geteuid", return_value=1000), \
             mock.patch.object(helper.subprocess, "run") as run:
            self.assertEqual(helper.main(["install", "firefox"]), 126)
            run.assert_not_called()

    def test_invalid_request_returns_2_and_never_runs_apt(self):
        with mock.patch.object(helper.os, "geteuid", return_value=0), \
             mock.patch.object(helper.subprocess, "run") as run:
            self.assertEqual(helper.main(["install", "-oX=1"]), 2)
            run.assert_not_called()

    def test_valid_request_runs_apt_with_sanitized_environment_and_no_shell(self):
        completed = subprocess.CompletedProcess(args=[], returncode=0, stdout="ok\n", stderr="")
        with mock.patch.object(helper.os, "geteuid", return_value=0), \
             mock.patch.object(helper.subprocess, "run", return_value=completed) as run:
            self.assertEqual(helper.main(["remove", "firefox"]), 0)
        argv = run.call_args.args[0]
        kwargs = run.call_args.kwargs
        self.assertEqual(argv[-2:], ["remove", "firefox"])
        self.assertFalse(kwargs["shell"])
        self.assertEqual(kwargs["env"], helper.SAFE_ENVIRONMENT)
        self.assertEqual(kwargs["env"]["DEBIAN_FRONTEND"], "noninteractive")
        self.assertEqual(kwargs["env"]["PATH"], "/usr/sbin:/usr/bin:/sbin:/bin")

    def test_apt_exit_code_is_propagated(self):
        failed = subprocess.CompletedProcess(args=[], returncode=100, stdout="", stderr="E: broken\n")
        with mock.patch.object(helper.os, "geteuid", return_value=0), \
             mock.patch.object(helper.subprocess, "run", return_value=failed):
            self.assertEqual(helper.main(["install", "firefox"]), 100)


if __name__ == "__main__":
    unittest.main()
