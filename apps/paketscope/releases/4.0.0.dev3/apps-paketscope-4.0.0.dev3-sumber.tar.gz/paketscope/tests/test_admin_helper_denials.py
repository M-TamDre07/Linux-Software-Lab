import os
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from paketscope import admin_helper as helper

# The helper refuses any path whose components are not root-owned and not group/other
# writable, so /tmp (mode 1777) can never be a fixture location. These tests check root
# ownership semantics, so they run only as root and build their tree under /var/lib.
FIXTURE_PARENT = "/var/lib"


@unittest.skipUnless(os.geteuid() == 0, "requires root: the helper validates root ownership")
class ReadTextFileDenialTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.mkdtemp(prefix="paketscope-test-", dir=FIXTURE_PARENT)
        self.addCleanup(lambda: shutil.rmtree(self._tmp, ignore_errors=True))
        self.base = Path(self._tmp).resolve()
        os.chmod(self.base, 0o755)
        self.allowed = self.base / "allowed"
        self.allowed.mkdir()
        os.chmod(self.allowed, 0o755)
        # Redirect the allowlist into the fixture tree; the code reads it at call time.
        patcher = mock.patch.object(helper, "ALLOWED_ROOTS", (self.allowed,))
        patcher.start()
        self.addCleanup(patcher.stop)

    def _file(self, name, data=b"hello\n"):
        path = self.allowed / name
        path.write_bytes(data)
        return path

    def assertDenied(self, raw_path, pattern=None):
        with self.assertRaises(ValueError) as ctx:
            helper.read_text_file(str(raw_path))
        if pattern:
            self.assertRegex(str(ctx.exception), pattern)

    def test_valid_small_utf8_file_is_read(self):
        path = self._file("notes.txt", b"halo\n")
        result = helper.read_text_file(str(path))
        self.assertEqual(result["content"], "halo\n")
        self.assertEqual(result["scope"], "selected-text-file-read-only")

    def test_relative_path_is_refused(self):
        self.assertDenied("allowed/notes.txt", r"absolute")

    def test_traversal_is_refused(self):
        self.assertDenied(str(self.allowed) + "/../allowed/notes.txt", r"traversal")

    def test_path_outside_allowed_roots_is_refused(self):
        outside = self.base / "outside.txt"
        outside.write_text("x", encoding="utf-8")
        self.assertDenied(outside, r"outside the allowed")

    def test_the_allowed_root_itself_is_not_a_readable_file(self):
        self.assertDenied(self.allowed, r"outside the allowed|Only regular")

    def test_excluded_secret_file_names_are_refused(self):
        for name in ("id_rsa", "shadow", "authorized_keys", ".env.local", "server.key", "cert.pem"):
            with self.subTest(name=name):
                self._file(name)
                self.assertDenied(self.allowed / name, r"sensitive")

    def test_excluded_secret_directory_is_refused(self):
        secret_dir = self.allowed / "private"
        secret_dir.mkdir()
        self._file("private/data.txt")
        self.assertDenied(secret_dir / "data.txt", r"sensitive")

    def test_symlinked_file_is_refused(self):
        target = self._file("real.txt")
        link = self.allowed / "link.txt"
        os.symlink(target, link)
        self.assertDenied(link, r"Symlinks")

    def test_symlinked_parent_directory_is_refused(self):
        real = self.base / "real_dir"
        real.mkdir()
        (real / "data.txt").write_text("x", encoding="utf-8")
        link_dir = self.allowed / "linked"
        os.symlink(real, link_dir)
        self.assertDenied(link_dir / "data.txt", r"Symlinks")

    def test_directory_is_not_a_text_file(self):
        (self.allowed / "subdir").mkdir()
        self.assertDenied(self.allowed / "subdir", r"Only regular")

    def test_oversized_file_is_refused(self):
        self._file("big.txt", b"a" * (helper.MAX_TEXT_FILE_BYTES + 1))
        self.assertDenied(self.allowed / "big.txt", r"KiB limit")

    def test_binary_file_is_refused(self):
        self._file("bin.dat", b"abc\x00def")
        self.assertDenied(self.allowed / "bin.dat", r"Binary|oversized")

    def test_non_utf8_file_is_refused(self):
        self._file("latin.txt", b"caf\xe9\n")
        self.assertDenied(self.allowed / "latin.txt", r"not UTF-8")

    def test_group_writable_parent_is_refused(self):
        writable = self.allowed / "open"
        writable.mkdir()
        os.chmod(writable, 0o777)
        self._file("open/notes.txt")
        self.assertDenied(writable / "notes.txt", r"root-owned and not group/other writable")

    def test_missing_file_is_refused(self):
        self.assertDenied(self.allowed / "missing.txt", r"cannot be accessed|not available")


class SecretExclusionTests(unittest.TestCase):
    def test_excluded_helpers_are_case_insensitive(self):
        self.assertTrue(helper._excluded(Path("/etc/SSH/config")))
        self.assertTrue(helper._excluded(Path("/etc/ID_RSA")))
        self.assertFalse(helper._excluded(Path("/etc/hostname")))


class CliAndTrustTests(unittest.TestCase):
    def test_unknown_arguments_return_2_and_print_usage(self):
        import contextlib
        import io
        buf = io.StringIO()
        with contextlib.redirect_stderr(buf):
            self.assertEqual(helper.main(["--bogus"]), 2)
        self.assertIn("Supported actions", buf.getvalue())

    def test_read_text_with_wrong_argument_shape_returns_2(self):
        self.assertEqual(helper.main(["--read-text"]), 2)

    def test_untrusted_install_location_returns_1_and_writes_no_json(self):
        import contextlib
        import io
        out = io.StringIO(); err = io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            self.assertEqual(helper.main(["--metadata"]), 1)
        self.assertEqual(out.getvalue(), "")
        self.assertIn("trusted", err.getvalue())

    def test_non_root_is_refused_by_the_trust_check(self):
        with mock.patch.object(helper.os, "geteuid", return_value=1000), \
             self.assertRaises(PermissionError):
            helper._require_trusted_root_install()

    def test_resolved_path_must_be_the_installed_helper(self):
        with mock.patch.object(helper.os, "geteuid", return_value=0), \
             mock.patch.object(helper, "TRUSTED_FILE", Path("/usr/libexec/paketscope/somewhere-else")), \
             self.assertRaises(PermissionError):
            helper._require_trusted_root_install()


@unittest.skipUnless(os.geteuid() == 0, "requires root: metadata collection reads root-owned trees")
class MetadataCollectionTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.mkdtemp(prefix="paketscope-meta-", dir=FIXTURE_PARENT)
        self.addCleanup(lambda: shutil.rmtree(self._tmp, ignore_errors=True))
        self.root = Path(self._tmp).resolve()
        os.chmod(self.root, 0o755)
        (self.root / "visible.conf").write_text("x", encoding="utf-8")
        (self.root / "private").mkdir()
        (self.root / "private" / "token.txt").write_text("secret", encoding="utf-8")
        (self.root / "real.conf").write_text("y", encoding="utf-8")
        os.symlink(self.root / "real.conf", self.root / "link.conf")
        patcher = mock.patch.object(helper, "ALLOWED_ROOTS", (self.root,))
        patcher.start(); self.addCleanup(patcher.stop)

    def test_symlinks_and_secret_directories_are_omitted_from_metadata(self):
        names = {Path(entry["path"]).name for entry in helper.collect_metadata()["entries"]}
        self.assertIn("visible.conf", names)
        self.assertIn("real.conf", names)
        self.assertNotIn("link.conf", names)
        self.assertNotIn("token.txt", names)
        self.assertNotIn("private", names)

    def test_metadata_contains_no_file_contents(self):
        payload = str(helper.collect_metadata())
        self.assertNotIn("secret", payload)
        self.assertNotIn("content", payload)


if __name__ == "__main__":
    unittest.main()
