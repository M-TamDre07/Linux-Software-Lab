import tempfile
import unittest
from pathlib import Path
from unittest import mock

from paketscope import discovery as D


def _entry(name, exec_line, extra=""):
    return f"[Desktop Entry]\nType=Application\nName={name}\nExec={exec_line}\n{extra}"


class ParsingTests(unittest.TestCase):
    def test_only_the_desktop_entry_group_is_read(self):
        text = "[Desktop Action x]\nExec=evil\n[Desktop Entry]\nName=App\nExec=app\n"
        fields = D.parse_desktop_entry(text)
        self.assertEqual(fields["Exec"], "app")

    def test_localised_keys_are_ignored_for_matching(self):
        fields = D.parse_desktop_entry("[Desktop Entry]\nName[id]=Aplikasi\nName=App\n")
        self.assertEqual(fields["Name"], "App")

    def test_executable_is_the_first_shell_word(self):
        self.assertEqual(D.executable_of({"Exec": '"/opt/My App/run" --flag %U'}), "/opt/My App/run")

    def test_env_prefix_and_variable_assignments_are_skipped(self):
        exec_line = "env WINEPREFIX=/x wine start /unix game.exe"
        self.assertEqual(D.executable_of({"Exec": exec_line}), "wine")


class ClassificationTests(unittest.TestCase):
    def test_appimage_is_recognised_from_exec(self):
        fields = D.parse_desktop_entry(_entry("Tool", "/home/u/Apps/Tool-x86_64.AppImage %U"))
        self.assertEqual(D.classify_source("/home/u/.local/share/applications/tool.desktop", fields, set()), D.SOURCE_APPIMAGE)

    def test_wine_program_is_recognised_from_exec_and_wine_folder(self):
        fields = D.parse_desktop_entry(_entry("Game", "env WINEPREFIX=/x wine start /unix game.exe"))
        self.assertEqual(D.classify_source("/home/u/.local/share/applications/game.desktop", fields, set()), D.SOURCE_WINE)
        plain = D.parse_desktop_entry(_entry("Prog", "/opt/prog/run"))
        self.assertEqual(
            D.classify_source("/home/u/.local/share/applications/wine/Programs/prog.desktop", plain, set()),
            D.SOURCE_WINE,
        )

    def test_waydroid_android_app_is_recognised(self):
        fields = D.parse_desktop_entry(_entry("Chat", "waydroid app launch com.example.chat"))
        self.assertEqual(D.classify_source("/home/u/.local/share/applications/waydroid.chat.desktop", fields, set()), D.SOURCE_WAYDROID)

    def test_snap_is_recognised_from_its_export_folder(self):
        fields = D.parse_desktop_entry(_entry("Editor", "/snap/bin/editor"))
        self.assertEqual(
            D.classify_source("/var/lib/snapd/desktop/applications/editor.desktop", fields, set()),
            D.SOURCE_SNAP,
        )

    def test_unrecognised_launcher_is_labelled_manual_not_guessed(self):
        fields = D.parse_desktop_entry(_entry("Mystery", "/opt/anon/bin/x"))
        self.assertEqual(D.classify_source("/usr/local/share/applications/x.desktop", fields, set()), D.SOURCE_MANUAL)

    def test_apt_owned_launcher_is_attributed_to_apt(self):
        fields = D.parse_desktop_entry(_entry("Firefox", "firefox %u"))
        owned = {"/usr/share/applications/firefox.desktop"}
        self.assertEqual(D.classify_source("/usr/share/applications/firefox.desktop", fields, owned), D.SOURCE_APT)

    def test_flatpak_exported_launcher_is_left_to_the_flatpak_provider(self):
        fields = D.parse_desktop_entry(_entry("Viewer", "flatpak run org.example.Viewer"))
        path = "/var/lib/flatpak/exports/share/applications/org.example.Viewer.desktop"
        self.assertIsNone(D.classify_source(path, fields, set()))


class ScanTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.base = Path(self._tmp.name)

    def _write(self, folder, name, text):
        folder.mkdir(parents=True, exist_ok=True)
        (folder / name).write_text(text, encoding="utf-8")

    def test_scan_reports_only_non_package_sources_and_counts_each_once(self):
        user = self.base / "user"
        system = self.base / "system"
        self._write(user, "tool.desktop", _entry("Tool", "/home/u/Tool.AppImage"))
        self._write(system, "tool.desktop", _entry("Tool (sistem)", "/usr/bin/tool"))  # user copy wins
        self._write(system, "firefox.desktop", _entry("Firefox", "firefox"))  # owned by APT
        owned = {str(system / "firefox.desktop")}
        apps, _ = D.scan_desktop_entries([user, system], dpkg_owned=owned)
        names = [app.name for app in apps]
        self.assertEqual(names, ["Tool"])
        self.assertEqual(apps[0].source, D.SOURCE_APPIMAGE)

    def test_oversized_and_non_application_entries_are_skipped(self):
        folder = self.base / "apps"
        self._write(folder, "link.desktop", "[Desktop Entry]\nType=Link\nName=Link\nURL=https://x\n")
        self._write(folder, "big.desktop", _entry("Big", "/opt/big") + ("#" * (D.MAX_DESKTOP_BYTES + 10)))
        apps, _ = D.scan_desktop_entries([folder], dpkg_owned=set())
        self.assertEqual(apps, [])

    def test_scan_stops_at_the_file_limit_with_a_diagnostic(self):
        folder = self.base / "many"
        for index in range(D.MAX_DESKTOP_FILES + 5):
            self._write(folder, f"app{index:04d}.desktop", _entry(f"A{index}", f"/opt/a{index}"))
        with mock.patch.object(D, "MAX_DESKTOP_FILES", 10):
            apps, diagnostics = D.scan_desktop_entries([folder], dpkg_owned=set())
        self.assertLessEqual(len(apps), 10)
        self.assertTrue(any("dihentikan" in item for item in diagnostics))

    def test_missing_directories_produce_no_error(self):
        apps, diagnostics = D.scan_desktop_entries([self.base / "absent"], dpkg_owned=set())
        self.assertEqual((apps, diagnostics), ([], []))


class DpkgOwnershipTests(unittest.TestCase):
    def test_desktop_paths_listed_in_dpkg_lists_are_collected(self):
        with tempfile.TemporaryDirectory() as tmp:
            info = Path(tmp)
            (info / "firefox.list").write_text("/usr/bin/firefox\n/usr/share/applications/firefox.desktop\n", encoding="utf-8")
            owned = D.load_dpkg_owned_paths(info)
        self.assertEqual(owned, {"/usr/share/applications/firefox.desktop"})

    def test_missing_dpkg_database_is_an_empty_set(self):
        self.assertEqual(D.load_dpkg_owned_paths(Path("/definitely/absent")), set())


class ProviderContractTests(unittest.TestCase):
    def test_provider_returns_results_and_never_executes_launchers(self):
        with mock.patch.object(D, "scan_desktop_entries", return_value=([], [])), \
             mock.patch("subprocess.run") as run, mock.patch("subprocess.Popen") as popen:
            result = D.DesktopEntryProvider().collect()
        self.assertEqual(result.applications, ())
        run.assert_not_called()
        popen.assert_not_called()


if __name__ == "__main__":
    unittest.main()
