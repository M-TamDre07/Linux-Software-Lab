import contextlib
import io
import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from paketscope import admin_helper as helper

FIXTURE_PARENT = "/var/lib"
ROOT_ONLY = unittest.skipUnless(os.geteuid() == 0, "requires root: ownership semantics")


@ROOT_ONLY
class TrustedInstallChainTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.mkdtemp(prefix="paketscope-trust-", dir=FIXTURE_PARENT)
        self.addCleanup(lambda: shutil.rmtree(self._tmp, ignore_errors=True))
        self.base = Path(self._tmp).resolve()
        os.chmod(self.base, 0o755)

    def test_helper_outside_the_usr_tree_is_refused(self):
        script = self.base / "paketscope-inspect-helper"
        script.write_text("# fixture\n", encoding="utf-8")
        os.chmod(script, 0o755)
        with mock.patch.object(helper, "__file__", str(script)), \
             mock.patch.object(helper, "TRUSTED_FILE", script), \
             mock.patch.object(helper.os, "geteuid", return_value=0), \
             self.assertRaisesRegex(PermissionError, "outside the system package location"):
            helper._require_trusted_root_install()

    def test_group_writable_helper_is_refused(self):
        script = self.base / "paketscope-inspect-helper"
        script.write_text("# fixture\n", encoding="utf-8")
        os.chmod(script, 0o777)
        with mock.patch.object(helper, "__file__", str(script)), \
             mock.patch.object(helper, "TRUSTED_FILE", script), \
             mock.patch.object(helper.os, "geteuid", return_value=0), \
             self.assertRaisesRegex(PermissionError, "root-owned and not writable"):
            helper._require_trusted_root_install()


@ROOT_ONLY
class ValidationBranchTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.mkdtemp(prefix="paketscope-branch-", dir=FIXTURE_PARENT)
        self.addCleanup(lambda: shutil.rmtree(self._tmp, ignore_errors=True))
        self.base = Path(self._tmp).resolve()
        os.chmod(self.base, 0o755)
        self.allowed = self.base / "allowed"
        self.allowed.mkdir()
        os.chmod(self.allowed, 0o755)
        patcher = mock.patch.object(helper, "ALLOWED_ROOTS", (self.allowed,))
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_a_regular_file_used_as_a_parent_component_is_refused(self):
        (self.allowed / "plain.txt").write_text("x", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "Every parent component must be a directory"):
            helper.read_text_file(str(self.allowed / "plain.txt" / "child.txt"))

    def test_missing_file_reports_it_cannot_be_accessed(self):
        with self.assertRaisesRegex(ValueError, "cannot be accessed"):
            helper.read_text_file(str(self.allowed / "absent.txt"))

    def test_entry_for_an_unreadable_path_is_skipped(self):
        self.assertIsNone(helper._entry(self.allowed / "does-not-exist"))

    def test_symlinked_root_is_not_scanned(self):
        target = self.base / "real-root"
        target.mkdir()
        link = self.base / "linked-root"
        os.symlink(target, link)
        with mock.patch.object(helper, "ALLOWED_ROOTS", (link,)):
            self.assertEqual(helper.collect_metadata()["entries"], [])


@ROOT_ONLY
class MetadataCapTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.mkdtemp(prefix="paketscope-cap-", dir=FIXTURE_PARENT)
        self.addCleanup(lambda: shutil.rmtree(self._tmp, ignore_errors=True))
        self.root = Path(self._tmp).resolve()
        os.chmod(self.root, 0o755)
        patcher = mock.patch.object(helper, "ALLOWED_ROOTS", (self.root,))
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_entry_cap_is_enforced_and_reported_as_a_diagnostic(self):
        for index in range(3010):
            (self.root / f"f{index:05d}.txt").write_text("", encoding="utf-8")
        payload = helper.collect_metadata()
        self.assertLessEqual(len(payload["entries"]), 3000)
        joined = " ".join(payload["diagnostics"])
        self.assertIn("Entry limit 3000 reached", joined)


@ROOT_ONLY
class CliSuccessPathTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.mkdtemp(prefix="paketscope-cli-", dir=FIXTURE_PARENT)
        self.addCleanup(lambda: shutil.rmtree(self._tmp, ignore_errors=True))
        self.root = Path(self._tmp).resolve()
        os.chmod(self.root, 0o755)
        self.note = self.root / "note.txt"
        self.note.write_text("halo\n", encoding="utf-8")
        patchers = [
            mock.patch.object(helper, "ALLOWED_ROOTS", (self.root,)),
            # The trust chain is covered above; here we test the CLI contract once trust passes.
            mock.patch.object(helper, "_require_trusted_root_install", lambda: None),
        ]
        for patcher in patchers:
            patcher.start()
            self.addCleanup(patcher.stop)

    def _main(self, args):
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = helper.main(args)
        return code, out.getvalue(), err.getvalue()

    def test_read_text_success_prints_json_and_returns_zero(self):
        code, out, _ = self._main(["--read-text", str(self.note)])
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(out)["content"], "halo\n")

    def test_metadata_success_prints_json_and_returns_zero(self):
        code, out, _ = self._main(["--metadata"])
        self.assertEqual(code, 0)
        self.assertIn("entries", json.loads(out))

    def test_read_text_refusal_returns_one_with_message_on_stderr(self):
        code, out, err = self._main(["--read-text", "relative.txt"])
        self.assertEqual(code, 1)
        self.assertEqual(out, "")
        self.assertIn("absolute", err)


if __name__ == "__main__":
    unittest.main()
