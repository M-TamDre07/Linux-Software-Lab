import tempfile
import unittest
from pathlib import Path

from PySide6.QtWidgets import QApplication

from paketscope import accessibility as A
from paketscope import onboarding as O
from paketscope.ui.onboarding_dialog import (
    PALETTE_LABELS,
    OnboardingDialog,
    scaled_point_size,
)


def _app():
    return QApplication.instance() or QApplication([])


class ScaledSizeTests(unittest.TestCase):
    def test_scale_multiplies_the_base_size(self):
        self.assertEqual(scaled_point_size(1.0, base=10), 10.0)
        self.assertEqual(scaled_point_size(1.5, base=10), 15.0)

    def test_scale_is_clamped(self):
        self.assertEqual(scaled_point_size(0.1, base=10), 10.0)
        self.assertEqual(scaled_point_size(9, base=10), 20.0)


class OnboardingDialogTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.qapp = _app()

    def test_dialog_starts_on_the_first_step_with_skip_available(self):
        dialog = OnboardingDialog(A.AccessibilitySettings())
        self.addCleanup(dialog.deleteLater)
        self.assertEqual(dialog.current_step_key(), "selamat-datang")
        self.assertTrue(dialog._skip.isEnabled())
        self.assertFalse(dialog._back.isEnabled())

    def test_skip_is_available_on_every_step_and_records_the_choice(self):
        for index in range(len(O.STEPS)):
            dialog = OnboardingDialog(A.AccessibilitySettings())
            self.addCleanup(dialog.deleteLater)
            dialog.go_to(index)
            self.assertTrue(dialog._skip.isEnabled(), f"skip missing on step {index}")
            dialog._skip.click()
            self.assertTrue(dialog.result_settings.onboarding_skipped)
            self.assertTrue(dialog.result_settings.onboarding_completed)

    def test_next_walks_the_steps_and_finish_keeps_the_chosen_palette(self):
        dialog = OnboardingDialog(A.AccessibilitySettings())
        self.addCleanup(dialog.deleteLater)
        for _ in range(len(O.STEPS) - 1):
            dialog._next.click()
        self.assertEqual(dialog.current_step_key(), "selesai")
        dialog._palette.setCurrentIndex(A.PALETTES.index(A.PALETTE_COLOUR_VISION))
        dialog._next.click()
        self.assertFalse(dialog.result_settings.onboarding_skipped)
        self.assertTrue(dialog.result_settings.onboarding_completed)
        self.assertEqual(dialog.result_settings.palette, A.PALETTE_COLOUR_VISION)

    def test_accessibility_choices_are_offered_on_their_step_only(self):
        dialog = OnboardingDialog(A.AccessibilitySettings())
        self.addCleanup(dialog.deleteLater)
        dialog.go_to(0)
        self.assertFalse(dialog._options.isVisibleTo(dialog))
        dialog.go_to([s.key for s in O.STEPS].index("aksesibilitas"))
        self.assertEqual(dialog.current_step_key(), "aksesibilitas")

    def test_every_palette_has_a_plain_language_label(self):
        for key in A.PALETTES:
            self.assertTrue(PALETTE_LABELS[key])

    def test_saved_choice_round_trips_through_the_settings_file(self):
        dialog = OnboardingDialog(A.AccessibilitySettings())
        self.addCleanup(dialog.deleteLater)
        dialog._skip.click()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "accessibility.json"
            A.save_settings(dialog.result_settings, path)
            again = A.load_settings(path)
        self.assertFalse(O.should_show(again))


if __name__ == "__main__":
    unittest.main()
