import unittest
from unittest import mock

from paketscope import package_manager as pm
from paketscope.commands import CommandResult, CommandTimedOut, CommandUnavailable


def _result(stdout="", stderr="", returncode=0, argv=("fake",)):
    return CommandResult(argv=tuple(argv), returncode=returncode, stdout=stdout, stderr=stderr)


class ControlParsingTests(unittest.TestCase):
    def test_continuation_lines_are_ignored_and_fields_are_split_on_first_colon(self):
        fields = pm._parse_control_fields("Package: tar\nDescription: archive: tool\n more text\nPriority: required\n")
        self.assertEqual(fields["Package"], "tar")
        self.assertEqual(fields["Description"], "archive: tool")
        self.assertEqual(fields["Priority"], "required")


class SearchTests(unittest.TestCase):
    def test_non_string_query_is_refused(self):
        with self.assertRaisesRegex(pm.PackageOperationError, "tidak valid"):
            pm.search_apt_packages(None)  # type: ignore[arg-type]

    def test_query_with_disallowed_characters_is_refused(self):
        with self.assertRaisesRegex(pm.PackageOperationError, "Gunakan 1"):
            pm.search_apt_packages("bad;name")

    def test_command_unavailable_or_timeout_is_reported(self):
        for exc in (CommandUnavailable("no apt-cache"), CommandTimedOut("slow")):
            with self.subTest(exc=type(exc).__name__), \
                 mock.patch.object(pm, "run_command", side_effect=exc), \
                 self.assertRaises(pm.PackageOperationError):
                pm.search_apt_packages("firefox")

    def test_nonzero_exit_reports_the_last_stderr_line(self):
        failed = _result(stderr="E: broken cache\nE: last line\n", returncode=100)
        with mock.patch.object(pm, "run_command", return_value=failed), \
             self.assertRaisesRegex(pm.PackageOperationError, "last line"):
            pm.search_apt_packages("firefox")

    def test_results_are_deduplicated_and_limit_is_capped(self):
        output = "\n".join(f"pkg{i % 3} - description {i}" for i in range(20))
        with mock.patch.object(pm, "run_command", return_value=_result(stdout=output)):
            matches = pm.search_apt_packages("pkg", limit=2)
        self.assertEqual(len(matches), 2)
        self.assertEqual(len({m.name for m in matches}), 2)

    def test_limit_is_clamped_to_at_least_one(self):
        with mock.patch.object(pm, "run_command", return_value=_result(stdout="one - x\ntwo - y\n")):
            self.assertEqual(len(pm.search_apt_packages("o", limit=0)), 1)


class RemovalSafetyMetadataTests(unittest.TestCase):
    def test_metadata_query_unavailable_refuses_removal(self):
        with mock.patch.object(pm, "run_command", side_effect=CommandUnavailable("no dpkg")), \
             self.assertRaisesRegex(pm.PackageOperationError, "Tidak dapat memverifikasi"):
            pm._ensure_removal_is_safe("firefox")

    def test_nonzero_dpkg_query_refuses_removal(self):
        with mock.patch.object(pm, "run_command", return_value=_result(returncode=1)), \
             self.assertRaisesRegex(pm.PackageOperationError, "tidak dapat diverifikasi"):
            pm._ensure_removal_is_safe("firefox")

    def test_package_no_longer_installed_refuses_removal(self):
        out = "Package: firefox\nStatus: deinstall ok config-files\nPriority: optional\n"
        with mock.patch.object(pm, "run_command", return_value=_result(stdout=out)), \
             self.assertRaisesRegex(pm.PackageOperationError, "bukan lagi paket terpasang"):
            pm._ensure_removal_is_safe("firefox")

    def test_required_priority_refuses_removal(self):
        out = "Package: tar\nStatus: install ok installed\nPriority: required\n"
        with mock.patch.object(pm, "run_command", return_value=_result(stdout=out)), \
             self.assertRaises(pm.PackageOperationError):
            pm._ensure_removal_is_safe("tar")


class PlanningAndApprovalTests(unittest.TestCase):
    def test_unsupported_action_is_refused_before_any_command(self):
        with mock.patch.object(pm, "run_command") as run, self.assertRaises(pm.PackageOperationError):
            pm.preview_apt_action("upgrade", "firefox")
        run.assert_not_called()

    def test_install_plan_that_would_remove_packages_is_refused(self):
        sim = _result(stdout="Inst hello (2.10)\nRemv other [1.0]\n")
        with mock.patch.object(pm, "run_command", return_value=sim), \
             self.assertRaisesRegex(pm.PackageOperationError, "menghapus paket lain"):
            pm.preview_apt_action("install", "hello")

    def test_install_plan_that_does_not_mention_the_package_is_refused(self):
        sim = _result(stdout="Inst other (1.0)\n")
        with mock.patch.object(pm, "run_command", return_value=sim), \
             self.assertRaisesRegex(pm.PackageOperationError, "tidak merencanakan"):
            pm.preview_apt_action("install", "hello")

    def test_empty_plan_is_refused(self):
        with mock.patch.object(pm, "run_command", return_value=_result(stdout="0 upgraded\n")), \
             self.assertRaisesRegex(pm.PackageOperationError, "tidak merencanakan"):
            pm.preview_apt_action("remove", "hello")

    def test_apply_without_an_approved_preview_never_reaches_pkexec(self):
        with mock.patch.object(pm, "run_command") as run, \
             self.assertRaisesRegex(pm.PackageOperationError, "disetujui di antarmuka"):
            pm.apply_apt_action("install", "hello", approved_preview=None)
        run.assert_not_called()

    def test_apply_with_changed_plan_is_refused_and_never_reaches_pkexec(self):
        approved = pm.AptTransactionPreview(
            action="install", package_name="hello", install=("hello",), remove=(), purge=(), output="old",
        )
        changed = _result(stdout="Inst hello (2.11)\n")
        with mock.patch.object(pm, "run_command", return_value=changed) as run, \
             self.assertRaisesRegex(pm.PackageOperationError, "berubah sejak ditinjau"):
            pm.apply_apt_action("install", "hello", approved_preview=approved)
        self.assertEqual(run.call_count, 1)  # only the re-simulation, never pkexec


@mock.patch.object(pm, "HELPER_GUARD", lambda path: None)
class PkexecFailureMessageTests(unittest.TestCase):
    SIMULATION = "Inst hello (2.10)\n"

    def _approved_preview(self):
        # Build the approved plan with the same simulation output the apply step will re-check.
        with mock.patch.object(pm, "run_command", return_value=_result(stdout=self.SIMULATION)):
            return pm.preview_apt_action("install", "hello")

    def _apply_with(self, second_result=None, side_effect=None):
        approved = self._approved_preview()
        effects = side_effect or [_result(stdout=self.SIMULATION), second_result]
        with mock.patch.object(pm, "run_command", side_effect=effects):
            return pm.apply_apt_action("install", "hello", approved_preview=approved)

    def test_cancelled_authentication_gets_a_clear_message(self):
        for code in (126, 127):
            with self.subTest(code=code), \
                 self.assertRaisesRegex(pm.PackageOperationError, "Autentikasi dibatalkan"):
                self._apply_with(_result(returncode=code, argv=("pkexec",)))

    def test_helper_refusal_shows_its_last_line(self):
        refusal = _result(returncode=3, stderr="paket inti tidak boleh dihapus: bash\n")
        with self.assertRaisesRegex(pm.PackageOperationError, "inti"):
            self._apply_with(refusal)

    def test_unknown_failure_reports_the_exit_code_when_no_text_is_given(self):
        with self.assertRaisesRegex(pm.PackageOperationError, "kode 42"):
            self._apply_with(_result(returncode=42))

    def test_timeout_during_pkexec_is_reported(self):
        with self.assertRaisesRegex(pm.PackageOperationError, "timeout"):
            self._apply_with(side_effect=[_result(stdout=self.SIMULATION), CommandTimedOut("timeout")])


if __name__ == "__main__":
    unittest.main()
