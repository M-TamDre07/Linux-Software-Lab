import unittest
from typing import ClassVar
from unittest import mock

from PySide6.QtCore import QPoint
from PySide6.QtWidgets import QApplication

from paketscope.domain import InstalledApplication
from paketscope.ui import context_menu
from paketscope.ui import main_window as mw


def _app():
    return QApplication.instance() or QApplication([])


class FakeMenu:
    instances: ClassVar[list] = []

    def __init__(self, parent=None):
        self.actions = []
        self.exec_position = None
        FakeMenu.instances.append(self)

    def addAction(self, label):
        action = _FakeAction(label)
        self.actions.append(action)
        return action

    def exec(self, position):
        self.exec_position = position


class _FakeAction:
    def __init__(self, label):
        self.label = label
        self.enabled = True
        self.tooltip = ""
        self.triggered = _Signal()

    def setEnabled(self, value):
        self.enabled = value

    def setToolTip(self, text):
        self.tooltip = text


class _Signal:
    def __init__(self):
        self.handlers = []

    def connect(self, handler):
        self.handlers.append(handler)

    def fire(self):
        for handler in self.handlers:
            handler()


class MenuDefinitionTests(unittest.TestCase):
    def test_apt_rows_offer_inspect_remove_and_purge_enabled(self):
        items = context_menu.application_menu_items("APT / dpkg")
        self.assertEqual([i.key for i in items], ["inspect", "remove", "purge"])
        self.assertTrue(all(i.enabled for i in items))

    def test_non_apt_rows_keep_removal_disabled_with_a_reason(self):
        items = {i.key: i for i in context_menu.application_menu_items("Flatpak")}
        self.assertTrue(items["inspect"].enabled)
        self.assertFalse(items["remove"].enabled)
        self.assertFalse(items["purge"].enabled)
        self.assertIn("APT/dpkg", items["remove"].reason)


class RowContextMenuWiringTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.qapp = _app()

    def setUp(self):
        FakeMenu.instances.clear()
        self.window = mw.MainWindow()
        self.addCleanup(self.window.close)

    def _select(self, source):
        app = InstalledApplication(name="tool", version="1.0", source=source, identifier="tool")
        return app

    def test_invalid_position_shows_no_menu(self):
        with mock.patch.object(mw, "QMenu", FakeMenu):
            self.window._show_row_context_menu(QPoint(-500, -500))
        self.assertEqual(FakeMenu.instances, [])

    def test_row_menu_offers_only_that_row_actions_and_routes_inspect(self):
        app = self._select("APT / dpkg")
        with mock.patch.object(mw, "QMenu", FakeMenu), \
             mock.patch.object(self.window.table, "indexAt", return_value=mock.Mock(isValid=lambda: True)), \
             mock.patch.object(self.window.table, "setCurrentIndex"), \
             mock.patch.object(self.window, "_selected_application", return_value=app), \
             mock.patch.object(self.window, "show_selected_application_details") as inspect:
            self.window._show_row_context_menu(QPoint(10, 10))
            menu = FakeMenu.instances[-1]
            labels = [a.label for a in menu.actions]
            self.assertEqual(labels[0], "Inspeksi detail…")
            self.assertIn("Copot paket…", labels)
            menu.actions[0].triggered.fire()
        inspect.assert_called_once()

    def test_remove_routes_to_the_existing_confirmed_removal_path(self):
        app = self._select("APT / dpkg")
        with mock.patch.object(mw, "QMenu", FakeMenu), \
             mock.patch.object(self.window.table, "indexAt", return_value=mock.Mock(isValid=lambda: True)), \
             mock.patch.object(self.window.table, "setCurrentIndex"), \
             mock.patch.object(self.window, "_selected_application", return_value=app), \
             mock.patch.object(self.window, "remove_selected_apt_package") as remove:
            self.window._show_row_context_menu(QPoint(10, 10))
            menu = FakeMenu.instances[-1]
            copot = next(a for a in menu.actions if a.label == "Copot paket…")
            copot.triggered.fire()
        remove.assert_called_once()

    def test_flatpak_row_shows_disabled_removal_items(self):
        app = self._select("Flatpak")
        with mock.patch.object(mw, "QMenu", FakeMenu), \
             mock.patch.object(self.window.table, "indexAt", return_value=mock.Mock(isValid=lambda: True)), \
             mock.patch.object(self.window.table, "setCurrentIndex"), \
             mock.patch.object(self.window, "_selected_application", return_value=app):
            self.window._show_row_context_menu(QPoint(10, 10))
        menu = FakeMenu.instances[-1]
        copot = next(a for a in menu.actions if a.label == "Copot paket…")
        self.assertFalse(copot.enabled)
        self.assertIn("APT/dpkg", copot.tooltip)


if __name__ == "__main__":
    unittest.main()
