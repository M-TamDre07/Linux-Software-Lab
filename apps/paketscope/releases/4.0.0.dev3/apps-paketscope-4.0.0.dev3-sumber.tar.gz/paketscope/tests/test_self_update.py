import unittest
from unittest import mock

from paketscope import updates as U
from paketscope.commands import CommandResult, CommandUnavailable


def _r(stdout="", returncode=0):
    return CommandResult(argv=("x",), returncode=returncode, stdout=stdout, stderr="")


POLICY = "paketscope:\n  Installed: {inst}\n  Candidate: {cand}\n  Version table:\n"


class SelfUpdateStatusTests(unittest.TestCase):
    def _run(self, installed_out, policy_out, compare_rc):
        def fake(argv, timeout):
            if argv[0] == "dpkg-query":
                return _r(installed_out, 0 if installed_out else 1)
            if argv[0] == "apt-cache":
                return _r(policy_out)
            if argv[0] == "dpkg":
                return _r("", compare_rc)
            raise AssertionError(argv)
        with mock.patch.object(U, "run_command", side_effect=fake):
            return U.self_update_status()

    def test_newer_candidate_is_reported_as_an_available_update(self):
        status = self._run("3.0.0~dev5-1", POLICY.format(inst="3.0.0~dev5-1", cand="4.0.0~dev1-1"), 0)
        self.assertEqual(status.state, "ada pembaruan")
        self.assertIn("4.0.0~dev1-1", status.detail)
        self.assertIn("tidak dihapus", status.detail)

    def test_same_version_is_reported_as_up_to_date(self):
        status = self._run("4.0.0~dev1-1", POLICY.format(inst="4.0.0~dev1-1", cand="4.0.0~dev1-1"), 1)
        self.assertEqual(status.state, "terbaru")

    def test_not_installed_from_a_package_is_unknown_not_guessed(self):
        status = self._run("", POLICY.format(inst="(none)", cand="4.0.0~dev1-1"), 1)
        self.assertEqual(status.state, "tidak diketahui")

    def test_missing_index_entry_is_unknown_with_guidance(self):
        status = self._run("3.0.0~dev5-1", POLICY.format(inst="3.0.0~dev5-1", cand="(none)"), 1)
        self.assertEqual(status.state, "tidak diketahui")
        self.assertIn("indeks", status.detail.lower())

    def test_unavailable_tools_do_not_crash_the_check(self):
        with mock.patch.object(U, "run_command", side_effect=CommandUnavailable("no apt-cache")):
            status = U.self_update_status()
        self.assertEqual(status.state, "tidak diketahui")

    def test_check_never_installs_or_executes_anything_but_read_tools(self):
        seen = []
        def fake(argv, timeout):
            seen.append(argv[0])
            return _r(POLICY.format(inst="1", cand="1") if argv[0] == "apt-cache" else "1", 0)
        with mock.patch.object(U, "run_command", side_effect=fake):
            U.self_update_status()
        self.assertTrue(set(seen) <= {"dpkg-query", "apt-cache", "dpkg"})
        self.assertNotIn("apt-get", seen)


if __name__ == "__main__":
    unittest.main()
