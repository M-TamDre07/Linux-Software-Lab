# Sumber aplikasi yang bisa dan belum bisa dideteksi

PaketScope membaca launcher `.desktop` dan dpkg. Tidak ada yang dijalankan.

## Yang bisa dideteksi
- Paket APT/dpkg (inventori utama).
- Flatpak.
- AppImage yang punya launcher di folder aplikasi pengguna atau sistem.
- Program Wine yang punya launcher (termasuk Lutris dan Bottles bila membuat launcher).
- Aplikasi Waydroid yang membuat launcher di folder aplikasi pengguna.
- Aplikasi Snap yang mengekspor launcher ke `/var/lib/snapd/desktop/applications`.
- Aplikasi manual dengan launcher. Ditandai "Manual / tidak dikenal", bukan ditebak asalnya.

## Yang belum bisa dideteksi, dan alasannya
- **AppImage tanpa launcher.** Tidak ada entri yang bisa dibaca. Pemindaian file di seluruh disk
  tidak dilakukan, karena terlalu mahal dan terlalu mengganggu.
- **Prefix Wine tanpa launcher.** Program yang tidak dibuatkan launcher tidak terlihat.
- **Aplikasi Waydroid di dalam container.** Daftar aplikasi Android hanya bisa diambil dengan menjalankan
  Waydroid. Itu tindakan yang mengubah keadaan sistem, jadi tidak dilakukan oleh PaketScope.
- **Aplikasi tanpa launcher sama sekali** (misalnya binary di `~/bin`). Tidak ada cara membedakannya
  dari file biasa tanpa menebak.

## Catatan kejujuran
Deteksi ini berdasarkan bukti yang ada di sistem. Aplikasi yang tidak punya bukti tidak akan muncul.
Itu sengaja: menebak lebih berbahaya daripada melewatkan.
