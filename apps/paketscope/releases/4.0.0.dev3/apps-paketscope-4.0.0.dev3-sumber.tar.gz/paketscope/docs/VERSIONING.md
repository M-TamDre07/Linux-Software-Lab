# Aturan versi PaketScope

PaketScope memakai Semantic Versioning, dengan penanda tahap yang jelas.

## Format
`MAJOR.MINOR.PATCH`, dengan penanda tahap di belakangnya bila belum stabil.

| Contoh | Arti |
|---|---|
| `4.0.0.dev1` (Debian `4.0.0~dev1-1`) | Pengembangan pertama jalur 4.0.0 (versi mayor berikutnya) |
| `4.0.0rc1` | Kandidat rilis 4.0.0, semua gerbang lulus, menunggu uji pengguna |
| `4.0.0` | Rilis stabil 4.0.0 |
| `4.1.0` | Fitur baru yang kompatibel, di atas 4.0.0 |
| `4.0.1` | Perbaikan bug atau keamanan saja, di 4.0.0 |
| `3.0.0` | Rilis stabil pertama jalur 3.x |
| `3.0.1` | Perbaikan bug atau keamanan di jalur 3.x |
| `3.1.0` | Fitur kompatibel di jalur 3.x |

## Kapan menaikkan
- **PATCH** (`x.y.Z`): hanya perbaikan bug dan keamanan. Tidak ada perubahan fitur atau perilaku.
- **MINOR** (`x.Y.0`): fitur baru atau peningkatan yang tetap kompatibel dengan versi sebelumnya.
- **MAJOR** (`X.0.0`): perubahan besar pada arsitektur, teknologi inti, pengalaman pengguna, atau
  kompatibilitas yang memutus. Pergantian teknologi saja tidak cukup.

## Aturan tahap
- Pekerjaan yang belum lulus gerbang rilis disebut `.devN`. Versi `.devN` tidak boleh disebarkan
  sebagai rilis.
- Naik ke `rcN` hanya jika semua gerbang rilis lulus. Temuan kritis pada kandidat berarti `rc` baru.
- Versi stabil hanya diberikan setelah kandidat lolos uji pengguna dan pemilik menyetujui.

## Konsistensi
Versi yang sama harus tercantum di `pyproject.toml`, `paketscope/__init__.py`,
`debian/changelog` (dengan format Debian, misalnya `4.0.0~dev1-1`), dan `metainfo.xml`
(entri `<release>`). Tes `test_app_version_matches_development_package_version` menjaga kesamaan
nilai di kode dan pyproject.
