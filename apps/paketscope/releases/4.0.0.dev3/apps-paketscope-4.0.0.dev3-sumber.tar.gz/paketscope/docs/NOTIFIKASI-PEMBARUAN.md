# Notifikasi pembaruan PaketScope: pilihan dan rekomendasi

Pertanyaan dari responden: apakah notifikasi pembaruan sebaiknya terhubung ke database website?

## Dua pilihan

### A. Indeks APT lokal (sudah diimplementasikan)
- Sumbernya indeks paket yang sudah dipercaya sistem: repositori bertanda tangan dan kunci yang
  dipasang lewat APT. PaketScope hanya membaca indeks lokal (`apt-cache policy`, `dpkg --compare-versions`).
- Tidak ada permintaan jaringan dari PaketScope, tidak ada identifier perangkat, tidak ada pelacakan.
- Berlaku untuk Debian, Ubuntu, dan Linux Mint (APT). Untuk Flatpak, pemeriksaan pembaruan sudah ada lewat
  `updates.py`.
- Keterbatasan: informasi hanya sebaru indeks lokal. Pengguna perlu menjalankan `apt update`.

### B. Feed dari website atau Supabase
- Cocok untuk paket yang bukan dari APT atau Flatpak, misalnya AppImage atau unduhan manual.
- Risiko: permintaan dari perangkat ke server mengungkap alamat IP dan waktu. Itu bertentangan
  dengan janji "tidak dikirim ke pengembang" bila tidak diatur dengan jelas.
- Risiko kedua: sumber yang berbeda dengan repositori pengguna bisa menampilkan versi yang tidak bisa
  dipasang. Notifikasi bisa salah.
- Jika dibangun, syaratnya: opt-in, paling sering sekali sehari, hanya membaca (kunci publik
  `anon` ke tabel publik), tidak ada identifier, dan data bertanda tangan agar bisa diverifikasi.
  Aplikasi tidak boleh menulis ke database.

## Rekomendasi
1. Untuk instalasi dari paket (.deb): pakai A. Ini paling jujur dan tidak mengirim apa pun.
2. Untuk AppImage dan unduhan manual: pakai B, hanya jika pengguna mengaktifkannya sendiri.
3. Notifikasi tidak boleh memasang apa pun tanpa persetujuan. Pembaruan selalu lewat pengelola paket.
