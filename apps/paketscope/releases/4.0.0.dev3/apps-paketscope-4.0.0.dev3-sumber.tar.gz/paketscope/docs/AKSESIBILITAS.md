# Aksesibilitas PaketScope

## Yang sudah ada
- **Tutorial pertama kali**: lima langkah, bisa dilewati di setiap langkah, dan pilihan "lewati" diingat.
  Tutorial tidak memberi izin apa pun dan tidak mengubah sistem.
- **Palet warna** untuk pengguna buta warna: standar, ramah buta warna (biru dan oranye), dan kontras tinggi.
  Setiap palet diuji terhadap kontras WCAG: teks minimal 4,5:1, warna status minimal 3:1.
- **Status tidak bergantung pada warna**: setiap status punya simbol dan label teks.
- **Ukuran teks** 1,0 sampai 2,0 kali standar.
- **Kurangi animasi** sebagai pilihan.
- **Tanpa suara**: aplikasi tidak memakai pustaka audio. Semua peringatan tampil sebagai teks.
  Ini diuji secara statis.
- **Pengaturan disimpan lokal** di folder konfigurasi pengguna. Tidak dikirim ke mana pun.

## Yang belum ada, dan perlu dikerjakan
- **Palet belum diterapkan ke tampilan tabel.** Saat ini tabel tidak memberi warna pada status,
  sehingga tidak ada warna yang perlu dibedakan. Begitu pewarnaan status ditambahkan, wajib memakai
  fungsi `state_label` dan palet dari `accessibility.py`.
- **Pembaca layar** (misalnya Orca) belum diuji langsung. Nama aksesibel sudah diberikan pada tombol dan
  judul tutorial, tetapi belum diverifikasi dengan pembaca layar.
- **Navigasi keyboard** belum diuji menyeluruh. Pengaturan `keyboard_hints` sudah disiapkan.
- **Pengujian pengguna nyata** dengan pengguna buta warna, tunarungu, dan pengguna pembaca layar
  belum dilakukan. Itu perlu sebelum klaim aksesibilitas dibuat publik.
