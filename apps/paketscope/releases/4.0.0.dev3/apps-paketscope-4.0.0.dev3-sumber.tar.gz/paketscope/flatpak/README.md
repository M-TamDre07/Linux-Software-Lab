# Fondasi Flatpak PaketScope

Status: **fondasi, belum dibangun dan belum diuji.** Tidak ada `flatpak-builder` di lingkungan
pengembangan ini, dan tidak ada akses ke runtime Flathub.

## Yang sudah ada
- `io.github.mtamdre07.paketscope.json`: manifest dengan izin sesedikit mungkin.
  - Tanpa `--share=network`: aplikasi tidak bisa mengirim data keluar.
  - Tanpa `--filesystem`: tidak ada akses ke berkas host. Berkas dipilih lewat portal.
  - Tanpa `--system-bus` atau polkit: operasi APT tidak tersedia di sandbox, dan `runtime_env.py` mengatakannya.
- Deteksi Flatpak di aplikasi (`runtime_env.py`) memberi tahu pengguna bahwa operasi APT tidak tersedia.

## Yang masih perlu dikerjakan sebelum bisa dikirim ke Flathub
1. Ganti sumber `dir` dengan arsip rilis dan `sha256`. Flathub tidak menerima sumber lokal.
2. Tambahkan PySide6 dan dependensi Python lewat `flatpak-pip-generator` dengan roda ber-hash.
3. Verifikasi versi runtime KDE terbaru di Flathub. Versi `6.8` di manifest hanya placeholder.
4. Tambahkan screenshot ke metainfo. Flathub mewajibkannya. Screenshot tidak dibuat di sini.
5. Bangun dengan `flatpak-builder` dan uji instal, jalankan, copot di sistem nyata.
6. Ajukan ke Flathub setelah pemilik menyetujui. Saya tidak punya akun atau izin untuk itu.

## Catatan izin
Setiap izin yang ditambahkan nanti harus dibenarkan dalam PR Flathub. Tes
`test_flatpak_foundation.py` menjaga agar izin berbahaya tidak masuk tanpa terlihat.
