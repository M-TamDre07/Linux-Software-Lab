# Kebijakan keamanan

## Versi yang didukung
Hanya rilis beta terbaru (0.4.x).

## Melaporkan kerentanan
Kontak keamanan maintainer **belum ditetapkan** (repositori belum dipublikasikan). Setelah repositori publik dibuat, gunakan fitur *Private vulnerability reporting* GitHub dan perbarui berkas ini dengan kontak yang valid. Jangan membuka isu publik untuk kerentanan.

## Model ancaman singkat
- Naskah dan pengaturan disimpan lokal (`~/.local/share/sorot`, `~/.config/sorot`) dengan izin berkas `0600`; tidak dienkripsi.
- API key tidak pernah ditulis ke berkas pengaturan, draf, atau log. Penyimpanan permanen hanya lewat keyring sistem yang dianggap aman; selain itu hanya di memori sesi (atau variabel `SOROT_API_KEY`).
- Permintaan AI hanya dikirim atas tindakan pengguna ke URL yang dikonfigurasi pengguna. HTTP polos hanya diterima untuk localhost; pengalihan (redirect) ditolak.
- rclone dijalankan tanpa shell, dengan argumen tervalidasi; aplikasi tidak menghapus berkas Drive.
- Tidak ada telemetri.
- Log memuat penyamaran pola rahasia umum sebagai lapis kedua; aplikasi sendiri tidak mencatat isi naskah atau key.
- Ekstensi kode berjalan di proses terpisah dengan izin akunmu. Itu melindungi stabilitas, **bukan keamanan** (bukan sandbox). Ekstensi baru tidak berjalan sebelum disetujui eksplisit; persetujuan terikat pada hash berkas dan dicabut jika kode berubah; lingkungan proses dibersihkan dari variabel rahasia. Lihat [docs/EXTENSIONS.md](docs/EXTENSIONS.md).
- Pemasang ekstensi menolak zip-slip, tautan simbolik, dan arsip raksasa.
