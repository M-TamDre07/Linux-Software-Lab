"""Real subprocess tests of the extension host (no mocks of the protocol)."""
from __future__ import annotations

import threading
import time

import pytest
from ext_helpers import GOOD_CODE, write_extension

from sorot.core.cancel import CancelToken, OperationCancelled
from sorot.extensions import discovery
from sorot.extensions.host import ExtensionCrashed, ExtensionHost, ExtensionProcess, ExtensionTimeout, scrubbed_environment
from sorot.extensions.manifest import ExtensionError

APP = "0.5.0"


def info_for(tmp_path, code=GOOD_CODE, ext_id="uji.host"):
    write_extension(tmp_path, ext_id, code=code)
    return discovery.discover(user_dir=tmp_path, system_dirs=(), include_pip=False)[0]


@pytest.fixture()
def proc(tmp_path):
    notes = []
    process = ExtensionProcess(info_for(tmp_path), APP, on_notify=lambda ext, msg: notes.append((ext, msg)))
    process.notes = notes  # type: ignore[attr-defined]
    process.start()
    yield process
    process.stop(kill=True)


def test_hello_reports_capabilities(proc):
    caps = proc.capabilities
    assert {t["id"] for t in caps.transforms} >= {"upper", "boom", "slow"}
    assert caps.importers == [{"id": "rev", "label": "Balik", "extensions": [".rev"]}]
    assert caps.exporters[0]["extension"] == ".up" and {a["id"] for a in caps.actions} == {"count", "say"}
    assert set(caps.events) == {"playback.started", "script.saved"}


def test_transform_import_export_and_action(proc, tmp_path):
    assert proc.call("transform", {"id": "upper", "text": "halo dunia ✓"}) == {"text": "HALO DUNIA ✓"}
    source = tmp_path / "x.rev"
    source.write_text("abc", encoding="utf-8")
    assert proc.call("import", {"id": "rev", "path": str(source)}) == {"text": "cba"}
    target = tmp_path / "out.up"
    assert proc.call("export", {"id": "up", "text": "kecil", "path": str(target)}) == {}
    assert target.read_text() == "KECIL"
    assert proc.call("action", {"id": "count", "text": "satu dua tiga"}) == {"notify": "3 kata", "set_text": "satu dua tiga (dihitung)"}


def test_large_scripts_round_trip(proc):
    text = "kata " * 200_000  # 1 MB
    assert proc.call("transform", {"id": "upper", "text": text}, timeout=20)["text"] == text.upper()


def test_extension_exceptions_become_errors_and_do_not_kill_the_process(proc):
    with pytest.raises(ExtensionError, match="ZeroDivisionError"):
        proc.call("transform", {"id": "boom", "text": "x"})
    with pytest.raises(ExtensionError, match="str"):
        proc.call("transform", {"id": "notstr", "text": "x"})
    with pytest.raises(ExtensionError, match="tidak terdaftar"):
        proc.call("transform", {"id": "tidak-ada", "text": "x"})
    assert proc.alive and proc.call("transform", {"id": "upper", "text": "ok"})["text"] == "OK"


def test_stdout_prints_cannot_corrupt_the_protocol(proc):
    assert proc.call("transform", {"id": "chatty", "text": "a"}) == {"text": "a!"}
    assert proc.call("transform", {"id": "upper", "text": "b"}) == {"text": "B"}


def test_environment_is_scrubbed_of_secrets(tmp_path, monkeypatch):
    monkeypatch.setenv("SOROT_API_KEY", "sk-rahasia-1234567890")
    monkeypatch.setenv("OPENAI_API_KEY", "sk-lain-1234567890")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "rahasia")
    process = ExtensionProcess(info_for(tmp_path), APP)
    process.start()
    try:
        names = process.call("transform", {"id": "env", "text": ""})["text"].split(",")
    finally:
        process.stop(kill=True)
    assert "SOROT_API_KEY" not in names and "OPENAI_API_KEY" not in names and "AWS_SECRET_ACCESS_KEY" not in names
    assert "PATH" in names
    assert set(scrubbed_environment()) <= {"PATH", "HOME", "LANG", "LC_ALL", "LC_CTYPE", "TZ", "TMPDIR", "XDG_RUNTIME_DIR", "DISPLAY",
                                           "WAYLAND_DISPLAY", "PYTHONDONTWRITEBYTECODE", "PYTHONUNBUFFERED"}


def test_working_directory_is_the_extension_folder(proc):
    assert proc.call("transform", {"id": "cwd", "text": ""})["text"] == str(proc.info.path)


def test_timeout_kills_the_process_and_reports_clearly(proc):
    started = time.monotonic()
    with pytest.raises(ExtensionTimeout, match="tepat waktu"):
        proc.call("transform", {"id": "slow", "text": "x"}, timeout=0.8)
    assert time.monotonic() - started < 4 and not proc.alive


def test_crash_is_reported_not_hung(proc):
    with pytest.raises(ExtensionCrashed, match="berhenti tiba-tiba"):
        proc.call("transform", {"id": "die", "text": "x"})
    assert not proc.alive
    with pytest.raises(ExtensionCrashed):
        proc.call("transform", {"id": "upper", "text": "x"})


def test_cancel_stops_the_call_and_the_process(proc):
    token = CancelToken()
    threading.Timer(0.4, token.cancel).start()
    started = time.monotonic()
    with pytest.raises(OperationCancelled):
        proc.call("transform", {"id": "slow", "text": "x"}, timeout=30, cancel=token)
    assert time.monotonic() - started < 4 and not proc.alive


def test_notifications_and_logs_come_back(proc):
    proc.call("action", {"id": "say", "text": ""})
    deadline = time.monotonic() + 3
    while not proc.notes and time.monotonic() < deadline:  # type: ignore[attr-defined]
        time.sleep(0.02)
    assert proc.notes == [("uji.host", "halo dari ekstensi")]  # type: ignore[attr-defined]


def wait_for_lines(ext_id: str, count: int, timeout: float = 4.0) -> list[str]:
    target = discovery.extension_data_dir(ext_id) / "saved.txt"
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if target.exists() and len(target.read_text().split()) >= count:
            break
        time.sleep(0.05)
    return target.read_text().split() if target.exists() else []


def test_events_are_delivered_only_to_subscribers(proc):
    proc.send_event("script.saved", {"name": "a.txt"})
    proc.send_event("script.saved", {"name": "b.txt"})
    proc.send_event("overlay.shown", {})  # not subscribed: must be dropped silently
    assert wait_for_lines("uji.host", 2) == ["a.txt", "b.txt"]
    assert proc.alive


def test_a_failing_entry_point_never_starts(tmp_path):
    for code, message in (("def activate(api):\n    raise RuntimeError('gagal aktif')\n", "gagal aktif"),
                          ("x = 1\n", "activate"), ("def activate(api\n", "SyntaxError")):
        info = info_for(tmp_path, code, ext_id="uji.gagal")
        process = ExtensionProcess(info, APP)
        with pytest.raises(ExtensionError) as err:
            process.start()
        assert message in str(err.value) or "berhenti" in str(err.value)
        assert not process.alive


def test_host_syncs_restarts_and_disables_flaky_extensions(tmp_path):
    info = info_for(tmp_path)
    host = ExtensionHost(APP)
    try:
        host.sync([info])
        assert host.status("uji.host") == "berjalan"
        assert host.call("uji.host", "transform", {"id": "upper", "text": "a"}) == {"text": "A"}
        for _ in range(3):
            with pytest.raises(ExtensionError):
                host.call("uji.host", "transform", {"id": "die", "text": "x"})
        with pytest.raises(ExtensionError, match="Dinonaktifkan"):
            host.call("uji.host", "transform", {"id": "upper", "text": "a"})
        assert "Dinonaktifkan" in host.status("uji.host")
        host.sync([])
        assert host.status("uji.host") == "tidak aktif"
    finally:
        host.shutdown()


def test_host_restarts_once_after_a_single_crash(tmp_path):
    host = ExtensionHost(APP)
    try:
        host.sync([info_for(tmp_path)])
        with pytest.raises(ExtensionError):
            host.call("uji.host", "transform", {"id": "die", "text": "x"})
        assert host.call("uji.host", "transform", {"id": "upper", "text": "ok"}) == {"text": "OK"}
    finally:
        host.shutdown()


def test_changed_code_is_restarted_on_sync(tmp_path):
    host = ExtensionHost(APP)
    try:
        info = info_for(tmp_path)
        host.sync([info])
        first_pid = host.entries["uji.host"].process._proc.pid
        (info.path / "main.py").write_text(GOOD_CODE + "\n# edit\n")
        host.sync(discovery.discover(user_dir=tmp_path, system_dirs=(), include_pip=False))
        assert host.entries["uji.host"].process._proc.pid != first_pid
    finally:
        host.shutdown()


def test_start_failure_is_recorded_not_raised(tmp_path):
    host = ExtensionHost(APP)
    host.sync([info_for(tmp_path, "def activate(api):\n    raise RuntimeError('rusak')\n", ext_id="uji.rusak")])
    assert "gagal" in host.status("uji.rusak") and "rusak" in host.status("uji.rusak")
    host.shutdown()


def test_broadcast_reaches_running_extensions(tmp_path):
    host = ExtensionHost(APP)
    try:
        host.sync([info_for(tmp_path)])
        host.broadcast("script.saved", {"name": "z.txt"})
        host.broadcast("overlay.hidden", {})
        assert wait_for_lines("uji.host", 1) == ["z.txt"]
    finally:
        host.shutdown()


def test_occasional_crashes_do_not_accumulate_into_a_permanent_ban(tmp_path):
    host = ExtensionHost(APP)
    try:
        host.sync([info_for(tmp_path)])
        for _ in range(6):  # six crashes in total, but never three in a row
            with pytest.raises(ExtensionError):
                host.call("uji.host", "transform", {"id": "die", "text": "x"})
            assert host.call("uji.host", "transform", {"id": "upper", "text": "ok"}) == {"text": "OK"}
        assert host.status("uji.host") == "berjalan"
    finally:
        host.shutdown()


def test_timeouts_count_as_failures_too(tmp_path):
    host = ExtensionHost(APP)
    try:
        host.sync([info_for(tmp_path)])
        for _ in range(3):
            with pytest.raises(ExtensionTimeout):
                host.call("uji.host", "transform", {"id": "slow", "text": "x"}, timeout=0.5)
        assert "Dinonaktifkan" in host.status("uji.host")
    finally:
        host.shutdown()
