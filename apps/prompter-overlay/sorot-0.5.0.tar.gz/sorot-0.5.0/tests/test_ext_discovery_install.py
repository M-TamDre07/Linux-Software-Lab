import os
import zipfile

import pytest
from ext_helpers import GOOD_CODE, write_extension, zip_directory

from sorot.extensions import discovery, installer
from sorot.extensions.manifest import ExtensionError

CODE = "def activate(api):\n    pass\n"
DECL = {"templates": [{"name": "Salam", "text": "Halo"}]}


def test_discovery_finds_user_and_system_and_reports_broken(tmp_path):
    user, system = tmp_path / "user", tmp_path / "system"
    write_extension(user, "uji.user", contributes=DECL)
    write_extension(system, "uji.system", code=CODE)
    broken = user / "rusak"
    broken.mkdir()
    (broken / "sorot-extension.json").write_text("{nope")
    infos = discovery.discover(user_dir=user, system_dirs=(system,), include_pip=False)
    by_id = {i.ext_id: i for i in infos}
    assert by_id["uji.user"].origin == "user" and by_id["uji.user"].code_hash == ""
    assert by_id["uji.system"].origin == "system" and len(by_id["uji.system"].code_hash) == 64
    bad = next(i for i in infos if not i.usable)
    assert "JSON" in bad.error and bad.ext_id.startswith("?")


def test_user_install_shadows_same_id_elsewhere(tmp_path):
    user, system = tmp_path / "user", tmp_path / "system"
    write_extension(user, "uji.sama", contributes=DECL)
    write_extension(system, "uji.sama", contributes=DECL)
    infos = discovery.discover(user_dir=user, system_dirs=(system,), include_pip=False)
    assert [i.origin for i in infos] == ["user"] and any("ganda" in p for p in infos[0].problems)


def test_pip_installed_extensions_are_found_through_entry_points(tmp_path, monkeypatch):
    package = tmp_path / "site" / "sorot_ext_demo"
    write_extension(package.parent, "sorot_ext_demo", contributes=DECL)
    (package / "__init__.py").write_text("")
    monkeypatch.syspath_prepend(str(package.parent))

    class Point:
        value = "sorot_ext_demo"

    monkeypatch.setattr("importlib.metadata.entry_points", lambda group=None: [Point()] if group == "sorot.extensions" else [])
    infos = discovery.discover(user_dir=tmp_path / "none", system_dirs=(), include_pip=True)
    assert [(i.ext_id, i.origin) for i in infos] == [("sorot_ext_demo", "pip")]


def test_code_hash_changes_when_any_file_changes_and_ignores_pycache(tmp_path):
    d = write_extension(tmp_path, "uji.hash", code=CODE)
    first = discovery.hash_tree(d)
    assert discovery.hash_tree(d) == first
    (d / "__pycache__").mkdir()
    (d / "__pycache__" / "x.pyc").write_bytes(b"1")
    assert discovery.hash_tree(d) == first
    (d / "main.py").write_text(CODE + "# diubah\n")
    assert discovery.hash_tree(d) != first
    (d / "extra.txt").write_text("baru")
    assert discovery.hash_tree(d) not in {first}


def test_hash_refuses_oversized_trees(tmp_path, monkeypatch):
    d = write_extension(tmp_path, "uji.besar", code=CODE)
    (d / "blob.bin").write_bytes(b"x" * 2000)
    monkeypatch.setattr(discovery, "MAX_TREE_BYTES", 1000)
    with pytest.raises(ExtensionError, match="50 MB"):
        discovery.hash_tree(d)


# ---- installer -------------------------------------------------------------------------
def test_install_from_folder_and_uninstall(tmp_path):
    src = write_extension(tmp_path / "src", "uji.pasang", code=CODE)
    user = tmp_path / "user"
    assert installer.install_from_dir(src, user_dir=user) == "uji.pasang"
    assert (user / "uji.pasang" / "main.py").is_file()
    with pytest.raises(ExtensionError, match="sudah terpasang"):
        installer.install_from_dir(src, user_dir=user)
    (src / "main.py").write_text(CODE + "# v2\n")
    installer.install_from_dir(src, replace=True, user_dir=user)
    assert "# v2" in (user / "uji.pasang" / "main.py").read_text()
    assert not (user / "uji.pasang.old").exists()
    installer.uninstall("uji.pasang", user_dir=user)
    assert not (user / "uji.pasang").exists()


def test_install_rejects_invalid_folder_and_leaves_no_residue(tmp_path):
    user = tmp_path / "user"
    empty = tmp_path / "kosong"
    empty.mkdir()
    with pytest.raises(ExtensionError, match="sorot-extension.json"):
        installer.install_from_dir(empty, user_dir=user)
    bad = write_extension(tmp_path / "bad", "uji.bad", code=CODE, extra={"api": 9})
    with pytest.raises(ExtensionError, match="API"):
        installer.install_from_dir(bad, user_dir=user)
    assert not any(user.iterdir()) if user.exists() else True


def test_install_rejects_symlinks_inside_a_folder(tmp_path):
    src = write_extension(tmp_path / "src", "uji.link", code=CODE)
    (src / "pintasan").symlink_to("/etc")
    with pytest.raises(ExtensionError, match="simbolik"):
        installer.install_from_dir(src, user_dir=tmp_path / "user")


@pytest.mark.parametrize("top_level", [False, True])
def test_install_from_zip_with_or_without_top_folder(tmp_path, top_level):
    src = write_extension(tmp_path / "src", "uji.zip", code=CODE)
    archive = zip_directory(src, tmp_path / "e.zip", top_level=top_level)
    assert installer.install_from_zip(archive, user_dir=tmp_path / "user") == "uji.zip"
    assert (tmp_path / "user" / "uji.zip" / "main.py").is_file()


def test_zip_slip_and_absolute_paths_are_rejected(tmp_path):
    for name in ("../../evil.py", "/abs/evil.py", "a/../../evil.py"):
        archive = tmp_path / "evil.zip"
        with zipfile.ZipFile(archive, "w") as zf:
            zf.writestr("sorot-extension.json", '{"id":"uji.evil","name":"E","api":1,"entry":"main.py"}')
            zf.writestr("main.py", "def activate(api): pass")
            zf.writestr(name, "x")
        with pytest.raises(ExtensionError, match="berbahaya"):
            installer.install_from_zip(archive, user_dir=tmp_path / "user")
        assert not (tmp_path / "evil.py").exists() and not (tmp_path / "user" / "uji.evil").exists()


def test_zip_with_symlink_member_is_rejected(tmp_path):
    archive = tmp_path / "link.zip"
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr("sorot-extension.json", '{"id":"uji.link","name":"E","api":1,"entry":"main.py"}')
        zf.writestr("main.py", "def activate(api): pass")
        info = zipfile.ZipInfo("pintasan")
        info.external_attr = (0o120777) << 16
        zf.writestr(info, "/etc/passwd")
    with pytest.raises(ExtensionError, match="simbolik"):
        installer.install_from_zip(archive, user_dir=tmp_path / "user")


def test_zip_bomb_and_garbage_are_rejected(tmp_path, monkeypatch):
    archive = tmp_path / "bomb.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("sorot-extension.json", '{"id":"uji.bomb","name":"B","api":1,"entry":"main.py"}')
        zf.writestr("main.py", "def activate(api): pass")
        zf.writestr("besar.bin", b"0" * 5_000)
    monkeypatch.setattr(installer, "MAX_TREE_BYTES", 1000)
    with pytest.raises(ExtensionError, match="50 MB"):
        installer.install_from_zip(archive, user_dir=tmp_path / "user")
    junk = tmp_path / "junk.zip"
    junk.write_bytes(b"bukan zip")
    with pytest.raises(ExtensionError, match="ZIP"):
        installer.install_from_zip(junk, user_dir=tmp_path / "user")
    no_manifest = tmp_path / "nm.zip"
    with zipfile.ZipFile(no_manifest, "w") as zf:
        zf.writestr("main.py", "x")
    with pytest.raises(ExtensionError, match="sorot-extension.json"):
        installer.install_from_zip(no_manifest, user_dir=tmp_path / "user")


def test_uninstall_never_leaves_the_user_directory(tmp_path):
    user = tmp_path / "user"
    user.mkdir()
    victim = tmp_path / "penting"
    victim.mkdir()
    (victim / "x.txt").write_text("jangan hapus")
    for target in ("../penting", "/tmp", "..", "tidak.ada"):
        with pytest.raises(ExtensionError):
            installer.uninstall(target, user_dir=user)
    assert (victim / "x.txt").exists()


def test_installed_example_is_discoverable_end_to_end(tmp_path):
    src = write_extension(tmp_path / "src", "uji.ujung", code=GOOD_CODE)
    user = tmp_path / "user"
    installer.install_from_dir(src, user_dir=user)
    info = discovery.discover(user_dir=user, system_dirs=(), include_pip=False)[0]
    assert info.usable and info.manifest.has_code and os.path.isdir(info.path)
