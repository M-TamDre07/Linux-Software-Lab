"""A tiny local HTTP server that imitates an OpenAI-compatible provider.

This is a *test double*: passing tests prove the client handles these
responses, not that any real provider behaves identically.
"""
from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class FakeProvider:
    def __init__(self) -> None:
        self.requests: list[dict] = []
        self.routes: dict[tuple[str, str], dict] = {}
        provider = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args):  # keep test output quiet
                pass

            def _handle(self):
                length = int(self.headers.get("Content-Length") or 0)
                body = self.rfile.read(length) if length else b""
                provider.requests.append({
                    "method": self.command, "path": self.path,
                    "headers": {k.lower(): v for k, v in self.headers.items()}, "body": body,
                })
                route = provider.routes.get((self.command, self.path), {"status": 404, "json": {"error": {"message": "tidak ada"}}})
                if route.get("delay"):
                    time.sleep(route["delay"])
                payload = route.get("raw")
                if payload is None:
                    payload = json.dumps(route.get("json", {})).encode()
                self.send_response(route.get("status", 200))
                for key, value in route.get("headers", {}).items():
                    self.send_header(key, value)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            do_GET = do_POST = _handle

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.server.server_address[1]}/v1"

    def start(self) -> FakeProvider:
        self.thread.start()
        return self

    def stop(self) -> None:
        self.server.shutdown()
        self.server.server_close()

    def route(self, method: str, path: str, **spec) -> None:
        self.routes[(method, path)] = spec


def chat_reply(text: str) -> dict:
    return {"choices": [{"message": {"role": "assistant", "content": text}}]}
