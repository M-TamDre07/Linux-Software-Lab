import json
import threading
import time

import pytest
from fake_rclone import install_fake_rclone

from sorot.core.cancel import CancelToken, OperationCancelled
from sorot.services import drive_service as drive
from sorot.services.drive_service import DriveIntegrationError


def calls(log):
    return [json.loads(line) for line in log.read_text().splitlines()]


# ---- pure validation -------------------------------------------------------
@pytest.mark.parametrize("remote", ["gdrive:", "My Drive:", "a_b.c-d:", "A1:"])
def test_valid_remote_names(remote):
    assert drive.validate_remote(remote) == remote


@pytest.mark.parametrize("remote", ["", "gdrive", "-flag:", ":", " gdrive:", "gd/rive:", "a;rm -rf:", "x:y:", "$(id):"])
def test_invalid_remote_names(remote):
    with pytest.raises(DriveIntegrationError):
        drive.validate_remote(remote)


@pytest.mark.parametrize("path", ["../x.txt", "a/../b.txt", "a//b.txt", "~/x.txt", "a\\b.txt", "x\x00.txt", "./a.txt", ""])
def test_invalid_paths_are_rejected(path):
    with pytest.raises(DriveIntegrationError):
        drive.remote_target("gdrive:", path)


def test_target_is_always_prefixed_by_the_remote():
    assert drive.remote_target("gdrive:", "/Naskah/video 1.txt") == "gdrive:Naskah/video 1.txt"
    assert drive.remote_target("gdrive:", "--config=/etc/shadow").startswith("gdrive:")


def test_parse_remotes_with_and_without_type():
    remotes = drive.parse_remotes("gdrive: drive\nlokal: local\nkosong:\nbukan-remote\n\n-bad: x\n")
    assert [(r.name, r.kind) for r in remotes] == [("gdrive:", "drive"), ("lokal:", "local"), ("kosong:", "")]
    assert remotes[0].is_google_drive and not remotes[1].is_google_drive


# ---- missing rclone ------------------------------------------------------------
def test_missing_rclone_gives_clear_message(monkeypatch):
    monkeypatch.setenv("PATH", "/nonexistent")
    assert drive.rclone_available() is False
    with pytest.raises(DriveIntegrationError, match="rclone belum terpasang"):
        drive.list_remotes()


# ---- against a fake rclone -------------------------------------------------
@pytest.fixture()
def fake(tmp_path, monkeypatch):
    return install_fake_rclone(tmp_path, monkeypatch)


def test_list_remotes_and_version(fake):
    remotes = drive.list_remotes()
    assert [r.name for r in remotes] == ["gdrive:", "lokal:", "kosong:"]
    assert drive.rclone_version().startswith("rclone v1.99")


def test_list_text_files_only_txt_and_respects_limit(fake):
    root, log = fake
    (root / "Naskah").mkdir()
    for name in ("a.txt", "b.TXT", "c.md", "Naskah/d.txt"):
        (root / name).write_text("x")
    files = drive.list_text_files("gdrive:")
    assert sorted(files) == ["Naskah/d.txt", "a.txt", "b.TXT"]
    assert len(drive.list_text_files("gdrive:", limit=2)) == 2
    args = calls(log)[0]
    assert args[:2] == ["lsf", "gdrive:"] and "--max-depth" in args and "--timeout" in args


def test_list_text_files_in_a_subfolder(fake):
    root, log = fake
    (root / "Naskah").mkdir()
    (root / "Naskah" / "d.txt").write_text("x")
    assert drive.list_text_files("gdrive:", "Naskah") == ["d.txt"]
    assert calls(log)[0][1] == "gdrive:Naskah"


def test_read_text_file_decodes_bom_and_bounds_request(fake):
    root, log = fake
    (root / "n.txt").write_bytes("\ufeffHalo dunia".encode())
    assert drive.read_text_file("gdrive:", "n.txt") == "Halo dunia"
    args = calls(log)[0]
    assert args[0] == "cat" and args[1] == "gdrive:n.txt" and "--count" in args


def test_read_text_file_rejects_oversized(fake, monkeypatch):
    root, _ = fake
    monkeypatch.setattr(drive, "MAX_TEXT_BYTES", 10)
    (root / "big.txt").write_text("x" * 100)
    with pytest.raises(DriveIntegrationError, match="terlalu besar"):
        drive.read_text_file("gdrive:", "big.txt")


def test_read_text_file_rejects_non_utf8(fake):
    root, _ = fake
    (root / "bin.txt").write_bytes(b"\xff\xfe\xfa")
    with pytest.raises(DriveIntegrationError, match="UTF-8"):
        drive.read_text_file("gdrive:", "bin.txt")


def test_write_text_file_uploads_content_via_argument_list(fake):
    root, log = fake
    drive.write_text_file("gdrive:", "Folder Baru/naskah saya; rm -rf.txt", "isi ✓")
    assert (root / "Folder Baru" / "naskah saya; rm -rf.txt").read_text(encoding="utf-8") == "isi ✓"
    args = calls(log)[0]
    assert args[0] == "copyto" and args[2] == "gdrive:Folder Baru/naskah saya; rm -rf.txt"


def test_rclone_failure_surfaces_last_error_line(fake, monkeypatch):
    monkeypatch.setenv("FAKE_RCLONE_FAIL", "didn't find section in config file")
    with pytest.raises(DriveIntegrationError, match="didn't find section"):
        drive.list_remotes()


def test_run_times_out_and_kills_process(fake, monkeypatch):
    monkeypatch.setenv("FAKE_RCLONE_SLEEP", "5")
    started = time.monotonic()
    with pytest.raises(DriveIntegrationError, match="batas waktu"):
        drive._run(["version"], timeout=0.6, cancel=None)
    assert time.monotonic() - started < 3


def test_run_can_be_cancelled(fake, monkeypatch):
    monkeypatch.setenv("FAKE_RCLONE_SLEEP", "5")
    token = CancelToken()
    threading.Timer(0.4, token.cancel).start()
    started = time.monotonic()
    with pytest.raises(OperationCancelled):
        drive._run(["version"], timeout=30, cancel=token)
    assert time.monotonic() - started < 3


def test_invalid_input_never_starts_a_process(fake):
    _, log = fake
    for call in (lambda: drive.read_text_file("bad", "a.txt"), lambda: drive.write_text_file("gdrive:", "../a.txt", "x"),
                 lambda: drive.list_text_files("gdrive:", "../.."), lambda: drive.list_text_files("-x:")):
        with pytest.raises(DriveIntegrationError):
            call()
    assert not log.exists()
