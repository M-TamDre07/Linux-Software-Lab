import json

from sorot.core.config import (
    DEFAULT_SHORTCUTS,
    SCHEMA_VERSION,
    AppConfig,
    ConfigStore,
    migrate_legacy_values,
    upgrade_schema,
)


def test_defaults_round_trip():
    config = AppConfig()
    assert AppConfig.from_dict(config.to_dict()) == config


def test_out_of_range_and_wrong_types_are_sanitised():
    config = AppConfig.from_dict({
        "font_size": 9999, "scroll_speed": -5, "wpm": "abc", "text_color": "red",
        "position": "somewhere", "click_through": "false", "overlay_width": True,
        "ai_timeout": 1, "text_align": 42, "shortcuts": {"show_overlay": "Ctrl+K", "nope": "x"},
    })
    assert config.font_size == 120
    assert config.scroll_speed == 0
    assert config.wpm == 130
    assert config.text_color == "#F7F9FC"
    assert config.position == "top-center"
    assert config.click_through is False
    assert config.overlay_width == 760
    assert config.ai_timeout == 10
    assert config.text_align == "left"
    assert config.shortcuts["show_overlay"] == "Ctrl+K"
    assert set(config.shortcuts) == set(DEFAULT_SHORTCUTS)


def test_hex_colors_are_normalised_to_uppercase():
    assert AppConfig.from_dict({"text_color": "#abcdef"}).text_color == "#ABCDEF"


def test_unknown_keys_survive_save_and_load(tmp_path):
    store = ConfigStore(tmp_path / "config.json")
    path = store.path
    path.write_text(json.dumps({"schema_version": SCHEMA_VERSION + 1, "font_size": 40, "fitur_masa_depan": {"a": 1}}))
    result = store.load()
    assert result.config.font_size == 40
    assert result.notices and "lebih baru" in result.notices[0]
    store.save(result.config)
    assert json.loads(path.read_text())["fitur_masa_depan"] == {"a": 1}


def test_missing_file_gives_defaults(tmp_path):
    result = ConfigStore(tmp_path / "x" / "config.json").load()
    assert result.is_new and result.config == AppConfig() and not result.notices


def test_corrupt_file_is_quarantined_not_deleted(tmp_path):
    store = ConfigStore(tmp_path / "config.json")
    store.path.write_text("{bukan json")
    result = store.load()
    assert result.config == AppConfig()
    assert result.notices and "rusak" in result.notices[0]
    assert not store.path.exists()
    quarantined = [p for p in tmp_path.iterdir() if ".corrupt-" in p.name]
    assert len(quarantined) == 1 and quarantined[0].read_text() == "{bukan json"


def test_non_object_json_is_treated_as_corrupt(tmp_path):
    store = ConfigStore(tmp_path / "config.json")
    store.path.write_text("[1, 2, 3]")
    assert store.load().notices


def test_save_keeps_previous_version_as_backup_and_restores(tmp_path):
    store = ConfigStore(tmp_path / "config.json")
    first = AppConfig(font_size=30)
    store.save(first)
    store.save(AppConfig(font_size=44))
    assert json.loads(store.backup_path.read_text())["font_size"] == 30
    assert store.restore_backup() is True
    assert store.load().config.font_size == 30


def test_save_is_skipped_when_nothing_changed(tmp_path):
    store = ConfigStore(tmp_path / "config.json")
    store.save(AppConfig())
    store.save(AppConfig())
    assert not store.backup_path.exists()


def test_restore_without_backup_returns_false(tmp_path):
    assert ConfigStore(tmp_path / "config.json").restore_backup() is False


def test_api_key_is_never_part_of_the_config():
    keys = " ".join(AppConfig().to_dict().keys()).lower()
    assert "api_key" not in keys and "secret" not in keys


def test_legacy_migration_maps_labels_and_text():
    config, text = migrate_legacy_values({
        "text": "Naskah lama", "font_size": "36", "text_color_name": "Kuning lembut",
        "position": "Bawah kanan", "click_through": "true", "scroll_speed": 40,
        "overlay_x": 10, "overlay_y": 20, "ai_model": "model-x",
    })
    assert text == "Naskah lama"
    assert config.font_size == 36
    assert config.text_color == "#FFE7A3"
    assert config.position == "bottom-right"
    assert config.click_through is True
    assert (config.overlay_x, config.overlay_y) == (10, 20)
    assert config.ai_model == "model-x"


def test_legacy_manual_position_without_coordinates_falls_back():
    config, _ = migrate_legacy_values({"position": "Posisi manual"})
    assert config.position == "top-center"


def test_legacy_manual_position_with_coordinates_is_kept():
    config, _ = migrate_legacy_values({"position": "Posisi manual", "overlay_x": 5, "overlay_y": 6})
    assert config.position == "manual" and (config.overlay_x, config.overlay_y) == (5, 6)


def test_legacy_privacy_acknowledgement_is_not_carried_over():
    config, _ = migrate_legacy_values({"ai_privacy_acknowledged": "true"})
    assert config.ai_confirmed_hosts == []


def test_new_installs_use_speaking_speed_but_old_configs_keep_pixel_speed(tmp_path):
    assert AppConfig().speed_mode == "wpm"
    store = ConfigStore(tmp_path / "config.json")
    store.path.write_text(json.dumps({"schema_version": 2, "scroll_speed": 55, "font_size": 40}))
    loaded = store.load().config
    assert loaded.speed_mode == "pps" and loaded.scroll_speed == 55
    store.save(loaded)
    assert json.loads(store.path.read_text())["schema_version"] == SCHEMA_VERSION


def test_upgrade_does_not_override_an_explicit_choice_and_is_idempotent():
    assert upgrade_schema({"schema_version": 2, "speed_mode": "duration"})["speed_mode"] == "duration"
    once = upgrade_schema({"schema_version": 1})
    assert upgrade_schema(once) == once


def test_restoring_an_old_backup_is_upgraded_too(tmp_path):
    store = ConfigStore(tmp_path / "config.json")
    store.backup_path.write_text(json.dumps({"schema_version": 2, "scroll_speed": 70}))
    assert store.restore_backup()
    restored = json.loads(store.path.read_text())
    assert restored["speed_mode"] == "pps" and restored["schema_version"] == SCHEMA_VERSION


def test_new_fields_are_sanitised():
    config = AppConfig.from_dict({"speed_mode": "turbo", "target_seconds": 1, "guide_position": 999, "window_width": 5, "guide_enabled": "no"})
    assert config.speed_mode == "wpm" and config.target_seconds == 10 and config.guide_position == 70
    assert config.window_width == 640 and config.guide_enabled is False


def test_legacy_import_keeps_pixel_speed_semantics():
    config, _ = migrate_legacy_values({"scroll_speed": 40})
    assert config.speed_mode == "pps" and config.scroll_speed == 40
