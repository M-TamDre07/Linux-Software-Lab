import pytest

from sorot.core.script_markup import MAX_CUE_SECONDS, MIN_CUE_SECONDS, parse_script


def test_notes_are_hidden_and_not_counted():
    parsed = parse_script("Halo dunia\n// ingat tersenyum\n   // catatan dengan spasi\nSelamat tinggal")
    assert parsed.display_text == "Halo dunia\nSelamat tinggal"
    assert parsed.notes_hidden == 2 and parsed.words == 4


def test_slashes_inside_a_spoken_line_are_not_a_note():
    parsed = parse_script("Buka https://contoh.id sekarang // bukan catatan")
    assert parsed.notes_hidden == 0 and parsed.words == 6


@pytest.mark.parametrize("line,seconds", [
    ("[jeda]", 2.0), ("[JEDA 3]", 3.0), ("[pause 2.5]", 2.5), ("[jeda 2,5]", 2.5),
    ("  [jeda 4 detik]  ", 4.0), ("[jeda 7s]", 7.0), ("[ jeda   1 dtk ]", 1.0),
])
def test_pause_cue_variants(line, seconds):
    parsed = parse_script(line)
    block = parsed.blocks[0]
    assert block.kind == "cue" and block.pause == seconds and block.words == 0
    assert "JEDA" in block.text and parsed.cue_seconds == seconds


def test_cue_seconds_are_clamped():
    assert parse_script("[jeda 0.1]").blocks[0].pause == MIN_CUE_SECONDS
    assert parse_script("[jeda 9999]").blocks[0].pause == MAX_CUE_SECONDS


@pytest.mark.parametrize("line", ["[jeda abc]", "jeda 3", "[jeda 3] lalu bicara", "[istirahat]"])
def test_lookalikes_stay_spoken_text(line):
    block = parse_script(line).blocks[0]
    assert block.kind == "text" and block.words >= 1


def test_blank_lines_become_short_pauses_and_blocks_match_display_lines():
    parsed = parse_script("Satu\n\nDua\r\n[jeda 1]\r\nTiga")
    assert [b.kind for b in parsed.blocks] == ["text", "blank", "text", "cue", "text"]
    assert len(parsed.display_text.split("\n")) == len(parsed.blocks)
    assert parsed.blocks[1].pause > 0


def test_empty_script():
    parsed = parse_script("")
    assert parsed.words == 0 and len(parsed.blocks) == 1 and parsed.blocks[0].kind == "blank"
