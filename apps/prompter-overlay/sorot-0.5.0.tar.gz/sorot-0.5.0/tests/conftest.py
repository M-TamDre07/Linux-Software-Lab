"""Shared fixtures. Every test runs against a throw-away home directory."""
from __future__ import annotations

import faulthandler
import os
import sys
from pathlib import Path

import pytest

SRC = Path(__file__).resolve().parents[1] / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))


@pytest.fixture(autouse=True)
def isolated_home(tmp_path, monkeypatch):
    """Never touch the developer's real configuration, scripts, or keyring."""
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    for name in ("XDG_CONFIG_HOME", "XDG_DATA_HOME", "XDG_STATE_HOME"):
        monkeypatch.setenv(name, str(home / name.lower()))
    monkeypatch.delenv("SOROT_API_KEY", raising=False)
    monkeypatch.delenv("SOROT_QT_PLATFORM", raising=False)
    monkeypatch.delenv("QT_QPA_PLATFORM", raising=False)
    return home


def pytest_collection_modifyitems(config, items):
    """GUI tests need PySide6 and an offscreen platform; skip cleanly when absent."""
    try:
        import PySide6  # noqa: F401
        import pytestqt  # noqa: F401
    except ImportError:
        skip = pytest.mark.skip(reason="PySide6/pytest-qt tidak terpasang")
        for item in items:
            if "gui" in item.keywords:
                item.add_marker(skip)


os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


@pytest.fixture(autouse=True)
def hang_watchdog():
    """A modal dialog nobody answers would hang the run forever: abort with a traceback instead."""
    faulthandler.dump_traceback_later(90, exit=True)
    yield
    faulthandler.cancel_dump_traceback_later()
