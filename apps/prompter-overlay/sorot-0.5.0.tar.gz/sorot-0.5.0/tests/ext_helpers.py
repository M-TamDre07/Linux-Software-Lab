"""Builders for throw-away extensions used by the extension tests."""
from __future__ import annotations

import json
import textwrap
import zipfile
from pathlib import Path


def write_extension(root: Path, ext_id: str = "uji.contoh", *, code: str | None = None, contributes: dict | None = None,
                    extra: dict | None = None) -> Path:
    directory = root / ext_id
    directory.mkdir(parents=True, exist_ok=True)
    manifest = {"id": ext_id, "name": f"Ekstensi {ext_id}", "version": "1.0.0", "api": 1, "author": "Penguji", "description": "Untuk pengujian."}
    if code is not None:
        manifest["entry"] = "main.py"
        (directory / "main.py").write_text(textwrap.dedent(code), encoding="utf-8")
    if contributes is not None:
        manifest["contributes"] = contributes
    manifest.update(extra or {})
    (directory / "sorot-extension.json").write_text(json.dumps(manifest), encoding="utf-8")
    return directory


def zip_directory(directory: Path, target: Path, *, top_level: bool = False) -> Path:
    with zipfile.ZipFile(target, "w") as zf:
        for file in sorted(directory.rglob("*")):
            if file.is_file():
                arc = file.relative_to(directory.parent if top_level else directory)
                zf.write(file, arc.as_posix())
    return target


GOOD_CODE = '''
import os, sys

def activate(api):
    api.register_transform("upper", "Huruf besar", lambda text: text.upper())
    api.register_transform("boom", "Rusak", lambda text: 1 / 0)
    api.register_transform("notstr", "Bukan teks", lambda text: 42)
    api.register_transform("slow", "Lambat", lambda text: __import__("time").sleep(30) or text)
    api.register_transform("die", "Mati", lambda text: os._exit(3))
    api.register_transform("chatty", "Berisik", lambda text: print("ini stdout biasa") or text + "!")
    api.register_transform("env", "Lingkungan", lambda text: ",".join(sorted(os.environ)))
    api.register_transform("cwd", "Folder kerja", lambda text: os.getcwd())
    api.register_importer("rev", "Balik", [".rev"], lambda path: open(path, encoding="utf-8").read()[::-1])
    api.register_exporter("up", "Besar", ".up", lambda text, path: open(path, "w", encoding="utf-8").write(text.upper()))
    api.register_action("count", "Hitung", lambda text: {"notify": f"{len(text.split())} kata", "set_text": text + " (dihitung)"})
    api.register_action("say", "Katakan", lambda text: api.notify("halo dari ekstensi"))
    events = []
    api.on("playback.started", lambda data: events.append(data) or api.log(f"mulai {data}"))
    api.on("script.saved", lambda data: open(api.data_dir / "saved.txt", "a").write(data.get("name", "") + "\\n"))
'''
