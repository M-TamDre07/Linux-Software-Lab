import pytest

from sorot.core.fileio import ScriptFileError
from sorot.core.scripts import DraftStore, ScriptLibrary, safe_script_name


def test_draft_round_trip_and_clear(tmp_path):
    store = DraftStore(tmp_path / "draft.txt")
    assert store.load() == ""
    store.save("halo\ndunia")
    assert store.load() == "halo\ndunia"
    store.clear()
    assert store.load() == ""
    store.clear()  # idempotent


def test_corrupt_draft_does_not_crash(tmp_path):
    path = tmp_path / "draft.txt"
    path.write_bytes(b"\xff\xfe\xfa")
    assert DraftStore(path).load() == ""


@pytest.mark.parametrize("raw,expected", [
    ("Video 1", "Video 1.txt"),
    ("  naskah.txt ", "naskah.txt"),
    ("../../etc/passwd", ".._.._etc_passwd.txt".lstrip(".")),
    ("a/b\\c:d*e?", "a_b_c_d_e_.txt"),
    ("...rahasia", "rahasia.txt"),
])
def test_safe_script_name_never_yields_a_path(raw, expected):
    name = safe_script_name(raw)
    assert "/" not in name and "\\" not in name and not name.startswith(".")
    assert name == expected


def test_safe_script_name_rejects_empty_and_truncates():
    for bad in ("", "   ", "...", ".txt"):
        with pytest.raises(ScriptFileError):
            safe_script_name(bad)
    assert len(safe_script_name("x" * 500)) <= 84


def test_library_save_list_load_delete(tmp_path):
    library = ScriptLibrary(tmp_path / "lib")
    assert library.list() == []
    library.save("Pembukaan", "Selamat datang")
    library.save("Penutup", "Terima kasih")
    names = {entry.name for entry in library.list()}
    assert names == {"Pembukaan", "Penutup"}
    assert library.load("Pembukaan") == "Selamat datang"
    assert library.exists("Penutup")
    library.delete("Penutup")
    assert not library.exists("Penutup")
    library.delete("Penutup")  # deleting a missing script is harmless


def test_library_ignores_non_txt_and_hidden_files(tmp_path):
    directory = tmp_path / "lib"
    directory.mkdir()
    (directory / "a.txt").write_text("a")
    (directory / "b.md").write_text("b")
    (directory / ".c.txt").write_text("c")
    assert [entry.name for entry in ScriptLibrary(directory).list()] == ["a"]


def test_library_delete_cannot_escape_directory(tmp_path):
    outside = tmp_path / "penting.txt"
    outside.write_text("jangan hapus")
    library = ScriptLibrary(tmp_path / "lib")
    library.save("x", "y")
    library.delete("../penting")
    assert outside.read_text() == "jangan hapus"


def test_snapshots_dedupe_throttle_and_prune(tmp_path):
    from sorot.core.scripts import SNAPSHOT_KEEP, SNAPSHOT_MIN_INTERVAL

    store = DraftStore(tmp_path / "draft.txt")
    assert store.snapshot("") is None and store.snapshot("   \n") is None
    first = store.snapshot("versi satu", now=1_000_000)
    assert first is not None
    assert store.snapshot("versi satu", force=True, now=1_000_500) is None, "isi identik tidak digandakan"
    assert store.snapshot("versi dua", now=1_000_000 + SNAPSHOT_MIN_INTERVAL - 1) is None, "terlalu cepat"
    assert store.snapshot("versi dua", force=True, now=1_000_000 + 5) is not None, "force melewati batas interval"
    for i in range(SNAPSHOT_KEEP + 8):
        store.snapshot(f"isi {i}", now=2_000_000 + i * 100)
    names = store.snapshots()
    assert len(names) == SNAPSHOT_KEEP
    assert store.load_snapshot(names[0].name) == f"isi {SNAPSHOT_KEEP + 7}"
    assert names == sorted(names, key=lambda s: (s.modified, s.name), reverse=True)


def test_snapshot_load_cannot_escape_history_directory(tmp_path):
    store = DraftStore(tmp_path / "draft.txt")
    store.snapshot("aman", now=1_000_000)
    (tmp_path / "rahasia.txt").write_text("jangan baca")
    with pytest.raises(ScriptFileError):
        store.load_snapshot("../rahasia")
    assert store.load_snapshot(store.snapshots()[0].name) == "aman"


def test_snapshots_survive_a_draft_clear(tmp_path):
    store = DraftStore(tmp_path / "draft.txt")
    store.save("penting")
    store.snapshot("penting", now=1_000_000)
    store.clear()
    assert store.load() == "" and store.load_snapshot(store.snapshots()[0].name) == "penting"
