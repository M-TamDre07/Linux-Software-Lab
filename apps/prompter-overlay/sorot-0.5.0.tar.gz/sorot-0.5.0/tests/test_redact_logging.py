import logging

from sorot.core.redact import redact
from sorot.logging_setup import setup_logging


def test_redacts_bearer_and_key_patterns():
    secret = "sk-abcdefghijklmnop1234"
    for text in (f"Authorization: Bearer {secret}", f"api_key={secret}", f'{{"api-key": "{secret}"}}', f"kunci {secret} bocor"):
        assert secret not in redact(text), text


def test_redacts_long_opaque_tokens_but_keeps_normal_text():
    token = "A" * 48
    assert token not in redact(f"token {token}")
    assert redact("Naskah selesai dibuka: video.txt") == "Naskah selesai dibuka: video.txt"


def test_logger_writes_redacted_private_file(tmp_path):
    log_path = tmp_path / "state" / "app.log"
    result = setup_logging(path=log_path)
    assert result == log_path
    logger = logging.getLogger("sorot.test")
    logger.error("gagal dengan Bearer sk-supersecretvalue12345")
    try:
        raise RuntimeError("password=hunter2hunter2")
    except RuntimeError:
        logger.exception("kesalahan tak terduga")
    for handler in logging.getLogger("sorot").handlers:
        handler.flush()
    content = log_path.read_text(encoding="utf-8")
    assert "supersecretvalue" not in content and "hunter2" not in content
    assert "RuntimeError" in content
    assert (log_path.stat().st_mode & 0o777) == 0o600
    setup_logging(path=tmp_path / "other.log")  # reconfiguring must not duplicate handlers
    assert len(logging.getLogger("sorot").handlers) == 1
