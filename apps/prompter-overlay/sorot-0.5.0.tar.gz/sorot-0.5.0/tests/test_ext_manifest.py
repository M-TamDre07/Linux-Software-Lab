import json

import pytest
from ext_helpers import write_extension

from sorot.extensions.manifest import ExtensionError, load_manifest, parse_manifest


def base(**over):
    data = {"id": "uji.satu", "name": "Satu", "version": "1.0", "api": 1}
    data.update(over)
    return json.dumps(data)


def test_valid_declarative_manifest():
    m = parse_manifest(base(contributes={"templates": [{"name": "Salam", "text": "Halo"}]}))
    assert m.ext_id == "uji.satu" and not m.has_code and m.kind == "deklaratif" and m.templates[0].name == "Salam" and not m.problems


@pytest.mark.parametrize("bad_id", ["", "ab", "UPPER.case", "has space", "../x", "a" * 65, "-lead", 7, None])
def test_bad_ids_are_rejected(bad_id):
    with pytest.raises(ExtensionError, match="id"):
        parse_manifest(base(id=bad_id))


@pytest.mark.parametrize("api", [0, 2, "1", None])
def test_unsupported_api_versions_are_rejected(api):
    with pytest.raises(ExtensionError, match="API"):
        parse_manifest(base(api=api))


def test_min_app_is_enforced():
    with pytest.raises(ExtensionError, match="Membutuhkan"):
        parse_manifest(base(min_app="99.0.0"))
    assert parse_manifest(base(min_app="0.1")).ext_id == "uji.satu"


@pytest.mark.parametrize("entry", ["../evil.py", "/etc/passwd.py", "a\\b.py", "main.txt", "", 5, "sub/../../x.py"])
def test_unsafe_or_wrong_entry_is_rejected(entry):
    with pytest.raises(ExtensionError):
        parse_manifest(base(entry=entry))


def test_missing_entry_file_is_reported(tmp_path):
    d = write_extension(tmp_path, code="def activate(api): pass")
    (d / "main.py").unlink()
    with pytest.raises(ExtensionError, match="tidak ditemukan"):
        load_manifest(d)


@pytest.mark.parametrize("raw", ["", "{bukan json", "[1,2]", '"teks"'])
def test_non_object_json_is_rejected(raw):
    with pytest.raises(ExtensionError):
        parse_manifest(raw)


def test_oversized_manifest_is_rejected():
    with pytest.raises(ExtensionError, match="besar"):
        parse_manifest(base(description="x" * 300_000))


def test_bad_entries_are_dropped_not_fatal():
    m = parse_manifest(base(contributes={
        "themes": [
            {"id": "ok", "name": "Bagus", "base": "dark", "colors": {"bg": "#101010", "accent": "#FFAA00"}},
            {"id": "warna", "name": "Salah", "colors": {"bg": "merah"}},
            {"id": "BAD ID", "name": "X", "colors": {"bg": "#000000"}},
            {"id": "ok", "name": "Ganda", "colors": {"bg": "#000000"}},
            "bukan objek",
        ],
        "overlay_presets": [
            {"name": "A", "text_color": "#ffffff", "background_color": "#000000", "background_opacity": 50},
            {"name": "B", "text_color": "putih", "background_color": "#000000"},
            {"name": "C", "text_color": "#ffffff", "background_color": "#000000", "background_opacity": 500},
        ],
        "ai_tasks": [{"id": "t1", "label": "Satu", "instruction": "Lakukan."}, {"id": "t1", "label": "Ganda", "instruction": "x"}, {"id": "t2", "label": "", "instruction": "x"}],
        "templates": [{"name": "T", "text": "ok"}, {"name": "", "text": "x"}, {"name": "Besar", "text": "x" * 200_000}],
    }))
    assert [t.theme_id for t in m.themes] == ["ok"] and m.themes[0].colors == {"bg": "#101010", "accent": "#FFAA00"}
    assert [p.name for p in m.presets] == ["A"] and m.presets[0].text_color == "#FFFFFF"
    assert [t.task_id for t in m.ai_tasks] == ["t1"]
    assert [t.name for t in m.templates] == ["T"]
    assert len(m.problems) >= 6


def test_homepage_and_permissions_are_sanitised():
    m = parse_manifest(base(homepage="http://insecure.example", permissions=["network", "root", "network", 3]))
    assert m.homepage == "" and m.permissions == ("network",) and any("homepage" in p for p in m.problems) and any("izin" in p for p in m.problems)
    assert parse_manifest(base(homepage="https://contoh.id/x")).homepage == "https://contoh.id/x"


def test_manifest_that_contributes_nothing_is_flagged():
    assert any("tidak menyumbangkan" in p for p in parse_manifest(base()).problems)


def test_symlinked_manifest_is_refused(tmp_path):
    real = tmp_path / "real.json"
    real.write_text(base())
    d = tmp_path / "ext"
    d.mkdir()
    (d / "sorot-extension.json").symlink_to(real)
    with pytest.raises(ExtensionError):
        load_manifest(d)
