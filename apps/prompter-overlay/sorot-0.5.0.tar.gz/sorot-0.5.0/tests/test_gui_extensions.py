"""End-to-end extension behaviour through the real window (real subprocesses, fake dialogs)."""
from __future__ import annotations

import time
from pathlib import Path

import pytest

pytest.importorskip("PySide6")
pytest.importorskip("pytestqt")

from ext_helpers import write_extension  # noqa: E402
from PySide6.QtWidgets import QFileDialog, QMessageBox  # noqa: E402

from sorot.core import paths  # noqa: E402
from sorot.core.config import ConfigStore  # noqa: E402
from sorot.core.scripts import DraftStore, ScriptLibrary  # noqa: E402
from sorot.extensions import discovery  # noqa: E402
from sorot.ui import theme  # noqa: E402
from sorot.ui.extensions_page import ApprovalDialog  # noqa: E402
from sorot.ui.main_window import EXTENSIONS_PAGE, MainWindow  # noqa: E402

pytestmark = pytest.mark.gui

CODE = '''
import time

def activate(api):
    (api.data_dir / "activated.txt").write_text("ya")
    api.register_transform("upper", "Huruf besar", lambda t: t.upper())
    api.register_transform("boom", "Rusak", lambda t: 1 / 0)
    api.register_transform("sleepy", "Pelan", lambda t: time.sleep(1.2) or t.upper())
    api.register_action("count", "Hitung kata", lambda t: {"notify": f"{len(t.split())} kata", "set_text": t + " (+)"})
    api.register_importer("rev", "Balik teks", [".rev"], lambda p: open(p, encoding="utf-8").read()[::-1])
    api.register_exporter("up", "Huruf besar", ".up", lambda t, p: open(p, "w", encoding="utf-8").write(t.upper()))
    for name in ("app.started", "script.saved", "overlay.shown", "playback.started", "script.changed"):
        api.on(name, lambda data, name=name: open(api.data_dir / "events.log", "a").write(name + "\\n"))
'''
DECLARATIVE = {
    "themes": [{"id": "senja", "name": "Senja", "base": "dark", "colors": {"accent": "#FF3366", "bg": "#101018"}}],
    "overlay_presets": [{"name": "Neon", "text_color": "#00FFAA", "background_color": "#000000", "background_opacity": 80}],
    "ai_tasks": [{"id": "puisi", "label": "Jadikan puisi", "instruction": "Ubah menjadi puisi singkat."}],
    "templates": [{"name": "Salam pembuka", "text": "Halo semuanya!\n[jeda 2]\nSelamat datang."}],
}


def user_dir() -> Path:
    return discovery.user_extensions_dir()


def make_window(qtbot) -> MainWindow:
    window = MainWindow(ConfigStore(), DraftStore(), ScriptLibrary())
    qtbot.addWidget(window)
    window.show()
    wait_refresh(qtbot, window)
    return window


def wait_refresh(qtbot, window) -> None:
    qtbot.waitUntil(lambda: not window.extensions.refreshing, timeout=20000)
    qtbot.wait(30)


def data_file(ext_id: str, name: str) -> Path:
    return discovery.extension_data_dir(ext_id) / name


def wait_for(path: Path, qtbot, timeout=6000) -> str:
    qtbot.waitUntil(path.exists, timeout=timeout)
    return path.read_text()


def approve(window, ext_id: str) -> None:
    window.extensions.approve(window.extensions.info(ext_id))
    wait_refresh(window.qtbot, window) if hasattr(window, "qtbot") else None


def approve_and_wait(qtbot, window, ext_id: str) -> None:
    window.extensions.approve(window.extensions.info(ext_id))
    wait_refresh(qtbot, window)


def finish(window) -> None:
    window.editor.document().setModified(False)
    window.close()


# ------------------------------------------------------------------ declarative
def test_declarative_contributions_appear_without_any_approval(qtbot):
    write_extension(user_dir(), "uji.dekor", contributes=DECLARATIVE)
    window = make_window(qtbot)
    assert window.extensions.approval(window.extensions.info("uji.dekor")) == "active"
    presets = [window.preset_combo.itemText(i) for i in range(window.preset_combo.count())]
    assert "Neon · Ekstensi uji.dekor" in presets
    assert window.templates_menu.isEnabled() and "Salam pembuka" in window.templates_menu.actions()[0].text()
    assert any("Jadikan puisi" in t.label for t in window.extensions.ai_tasks().values())
    finish(window)


def test_extension_preset_applies_colours(qtbot):
    write_extension(user_dir(), "uji.dekor", contributes=DECLARATIVE)
    window = make_window(qtbot)
    window.preset_combo.setCurrentText("Neon · Ekstensi uji.dekor")
    window._on_preset_chosen(0)
    assert (window.text_color_btn.color, window.bg_color_btn.color, window.opacity_slider.value()) == ("#00FFAA", "#000000", 80)
    finish(window)


def test_template_replaces_script_and_can_be_undone(qtbot):
    write_extension(user_dir(), "uji.dekor", contributes=DECLARATIVE)
    window = make_window(qtbot)
    window._replace_editor_text("naskah lama", modified=False)
    window.templates_menu.actions()[0].trigger()
    assert window.editor.toPlainText().startswith("Halo semuanya!")
    window.editor.undo()
    assert window.editor.toPlainText() == "naskah lama"
    finish(window)


def test_extension_theme_is_applied_and_reverts_when_disabled(qtbot):
    write_extension(user_dir(), "uji.dekor", contributes=DECLARATIVE)
    window = make_window(qtbot)
    index = window.ext_theme_combo.findData("uji.dekor/senja")
    assert index > 0
    window.ext_theme_combo.setCurrentIndex(index)
    window._on_ext_theme_chosen(index)
    assert theme.palette().accent == "#FF3366" and theme.palette().surface == theme.DARK.surface
    window.extensions.disable("uji.dekor")
    wait_refresh(qtbot, window)
    assert window.config.theme_ext == "" and theme.palette().accent == theme.DARK.accent
    finish(window)


def test_disabled_declarative_extension_contributes_nothing(qtbot):
    write_extension(user_dir(), "uji.dekor", contributes=DECLARATIVE)
    window = make_window(qtbot)
    window.extensions.disable("uji.dekor")
    wait_refresh(qtbot, window)
    assert not window.templates_menu.isEnabled() and not window.extensions.ai_tasks()
    window.extensions.enable("uji.dekor")
    wait_refresh(qtbot, window)
    assert window.templates_menu.isEnabled()
    finish(window)


def test_extension_ai_task_reaches_the_prompt():
    import json

    from sorot.extensions.manifest import parse_manifest
    from sorot.services import ai_service as ai
    from sorot.services.ai_service import AITask

    manifest = parse_manifest(json.dumps({"id": "uji.ai", "name": "A", "api": 1, "contributes": {"ai_tasks": [{"id": "puisi", "label": "P", "instruction": "Ubah menjadi puisi singkat."}]}}))
    task = manifest.ai_tasks[0]
    extra = {"ext:uji.ai/puisi": AITask("ext:uji.ai/puisi", task.label, task.instruction)}
    messages = ai.build_messages("ext:uji.ai/puisi", "Halo", extra_tasks=extra)
    assert "Ubah menjadi puisi singkat." in messages[1]["content"]
    with pytest.raises(ai.AIError):
        ai.build_messages("ext:uji.ai/puisi", "Halo")  # not offered unless the extension is active


def test_ai_dialog_lists_extension_tasks(qtbot):
    from sorot.ui.ai_dialog import AIAssistantDialog

    write_extension(user_dir(), "uji.dekor", contributes=DECLARATIVE)
    window = make_window(qtbot)
    captured = {}

    def fake_exec(self):
        captured["labels"] = [self.task_combo.itemText(i) for i in range(self.task_combo.count())]
        return 0

    from unittest import mock

    with mock.patch.object(AIAssistantDialog, "exec", fake_exec):
        window.open_ai_assistant()
    assert any("Jadikan puisi" in label for label in captured["labels"]) and "Perbaiki tata bahasa" in captured["labels"]
    finish(window)


# ------------------------------------------------------------------- code ext
def test_code_extension_never_runs_before_approval(qtbot):
    write_extension(user_dir(), "uji.kode", code=CODE)
    window = make_window(qtbot)
    info = window.extensions.info("uji.kode")
    assert window.extensions.approval(info) == "needs_approval"
    qtbot.wait(400)
    assert not data_file("uji.kode", "activated.txt").exists(), "kode tidak boleh dijalankan sebelum disetujui"
    assert not window.extensions.commands()
    finish(window)


def test_approved_extension_runs_and_adds_menu_commands(qtbot):
    write_extension(user_dir(), "uji.kode", code=CODE)
    window = make_window(qtbot)
    approve_and_wait(qtbot, window, "uji.kode")
    assert wait_for(data_file("uji.kode", "activated.txt"), qtbot) == "ya"
    labels = [a.text().strip() for a in window.extensions_menu.actions()]
    assert "Huruf besar" in labels and "Hitung kata" in labels
    assert window.extensions.status_text(window.extensions.info("uji.kode")) == "aktif"
    finish(window)


def test_approval_survives_restart_but_not_a_code_change(qtbot):
    ext = write_extension(user_dir(), "uji.kode", code=CODE)
    first = make_window(qtbot)
    approve_and_wait(qtbot, first, "uji.kode")
    first.close()
    second = make_window(qtbot)
    assert second.extensions.approval(second.extensions.info("uji.kode")) == "active" and second.extensions.commands()
    (ext / "main.py").write_text(CODE + "\n# tambahan berbahaya\n")
    second.extensions.refresh()
    wait_refresh(qtbot, second)
    assert second.extensions.approval(second.extensions.info("uji.kode")) == "changed"
    assert not second.extensions.commands() and "uji.kode" not in second.extensions.host.entries
    finish(second)


def test_transform_applies_to_selection_only_and_is_undoable(qtbot):
    write_extension(user_dir(), "uji.kode", code=CODE)
    window = make_window(qtbot)
    approve_and_wait(qtbot, window, "uji.kode")
    window._replace_editor_text("halo dunia indah", modified=False)
    cursor = window.editor.textCursor()
    cursor.setPosition(5)
    cursor.setPosition(10, cursor.MoveMode.KeepAnchor)
    window.editor.setTextCursor(cursor)
    command = next(c for c in window.extensions.commands() if c.command_id == "upper")
    window._run_ext_command(command)
    qtbot.waitUntil(lambda: window.editor.toPlainText() == "halo DUNIA indah", timeout=8000)
    assert window.editor.document().isModified()
    window.editor.undo()
    assert window.editor.toPlainText() == "halo dunia indah"
    window._run_ext_command(command)  # no selection -> whole script
    window.editor.moveCursor(window.editor.textCursor().MoveOperation.Start)
    qtbot.waitUntil(lambda: window.editor.toPlainText() == "HALO DUNIA INDAH", timeout=8000)
    finish(window)


def test_result_is_discarded_if_the_script_changed_meanwhile(qtbot):
    write_extension(user_dir(), "uji.kode", code=CODE)
    window = make_window(qtbot)
    approve_and_wait(qtbot, window, "uji.kode")
    window._replace_editor_text("naskah awal", modified=False)
    command = next(c for c in window.extensions.commands() if c.command_id == "sleepy")
    window._run_ext_command(command)
    qtbot.wait(150)
    window.editor.insertPlainText(" + ketikan saya")
    qtbot.waitUntil(lambda: not window.extensions.busy(), timeout=8000)
    text = window.editor.toPlainText()
    assert "ketikan saya" in text and "NASKAH" not in text, "ketikan pengguna tidak boleh tertimpa hasil lama"
    assert "tidak diterapkan" in window.status_label.text()
    finish(window)


def test_failing_command_shows_a_clear_error_and_keeps_the_script(qtbot, monkeypatch):
    warnings = []
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: warnings.append(a[2]))
    write_extension(user_dir(), "uji.kode", code=CODE)
    window = make_window(qtbot)
    approve_and_wait(qtbot, window, "uji.kode")
    window._replace_editor_text("tetap aman", modified=False)
    window._run_ext_command(next(c for c in window.extensions.commands() if c.command_id == "boom"))
    qtbot.waitUntil(lambda: bool(warnings), timeout=8000)
    assert "ZeroDivisionError" in warnings[0] and window.editor.toPlainText() == "tetap aman"
    finish(window)


def test_a_command_can_be_cancelled_and_does_not_block_the_app(qtbot):
    write_extension(user_dir(), "uji.kode", code=CODE)
    window = make_window(qtbot)
    approve_and_wait(qtbot, window, "uji.kode")
    window._replace_editor_text("isi", modified=False)
    window._run_ext_command(next(c for c in window.extensions.commands() if c.command_id == "sleepy"))
    qtbot.waitUntil(window.extensions.busy, timeout=3000)
    window._run_ext_command(next(c for c in window.extensions.commands() if c.command_id == "upper"))
    assert "Masih ada perintah" in window.status_label.text()
    started = time.monotonic()
    window.extensions.cancel_call()
    qtbot.waitUntil(lambda: not window.extensions.busy(), timeout=5000)
    assert time.monotonic() - started < 3 and window.editor.toPlainText() == "isi"
    finish(window)


def test_action_notifies_and_sets_text(qtbot):
    write_extension(user_dir(), "uji.kode", code=CODE)
    window = make_window(qtbot)
    approve_and_wait(qtbot, window, "uji.kode")
    window._replace_editor_text("satu dua tiga", modified=False)
    window._run_ext_command(next(c for c in window.extensions.commands() if c.command_id == "count"))
    qtbot.waitUntil(lambda: window.editor.toPlainText() == "satu dua tiga (+)", timeout=8000)
    assert "3 kata" in window.status_label.text() or "diterapkan" in window.status_label.text()
    finish(window)


def test_importer_and_exporter_use_the_file_dialogs(qtbot, tmp_path, monkeypatch):
    write_extension(user_dir(), "uji.kode", code=CODE)
    window = make_window(qtbot)
    approve_and_wait(qtbot, window, "uji.kode")
    source = tmp_path / "x.rev"
    source.write_text("abc", encoding="utf-8")
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (str(source), ""))
    window._run_ext_command(next(c for c in window.extensions.commands() if c.kind == "importer"))
    qtbot.waitUntil(lambda: window.editor.toPlainText() == "cba", timeout=8000)
    target = tmp_path / "keluar.up"
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **k: (str(target), ""))
    window._run_ext_command(next(c for c in window.extensions.commands() if c.kind == "exporter"))
    qtbot.waitUntil(target.exists, timeout=8000)
    qtbot.waitUntil(lambda: target.read_text() == "CBA", timeout=3000)
    finish(window)


def test_events_reach_subscribed_extensions(qtbot, tmp_path, monkeypatch):
    write_extension(user_dir(), "uji.kode", code=CODE)
    window = make_window(qtbot)
    approve_and_wait(qtbot, window, "uji.kode")
    log = data_file("uji.kode", "events.log")
    window.extensions.broadcast("app.started", {})
    window.show_overlay()
    target = tmp_path / "naskah.txt"
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **k: (str(target), "Berkas teks (*.txt)"))
    window.editor.insertPlainText("isi")
    window.save_file()
    qtbot.waitUntil(lambda: log.exists() and {"overlay.shown", "script.saved"} <= set(log.read_text().split()), timeout=8000)
    window.close()


def test_closing_the_window_stops_extension_processes(qtbot):
    write_extension(user_dir(), "uji.kode", code=CODE)
    window = make_window(qtbot)
    approve_and_wait(qtbot, window, "uji.kode")
    process = window.extensions.host.entries["uji.kode"].process
    assert process.alive
    finish(window)
    assert not process.alive and not window.extensions.host.entries


# ------------------------------------------------------------------- the page
def test_approval_dialog_requires_an_explicit_acknowledgement(qtbot):
    write_extension(user_dir(), "uji.kode", code=CODE, extra={"permissions": ["network", "filesystem"], "author": "Pembuat X"})
    window = make_window(qtbot)
    dialog = ApprovalDialog(window.extensions.info("uji.kode"), window)
    qtbot.addWidget(dialog)
    assert not dialog.ok_btn.isEnabled()
    dialog.understand.setChecked(True)
    assert dialog.ok_btn.isEnabled()
    from PySide6.QtWidgets import QLabel

    text = " ".join(label.text() for label in dialog.findChildren(QLabel))
    assert "BUKAN sandbox" in text and "Pembuat X" in text and "mengakses jaringan" in text
    finish(window)


def test_page_lists_invalid_extensions_without_crashing(qtbot):
    broken = user_dir() / "rusak"
    broken.mkdir(parents=True)
    (broken / "sorot-extension.json").write_text("{bukan json")
    write_extension(user_dir(), "uji.dekor", contributes=DECLARATIVE)
    window = make_window(qtbot)
    page = window.extensions_page
    texts = [page.list.item(i).text() for i in range(page.list.count())]
    assert any("tidak valid" in t for t in texts) and any("Ekstensi uji.dekor" in t for t in texts)
    page.list.setCurrentRow(next(i for i, t in enumerate(texts) if "tidak valid" in t))
    assert "Tidak valid" in page.status_label.text() and not page.toggle_btn.isEnabled()
    finish(window)


def test_page_installs_from_folder_and_zip_then_removes(qtbot, tmp_path, monkeypatch):
    from ext_helpers import zip_directory

    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: QMessageBox.StandardButton.Yes)
    window = make_window(qtbot)
    page = window.extensions_page
    src = write_extension(tmp_path / "src", "uji.pasang", contributes=DECLARATIVE)
    monkeypatch.setattr(QFileDialog, "getExistingDirectory", lambda *a, **k: str(src))
    page.install_from_folder()
    wait_refresh(qtbot, window)
    assert window.extensions.info("uji.pasang") is not None
    archive = zip_directory(write_extension(tmp_path / "src2", "uji.zipku", code=CODE), tmp_path / "z.zip")
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (str(archive), ""))
    page.install_from_zip()
    wait_refresh(qtbot, window)
    assert window.extensions.approval(window.extensions.info("uji.zipku")) == "needs_approval"
    page.list.setCurrentRow(next(i for i, inf in enumerate(window.extensions.infos) if inf.ext_id == "uji.pasang"))
    page._remove()
    wait_refresh(qtbot, window)
    assert window.extensions.info("uji.pasang") is None and not (user_dir() / "uji.pasang").exists()
    finish(window)


def test_system_extensions_cannot_be_removed_from_the_page(qtbot, tmp_path, monkeypatch):
    window = make_window(qtbot)
    system = tmp_path / "sys"
    write_extension(system, "uji.sistem", contributes=DECLARATIVE)
    window.extensions.system_dirs = (system,)
    window.extensions.refresh()
    wait_refresh(qtbot, window)
    page = window.extensions_page
    page.list.setCurrentRow(next(i for i, inf in enumerate(window.extensions.infos) if inf.ext_id == "uji.sistem"))
    assert not page.remove_btn.isEnabled()
    finish(window)


def test_manage_menu_entry_opens_the_extensions_page(qtbot):
    window = make_window(qtbot)
    manage = next(a for a in window.extensions_menu.actions() if a.text() == "Kelola ekstensi…")
    manage.trigger()
    assert window.pages.currentIndex() == EXTENSIONS_PAGE and window.nav_buttons[EXTENSIONS_PAGE].isChecked()
    finish(window)


def test_extension_states_persist_in_config_without_secrets(qtbot):
    write_extension(user_dir(), "uji.kode", code=CODE)
    window = make_window(qtbot)
    approve_and_wait(qtbot, window, "uji.kode")
    window.close()
    saved = paths.config_file().read_text()
    assert "uji.kode" in saved and "approved_hash" in saved and "api_key" not in saved
