"""The shipped example extensions must stay valid and working."""
from pathlib import Path

import pytest

from sorot.extensions import discovery
from sorot.extensions.host import ExtensionProcess
from sorot.extensions.manifest import load_manifest

EXAMPLES = Path(__file__).resolve().parents[1] / "examples" / "extensions"


@pytest.mark.parametrize("folder", sorted(p for p in EXAMPLES.iterdir() if p.is_dir()), ids=lambda p: p.name)
def test_example_manifests_are_valid_and_clean(folder):
    manifest = load_manifest(folder)
    assert manifest.ext_id == folder.name and not manifest.problems and manifest.author == "Muhammad Andreatama"


def test_declarative_example_contributes_everything():
    m = load_manifest(EXAMPLES / "contoh.tema-senja")
    assert (len(m.themes), len(m.presets), len(m.ai_tasks), len(m.templates)) == (1, 1, 1, 1) and not m.has_code


def test_code_example_transforms_and_converts_markdown(tmp_path):
    folder = EXAMPLES / "contoh.rapikan-teks"
    info = discovery.ExtensionInfo(load_manifest(folder), folder, "user", code_hash=discovery.hash_tree(folder))
    process = ExtensionProcess(info, "0.5.0")
    process.start()
    try:
        assert process.call("transform", {"id": "spasi", "text": "halo   dunia \n\n\n\nbaris  dua"})["text"] == "halo dunia\n\nbaris dua"
        assert process.call("transform", {"id": "kapital", "text": "halo. apa kabar? baik."})["text"] == "Halo. Apa kabar? Baik."
        assert process.call("action", {"id": "hitung", "text": "satu dua tiga"}) == {"notify": "3 kata"}
        target = tmp_path / "n.md"
        process.call("export", {"id": "md", "text": "isi naskah", "path": str(target)})
        assert target.read_text().startswith("# Naskah")
        assert process.call("import", {"id": "md", "path": str(target)})["text"].strip().startswith("Naskah")
    finally:
        process.stop(kill=True)


def test_event_example_logs_without_receiving_script_text(tmp_path):
    folder = EXAMPLES / "contoh.log-aktivitas"
    info = discovery.ExtensionInfo(load_manifest(folder), folder, "user", code_hash=discovery.hash_tree(folder))
    process = ExtensionProcess(info, "0.5.0")
    caps = process.start()
    try:
        assert "playback.started" in caps.events and "script.changed" not in caps.events
        process.send_event("playback.started", {"total": 12.0})
        log = discovery.extension_data_dir("contoh.log-aktivitas") / "sesi.log"
        import time

        deadline = time.monotonic() + 4
        while time.monotonic() < deadline and not log.exists():
            time.sleep(0.05)
        assert "playback.started" in log.read_text()
    finally:
        process.stop(kill=True)
