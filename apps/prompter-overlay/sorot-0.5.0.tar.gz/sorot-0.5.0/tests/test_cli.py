import sorot
from sorot.app import main


def test_version_flag(capsys):
    assert main(["--version"]) == 0
    assert capsys.readouterr().out.strip() == f"Sorot {sorot.__version__}"


def test_help_flag_lists_options(capsys):
    assert main(["--help"]) == 0
    out = capsys.readouterr().out
    assert "--diagnostics" in out and "SOROT_QT_PLATFORM" in out


def test_diagnostics_runs_without_a_window(capsys):
    assert main(["--diagnostics"]) == 0
    out = capsys.readouterr().out
    assert "Diagnostik Sistem" in out and "Pilihan backend" in out and "BUKAN hasil uji" in out


def test_version_strings_are_consistent():
    assert sorot.VERSION_LABEL == f"{sorot.__version__} Beta"


def test_extensions_listing_and_validation(capsys, tmp_path):
    from ext_helpers import GOOD_CODE, write_extension

    from sorot.extensions import discovery

    assert main(["--extensions"]) == 0 and "Tidak ada ekstensi" in capsys.readouterr().out
    write_extension(discovery.user_extensions_dir(), "uji.cli", contributes={"templates": [{"name": "T", "text": "x"}]})
    assert main(["--extensions"]) == 0
    assert "uji.cli" in capsys.readouterr().out
    code_dir = write_extension(tmp_path, "uji.kode", code=GOOD_CODE)
    assert main(["--validate-extension", str(code_dir)]) == 0
    out = capsys.readouterr().out
    assert "Manifest valid" in out and "sidik jari" in out and "--run" in out
    assert main(["--validate-extension", str(code_dir), "--run"]) == 0
    assert "upper" in capsys.readouterr().out
    assert main(["--validate-extension", str(tmp_path / "tidak-ada")]) == 1
    assert main(["--validate-extension"]) == 2


def test_validating_a_crashing_extension_reports_failure(capsys, tmp_path):
    from ext_helpers import write_extension

    broken = write_extension(tmp_path, "uji.rusak", code="def activate(api):\n    raise RuntimeError('meledak')\n")
    assert main(["--validate-extension", str(broken), "--run"]) == 1
    assert "GAGAL DIMUAT" in capsys.readouterr().out
