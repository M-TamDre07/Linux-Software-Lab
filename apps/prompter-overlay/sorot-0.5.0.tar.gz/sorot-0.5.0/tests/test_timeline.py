import pytest

from sorot.core.script_markup import Block, parse_script
from sorot.core.timeline import MAX_PPS, LineBox, SpeedMode, build_timeline


def text(words):
    return Block(" ".join(["kata"] * words), words, "text", 0.0)


def boxes(count, height=100, gap=0):
    return [LineBox(i * (height + gap), i * (height + gap) + height) for i in range(count)]


def speed_in(timeline, t0, t1):
    return abs(timeline.position_at(t1) - timeline.position_at(t0)) / (t1 - t0)


def test_empty_input_gives_empty_timeline():
    tl = build_timeline([], [], mode=SpeedMode.WPM)
    assert tl.duration == 0 and tl.position_at(5) == 0 and tl.time_at(5) == 0


def test_wpm_mode_follows_the_speaker_not_the_pixels():
    short, dense = text(10), text(40)
    tl = build_timeline([short, dense], boxes(2), mode=SpeedMode.WPM, wpm=130)
    first_end = 10 * 60 / 130
    assert tl.position_at(first_end) == pytest.approx(100, abs=0.5)
    assert speed_in(tl, 0.1, first_end - 0.1) > 3 * speed_in(tl, first_end + 0.5, first_end + 2.5)
    assert tl.duration == pytest.approx(50 * 60 / 130, rel=1e-6)
    assert tl.effective_wpm == pytest.approx(130, rel=1e-6)


def test_higher_wpm_is_proportionally_faster():
    blocks, lines = [text(26)] * 3, boxes(3)
    slow = build_timeline(blocks, lines, mode=SpeedMode.WPM, wpm=100).duration
    fast = build_timeline(blocks, lines, mode=SpeedMode.WPM, wpm=200).duration
    assert slow == pytest.approx(2 * fast, rel=1e-6)


def test_pause_cue_holds_the_screen():
    blocks = [text(13), Block("— JEDA 3 DTK —", 0, "cue", 3.0), text(13)]
    tl = build_timeline(blocks, boxes(3), mode=SpeedMode.WPM, wpm=130)
    hold = [s for s in tl.segments if s.y0 == s.y1]
    assert len(hold) == 1 and hold[0].t1 - hold[0].t0 == pytest.approx(3.0)
    mid = (hold[0].t0 + hold[0].t1) / 2
    assert tl.position_at(mid) == tl.position_at(hold[0].t0 + 0.01)
    assert tl.duration >= 3.0 + 2 * 6.0 - 1e-6


def test_pps_mode_is_constant_speed_and_still_honours_cues():
    blocks = [text(5), text(50), Block("— JEDA 2 DTK —", 0, "cue", 2.0)]
    tl = build_timeline(blocks, boxes(3), mode=SpeedMode.PPS, pps=50)
    assert tl.duration == pytest.approx(300 / 50 + 2.0)
    assert speed_in(tl, 0.2, 1.0) == pytest.approx(50, rel=1e-6)
    assert speed_in(tl, 3.0, 4.0) == pytest.approx(50, rel=1e-6)


def test_duration_mode_hits_the_target_and_keeps_cue_holds():
    blocks = [text(30), Block("— JEDA 4 DTK —", 0, "cue", 4.0), text(60)]
    tl = build_timeline(blocks, boxes(3), mode=SpeedMode.DURATION, target_seconds=60)
    assert tl.duration == pytest.approx(60, abs=0.01)
    assert any(s.y0 == s.y1 and s.t1 - s.t0 == pytest.approx(4.0) for s in tl.segments)


def test_duration_mode_scales_both_ways():
    blocks, lines = [text(130)], boxes(1)
    natural = build_timeline(blocks, lines, mode=SpeedMode.WPM, wpm=130).duration
    assert build_timeline(blocks, lines, mode=SpeedMode.DURATION, target_seconds=natural * 2).duration == pytest.approx(natural * 2, abs=0.01)
    assert build_timeline(blocks, lines, mode=SpeedMode.DURATION, target_seconds=natural / 2).duration == pytest.approx(natural / 2, abs=0.01)


def test_absurdly_short_target_is_capped_by_max_speed():
    tl = build_timeline([text(500)], [LineBox(0, 100000)], mode=SpeedMode.DURATION, target_seconds=10)
    assert tl.segments[0].t1 - tl.segments[0].t0 >= 100000 / MAX_PPS - 1e-9


def test_position_is_monotonic_and_clamped():
    blocks = [text(8), Block("", 0, "blank", 0.5), text(20), Block("— JEDA 1 DTK —", 0, "cue", 1.0), text(4)]
    tl = build_timeline(blocks, boxes(5, gap=7), mode=SpeedMode.WPM)
    samples = [tl.position_at(i * tl.duration / 400) for i in range(401)]
    assert samples == sorted(samples)
    assert tl.position_at(-5) == tl.start_position and tl.position_at(tl.duration + 99) == tl.end_position == 5 * 100 + 4 * 7


def test_gaps_between_lines_do_not_create_jumps():
    tl = build_timeline([text(10), text(10)], [LineBox(0, 100), LineBox(130, 230)], mode=SpeedMode.WPM)
    jumps = [b.y0 - a.y1 for a, b in zip(tl.segments, tl.segments[1:], strict=False)]
    assert all(abs(j) < 1e-9 for j in jumps)


def test_time_at_inverts_position_at_and_handles_holds():
    blocks = [text(13), Block("— JEDA 3 DTK —", 0, "cue", 3.0), text(13)]
    tl = build_timeline(blocks, boxes(3), mode=SpeedMode.WPM)
    for t in (0.5, 3.0, 5.9, 12.0, 14.5):
        y = tl.position_at(t)
        assert tl.position_at(tl.time_at(y)) == pytest.approx(y, abs=1e-6)
    hold = next(s for s in tl.segments if s.y0 == s.y1)
    assert tl.time_at(hold.y0) == pytest.approx(hold.t0 - 0 if hold.y0 == hold.y1 else hold.t0, abs=1.0)
    assert tl.time_at(-10) == 0 and tl.time_at(10**6) == tl.duration


def test_real_script_round_trip_with_parser():
    parsed = parse_script("Selamat pagi, semuanya.\n\n[jeda 2]\nMari kita mulai hari ini.")
    lines = boxes(len(parsed.blocks), 60)
    tl = build_timeline(parsed.blocks, lines, mode=SpeedMode.WPM, wpm=120)
    assert tl.duration > 2.0 and tl.end_position == len(parsed.blocks) * 60
