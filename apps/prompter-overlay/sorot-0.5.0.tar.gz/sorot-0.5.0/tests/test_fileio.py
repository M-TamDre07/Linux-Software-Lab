import os
import stat

import pytest

from sorot.core.fileio import ScriptFileError, atomic_write_text, read_script


def test_atomic_write_creates_private_file_and_leaves_no_temp(tmp_path):
    target = tmp_path / "sub" / "a.txt"
    atomic_write_text(target, "halo ✓")
    assert target.read_text(encoding="utf-8") == "halo ✓"
    assert stat.S_IMODE(target.stat().st_mode) == 0o600
    assert [p.name for p in target.parent.iterdir()] == ["a.txt"]


def test_atomic_write_replaces_existing_content(tmp_path):
    target = tmp_path / "a.txt"
    atomic_write_text(target, "lama")
    atomic_write_text(target, "baru")
    assert target.read_text() == "baru"


def test_failed_write_keeps_old_content_and_cleans_temp(tmp_path, monkeypatch):
    tmp_path = tmp_path / "work"
    tmp_path.mkdir()
    target = tmp_path / "a.txt"
    atomic_write_text(target, "aman")

    def boom(*_args, **_kwargs):
        raise OSError("disk penuh")

    monkeypatch.setattr(os, "replace", boom)
    with pytest.raises(OSError):
        atomic_write_text(target, "rusak")
    monkeypatch.undo()
    assert target.read_text() == "aman"
    assert [p.name for p in tmp_path.iterdir()] == ["a.txt"]


def test_read_script_handles_bom_and_utf8(tmp_path):
    path = tmp_path / "b.txt"
    path.write_bytes("\ufeffSelamat pagi".encode("utf-8"))
    assert read_script(path) == "Selamat pagi"


def test_read_script_rejects_invalid_utf8(tmp_path):
    path = tmp_path / "c.txt"
    path.write_bytes(b"\xff\xfe\xfa bukan utf8")
    with pytest.raises(ScriptFileError, match="UTF-8"):
        read_script(path)


def test_read_script_rejects_oversized_and_missing(tmp_path):
    big = tmp_path / "big.txt"
    big.write_text("x" * 50)
    with pytest.raises(ScriptFileError, match="terlalu besar"):
        read_script(big, max_bytes=10)
    with pytest.raises(ScriptFileError):
        read_script(tmp_path / "tidak-ada.txt")
    with pytest.raises(ScriptFileError, match="bukan berkas"):
        read_script(tmp_path)
