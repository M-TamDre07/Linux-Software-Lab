import pytest

from sorot import support
from sorot.support import (
    SupportInfo,
    format_id_phone,
    international_id_phone,
    normalize_id_phone,
    support_info,
)


@pytest.mark.parametrize("raw", ["081274852534", "81274852534", "+62 812-7485-2534", "6281274852534", "0812 7485 2534", "0812-7485-2534"])
def test_phone_variants_normalise_to_national_form(raw):
    assert normalize_id_phone(raw) == "081274852534"


@pytest.mark.parametrize("raw", ["", "abc", "0212345678", "0812", "08127485253400000", "+1 202 555 0100"])
def test_non_mobile_numbers_are_rejected(raw):
    with pytest.raises(ValueError):
        normalize_id_phone(raw)


def test_display_formats():
    assert format_id_phone("81274852534") == "0812-7485-2534"
    assert international_id_phone("081274852534") == "+62 812-7485-2534"


def test_configured_support_info_is_valid_and_https_only():
    info = support_info()
    assert info.saweria_url == "https://saweria.co/tamaandrea" and info.gopay_display == "0812-7485-2534"
    assert info.author == "Muhammad Andreatama"
    with pytest.raises(ValueError):
        SupportInfo("x", "http://saweria.co/x", "081274852534").validate()
    with pytest.raises(ValueError):
        SupportInfo("x", "javascript:alert(1)", "081274852534").validate()
    with pytest.raises(ValueError):
        SupportInfo("x", "https://saweria.co/x", "123").validate()


def test_promise_text_states_there_is_no_nagging_or_tracking():
    assert "sukarela" in support.PROMISE and "tidak ada pelacakan" in support.PROMISE
