"""Overlay playback, driven by a fake clock so timing is deterministic."""
from __future__ import annotations

from types import SimpleNamespace

import pytest

pytest.importorskip("PySide6")
pytest.importorskip("pytestqt")

from PySide6.QtCore import QRect  # noqa: E402

from sorot.ui import overlay as overlay_module  # noqa: E402
from sorot.ui.overlay import PromptOverlay  # noqa: E402

pytestmark = pytest.mark.gui

SCRIPT = "Selamat pagi semuanya.\nIni baris kedua yang lebih panjang dari baris pertama.\nBaris ketiga.\n" * 3


class Clock:
    def __init__(self) -> None:
        self.now = 1000.0

    def __call__(self) -> float:
        return self.now


@pytest.fixture()
def clock(monkeypatch):
    fake = Clock()
    monkeypatch.setattr(overlay_module, "time", SimpleNamespace(monotonic=fake))
    return fake


def make_overlay(qtbot, script=SCRIPT, *, mode="wpm", wpm=130, pps=40, target=60):
    o = PromptOverlay()
    qtbot.addWidget(o)
    o.apply_geometry(QRect(0, 0, 640, 240))
    o.set_speed(mode, pps=pps, wpm=wpm, target_seconds=target)
    o.set_text(script)
    o.show()
    qtbot.waitExposed(o)
    o._relayout()
    return o


def run(o, clock, seconds, step=0.016):
    steps = round(seconds / step)
    for _ in range(steps):
        clock.now += step
        o._tick()


def bar(o):
    return o.text_view.verticalScrollBar()


def test_first_line_starts_at_the_reading_guide(qtbot, clock):
    o = make_overlay(qtbot)
    o.set_guide(enabled=True, position_percent=40, show_progress=True)
    o._relayout()
    margin = o.text_view.document().rootFrame().frameFormat().topMargin()
    assert margin == pytest.approx(o.text_view.viewport().height() * 0.4, abs=1.5)
    assert bar(o).value() == 0


def test_playback_follows_the_timeline_after_the_ramp(qtbot, clock):
    o = make_overlay(qtbot)
    o.start_scrolling()
    run(o, clock, 3.0)
    timeline = o._timeline
    assert timeline is not None and o.is_scrolling()
    assert abs(bar(o).value() - round(timeline.position_at(o.elapsed()))) <= 1
    assert 2.4 < o.elapsed() < 3.0, "easing makes the clock lag real time by a fraction of a second, not more"


def test_speed_does_not_depend_on_tick_rate(qtbot, clock):
    a = make_overlay(qtbot)
    a.start_scrolling()
    run(a, clock, 4.0, step=0.016)
    fine = a.elapsed()
    clock.now = 1000.0
    b = make_overlay(qtbot)
    b.start_scrolling()
    run(b, clock, 4.0, step=0.05)
    assert b.elapsed() == pytest.approx(fine, abs=0.08)


def test_pause_cue_really_holds_the_screen(qtbot, clock):
    o = make_overlay(qtbot, "Satu dua tiga empat lima.\n[jeda 3]\nEnam tujuh delapan sembilan sepuluh.", wpm=300)
    timeline = o._timeline
    hold = next(seg for seg in timeline.segments if seg.y0 == seg.y1 and seg.t1 - seg.t0 == pytest.approx(3.0))
    o.start_scrolling()
    run(o, clock, 1.0)
    # jump the clock to the middle of the hold and make sure nothing moves for the next two seconds
    o._elapsed = hold.t0 + 0.2
    o._factor = 1.0
    value = bar(o).value()
    run(o, clock, 2.0)
    assert bar(o).value() == pytest.approx(round(timeline.position_at(hold.t0 + 0.2)), abs=1) or bar(o).value() == value
    assert o._elapsed > hold.t0 + 2.0 and o._elapsed < hold.t1


def test_finishing_stops_signals_and_restarts_from_the_top(qtbot, clock):
    o = make_overlay(qtbot, "Kalimat pendek saja.", wpm=260)
    changes, progress = [], []
    o.scrollingChanged.connect(changes.append)
    o.progressChanged.connect(lambda e, t: progress.append((e, t)))
    o.start_scrolling()
    run(o, clock, o.duration() + 2.0)
    assert not o.is_scrolling() and o.at_end() and not o.tick_timer.isActive()
    assert changes == [True, False]
    assert progress[-1][0] == pytest.approx(progress[-1][1])
    assert "−00:00" in o.clock_label.text()
    o.start_scrolling()
    assert o.is_scrolling() and o.elapsed() == 0.0 and bar(o).value() == 0


def test_pause_eases_to_a_stop_and_the_timer_shuts_off(qtbot, clock):
    o = make_overlay(qtbot, wpm=260)
    o.start_scrolling()
    run(o, clock, 2.0)
    o.pause_scrolling()
    assert not o.is_scrolling() and o.tick_timer.isActive()
    run(o, clock, 1.5)
    assert not o.tick_timer.isActive()
    stopped = bar(o).value()
    run(o, clock, 1.0)
    assert bar(o).value() == stopped


def test_scrolling_by_hand_re_anchors_the_clock(qtbot, clock):
    o = make_overlay(qtbot, "kata " * 400, wpm=200)
    o.start_scrolling()
    run(o, clock, 1.0)
    target = int(o._timeline.position_at(o._timeline.duration * 0.5))
    bar(o).setValue(target)  # the reader drags the text ahead
    run(o, clock, 0.1)
    assert o.elapsed() == pytest.approx(o._timeline.time_at(bar(o).value()), abs=0.5)
    assert o.elapsed() > o._timeline.duration * 0.4


def test_resuming_after_manual_scroll_continues_from_there(qtbot, clock):
    o = make_overlay(qtbot, "kata " * 400, wpm=200)
    bar(o).setValue(int(o._timeline.position_at(o._timeline.duration * 0.3)))
    o.start_scrolling()
    assert o.elapsed() == pytest.approx(o._timeline.duration * 0.3, rel=0.05)


def test_changing_speed_mid_playback_keeps_the_position(qtbot, clock):
    o = make_overlay(qtbot, "kata " * 300, wpm=100)
    o.start_scrolling()
    run(o, clock, 3.0)
    before = bar(o).value()
    o.set_speed("wpm", pps=40, wpm=200, target_seconds=60)
    o._ensure_timeline()
    assert abs(bar(o).value() - before) <= 2
    first = o.duration()
    o.set_speed("wpm", pps=40, wpm=100, target_seconds=60)
    assert o.duration() > first


def test_duration_mode_matches_the_target_including_cue_holds(qtbot, clock):
    o = make_overlay(qtbot, "Satu dua tiga.\n[jeda 4]\nEmpat lima enam tujuh delapan.", mode="duration", target=40)
    assert o.duration() == pytest.approx(40, abs=0.05)
    o.set_speed("duration", pps=40, wpm=130, target_seconds=25)
    assert o.duration() == pytest.approx(25, abs=0.05)
    assert o.effective_wpm() > 0


def test_notes_never_reach_the_prompt(qtbot, clock):
    o = make_overlay(qtbot, "Teks tampil.\n// catatan rahasia\nTeks lagi.")
    shown = o.text_view.toPlainText()
    assert "rahasia" not in shown and "Teks tampil." in shown


def test_empty_script_shows_placeholder_and_cannot_play(qtbot, clock):
    o = make_overlay(qtbot, "")
    assert not o.can_scroll()
    o.start_scrolling()
    assert not o.is_scrolling() and o.duration() == 0


def test_pixel_mode_with_zero_speed_cannot_play(qtbot, clock):
    o = make_overlay(qtbot, mode="pps", pps=0)
    assert not o.can_scroll()


def test_progress_signal_is_throttled(qtbot, clock):
    o = make_overlay(qtbot, "kata " * 600, wpm=150)
    seen = []
    o.progressChanged.connect(lambda e, t: seen.append(e))
    o.start_scrolling()
    seen.clear()
    run(o, clock, 2.0)
    assert 4 <= len(seen) <= 10


def test_reset_returns_to_the_start_without_playing(qtbot, clock):
    o = make_overlay(qtbot)
    o.start_scrolling()
    run(o, clock, 3.0)
    o.reset_scroll()
    assert bar(o).value() == 0 and o.elapsed() == 0 and not o.is_scrolling() and not o.tick_timer.isActive()


def test_overlay_unicode_line_separators_do_not_break_the_line_mapping(qtbot, clock):
    o = make_overlay(qtbot, "Satu\u2029dua\u2028tiga\nempat")
    assert o.text_view.document().blockCount() == len(o._parsed.blocks)


def test_empty_script_with_progress_listener_in_duration_mode_does_not_recurse(qtbot, clock):
    """Regression: progress listeners that query the overlay re-entered _ensure_timeline forever."""
    o = make_overlay(qtbot, "", mode="duration", target=30)
    o.progressChanged.connect(lambda *_: o.effective_wpm())
    o.set_speed("duration", pps=40, wpm=130, target_seconds=45)
    assert o.duration() == 0 and o.effective_wpm() == 0
