"""GUI tests against the real widgets using Qt's offscreen platform.

They exercise application logic and widget wiring. They do NOT prove behaviour
on a real GNOME/KDE compositor (always-on-top, click-through, native Wayland
placement); those remain manual checks, see docs/MANUAL-TESTING.md.
"""
from __future__ import annotations

import hashlib
import json

import pytest

pytest.importorskip("PySide6")
pytest.importorskip("pytestqt")

from PySide6.QtCore import QRect, Qt, QTimer  # noqa: E402
from PySide6.QtTest import QTest  # noqa: E402
from PySide6.QtWidgets import QApplication, QFileDialog, QMessageBox, QPushButton  # noqa: E402

from sorot.core import paths  # noqa: E402
from sorot.core.config import AppConfig, ConfigStore  # noqa: E402
from sorot.core.scripts import DraftStore, ScriptLibrary  # noqa: E402
from sorot.ui.main_window import MainWindow  # noqa: E402

pytestmark = pytest.mark.gui


def make_window(qtbot, **kwargs) -> MainWindow:
    window = MainWindow(ConfigStore(), DraftStore(), ScriptLibrary(), **kwargs)
    qtbot.addWidget(window)
    window.show()
    qtbot.waitExposed(window)
    return window


def type_text(window: MainWindow, text: str) -> None:
    window.editor.insertPlainText(text)  # unlike setPlainText this marks the document modified


def click_dialog_button(label: str, delay: int = 60) -> None:
    """Press a button on whichever modal dialog appears next."""

    def press():
        modal = QApplication.activeModalWidget()
        assert modal is not None, "tidak ada dialog modal"
        for button in modal.findChildren(QPushButton):
            if button.text().replace("&", "") == label:
                button.click()
                return
        raise AssertionError(f"tombol {label!r} tidak ada: {[b.text() for b in modal.findChildren(QPushButton)]}")

    QTimer.singleShot(delay, press)


# ------------------------------------------------------------------ lifecycle
def test_window_starts_and_closes_cleanly(qtbot):
    window = make_window(qtbot)
    assert "0.5.0" in window.windowTitle()
    window.show_overlay()
    assert window.overlay.isVisible()
    window.close()
    assert not window.overlay.isVisible()


def test_minimum_size_fits_a_1366x768_screen(qtbot):
    window = make_window(qtbot)
    hint = window.minimumSizeHint()
    assert hint.width() <= 900 and hint.height() <= 600


# ---------------------------------------------------------------- persistence
def test_settings_survive_restart(qtbot):
    first = make_window(qtbot)
    first.font_spin.setValue(44)
    first.margin_spin.setValue(30)
    first.opacity_slider.setValue(33)
    first.speed_spin.setValue(55)
    first.wpm_spin.setValue(160)
    first.text_color_btn.set_color("#123456", emit=True)
    first.align_seg.setValue("center")
    first.clickthrough_check.setChecked(True)
    first.close()
    saved = json.loads(paths.config_file().read_text())
    assert saved["font_size"] == 44 and saved["text_color"] == "#123456" and saved["click_through"] is True
    second = make_window(qtbot)
    assert second.font_spin.value() == 44 and second.margin_spin.value() == 30
    assert second.speed_spin.value() == 55 and second.wpm_spin.value() == 160
    assert second.text_color_btn.color == "#123456" and second.align_seg.value() == "center"
    assert second.clickthrough_check.isChecked()
    second.close()


def test_manual_overlay_position_is_restored_after_restart(qtbot):
    """Regression: 0.3.0 saved overlay_x/y but never loaded them."""
    ConfigStore().save(AppConfig(position="manual", overlay_x=37, overlay_y=53, overlay_width=500, overlay_height=180))
    window = make_window(qtbot)
    window.show_overlay()
    geometry = window.overlay.geometry()
    assert (geometry.x(), geometry.y(), geometry.width(), geometry.height()) == (37, 53, 500, 180)
    window.close()


def test_offscreen_manual_position_falls_back_to_a_preset(qtbot):
    ConfigStore().save(AppConfig(position="manual", overlay_x=99999, overlay_y=99999))
    window = make_window(qtbot)
    window.show_overlay()
    screen = window.overlay.screen().availableGeometry()
    assert screen.intersects(window.overlay.geometry())
    window.close()


def test_user_move_and_resize_are_remembered(qtbot):
    window = make_window(qtbot)
    window.show_overlay()
    window.overlay.setGeometry(QRect(70, 80, 640, 210))
    qtbot.waitUntil(lambda: window.config.position == "manual", timeout=3000)
    assert (window.config.overlay_x, window.config.overlay_y) == (70, 80)
    assert (window.config.overlay_width, window.config.overlay_height) == (640, 210)
    assert window.width_spin.value() == 640
    window.close()


def test_draft_is_written_while_typing_for_crash_recovery(qtbot):
    window = make_window(qtbot)
    type_text(window, "Naskah penting")
    qtbot.waitUntil(lambda: DraftStore().load() == "Naskah penting", timeout=3000)
    # Simulate a crash: no closeEvent. A fresh window must see the text.
    other = make_window(qtbot)
    assert other.editor.toPlainText() == "Naskah penting"
    assert not other.editor.document().isModified()
    window.editor.document().setModified(False)  # avoid the prompt on teardown
    window.close()
    other.close()


def test_corrupt_config_does_not_prevent_startup(qtbot):
    paths.config_file().parent.mkdir(parents=True)
    paths.config_file().write_text("{rusak")
    store = ConfigStore()
    loaded = store.load()
    window = MainWindow(store, DraftStore(), ScriptLibrary(), startup_notices=loaded.notices)
    qtbot.addWidget(window)
    window.show()
    assert "rusak" in window.status_label.text()
    window.close()


# --------------------------------------------------------------------- editor
def test_stats_update_and_empty_state(qtbot):
    window = make_window(qtbot)
    assert window.stat_chars.text() == "0" and window.stat_words.text() == "0" and window.stat_time.text() == "00:00"
    type_text(window, "satu dua tiga")
    qtbot.waitUntil(lambda: window.stat_words.text() == "3", timeout=2000)
    window.editor.document().setModified(False)
    window.close()


def test_long_script_is_handled(qtbot):
    window = make_window(qtbot)
    window._replace_editor_text("kata " * 100_000, modified=False)
    assert window.stat_words.text() == "100.000"
    window.close()


def test_ai_replace_is_undoable(qtbot):
    window = make_window(qtbot)
    window._replace_editor_text("naskah asli", modified=False)
    window._apply_ai_result("replace", "hasil AI")
    assert window.editor.toPlainText() == "hasil AI"
    window.editor.undo()
    assert window.editor.toPlainText() == "naskah asli"
    window.editor.document().setModified(False)
    window.close()


def test_ai_append_keeps_original(qtbot):
    window = make_window(qtbot)
    window._replace_editor_text("awal", modified=False)
    window._apply_ai_result("append", "tambahan")
    assert window.editor.toPlainText() == "awal\n\ntambahan"
    window.editor.document().setModified(False)
    window.close()


# ------------------------------------------------------------ unsaved changes
def test_close_with_unsaved_changes_can_be_cancelled(qtbot):
    window = make_window(qtbot)
    type_text(window, "belum disimpan")
    click_dialog_button("Batal")
    window.close()
    assert window.isVisible(), "jendela harus tetap terbuka setelah Batal"
    window.editor.document().setModified(False)
    window.close()


def test_open_file_asks_before_discarding_and_respects_cancel(qtbot, tmp_path, monkeypatch):
    target = tmp_path / "lain.txt"
    target.write_text("isi lain")
    opened = []
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (opened.append(1), (str(target), ""))[1])
    window = make_window(qtbot)
    type_text(window, "perubahan saya")
    click_dialog_button("Batal")
    window.open_file()
    assert window.editor.toPlainText() == "perubahan saya" and not opened
    click_dialog_button("Lanjutkan tanpa menyimpan")
    window.open_file()
    assert window.editor.toPlainText() == "isi lain" and window.current_file == target
    assert not window.editor.document().isModified()
    window.close()


def test_discarded_text_can_be_recovered_with_undo(qtbot, tmp_path, monkeypatch):
    target = tmp_path / "lain.txt"
    target.write_text("isi lain")
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (str(target), ""))
    window = make_window(qtbot)
    type_text(window, "jangan hilang")
    click_dialog_button("Lanjutkan tanpa menyimpan")
    window.open_file()
    window.editor.undo()
    assert window.editor.toPlainText() == "jangan hilang"
    window.editor.document().setModified(False)
    window.close()


def test_save_then_close_without_prompt(qtbot, tmp_path, monkeypatch):
    target = tmp_path / "hasil.txt"
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **k: (str(target), "Berkas teks (*.txt)"))
    window = make_window(qtbot)
    type_text(window, "tersimpan ✓")
    assert window.editor.document().isModified()
    assert window.save_file() is True
    assert target.read_text(encoding="utf-8") == "tersimpan ✓"
    assert (target.stat().st_mode & 0o777) == 0o644
    window.close()
    assert not window.isVisible()


def test_save_dialog_adds_extension_by_selected_filter(qtbot, tmp_path, monkeypatch):
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **k: (str(tmp_path / "catatan"), "Markdown (*.md)"))
    window = make_window(qtbot)
    type_text(window, "# judul")
    assert window.save_file_as()
    assert (tmp_path / "catatan.md").read_text() == "# judul"
    window.close()


def test_open_invalid_utf8_shows_error_and_keeps_text(qtbot, tmp_path, monkeypatch):
    bad = tmp_path / "rusak.txt"
    bad.write_bytes(b"\xff\xfe\xfa")
    warnings = []
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (str(bad), ""))
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: warnings.append(a[2]))
    window = make_window(qtbot)
    window._replace_editor_text("aman", modified=False)
    window.open_file()
    assert warnings and "UTF-8" in warnings[0]
    assert window.editor.toPlainText() == "aman"
    window.close()


def test_library_open_replaces_text_via_signal(qtbot):
    library = ScriptLibrary()
    library.save("Pembuka", "Halo semuanya")
    window = make_window(qtbot)
    window._open_from_library("Pembuka")
    assert window.editor.toPlainText() == "Halo semuanya"
    window.close()


# --------------------------------------------------------------------- scroll
def test_scroll_start_pause_reset_and_end(qtbot):
    window = make_window(qtbot)
    window._replace_editor_text("baris panjang\n" * 40, modified=False)
    window.speed_mode_seg.setValue("pps")
    window.speed_spin.setValue(400)
    window.show_overlay()
    assert window.overlay.is_scrolling()
    bar = window.overlay.text_view.verticalScrollBar()
    qtbot.waitUntil(lambda: bar.value() > 50, timeout=4000)
    window.toggle_scroll()
    assert not window.overlay.is_scrolling()
    qtbot.waitUntil(lambda: not window.overlay.tick_timer.isActive(), timeout=2000)  # eased to a stop
    paused_at = bar.value()
    qtbot.wait(150)
    assert bar.value() == paused_at
    window.reset_scroll()
    assert bar.value() == 0
    window.toggle_scroll()
    qtbot.waitUntil(lambda: window.overlay.at_end() and not window.overlay.is_scrolling(), timeout=20000)
    assert "akhir" in window.status_label.text()
    window.toggle_scroll()  # at the end, play restarts from the top
    assert bar.value() < bar.maximum() and window.overlay.is_scrolling()
    window.close()


def test_zero_pixel_speed_explains_instead_of_silently_doing_nothing(qtbot):
    window = make_window(qtbot)
    window._replace_editor_text("ada isi naskah", modified=False)
    window.show_overlay()
    window.speed_mode_seg.setValue("pps")
    window.speed_spin.setValue(0)
    window.overlay.pause_scrolling()
    window.toggle_scroll()
    assert "Kecepatan gulir 0" in window.status_label.text()
    window.close()


def test_empty_script_cannot_scroll_and_says_so(qtbot):
    window = make_window(qtbot)
    window.show_overlay()
    window.toggle_scroll()
    assert "kosong" in window.status_label.text() and not window.overlay.is_scrolling()
    window.close()


def test_overlay_buttons_drive_the_application(qtbot):
    window = make_window(qtbot)
    window._replace_editor_text("isi naskah untuk diuji", modified=False)
    window.show_overlay()
    before = window.wpm_spin.value()
    window.overlay.faster_button.click()
    assert window.wpm_spin.value() == before + 5
    window.overlay.slower_button.click()
    assert window.wpm_spin.value() == before
    window.overlay.play_button.click()
    assert not window.overlay.is_scrolling()
    window.overlay.reset_button.click()
    window.overlay.hide_button.click()
    assert not window.overlay.isVisible()
    window.close()


def test_speed_buttons_follow_the_active_mode(qtbot):
    window = make_window(qtbot)
    window.speed_mode_seg.setValue("duration")
    window.target_spin.setValue(120)
    window.adjust_speed(+1)  # faster = shorter
    assert window.target_spin.value() == 105
    window.speed_mode_seg.setValue("pps")
    window.speed_spin.setValue(40)
    window.adjust_speed(+1)
    assert window.speed_spin.value() == 48
    window.close()


def test_default_keyboard_shortcuts_work_with_editor_focused(qtbot):
    window = make_window(qtbot)
    window.editor.setFocus()
    qtbot.waitUntil(window.editor.hasFocus, timeout=2000)
    QTest.keyClick(window.editor, Qt.Key.Key_Return, Qt.KeyboardModifier.ControlModifier)
    assert window.overlay.isVisible()
    QTest.keyClick(window.editor, Qt.Key.Key_Space, Qt.KeyboardModifier.ControlModifier)
    assert not window.overlay.is_scrolling()
    speed = window.wpm_spin.value()
    QTest.keyClick(window.editor, Qt.Key.Key_Up, Qt.KeyboardModifier.AltModifier)
    assert window.wpm_spin.value() == speed + 5
    QTest.keyClick(window.editor, Qt.Key.Key_Escape)
    assert not window.overlay.isVisible()
    window.close()


def test_custom_shortcut_is_applied_and_persisted(qtbot):
    window = make_window(qtbot)
    window.config.shortcuts["hide_overlay"] = "Ctrl+Shift+H"
    window._apply_shortcuts()
    window.show_overlay()
    window.activateWindow()
    window.editor.setFocus()
    qtbot.waitUntil(window.editor.hasFocus, timeout=2000)
    QTest.keyClick(window.editor, Qt.Key.Key_H, Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier)
    assert not window.overlay.isVisible()
    window.close()
    assert json.loads(paths.config_file().read_text())["shortcuts"]["hide_overlay"] == "Ctrl+Shift+H"


# ------------------------------------------------------------- window options
def test_click_through_and_frame_toggles_keep_geometry_and_visibility(qtbot):
    window = make_window(qtbot)
    window.show_overlay()
    before = window.overlay.geometry()
    window.clickthrough_check.setChecked(True)
    assert window.overlay.windowFlags() & Qt.WindowType.WindowTransparentForInput
    assert window.overlay.isVisible() and window.overlay.geometry() == before
    window.clickthrough_check.setChecked(False)
    window.frameless_check.setChecked(False)
    assert not (window.overlay.windowFlags() & Qt.WindowType.FramelessWindowHint)
    window.aot_check.setChecked(False)
    assert not (window.overlay.windowFlags() & Qt.WindowType.WindowStaysOnTopHint)
    assert window.overlay.windowFlags() & Qt.WindowType.WindowDoesNotAcceptFocus
    assert window.overlay.isVisible()
    window.close()


def test_preset_changes_all_three_values_and_custom_edit_returns_to_custom(qtbot):
    window = make_window(qtbot)
    window.preset_combo.setCurrentText("Terang (hitam di putih)")
    window._on_preset_chosen(0)
    assert (window.text_color_btn.color, window.bg_color_btn.color) == ("#111827", "#FFFFFF")
    window.text_color_btn.set_color("#010203", emit=True)
    assert window.preset_combo.currentText() == "Kustom"
    window.close()


def test_diagnostics_tab_reports_environment_without_secrets(qtbot, monkeypatch):
    monkeypatch.setenv("SOROT_API_KEY", "sk-jangan-bocor-1234567890")
    window = make_window(qtbot)
    window.show_diagnostics()
    report = window.report_view.toPlainText()
    assert "Diagnostik Sistem" in report and "jangan-bocor" not in report
    window.close()


def test_restore_settings_backup(qtbot, monkeypatch):
    store = ConfigStore()
    store.save(AppConfig(font_size=30))
    store.save(AppConfig(font_size=50))
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **k: QMessageBox.StandardButton.Yes)
    window = make_window(qtbot)
    assert window.font_spin.value() == 50
    window.restore_settings_backup()
    assert window.font_spin.value() == 30
    window.close()


# ------------------------------------------------------------------ migration
def test_legacy_settings_are_imported_without_touching_the_old_file(qtbot):
    from PySide6.QtCore import QSettings

    from sorot.legacy_import import import_legacy

    legacy = paths.legacy_qsettings_file()
    legacy.parent.mkdir(parents=True)
    old = QSettings(str(legacy), QSettings.Format.IniFormat)
    old.setValue("text", "Naskah dari 0.3.0")
    old.setValue("font_size", 40)
    old.setValue("text_color_name", "Hijau muda")
    old.setValue("position", "Bawah kiri")
    old.setValue("click_through", True)
    old.sync()
    digest = hashlib.sha256(legacy.read_bytes()).hexdigest()
    store, draft = ConfigStore(), DraftStore()
    config, text = import_legacy(store, draft)
    assert text == "Naskah dari 0.3.0" and draft.load() == text
    assert config.font_size == 40 and config.text_color == "#B8F7D4" and config.position == "bottom-left" and config.click_through
    assert store.load().config.font_size == 40
    assert hashlib.sha256(legacy.read_bytes()).hexdigest() == digest


def test_no_legacy_file_means_no_import():
    from sorot.legacy_import import import_legacy

    assert import_legacy(ConfigStore(), DraftStore()) is None
    assert not paths.config_file().exists()


def test_shortcut_dialog_rejects_conflicts_and_typing_keys(qtbot):
    from PySide6.QtGui import QKeySequence

    from sorot.core.config import DEFAULT_SHORTCUTS
    from sorot.ui.dialogs import ShortcutsDialog, shortcut_problem

    assert shortcut_problem("Ctrl+H") and shortcut_problem("Ctrl+S") and shortcut_problem("A") and shortcut_problem("")
    assert shortcut_problem("Ctrl+Shift+H") is None and shortcut_problem("Alt+Up") is None and shortcut_problem("F5") is None
    dialog = ShortcutsDialog(dict(DEFAULT_SHORTCUTS))
    qtbot.addWidget(dialog)
    dialog.edits["hide_overlay"].setKeySequence(QKeySequence("Ctrl+Space"))  # duplicates toggle_scroll
    dialog._accept()
    assert dialog.result() == 0 and "ganda" in dialog.error.text()
    dialog.edits["hide_overlay"].setKeySequence(QKeySequence("Ctrl+H"))
    dialog._accept()
    assert "bentrok" in dialog.error.text() and dialog.result() == 0
    dialog.edits["hide_overlay"].setKeySequence(QKeySequence("F6"))
    dialog._accept()
    assert dialog.result() == 1 and dialog.values()["hide_overlay"] == "F6"


def test_untouched_font_choice_is_not_written_to_config(qtbot):
    window = make_window(qtbot)
    window.font_spin.setValue(36)
    assert window.config.font_family == ""
    window.font_combo.activated.emit(0)
    window.font_spin.setValue(37)
    assert window.config.font_family == window.font_combo.currentFont().family()
    window.close()


def test_loading_a_draft_or_changing_theme_does_not_mark_the_script_unsaved(qtbot):
    """Regression: re-colouring the markup used to flip the document to 'modified'."""
    DraftStore().save("Naskah lama\n[jeda 2]\n// catatan")
    window = make_window(qtbot)
    assert window.editor.toPlainText().startswith("Naskah lama")
    assert not window.editor.document().isModified()
    window.theme_seg.setValue("light")
    window.theme_seg.setValue("dark")
    assert not window.editor.document().isModified()
    window.close()
    assert not window.isVisible(), "menutup tanpa perubahan tidak boleh memunculkan dialog"
