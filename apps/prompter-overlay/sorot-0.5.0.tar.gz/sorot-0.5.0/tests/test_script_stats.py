from sorot.core.script_stats import compute_stats, estimate_seconds, format_clock, format_duration, format_stats


def test_empty_script_has_zero_duration():
    assert estimate_seconds("") == 0
    assert estimate_seconds("   \n\t ") == 0


def test_duration_scales_with_wpm():
    text = "kata " * 130
    assert estimate_seconds(text, 130) == 60
    assert estimate_seconds(text, 260) == 30


def test_wpm_is_clamped_to_sane_range():
    text = "kata " * 100
    assert estimate_seconds(text, 0) == estimate_seconds(text, 60)
    assert estimate_seconds(text, 10_000) == estimate_seconds(text, 260)


def test_single_word_is_at_least_one_second():
    assert estimate_seconds("halo", 260) >= 1


def test_format_duration_variants():
    assert format_duration(0) == "0 detik"
    assert format_duration(45) == "45 detik"
    assert format_duration(125) == "2 menit 05 detik"
    assert format_duration(3725) == "1 jam 02 menit"


def test_format_stats_uses_indonesian_thousands_separator():
    text = "a " * 1500
    label = format_stats(compute_stats(text))
    assert "1.500 kata" in label and "3.000 karakter" in label


def test_punctuation_adds_breathing_pauses():
    plain = estimate_seconds("halo dunia " * 30, 130)
    punctuated = estimate_seconds("halo, dunia. " * 30, 130)
    assert punctuated >= plain + 20  # 30 commas (7.5 s) + 30 sentence ends (15 s)


def test_decimal_points_and_abbreviations_inside_words_are_not_pauses():
    assert estimate_seconds("versi 3.14 rilis", 130) == estimate_seconds("versi 314 rilis", 130)


def test_cues_add_time_and_notes_are_ignored():
    base = "kata " * 130
    assert estimate_seconds(base + "\n[jeda 5]", 130) == estimate_seconds(base, 130) + 5
    assert estimate_seconds("// hanya catatan", 130) == 0
    assert estimate_seconds(base + "\n// " + "catatan " * 500, 130) == estimate_seconds(base, 130)
    assert compute_stats("// x\nhalo dunia").words == 2


def test_clock_format():
    assert format_clock(0) == "00:00" and format_clock(65.4) == "01:05" and format_clock(3725) == "1:02:05" and format_clock(-3) == "00:00"
