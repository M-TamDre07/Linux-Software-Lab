"""Create a fake ``rclone`` executable on PATH for integration-style tests.

The fake records every argv (one JSON line per call) so tests can assert that
arguments are passed as a list and never interpreted by a shell. It does NOT
prove compatibility with the real rclone.
"""
from __future__ import annotations

import os
import stat
import textwrap
from pathlib import Path

SCRIPT = textwrap.dedent('''\
    #!/usr/bin/env python3
    import json, os, shutil, sys, time
    args = sys.argv[1:]
    with open(os.environ["FAKE_RCLONE_LOG"], "a") as log:
        log.write(json.dumps(args) + "\\n")
    if os.environ.get("FAKE_RCLONE_SLEEP"):
        time.sleep(float(os.environ["FAKE_RCLONE_SLEEP"]))
    if os.environ.get("FAKE_RCLONE_FAIL"):
        sys.stderr.write("ERROR : " + os.environ["FAKE_RCLONE_FAIL"] + "\\n")
        sys.exit(1)
    root = os.environ["FAKE_RCLONE_ROOT"]
    cmd = args[0] if args else ""
    def local(target):
        return os.path.join(root, target.split(":", 1)[1])
    if cmd == "listremotes":
        sys.stdout.write("gdrive: drive\\nlokal: local\\nkosong:\\n")
    elif cmd == "version":
        sys.stdout.write("rclone v1.99.0-fake\\n- os/arch: linux/amd64\\n")
    elif cmd == "lsf":
        base = local(args[1])
        for dirpath, _dirs, files in os.walk(base):
            for name in sorted(files):
                if name.lower().endswith(".txt"):
                    sys.stdout.write(os.path.relpath(os.path.join(dirpath, name), base) + "\\n")
    elif cmd == "cat":
        limit = int(args[args.index("--count") + 1]) if "--count" in args else None
        with open(local(args[1]), "rb") as handle:
            sys.stdout.buffer.write(handle.read(limit))
    elif cmd == "copyto":
        dest = local(args[2])
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.copyfile(args[1], dest)
    else:
        sys.stderr.write("perintah tidak dikenal\\n")
        sys.exit(2)
''')


def install_fake_rclone(tmp_path: Path, monkeypatch) -> tuple[Path, Path]:
    """Returns (remote_root, call_log)."""
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    exe = bin_dir / "rclone"
    exe.write_text(SCRIPT)
    exe.chmod(exe.stat().st_mode | stat.S_IXUSR)
    root = tmp_path / "remote"
    root.mkdir()
    log = tmp_path / "rclone.log"
    monkeypatch.setenv("PATH", f"{bin_dir}{os.pathsep}{os.environ['PATH']}")
    monkeypatch.setenv("FAKE_RCLONE_ROOT", str(root))
    monkeypatch.setenv("FAKE_RCLONE_LOG", str(log))
    return root, log
