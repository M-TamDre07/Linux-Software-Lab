import json
import threading
import time

import pytest
from fake_server import FakeProvider, chat_reply

from sorot.core.cancel import CancelToken
from sorot.services import ai_service as ai
from sorot.services.ai_service import AIConfig, AIError, AIErrorKind

CHAT = "/v1/chat/completions"
MODELS = "/v1/models"
SECRET = "sk-test-secret-key-123456"


@pytest.fixture()
def provider():
    server = FakeProvider().start()
    yield server
    server.stop()


def make_config(provider, **overrides):
    values = dict(base_url=provider.base_url, model="model-uji", api_key=SECRET, timeout_seconds=15)
    values.update(overrides)
    return AIConfig(**values)


# ---- URL validation ------------------------------------------------------
@pytest.mark.parametrize("url", [
    "https://api.openai.com/v1", "https://api.openai.com/v1/", "https://api.openai.com/v1/chat/completions",
    "http://localhost:11434/v1", "http://127.0.0.1:8080/v1", "http://[::1]:8080/v1",
])
def test_valid_urls_normalise_to_chat_endpoint(url):
    assert ai.chat_completions_url(url).endswith("/v1/chat/completions")


@pytest.mark.parametrize("url", [
    "", "   ", "ftp://x.example/v1", "api.openai.com/v1", "http://api.example.com/v1",
    "https://user:pass@api.example.com/v1", "https://api.example.com/v1?key=abc", "https://api.example.com/v1#frag",
])
def test_invalid_urls_are_rejected_with_config_error(url):
    with pytest.raises(AIError) as info:
        ai.chat_completions_url(url)
    assert info.value.kind is AIErrorKind.CONFIG


def test_api_host_for_privacy_prompt():
    assert ai.api_host("https://api.example.com/v1/chat/completions") == "api.example.com"


# ---- prompts -------------------------------------------------------------
def test_every_task_builds_a_prompt():
    for task in ai.TASKS:
        kwargs = {}
        if task.needs_custom:
            kwargs["custom_instruction"] = "Ubah jadi puisi"
        if task.needs_minutes:
            kwargs["target_minutes"] = 3
        messages = ai.build_messages(task.task_id, "Halo dunia", **kwargs)
        assert messages[0]["role"] == "system" and "NASKAH:\nHalo dunia" in messages[1]["content"]


def test_duration_task_computes_target_word_count():
    prompt = ai.build_messages("target_duration", "x", target_minutes=2, wpm=150)[1]["content"]
    assert "2 menit" in prompt and "300 kata" in prompt


def test_missing_parameters_are_rejected():
    with pytest.raises(AIError):
        ai.build_messages("custom", "x")
    with pytest.raises(AIError):
        ai.build_messages("target_duration", "x")
    with pytest.raises(AIError):
        ai.build_messages("tidak-ada", "x")


# ---- complete(): success and request shape ------------------------------
def test_complete_sends_expected_request_and_returns_text(provider):
    provider.route("POST", CHAT, json=chat_reply("  Hasil akhir  "))
    result = ai.complete(make_config(provider), "fix_language", "naskah saya")
    assert result == "Hasil akhir"
    request = provider.requests[0]
    assert request["headers"]["authorization"] == f"Bearer {SECRET}"
    assert request["headers"]["user-agent"].startswith("Sorot/")
    body = json.loads(request["body"])
    assert body["model"] == "model-uji" and body["stream"] is False
    assert "naskah saya" in body["messages"][1]["content"]


def test_list_style_content_is_joined(provider):
    provider.route("POST", CHAT, json={"choices": [{"message": {"content": [{"type": "text", "text": "A"}, {"type": "text", "text": "B"}]}}]})
    assert ai.complete(make_config(provider), "natural", "x") == "A\nB"


@pytest.mark.parametrize("raw", [b"bukan json", b"{}", b'{"choices": []}', b'{"choices": [{"message": {"content": ""}}]}'])
def test_unrecognised_or_empty_responses_raise(provider, raw):
    provider.route("POST", CHAT, raw=raw)
    with pytest.raises(AIError) as info:
        ai.complete(make_config(provider), "natural", "x")
    assert info.value.kind is AIErrorKind.INVALID_RESPONSE


# ---- input validation happens before any network traffic ----------------
def test_validation_errors_never_touch_the_network(provider):
    for config, text in [
        (make_config(provider, api_key=" "), "x"),
        (make_config(provider, model=""), "x"),
        (make_config(provider), "   "),
        (make_config(provider), "a" * (ai.MAX_INPUT_CHARS + 1)),
    ]:
        with pytest.raises(AIError) as info:
            ai.complete(config, "natural", text)
        assert info.value.kind is AIErrorKind.CONFIG
    assert provider.requests == []


# ---- HTTP error mapping ---------------------------------------------------
@pytest.mark.parametrize("status,kind", [
    (401, AIErrorKind.AUTH), (403, AIErrorKind.AUTH), (404, AIErrorKind.NOT_FOUND),
    (400, AIErrorKind.BAD_REQUEST), (413, AIErrorKind.BAD_REQUEST), (422, AIErrorKind.BAD_REQUEST),
    (500, AIErrorKind.SERVER), (503, AIErrorKind.SERVER),
])
def test_http_errors_are_classified(provider, status, kind):
    provider.route("POST", CHAT, status=status, json={"error": {"message": "pesan provider"}})
    with pytest.raises(AIError) as info:
        ai.complete(make_config(provider), "natural", "x")
    assert info.value.kind is kind and info.value.status == status
    assert "pesan provider" in str(info.value) or kind is AIErrorKind.NOT_FOUND


def test_rate_limit_exposes_retry_after(provider):
    provider.route("POST", CHAT, status=429, headers={"Retry-After": "17"}, json={"error": {"message": "pelan-pelan"}})
    with pytest.raises(AIError) as info:
        ai.complete(make_config(provider), "natural", "x")
    assert info.value.kind is AIErrorKind.RATE_LIMIT and info.value.retry_after == 17
    assert "17 detik" in str(info.value)


def test_api_key_echoed_by_provider_is_redacted_in_user_message(provider):
    provider.route("POST", CHAT, status=401, json={"error": {"message": f"Incorrect API key provided: {SECRET}"}})
    with pytest.raises(AIError) as info:
        ai.complete(make_config(provider), "natural", "x")
    assert SECRET not in str(info.value)


@pytest.mark.parametrize("status", [301, 302, 303, 307, 308])
def test_redirects_are_not_followed_and_key_is_not_forwarded(provider, status):
    other = FakeProvider().start()
    try:
        for method in ("GET", "POST"):
            other.route(method, CHAT, json=chat_reply("jangan sampai ke sini"))
            other.route(method, "/v1/chat/completions", json=chat_reply("jangan sampai ke sini"))
        provider.route("POST", CHAT, status=status, headers={"Location": other.base_url + "/chat/completions"})
        with pytest.raises(AIError) as info:
            ai.complete(make_config(provider), "natural", "x")
        assert info.value.kind is AIErrorKind.CONFIG and "mengalihkan" in str(info.value)
        assert other.requests == [], "permintaan (dan API key) tidak boleh sampai ke host tujuan redirect"
    finally:
        other.stop()


def test_connection_refused_is_a_network_error():
    config = AIConfig("http://127.0.0.1:9/v1", "m", SECRET, 10)
    with pytest.raises(AIError) as info:
        ai.complete(config, "natural", "x")
    assert info.value.kind is AIErrorKind.NETWORK


def test_oversized_response_is_rejected(provider, monkeypatch):
    monkeypatch.setattr(ai, "MAX_RESPONSE_BYTES", 100)
    provider.route("POST", CHAT, json=chat_reply("x" * 500))
    with pytest.raises(AIError) as info:
        ai.complete(make_config(provider), "natural", "x")
    assert info.value.kind is AIErrorKind.INVALID_RESPONSE


def test_timeout_is_reported(provider, monkeypatch):
    monkeypatch.setattr(ai, "MIN_TIMEOUT", 1)
    provider.route("POST", CHAT, delay=3, json=chat_reply("terlambat"))
    started = time.monotonic()
    with pytest.raises(AIError) as info:
        ai.complete(make_config(provider, timeout_seconds=1), "natural", "x")
    assert info.value.kind is AIErrorKind.TIMEOUT
    assert time.monotonic() - started < 2.9


def test_cancellation_discards_the_result(provider):
    provider.route("POST", CHAT, delay=1.0, json=chat_reply("terlambat"))
    token = CancelToken()
    threading.Timer(0.2, token.cancel).start()
    with pytest.raises(AIError) as info:
        ai.complete(make_config(provider), "natural", "x", cancel=token)
    assert info.value.kind is AIErrorKind.CANCELLED


def test_already_cancelled_token_sends_nothing(provider):
    token = CancelToken()
    token.cancel()
    with pytest.raises(AIError):
        ai.complete(make_config(provider), "natural", "x", cancel=token)
    assert provider.requests == []


# ---- test_connection ------------------------------------------------------
def test_connection_ok_never_sends_script_text(provider):
    provider.route("GET", MODELS, json={"data": [{"id": "model-uji"}, {"id": "lain"}]})
    message = ai.test_connection(make_config(provider))
    assert "berhasil" in message
    assert [r["path"] for r in provider.requests] == [MODELS]


def test_connection_warns_when_model_is_not_listed(provider):
    provider.route("GET", MODELS, json={"data": [{"id": "lain"}]})
    assert "tidak ada di daftar" in ai.test_connection(make_config(provider))


def test_connection_reports_bad_key(provider):
    provider.route("GET", MODELS, status=401, json={"error": {"message": "kunci salah"}})
    with pytest.raises(AIError) as info:
        ai.test_connection(make_config(provider))
    assert info.value.kind is AIErrorKind.AUTH


def test_connection_falls_back_to_tiny_chat_when_models_missing(provider):
    provider.route("GET", MODELS, status=404, json={"error": {"message": "x"}})
    provider.route("POST", CHAT, json=chat_reply("pong"))
    assert "uji singkat" in ai.test_connection(make_config(provider))
    body = json.loads(provider.requests[-1]["body"])
    assert body["messages"] == [{"role": "user", "content": "ping"}]
