from sorot.services.platform_info import (
    Support,
    available_qt_platforms,
    capability,
    classify_session,
    detect_capabilities,
    format_platform_report,
    select_qt_platform,
)

WAYLAND_X = {"XDG_SESSION_TYPE": "wayland", "DISPLAY": ":0", "WAYLAND_DISPLAY": "wayland-0"}
WAYLAND_ONLY = {"XDG_SESSION_TYPE": "wayland", "WAYLAND_DISPLAY": "wayland-0"}
BOTH = {"xcb", "wayland"}


def test_session_classification():
    assert classify_session({"XDG_SESSION_TYPE": "Wayland"}) == "wayland"
    assert classify_session({"WAYLAND_DISPLAY": "w"}) == "wayland"
    assert classify_session({"DISPLAY": ":0"}) == "x11"
    assert classify_session({}) == "tidak diketahui"


def test_auto_prefers_xwayland_when_available():
    assert select_qt_platform(WAYLAND_X, available=BOTH).platform == "xcb"


def test_auto_uses_native_wayland_without_xwayland():
    assert select_qt_platform(WAYLAND_ONLY, available=BOTH).platform == "wayland"


def test_auto_falls_back_to_wayland_when_xcb_plugin_is_missing():
    assert select_qt_platform(WAYLAND_X, available={"wayland"}).platform == "wayland"


def test_auto_leaves_qt_alone_on_x11():
    assert select_qt_platform({"XDG_SESSION_TYPE": "x11", "DISPLAY": ":0"}, available=BOTH).platform is None


def test_user_environment_choice_is_respected():
    choice = select_qt_platform({**WAYLAND_X, "QT_QPA_PLATFORM": "wayland"}, available=BOTH)
    assert choice.platform is None and "wayland" in choice.description


def test_env_override_beats_config_preference():
    choice = select_qt_platform({**WAYLAND_X, "SOROT_QT_PLATFORM": "wayland"}, preference="xcb", available=BOTH)
    assert choice.platform == "wayland"


def test_configured_preference_applies_and_missing_plugin_degrades_safely():
    assert select_qt_platform(WAYLAND_X, preference="xcb", available=BOTH).platform == "xcb"
    degraded = select_qt_platform(WAYLAND_X, preference="xcb", available={"wayland"})
    assert degraded.platform is None and "tidak ditemukan" in degraded.description


def test_invalid_values_fall_back_to_auto():
    assert select_qt_platform({**WAYLAND_X, "SOROT_QT_PLATFORM": "x11"}, preference="bogus", available=BOTH).platform == "xcb"


def test_unknown_plugin_inventory_does_not_block_choice():
    assert select_qt_platform(WAYLAND_X, preference="xcb", available=None).platform == "xcb"


def test_capabilities_do_not_overpromise_on_native_wayland():
    items = detect_capabilities("wayland")
    assert capability(items, "position").support is Support.UNSUPPORTED
    assert capability(items, "always_on_top").support is Support.LIMITED
    assert capability(items, "click_through").support is Support.UNKNOWN
    assert capability(items, "drag_resize").support is Support.SUPPORTED


def test_capabilities_on_xcb_and_unknown_backends():
    assert capability(detect_capabilities("xcb"), "position").support is Support.SUPPORTED
    assert all(item.support is Support.UNKNOWN for item in detect_capabilities("cocoa"))
    assert capability(detect_capabilities("wayland-egl"), "position").support is Support.UNSUPPORTED


def test_report_is_honest_and_never_includes_secrets(monkeypatch):
    monkeypatch.setenv("SOROT_API_KEY", "sk-rahasia-jangan-bocor-123456")
    report = format_platform_report("wayland", env={**WAYLAND_ONLY, "SOROT_API_KEY": "sk-rahasia-jangan-bocor-123456"})
    assert "BUKAN hasil uji" in report and "Backend Qt      : wayland" in report
    assert "rahasia" not in report


def test_plugin_inventory_is_a_set_or_none():
    assert available_qt_platforms() is None or isinstance(available_qt_platforms(), set)


def test_plugin_with_missing_dependency_is_not_offered(tmp_path):
    """A plugin file that cannot be loaded (e.g. missing libxcb-cursor0) must not count."""
    (tmp_path / "libqxcb.so").write_bytes(b"not an ELF library")
    (tmp_path / "libqoffscreen.so").write_bytes(b"x")
    found = available_qt_platforms(tmp_path)
    assert found is not None and "xcb" not in found and "offscreen" in found
    assert select_qt_platform(WAYLAND_X, available=found).platform is None


def test_missing_plugin_directory_means_unknown(tmp_path):
    assert available_qt_platforms(tmp_path / "nope") is None
