import logging
import os
import subprocess
import sys

import pytest

pytest.importorskip("PySide6")

from sorot import crash  # noqa: E402
from sorot.logging_setup import setup_logging  # noqa: E402
from sorot.single_instance import InstanceLock  # noqa: E402


def test_second_instance_cannot_take_the_lock_until_released(tmp_path):
    first, second = InstanceLock(tmp_path / "x.lock"), InstanceLock(tmp_path / "x.lock")
    assert first.acquire()
    assert not second.acquire() and second.owner_pid() == os.getpid()
    first.release()
    assert second.acquire()
    second.release()


def test_lock_left_by_a_dead_process_is_taken_over(tmp_path):
    dead = subprocess.Popen([sys.executable, "-c", "pass"])
    dead.wait()
    lock_path = tmp_path / "x.lock"
    lock_path.write_text(f"{dead.pid}\nsorot\nlocalhost\n")
    os.utime(lock_path, (1, 1))  # old enough to be judged stale
    assert InstanceLock(lock_path).acquire()


def test_uncaught_exceptions_are_logged_without_secrets(tmp_path, monkeypatch):
    log_path = tmp_path / "state" / "app.log"
    setup_logging(path=log_path)
    original_hook, original_thread_hook = sys.excepthook, __import__("threading").excepthook
    monkeypatch.setattr(sys, "excepthook", lambda *a: None)
    crash.install_crash_handlers(tmp_path / "state" / "crash.log")
    try:
        raise RuntimeError("gagal dengan Bearer sk-sangatrahasia1234567890")
    except RuntimeError:
        sys.excepthook(*sys.exc_info())
    for handler in logging.getLogger("tama_prompter").handlers + logging.getLogger("sorot").handlers:
        handler.flush()
    content = log_path.read_text()
    assert "RuntimeError" in content and "sangatrahasia" not in content and "lokasi:" in content
    sys.excepthook = original_hook
    __import__("threading").excepthook = original_thread_hook
