#!/bin/sh
# Remove the per-user installation. Your scripts and settings are NOT deleted.
set -eu
DATA="${XDG_DATA_HOME:-$HOME/.local/share}"
rm -rf "$DATA/sorot/venv"
rm -f "$HOME/.local/bin/sorot" "$DATA/applications/sorot.desktop" "$DATA/icons/hicolor/scalable/apps/sorot.svg"
echo "Aplikasi dihapus. Data pengguna tetap ada di ~/.config/sorot dan $DATA/sorot (hapus manual jika ingin)."
