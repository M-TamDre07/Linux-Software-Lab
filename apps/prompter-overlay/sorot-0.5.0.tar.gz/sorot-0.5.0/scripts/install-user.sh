#!/bin/sh
# Install Sorot for the current user (no root). Needs python3-venv and PyPI access.
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PREFIX="${XDG_DATA_HOME:-$HOME/.local/share}/sorot"
BIN="$HOME/.local/bin"
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
ICONS="${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor/scalable/apps"

if [ "$(id -u)" = "0" ]; then
    echo "Jangan jalankan sebagai root; skrip ini memasang untuk pengguna biasa." >&2
    exit 1
fi
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)' || { echo "Dibutuhkan Python 3.11 atau lebih baru." >&2; exit 1; }
python3 -c 'import venv, ensurepip' 2>/dev/null || { echo "Pasang python3-venv terlebih dahulu (sudo apt install python3-venv)." >&2; exit 1; }

mkdir -p "$PREFIX" "$BIN" "$APPS" "$ICONS"
python3 -m venv "$PREFIX/venv"
"$PREFIX/venv/bin/python" -m pip install --quiet --upgrade pip
# Build from a scratch copy so a read-only or shared source tree is never written to.
BUILD="$(mktemp -d)"
trap 'rm -rf "$BUILD"' EXIT
cp -r "$ROOT/src" "$ROOT/pyproject.toml" "$ROOT/README.md" "$ROOT/LICENSE" "$BUILD/"
"$PREFIX/venv/bin/python" -m pip install --quiet "$BUILD[keyring]"

cat > "$BIN/sorot" <<LAUNCHER
#!/bin/sh
exec "$PREFIX/venv/bin/python" -m sorot "\$@"
LAUNCHER
chmod 0755 "$BIN/sorot"
install -m 0644 "$ROOT/packaging/sorot.svg" "$ICONS/sorot.svg"
sed "s|^Exec=.*|Exec=$BIN/sorot|" "$ROOT/packaging/sorot.desktop" > "$APPS/sorot.desktop"

echo "Terpasang. Jalankan: $BIN/sorot"
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Catatan: $BIN belum ada di PATH." ;; esac
