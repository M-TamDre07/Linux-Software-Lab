#!/bin/bash
# Build a reproducible Debian package (Architecture: all) and release artifacts.
# Usage: scripts/build-deb.sh [output-dir]
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "${1:-$ROOT/dist}"
OUT="$(cd "${1:-$ROOT/dist}" && pwd)"
VERSION="$(python3 - <<PY
import re
print(re.search(r'__version__ = "([^"]+)"', open("$ROOT/src/sorot/__init__.py").read()).group(1))
PY
)"
RELEASE_DATE="$(tr -d '[:space:]' < "$ROOT/packaging/RELEASE_DATE")"
export SOURCE_DATE_EPOCH="${SOURCE_DATE_EPOCH:-$(date -u -d "$RELEASE_DATE 00:00:00" +%s)}"
export LC_ALL=C TZ=UTC

PKG="sorot_${VERSION}_all"
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT

# ---- payload ------------------------------------------------------------
install -d "$STAGE/usr/lib/sorot" "$STAGE/usr/bin" "$STAGE/usr/share/applications" \
    "$STAGE/usr/share/icons/hicolor/scalable/apps" "$STAGE/usr/share/doc/sorot" "$STAGE/usr/share/man/man1"
(cd "$ROOT/src" && find sorot \( -name '*.py' -o -name '*.svg' \) -print0 | sort -z | xargs -0 -I{} install -D -m 0644 {} "$STAGE/usr/lib/sorot/{}")
install -m 0755 "$ROOT/packaging/sorot.sh" "$STAGE/usr/bin/sorot"
install -m 0644 "$ROOT/packaging/sorot.desktop" "$STAGE/usr/share/applications/sorot.desktop"
install -m 0644 "$ROOT/packaging/sorot.svg" "$STAGE/usr/share/icons/hicolor/scalable/apps/sorot.svg"
install -m 0644 "$ROOT/packaging/copyright" "$STAGE/usr/share/doc/sorot/copyright"
install -m 0644 "$ROOT/README.md" "$STAGE/usr/share/doc/sorot/README.md"
install -d "$STAGE/usr/share/doc/sorot/docs" "$STAGE/usr/share/sorot/extensions"
(cd "$ROOT" && find examples -type f -print0 | sort -z | xargs -0 -I{} install -D -m 0644 {} "$STAGE/usr/share/doc/sorot/{}")
install -m 0644 "$ROOT/packaging/extensions-README" "$STAGE/usr/share/sorot/extensions/README"
install -m 0644 "$ROOT"/docs/*.md "$STAGE/usr/share/doc/sorot/docs/"
gzip -9n -c "$ROOT/packaging/sorot.1" > "$STAGE/usr/share/man/man1/sorot.1.gz"
gzip -9n -c "$ROOT/packaging/debian-changelog" > "$STAGE/usr/share/doc/sorot/changelog.gz"
chmod 0644 "$STAGE/usr/share/man/man1/sorot.1.gz" "$STAGE/usr/share/doc/sorot/changelog.gz"

# ---- control data -----------------------------------------------------------
install -d "$STAGE/DEBIAN"
SIZE="$(du -sk --apparent-size "$STAGE" | cut -f1)"
sed -e "s/@VERSION@/$VERSION/" -e "s/@SIZE@/$SIZE/" "$ROOT/packaging/control.in" > "$STAGE/DEBIAN/control"
for script in postinst prerm postrm; do install -m 0755 "$ROOT/packaging/$script" "$STAGE/DEBIAN/$script"; done
(cd "$STAGE" && find usr -type f -print0 | sort -z | xargs -0 md5sum > DEBIAN/md5sums)
chmod 0644 "$STAGE/DEBIAN/md5sums"

# ---- normalise and build --------------------------------------------------------
find "$STAGE" -exec touch -h -d "@$SOURCE_DATE_EPOCH" {} +
dpkg-deb --root-owner-group -Zxz -b "$STAGE" "$OUT/$PKG.deb" >/dev/null

# ---- source archives ---------------------------------------------------------------
if git -C "$ROOT" rev-parse --git-dir >/dev/null 2>&1 && [ -n "$(git -C "$ROOT" ls-files | head -1)" ]; then
    FILES="$(git -C "$ROOT" ls-files)"
else
    FILES="$(cd "$ROOT" && find . -type f -not -path './.git/*' -not -path './dist/*' -not -path '*/__pycache__/*' -not -path './.venv/*' \
        -not -path './.pytest_cache/*' -not -path './.mypy_cache/*' -not -path './.ruff_cache/*' -not -name '*.pyc' | sed 's|^\./||' | sort)"
fi
SRC="sorot-$VERSION"
SRCSTAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE" "$SRCSTAGE"' EXIT
mkdir -p "$SRCSTAGE/$SRC"
(cd "$ROOT" && echo "$FILES" | tar -cf - -T -) | tar -xf - -C "$SRCSTAGE/$SRC"
find "$SRCSTAGE" -exec touch -h -d "@$SOURCE_DATE_EPOCH" {} +
(cd "$SRCSTAGE" && tar --sort=name --owner=0 --group=0 --numeric-owner --mtime="@$SOURCE_DATE_EPOCH" -cf - "$SRC" | gzip -9n > "$OUT/$SRC.tar.gz")
rm -f "$OUT/$SRC.zip"
(cd "$SRCSTAGE" && find "$SRC" -type f | sort | TZ=UTC zip -X -q -9 "$OUT/$SRC.zip" -@)

# ---- checksums ------------------------------------------------------------------------
(cd "$OUT" && sha256sum "$PKG.deb" "$SRC.tar.gz" "$SRC.zip" > SHA256SUMS && cat SHA256SUMS)
