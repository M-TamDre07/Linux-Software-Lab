#!/bin/sh
# Launcher for the Debian package. All backend selection lives in Python
# (see sorot.services.platform_info.select_qt_platform) so it can be tested.
set -eu
export PYTHONPATH="/usr/lib/sorot${PYTHONPATH:+:$PYTHONPATH}"
exec /usr/bin/python3 -m sorot "$@"
