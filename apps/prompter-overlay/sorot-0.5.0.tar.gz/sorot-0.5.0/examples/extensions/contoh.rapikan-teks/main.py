"""Contoh ekstensi Sorot: rapikan spasi, kapitalisasi kalimat, impor/ekspor Markdown."""
import re


def collapse_spaces(text):
    lines = [re.sub(r"[ \t]+", " ", line).strip() for line in text.split("\n")]
    return re.sub(r"\n{3,}", "\n\n", "\n".join(lines)).strip("\n")


def capitalise_sentences(text):
    return re.sub(r"(^|[.!?]\s+)([a-z])", lambda m: m.group(1) + m.group(2).upper(), text)


def read_markdown(path):
    with open(path, encoding="utf-8") as handle:
        text = handle.read()
    return re.sub(r"^#+\s*", "", text, flags=re.MULTILINE)  # drop heading markers


def write_markdown(text, path):
    with open(path, "w", encoding="utf-8") as handle:
        handle.write("# Naskah\n\n" + text + "\n")


def activate(api):
    api.register_transform("spasi", "Rapikan spasi dan baris kosong", collapse_spaces)
    api.register_transform("kapital", "Kapitalisasi awal kalimat", capitalise_sentences)
    api.register_action("hitung", "Hitung kata (tanpa mengubah naskah)", lambda text: f"{len(text.split())} kata")
    api.register_importer("md", "Markdown", [".md"], read_markdown)
    api.register_exporter("md", "Markdown", ".md", write_markdown)
