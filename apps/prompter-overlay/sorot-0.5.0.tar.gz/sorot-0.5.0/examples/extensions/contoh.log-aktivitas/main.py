"""Contoh: mencatat kapan overlay dipakai. Event tidak membawa isi naskah, hanya angka dan nama berkas."""
import time


def activate(api):
    log = api.data_dir / "sesi.log"

    def write(name):
        def handler(data):
            with open(log, "a", encoding="utf-8") as handle:
                handle.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {name} {data}\n")
        return handler

    for event in ("overlay.shown", "overlay.hidden", "playback.started", "playback.paused", "playback.finished", "script.saved"):
        api.on(event, write(event))
    api.register_action("lokasi", "Tampilkan lokasi log", lambda text: f"Log: {log}")
