# Berkontribusi

Terima kasih sudah tertarik. Proyek ini kecil dan sengaja dibuat sederhana.

## Menyiapkan lingkungan

```bash
python3 -m venv .venv && . .venv/bin/activate
python -m pip install -e ".[dev]"
```

## Menjalankan pemeriksaan

```bash
ruff check src tests
mypy src
QT_QPA_PLATFORM=offscreen python -m pytest
```

Tes GUI memakai platform Qt `offscreen`, jadi **tidak membuktikan** perilaku pada compositor nyata. Lihat [docs/MANUAL-TESTING.md](docs/MANUAL-TESTING.md) untuk pemeriksaan manual GNOME/KDE.

## Pedoman

- Logika tanpa Qt ditaruh di `src/sorot/core/` agar mudah diuji; kode Qt di `ui/`; integrasi eksternal di `services/`.
- Operasi jaringan atau subprocess **tidak boleh** berjalan di thread GUI; gunakan `BackgroundTask`.
- Jangan pernah memasukkan API key, naskah pengguna, atau konfigurasi pribadi ke repositori, log, atau laporan bug.
- Perubahan perilaku harus disertai tes yang memeriksa perilaku bermakna, bukan sekadar membuat tes lulus.
- Klaim kompatibilitas (desktop/compositor) harus berdasarkan pengujian yang dicatat.
- Tambahkan catatan di `CHANGELOG.md`.

## Melaporkan bug

Gunakan templat isu. Sertakan keluaran `sorot --diagnostics` (periksa dulu isinya) dan langkah reproduksi. Jangan melampirkan naskah atau kunci rahasia.
