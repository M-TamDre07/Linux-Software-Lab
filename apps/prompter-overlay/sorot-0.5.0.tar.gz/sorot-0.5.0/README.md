# Sorot 0.5.0 Beta

Teleprompter overlay untuk Linux. Naskah tampil dalam jendela transparan yang menggulir **mengikuti kecepatan bicaramu**, di atas aplikasi lain. Naskah dan pengaturan **hanya disimpan di komputermu**; aplikasi berfungsi penuh tanpa internet, tanpa akun, dan tanpa API key.

Dibuat oleh **Muhammad Andreatama** · Hak cipta © 2026 Muhammad Andreatama · Lisensi MIT

> **Status: beta.** Logika diuji otomatis ([laporan tes](docs/TEST-REPORT.md)). Pengguna melaporkan versi 0.4.0 berjalan di Debian 13 / KDE Plasma Wayland (lewat XWayland). Perilaku overlay pada compositor nyata (selalu-di-atas, klik-tembus, geser/ubah ukuran di Wayland asli) **belum diuji secara manual**; lihat [kompatibilitas](docs/COMPATIBILITY.md). Sorot dulu bernama *Tama Prompter* (0.3–0.4); data lama diimpor otomatis.

## Fitur utama

**Gulir yang mengikuti pembicara.** Tiga mode: *kata/menit* (gulir mengikuti laju bicara, dengan jeda napas pada koma dan akhir kalimat), *durasi target* (selesai tepat dalam m:ss), dan *piksel/detik* (konstan). Mulai dan berhenti dihaluskan; jika kamu menggulir dengan roda mouse saat berjalan, waktu otomatis menyesuaikan posisimu; mengubah kecepatan di tengah jalan tidak membuat teks melompat.

**Isyarat naskah.** Baris `// catatan` tidak tampil dan tidak dihitung. Baris `[jeda]` atau `[jeda 5]` benar-benar menahan layar. Penyorot warna di editor menandai keduanya.

**Overlay.** Garis baca (baris yang sedang dibaca), garis progres dan sisa waktu, jenis huruf, warna teks/latar (tema siap pakai atau kustom), transparansi, perataan, margin, posisi lewat peta layar, selalu-di-atas, tanpa bingkai, klik-tembus. Arahkan kursor ke overlay untuk tombol Mulai/Jeda, Awal, kecepatan, Tutup, pegangan **Geser**, dan pegangan ubah ukuran. Roda mouse menggulir manual.

**Naskah.** Buka/simpan/ekspor `.txt` dan `.md`, pustaka “Naskah lokal”, draf otomatis untuk pemulihan setelah crash, **riwayat draf** (20 snapshot, termasuk sebelum naskah diganti), peringatan sebelum perubahan hilang, estimasi durasi.

**Ekstensi.** Tema, preset warna, tugas AI, templat naskah (deklaratif), serta perintah Python (transformasi, aksi, impor/ekspor, pendengar event) yang berjalan di proses terpisah dan **wajib kamu setujui**. Lihat [docs/EXTENSIONS.md](docs/EXTENSIONS.md). Ini bukan sandbox: pasang hanya dari sumber yang kamu percaya.

**Asisten AI (opsional)** — perbaiki bahasa, ringkas, terjemahkan, sesuaikan durasi, dan lainnya lewat API milikmu (format OpenAI Chat Completions). Hasil tampil sebagai pratinjau; tidak menimpa naskah sampai kamu memilih. **Google Drive (opsional)** lewat rclone buatanmu sendiri.

**Pintasan** (dapat diubah, aktif saat jendela utama terfokus): `Ctrl+Enter` tampilkan, `Ctrl+Space` mulai/jeda, `Esc` sembunyikan, `Ctrl+R` ke awal, `Alt+↑/↓` kecepatan.

## Instalasi

### Debian 13 (paket `.deb`)

```bash
sudo apt install ./sorot_0.5.0_all.deb
```

Paket ini menggantikan `tama-prompter` jika terpasang. Dependensi wajib: `python3 (>= 3.11)`, `python3-pyside6.qtwidgets (>= 6.8.2.1)` serta pustaka xcb. Opsional: `qt6-wayland`, `xwayland`, `rclone`, `python3-keyring`. Menjalankan: cari “Sorot” di menu aplikasi atau jalankan `sorot`. Menghapus: `sudo apt remove sorot` (data pengguna tidak dihapus).

### Distribusi lain

```bash
./scripts/install-user.sh      # ke ~/.local, dalam virtual environment
./scripts/uninstall-user.sh
```

### Pengembangan

```bash
python3 -m venv .venv && . .venv/bin/activate
python -m pip install -e ".[dev]"
sorot
```

## Data dan privasi

| Data | Lokasi | Catatan |
|---|---|---|
| Pengaturan | `~/.config/sorot/config.json` | tanpa rahasia; cadangan `.bak` |
| Draf, riwayat, pustaka naskah | `~/.local/share/sorot/` | izin `0600`, **tidak dienkripsi** |
| Ekstensi dan datanya | `~/.local/share/sorot/extensions/`, `extension-data/` | |
| Log | `~/.local/state/sorot/` | rahasia disamarkan; isi naskah tidak dicatat |
| API key | keyring sistem (jika dicentang) atau memori sesi | tidak pernah ke berkas |

Tidak ada telemetri. Naskah hanya dikirim ke penyedia AI saat kamu menekan **Proses naskah** dan menyetujui tujuannya. Biaya API bergantung pada penyedia. Overlay tidak menjamin tersembunyi dari berbagi layar atau rekaman.

## Diagnostik

```bash
sorot --diagnostics                      # laporan lingkungan tanpa jendela
sorot --extensions                       # ekstensi yang ditemukan dan statusnya
sorot --validate-extension FOLDER        # periksa ekstensi buatanmu
SOROT_QT_PLATFORM=xcb sorot              # paksa backend sementara (auto|xcb|wayland)
```

## Dukung pengembangan

Sorot gratis dan bebas dipakai. Jika bermanfaat, dukunganmu membantu pemeliharaan dan fitur berikutnya. Dukungan **sukarela**: tidak ada fitur yang dikunci, tidak ada pop-up, tidak ada pelacakan.

* **Saweria:** https://saweria.co/tamaandrea
* **GoPay:** 0812-7485-2534 (periksa nama penerima di aplikasi sebelum mengirim)

Di aplikasi: tombol *Dukung Sorot* di rail kiri, atau menu Bantuan → Dukung pengembangan.

## Dokumentasi

[Ekstensi](docs/EXTENSIONS.md) · [Kompatibilitas](docs/COMPATIBILITY.md) · [Arsitektur](docs/ARCHITECTURE.md) · [Pengujian manual](docs/MANUAL-TESTING.md) · [Pemecahan masalah](docs/TROUBLESHOOTING.md) · [Audit 0.3.0](docs/AUDIT-0.3.0.md) · [Laporan tes](docs/TEST-REPORT.md) · [Checklist rilis](docs/RELEASE-CHECKLIST.md) · [CHANGELOG](CHANGELOG.md) · [CONTRIBUTING](CONTRIBUTING.md) · [SECURITY](SECURITY.md)
