# Checklist rilis

- [ ] Ganti maintainer placeholder `maintainer@sorot.invalid` (nama sudah Muhammad Andreatama; **email asli belum ada**) di `packaging/control.in`, `packaging/debian-changelog`, `packaging/copyright` dengan kontak nyata
- [ ] Isi `Source:` di `packaging/copyright` dan `Homepage:` di `control.in` setelah URL repositori ada; perbarui `SECURITY.md`
- [ ] Verifikasi dependensi `.deb` pada Debian 13 bersih (`apt install ./...`), termasuk nama/versi `python3-pyside6.qtwidgets`
- [ ] `ruff check src tests`, `mypy src`, `pytest` lulus
- [ ] CI GitHub Actions hijau (matriks Python 3.11/3.12/3.13)
- [ ] Jalankan [pengujian manual](MANUAL-TESTING.md) minimal baris 1 dan 3; perbarui `docs/COMPATIBILITY.md`
- [ ] Uji integrasi Drive dengan rclone asli dan akun uji
- [ ] Uji AI dengan satu penyedia nyata (uji koneksi + satu tugas)
- [ ] Naikkan versi di `src/sorot/__init__.py`, `packaging/debian-changelog`, `packaging/sorot.1`, `CHANGELOG.md`, README
- [ ] `scripts/build-deb.sh`; `lintian`; build kedua menghasilkan checksum sama
- [ ] Pasang, jalankan, hapus (`remove` dan `purge`) pada mesin bersih
- [ ] Tag git, unggah artefak + `SHA256SUMS` — **hanya setelah persetujuan eksplisit pemilik**
- [ ] Konfirmasi nomor GoPay (`src/sorot/support.py`) dan tautan Saweria benar; sadari keduanya menjadi publik di repositori dan paket
- [ ] Periksa nama “Sorot” belum dipakai produk lain di bidang yang sama (pemeriksaan merek dagang belum dilakukan)
- [ ] Uji ekstensi contoh pada desktop nyata dan pasang satu ekstensi dari ZIP
