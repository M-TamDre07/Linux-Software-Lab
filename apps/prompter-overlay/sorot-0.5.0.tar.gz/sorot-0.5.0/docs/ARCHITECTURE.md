# Arsitektur

```
src/sorot/
  app.py             pintu masuk: argumen CLI, logging, pemilihan backend, impor 0.3.x, MainWindow
  logging_setup.py   log berputar 0600 + penyamaran rahasia
  legacy_import.py   impor sekali pengaturan QSettings 0.3.x (hanya membaca)
  core/              TANPA Qt — mudah diuji
    paths.py         lokasi XDG
    fileio.py        tulis atomik, baca terbatas UTF-8
    config.py        AppConfig tervalidasi, ConfigStore (JSON berversi, .bak, karantina), migrasi
    scripts.py       DraftStore, ScriptLibrary (nama file aman, hapus terkurung)
    script_stats.py  hitung kata dan estimasi durasi
    cancel.py        CancelToken
    redact.py        penyamaran rahasia
  services/          integrasi eksternal, tanpa Qt kecuali pendeteksian plugin
    ai_service.py    klien Chat Completions (stdlib), klasifikasi error, uji koneksi
    drive_service.py pembungkus rclone (tanpa shell, timeout, batal, validasi jalur)
    keyring_service.py pembungkus keyring konservatif
    platform_info.py sesi, pilihan backend Qt, tabel kemampuan, laporan diagnostik
  ui/
    main_window.py   jendela utama (Studio, Tampilan, Integrasi, Sistem)
    overlay.py       jendela overlay
    ai_dialog.py     dialog AI (dependensi masuk lewat AIContext)
    drive_controller.py alur Drive
    dialogs.py       pintasan, naskah lokal
    task_worker.py   BackgroundTask: thread daemon + pembatalan
    appearance.py, widgets.py, styles.py
```

## Keputusan desain

- **Pemisahan lapisan.** UI tidak melakukan I/O jaringan/subprocess; `core/` tidak mengimpor Qt, sehingga 100+ tes berjalan tanpa display.
- **Operasi lama di luar thread GUI.** AI dan Drive berjalan di `BackgroundTask` (thread daemon). Hasil kembali lewat sinyal Qt antrean. Pembatalan bersifat kooperatif: permintaan HTTP yang sudah terkirim tidak dapat ditarik, hasil terlambat dibuang, dan thread daemon tidak menahan penutupan aplikasi (berbeda dengan `QThreadPool`). Subprocess rclone dihentikan sungguhan saat dibatalkan.
- **Penyimpanan.** Pengaturan JSON dengan `schema_version`, nilai divalidasi dan dijepit saat dimuat, kunci tak dikenal dipertahankan, penulisan atomik + cadangan, berkas rusak dikarantina (tidak dihapus). Naskah terpisah dari pengaturan dan ditulis dengan debounce 0,8 detik.
- **Kompatibilitas jendela.** Geser/ubah ukuran memakai `startSystemMove/Resize`, satu-satunya cara yang bekerja pada Wayland. Posisi absolut hanya dicoba bila backend mendukungnya; selalu-di-atas dan klik-tembus diperlakukan sebagai permintaan.
- **HTTP.** `urllib` standar dengan penanganan redirect dimatikan (agar `Authorization` tidak diteruskan), batas respons 2 MB, batas waktu keseluruhan. Proxy sistem dari variabel lingkungan tetap dihormati oleh `urllib`.
- **Adapter provider.** Hanya format OpenAI Chat Completions yang diimplementasikan. Penyedia dengan API berbeda memerlukan adapter baru di `ai_service.py` (`build_chat_request` / `parse_chat_response` sudah dipisah dari transport).
- **Tanpa dependensi baru.** Selain PySide6 hanya pustaka standar; `keyring` opsional.
