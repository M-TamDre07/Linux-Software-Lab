# Kompatibilitas

Status di bawah dibedakan tegas antara **diuji otomatis**, **diharapkan** (berdasarkan dokumentasi Qt/perilaku umum), dan **BELUM DIUJI**. Tidak ada klaim kompatibilitas universal.

## Versi minimum

| Komponen | Minimum | Bukti |
|---|---|---|
| Python | 3.11 (kode memakai `StrEnum`) | Diuji dengan Python 3.12.3. Python 3.13.5 **berjalan** pada laporan pengguna (0.4.0). 3.11: **BELUM DIUJI** (CI disiapkan, belum dijalankan) |
| PySide6 / Qt | 6.8 (deb: `python3-pyside6.qtwidgets >= 6.8.2.1`) | Diuji dengan PySide6 6.12.0 (wheel PyPI). PySide6 6.8.2.1 dari paket Debian 13 **berjalan** pada laporan pengguna (0.4.0); suite tes belum dijalankan pada versi itu |
| Arsitektur paket | `all` (Python murni) | Benar: tidak ada kode native; dependensi PySide6 yang native ditarik lewat `Depends` |
| Platform build/uji | Ubuntu 24.04 x86_64, Qt `offscreen` dan `xcb` (Xvfb) | Lihat laporan tes |

## Laporan lapangan

Pengguna melaporkan (tangkapan layar tab Sistem, versi 0.4.0 / saat itu bernama Tama Prompter) aplikasi **berjalan** di **Debian GNU/Linux 13 (trixie), kernel 6.12.111+deb13-amd64, KDE Plasma, sesi Wayland, backend Qt `xcb` melalui XWayland, Python 3.13.5, PySide6 6.8.2.1**, dengan impor data 0.3.x berhasil. Ini membuktikan *peluncuran dan dependensi paket* pada konfigurasi itu. Perilaku overlay (selalu-di-atas, klik-tembus, geser/ubah ukuran) pada sesi tersebut **belum dilaporkan**.

## Desktop dan backend

| Target | Status |
|---|---|
| Debian 13, GNOME Wayland (lewat XWayland, pilihan otomatis) | **BELUM DIUJI** pada sesi nyata |
| Debian 13, KDE Plasma Wayland via XWayland (xcb) | aplikasi **berjalan** (laporan pengguna, 0.4.0); overlay **BELUM DIUJI** |
| Debian 13, GNOME Wayland asli (`SOROT_QT_PLATFORM=wayland`) | **BELUM DIUJI** |
| KDE Plasma X11, Wayland asli | **BELUM DIUJI** |
| Xfce, Cinnamon (X11) | **BELUM DIUJI** (backend xcb diuji hanya di Xvfb tanpa window manager sungguhan) |
| Ubuntu, Linux Mint | **BELUM DIUJI**; nama paket PySide6 berbeda per rilis |

## Kemampuan overlay yang diharapkan per backend

| Kemampuan | xcb (X11/XWayland) | wayland asli |
|---|---|---|
| Transparansi latar | didukung (butuh compositing) | didukung |
| Posisi diatur aplikasi | didukung | **tidak tersedia** — compositor memutuskan; preset posisi dan pilihan monitor dapat diabaikan |
| Selalu di atas | didukung (bergantung window manager) | **terbatas** — tidak ada mekanisme standar; sebagian compositor (mis. GNOME) mengabaikannya |
| Klik-tembus | didukung (input shape) | tidak diketahui — umumnya memakai input region kosong |
| Geser / ubah ukuran | didukung | didukung via permintaan geser/ubah ukuran compositor |
| Pilih monitor | didukung | terbatas |
| Layar penuh eksklusif | overlay dapat tertutup | overlay dapat tertutup |

Aplikasi menampilkan tabel ini (berdasarkan backend aktif) di tab Sistem dan di bawah pengaturan jendela. Pada backend selain xcb/wayland semuanya ditandai “tidak diketahui”.

## Pemilihan backend

Urutan prioritas: `SOROT_QT_PLATFORM` → pengaturan tab Sistem → kebijakan otomatis.

Kebijakan otomatis: jika `QT_QPA_PLATFORM` sudah diatur pengguna, dihormati. Pada sesi Wayland dengan `DISPLAY` tersedia dan plugin xcb ada → `xcb` (XWayland, posisi lebih terkontrol). Jika xcb tidak ada tetapi plugin wayland ada → `wayland`. Selainnya Qt memilih sendiri. Jika backend yang dipilih eksplisit tidak ditemukan, aplikasi tidak memaksanya dan Qt memilih sendiri (daripada berhenti tanpa pesan).

Aplikasi tidak memasang paket, ekstensi desktop, atau driver, dan tidak mengubah pengaturan sistem.
