# Pemecahan masalah

Mulai dari `sorot --diagnostics` dan log di `~/.local/state/sorot/sorot.log` (periksa sebelum dibagikan).

| Gejala | Kemungkinan penyebab dan langkah |
|---|---|
| `apt` menolak memasang dependensi PySide6 | Nama/versi paket berbeda di rilismu. Gunakan `./scripts/install-user.sh` (wheel PyPI) atau pasang PySide6 sesuai distribusimu. |
| Aplikasi tidak mau mulai, pesan tentang plugin Qt `xcb`/`wayland` | Pasang `libxcb-cursor0` (xcb) atau `qt6-wayland` (Wayland). Coba `SOROT_QT_PLATFORM=xcb` atau `wayland`. |
| Overlay muncul di posisi tak terduga di Wayland | Wajar: compositor memutuskan posisi. Seret dengan pegangan “Geser”, atau jalankan dengan `SOROT_QT_PLATFORM=xcb` (XWayland). |
| Overlay tertutup jendela lain | “Selalu di atas” tidak dijamin di Wayland asli; coba mode `xcb`. Aplikasi layar penuh eksklusif dapat menutupi overlay. |
| Klik-tembus aktif dan overlay tak bisa dipindah | Itu perilaku klik-tembus. Matikan di tab Tampilan, atau tekan “Sembunyikan”/pintasan di jendela utama. |
| Pintasan tidak bereaksi saat overlay di atas aplikasi lain | Pintasan hanya aktif ketika jendela utama terfokus. Pakai bar kontrol di overlay (arahkan kursor). |
| “Simpan API key di keyring” nonaktif | Pasang `python3-keyring` dan layanan seperti GNOME Keyring/KWallet. Tanpa itu key hanya berlaku selama sesi atau lewat `SOROT_API_KEY`. |
| AI: “Autentikasi ditolak” | Periksa key, hak akses, dan saldo/kuota di akun penyedia. |
| AI: “Endpoint atau model tidak ditemukan” | Periksa base URL (biasanya berakhiran `/v1`) dan nama model. Gunakan Uji koneksi. |
| AI: “Server mengalihkan permintaan” | Base URL salah atau memakai redirect; pengalihan sengaja tidak diikuti. Perbaiki URL. |
| Drive: “rclone belum terpasang” | `sudo apt install rclone`, lalu `rclone config` untuk membuat remote bertipe `drive`. |
| Drive gagal / token kedaluwarsa | Jalankan `rclone config reconnect <remote>:`. |
| Pengaturan kembali ke bawaan setelah update | Berkas rusak dikarantina sebagai `config.json.corrupt-*`; cadangan terakhir ada di `config.json.bak` (menu Berkas → Pulihkan pengaturan). |
| Naskah lama dari 0.3.0 tidak muncul | Impor hanya berjalan sekali, jika belum ada `config.json`/draf. Berkas lama tetap ada di `~/.config/TamaAndrea/TamaPrompter.conf`. |

Mencabut akses Drive: hapus remote dengan `rclone config` (opsi `d`) dan cabut aplikasi “rclone” di https://myaccount.google.com/permissions.
