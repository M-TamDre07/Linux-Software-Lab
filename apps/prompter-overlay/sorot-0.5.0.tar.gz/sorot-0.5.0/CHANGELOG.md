# Changelog

Format mengikuti [Keep a Changelog](https://keepachangelog.com/id/1.1.0/). Proyek ini masih beta; nomor versi belum menjamin kestabilan API internal.

## [0.5.0 Beta] — 2026-10-18

Aplikasi berganti nama dari **Tama Prompter** menjadi **Sorot** dan mendapat tampilan serta mesin gulir baru.

### Diubah
- Nama, paket (`sorot`), perintah (`sorot`), folder data (`~/.config/sorot`, `~/.local/share/sorot`, `~/.local/state/sorot`), dan variabel lingkungan (`SOROT_QT_PLATFORM`, `SOROT_API_KEY`). Paket `.deb` menggantikan `tama-prompter`. Data 0.4.x dan 0.3.x diimpor otomatis saat pertama dijalankan (berkas lama tidak diubah); API key keyring lama tetap terbaca.
- Antarmuka dirancang ulang: rail navigasi, tema Studio gelap/Kertas terang/ikuti sistem, stepper, kontrol segmented, peta posisi overlay, readout waktu, penyorot markup. Skema konfigurasi naik ke versi 3 (pengguna lama tetap memakai mode piksel/detik).
- Model durasi memperhitungkan jeda koma, akhir kalimat, dan isyarat jeda.

### Ditambahkan
- Mesin gulir berbasis garis waktu: mode kata/menit, durasi target, piksel/detik; jam monotonik; mulai/berhenti halus; sinkron ulang saat digulir manual; garis baca, progres, dan sisa waktu.
- Isyarat naskah `// catatan` dan `[jeda N]`.
- Sistem ekstensi (deklaratif dan kode, proses terpisah, persetujuan berbasis hash, pemasang aman, entry point pip, CLI `--extensions` dan `--validate-extension`), dengan tiga contoh.
- Riwayat draf (snapshot), instance tunggal, penangan crash/thread, ukuran jendela diingat.
- Dialog *Dukung pengembangan* (Saweria dan GoPay), sukarela dan tidak pernah muncul sendiri; kredit pembuat dan hak cipta di aplikasi dan paket.

### Diperbaiki
- Menutup aplikasi tanpa mengedit memunculkan peringatan “belum disimpan” palsu (penyorot warna menandai dokumen berubah).
- Rekursi tak terbatas pada overlay dengan naskah kosong di mode durasi.
- Interval tick negatif dapat memicu overflow pada pelunakan kecepatan.

## [0.4.0 Beta] — 2026-10-18

Hasil audit menyeluruh terhadap 0.3.0. Detail temuan: [docs/AUDIT-0.3.0.md](docs/AUDIT-0.3.0.md).

### Diperbaiki
- Posisi overlay manual disimpan tetapi **tidak pernah dipulihkan** saat aplikasi dibuka kembali. Kini dipulihkan, dan jika posisi tersimpan berada di luar semua layar (mis. monitor dicabut) overlay memakai posisi preset.
- Mengganti naskah (buka berkas, buka dari Drive, hasil AI) memakai `setPlainText`, yang **menghapus riwayat undo**. Kini penggantian dapat dibatalkan dengan Ctrl+Z.
- Membuka berkas atau naskah Drive menimpa editor tanpa peringatan. Kini ada konfirmasi Simpan / Lanjutkan tanpa menyimpan / Batal, juga saat keluar.
- Menggeser overlay dengan `move()` manual tidak bekerja pada Wayland asli. Kini memakai fitur geser/ubah ukuran dari compositor.
- Permintaan AI mengikuti pengalihan (redirect) HTTP sehingga header `Authorization` dapat diteruskan ke host lain. Pengalihan kini ditolak.
- Permintaan AI tidak dapat dibatalkan dan dialog tidak bisa ditutup selama permintaan berjalan. Kini dapat dibatalkan dan tidak menahan aplikasi saat keluar.
- Menghapus centang “simpan di keyring” diam-diam menghapus API key yang tersimpan. Kini ada tombol “Hapus key tersimpan” yang eksplisit.
- Memaksa backend xcb ketika plugin Qt xcb tidak ada membuat Qt berhenti tanpa pesan. Kini plugin diperiksa dan aplikasi turun ke pilihan lain.
- `rclone cat` tidak dibatasi ukurannya dan `rclone lsf` menelusuri seluruh Drive tanpa batas kedalaman. Kini keduanya dibatasi, ada timeout, dan dapat dibatalkan.
- Penyegaran overlay pada setiap ketikan membuat naskah panjang lambat; kini di-debounce.

### Ditambahkan
- Pengaturan JSON berversi di `~/.config/tama-prompter/config.json` (validasi nilai, tulis atomik, cadangan `.bak`, berkas rusak dikarantina), impor sekali dari 0.3.x tanpa mengubah berkas lama.
- Draf naskah otomatis (pemulihan setelah crash) dan pustaka “Naskah lokal”.
- Overlay: jenis huruf, warna teks/latar kustom + tema siap pakai, perataan, margin, selalu-di-atas, mode tanpa bingkai, pegangan geser, pegangan ubah ukuran, bar kontrol (Mulai/Jeda, Awal, kecepatan, Tutup) saat kursor di atas overlay, pratinjau di tab Tampilan.
- Pintasan keyboard yang dapat dikonfigurasi (dengan deteksi bentrok), kecepatan gulir dari keyboard.
- Lapisan kompatibilitas: pilihan backend Qt yang dapat diuji, tabel kemampuan overlay per backend, diagnostik yang diperluas (`--diagnostics`).
- AI: uji koneksi (tanpa mengirim naskah), batas waktu yang dapat diatur, klasifikasi error (autentikasi, kuota/Retry-After, model tidak ditemukan, server), tugas “formal”, “santai”, dan “sesuaikan durasi”, konfirmasi tujuan pengiriman per layanan.
- Drive: pilihan remote bertipe, pencarian per folder dengan penyaring, pembatalan, progres.
- Logging dengan penyamaran rahasia ke `~/.local/state/tama-prompter/`.
- Suite tes otomatis (unit, integrasi dengan server/rclone palsu lokal, GUI offscreen), CI GitHub Actions (belum dijalankan), skrip build `.deb` yang reproducible.

### Diubah
- Lokasi data: pengaturan kini JSON di `~/.config/tama-prompter/`, naskah di `~/.local/share/tama-prompter/` (sebelumnya satu berkas QSettings `~/.config/TamaAndrea/TamaPrompter.conf`).
- Pintasan bawaan baru: `Ctrl+R` kembali ke atas, `Alt+Up`/`Alt+Down` kecepatan (kombinasi `Ctrl+Home/Up/Down` bentrok dengan editor).
- Pilihan konfirmasi privasi AI kini per host, bukan satu persetujuan global.

### Catatan peningkatan dari 0.3.0
Saat pertama dijalankan, pengaturan dan naskah terakhir diimpor otomatis. Berkas lama tidak diubah atau dihapus; hapus sendiri `~/.config/TamaAndrea/` setelah yakin (berkas itu menyimpan naskah terakhir tanpa enkripsi).

## [0.3.0 Beta]
Prototipe dasar (tidak ada riwayat perubahan terperinci pada materi yang diterima).
