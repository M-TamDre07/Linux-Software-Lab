"""Where people can support the author. Single source of truth for the UI and docs.

Support is voluntary: nothing in Sorot is locked behind it, nothing nags, and no
network request is made unless the user clicks a button.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from urllib.parse import urlparse

from sorot import AUTHOR

SAWERIA_URL = "https://saweria.co/tamaandrea"
GOPAY_NUMBER = "081274852534"  # Indonesian mobile number registered with GoPay


def normalize_id_phone(raw: str) -> str:
    """Return an Indonesian mobile number in national form (``08…``).

    Accepts ``+62 812…``, ``62812…``, ``0812…`` and ``812…``; raises ``ValueError``
    for anything that is not a plausible mobile number (9–13 digits after the ``0``).
    """
    digits = re.sub(r"\D", "", raw or "")
    if digits.startswith("62"):
        digits = digits[2:]
    digits = digits.lstrip("0")
    if not re.fullmatch(r"8\d{8,11}", digits):
        raise ValueError("nomor ponsel Indonesia tidak valid")
    return "0" + digits


def format_id_phone(number: str) -> str:
    """``081274852534`` -> ``0812-7485-2534``."""
    national = normalize_id_phone(number)
    return f"{national[:4]}-{national[4:8]}-{national[8:]}"


def international_id_phone(number: str) -> str:
    national = normalize_id_phone(number)
    return f"+62 {national[1:4]}-{national[4:8]}-{national[8:]}"


@dataclass(frozen=True)
class SupportInfo:
    author: str
    saweria_url: str
    gopay_number: str

    @property
    def gopay_display(self) -> str:
        return format_id_phone(self.gopay_number)

    @property
    def gopay_international(self) -> str:
        return international_id_phone(self.gopay_number)

    def validate(self) -> None:
        parsed = urlparse(self.saweria_url)
        if parsed.scheme != "https" or not parsed.netloc:
            raise ValueError("tautan dukungan harus memakai https")
        normalize_id_phone(self.gopay_number)


def support_info() -> SupportInfo:
    info = SupportInfo(AUTHOR, SAWERIA_URL, GOPAY_NUMBER)
    info.validate()
    return info


INTRO = (
    "Sorot gratis dan bebas dipakai. Jika aplikasi ini bermanfaat bagimu, dukunganmu membantu pemeliharaan, "
    "perbaikan bug, dan pengembangan fitur berikutnya."
)
PROMISE = (
    "Dukungan bersifat sukarela. Tidak ada fitur yang dikunci, tidak ada pop-up yang mengganggu, dan tidak ada pelacakan. "
    "Aplikasi tidak menghubungi siapa pun sampai kamu menekan tombol di bawah."
)
