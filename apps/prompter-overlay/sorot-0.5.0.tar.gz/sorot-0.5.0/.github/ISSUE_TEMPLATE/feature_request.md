---
name: Permintaan fitur
about: Usulkan peningkatan
labels: enhancement
---

**Masalah yang ingin diselesaikan**

**Usulan**

**Alternatif yang sudah dipertimbangkan**

**Apakah fitur ini bergantung pada compositor/desktop tertentu?**
