---
name: Laporan bug
about: Sesuatu tidak bekerja seperti seharusnya
labels: bug
---

**Apa yang terjadi?**

**Apa yang kamu harapkan?**

**Langkah reproduksi**
1.
2.

**Lingkungan** (tempel keluaran `sorot --diagnostics` setelah memeriksa isinya)

```
```

**Backend Qt yang dicoba** (otomatis / xcb / wayland) dan hasilnya:

**Log** (opsional; `~/.local/state/sorot/sorot.log`, periksa dulu agar tidak memuat data pribadi)

> Jangan melampirkan naskah pribadi atau API key.
