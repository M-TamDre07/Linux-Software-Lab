# Kebijakan keamanan

## Versi yang didukung
Hanya rilis beta terbaru.

## Melaporkan kerentanan
Repositori publik: https://github.com/M-TamDre07/Linux-Software-Lab (Sorot ada di `apps/sorot/`). Untuk kerentanan, jangan membuka isu publik; kirim email ke **muhammadandreatama@outlook.com**, atau gunakan *Private vulnerability reporting* GitHub bila pengelola sudah mengaktifkannya di tab Security repositori. Kirim email dengan judul “Sorot security” yang berisi **ringkasan, versi, dan dampak saja**; rincian eksploit sebaiknya dikirim setelah ada balasan yang menyepakati saluran yang lebih aman. Jangan melampirkan naskah pribadi atau API key. Tidak ada jaminan waktu tanggapan tertulis untuk proyek beta ini.

## Model ancaman singkat
- Naskah dan pengaturan disimpan lokal (`~/.local/share/sorot`, `~/.config/sorot`) dengan izin berkas `0600`; tidak dienkripsi.
- API key tidak pernah ditulis ke berkas pengaturan, draf, atau log. Penyimpanan permanen hanya lewat keyring sistem yang dianggap aman; selain itu hanya di memori sesi (atau variabel `SOROT_API_KEY`).
- Permintaan AI hanya dikirim atas tindakan pengguna ke URL yang dikonfigurasi pengguna. HTTP polos hanya diterima untuk localhost; pengalihan (redirect) ditolak.
- rclone dijalankan tanpa shell, dengan argumen tervalidasi; aplikasi tidak menghapus berkas Drive.
- Tidak ada telemetri.
- Log memuat penyamaran pola rahasia umum sebagai lapis kedua; aplikasi sendiri tidak mencatat isi naskah atau key.
- Ekstensi kode berjalan di proses terpisah dengan izin akunmu. Itu melindungi stabilitas, **bukan keamanan** (bukan sandbox). Ekstensi baru tidak berjalan sebelum disetujui eksplisit; persetujuan terikat pada hash berkas dan dicabut jika kode berubah; lingkungan proses dibersihkan dari variabel rahasia. Lihat [docs/EXTENSIONS.md](docs/EXTENSIONS.md).
- Pemasang ekstensi menolak zip-slip, tautan simbolik, dan arsip raksasa.
- Cadangan (`sorot --backup`, cadangan otomatis) berisi naskah dan pengaturan **tanpa enkripsi** dengan izin `0600`; tidak memuat API key. Pemulihan memeriksa hash SHA-256 tiap berkas dan menolak nama berkas yang keluar dari folder data (path traversal, tautan simbolik). Hash melindungi dari kerusakan dan perubahan tidak sengaja, **bukan** dari penyerang yang dapat menulis ulang seluruh arsip beserta manifestnya; perlakukan cadangan dari sumber yang tidak dipercaya seperti ekstensi.
