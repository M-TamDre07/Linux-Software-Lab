"""SIGTERM/SIGHUP/SIGINT must close the real application cleanly (save, release the lock, exit 0)."""
from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import pytest

SRC = Path(__file__).resolve().parents[1] / "src"
pytestmark = pytest.mark.skipif(sys.platform == "win32", reason="POSIX signals")


def _env(root: Path) -> dict[str, str]:
    run = root / "run"
    run.mkdir(parents=True, exist_ok=True)
    run.chmod(0o700)
    env = {k: v for k, v in os.environ.items() if not k.startswith(("XDG_", "SOROT_"))}
    env.update(
        HOME=str(root), XDG_DATA_HOME=str(root / "d"), XDG_CONFIG_HOME=str(root / "c"),
        XDG_STATE_HOME=str(root / "s"), XDG_RUNTIME_DIR=str(run), QT_QPA_PLATFORM="offscreen",
        PYTHONPATH=str(SRC),
    )
    return env


def _wait_for(path_glob: Path, pattern: str, needle: str, timeout: float) -> bool:
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        for file in path_glob.glob(pattern):
            if needle in file.read_text(encoding="utf-8", errors="replace"):
                return True
        time.sleep(0.1)
    return False


@pytest.mark.parametrize("sig", [signal.SIGTERM, signal.SIGHUP, signal.SIGINT])
def test_a_termination_signal_closes_the_application_cleanly(tmp_path, sig):
    root = tmp_path / "appdata"
    root.mkdir()
    proc = subprocess.Popen([sys.executable, "-m", "sorot"], env=_env(root), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        assert _wait_for(root / "s", "**/*.log", "Memulai Sorot", 30), "aplikasi tidak sempat mulai"
        time.sleep(1.5)  # let the window and the signal bridge come up
        proc.send_signal(sig)
        code = proc.wait(timeout=20)
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.wait()
    assert code == 0, f"keluar dengan kode {code}"
    assert (root / "c" / "sorot" / "config.json").is_file(), "pengaturan tidak disimpan saat ditutup"
    assert _wait_for(root / "s", "**/*.log", "menutup dengan rapi", 2)
