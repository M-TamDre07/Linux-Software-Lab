"""The optional update check: strict parsing, privacy (no redirects, https only) and a real local server."""
from __future__ import annotations

import http.server
import json
import threading

import pytest

from sorot import __version__
from sorot.services import update_service as us

GOOD = {"schema": 1, "name": "sorot", "version": "9.9.9", "date": "2030-01-02", "notes": "Baru.", "page": "https://example.com/rilis",
        "files": {"sorot_9.9.9_all.deb": {"url": "https://example.com/a.deb", "sha256": "a" * 64}}}


def enc(doc):
    return json.dumps(doc).encode()


def test_good_manifest_parses_and_compares():
    info = us.parse_manifest(enc(GOOD))
    assert info.version == "9.9.9" and info.files["sorot_9.9.9_all.deb"][1] == "a" * 64
    assert info.is_newer_than("0.7.3") and not info.is_newer_than("9.9.9") and not info.is_newer_than("10.0.0")


@pytest.mark.parametrize("a,b,newer", [("0.8.0", "0.7.3 Beta", True), ("0.10.0", "0.9.9", True), ("1.0.0", "0.99.99", True), ("0.7.3", "0.7.3", False), ("junk", "0.7.3", False)])
def test_version_comparison_is_numeric_not_textual(a, b, newer):
    assert (us.version_key(a) > us.version_key(b)) is newer


@pytest.mark.parametrize("mutate", [
    lambda d: d.update(schema=2), lambda d: d.update(name="lain"), lambda d: d.update(version="1.0"), lambda d: d.update(version="1.0.0; rm"),
    lambda d: d.update(date="kemarin"), lambda d: d.update(notes=5), lambda d: d.update(page="http://example.com/x"), lambda d: d.update(page="javascript:alert(1)"),
    lambda d: d.update(page="file:///etc/passwd"), lambda d: d["files"].update({"../x": {"url": "https://e.com/x", "sha256": "a" * 64}}),
    lambda d: d["files"]["sorot_9.9.9_all.deb"].update(sha256="xyz"), lambda d: d["files"]["sorot_9.9.9_all.deb"].update(url="ftp://e.com/a"),
    lambda d: d.update(files=[1]),
])
def test_invalid_manifests_are_rejected(mutate):
    doc = json.loads(json.dumps(GOOD))
    mutate(doc)
    with pytest.raises(us.UpdateError):
        us.parse_manifest(enc(doc))


@pytest.mark.parametrize("data", [b"", b"[]", b"null", b"\xff\xfe", b"{" * 10, b"x" * 70_000])
def test_garbage_is_an_error_not_a_crash(data):
    with pytest.raises(us.UpdateError):
        us.parse_manifest(data)


class _Handler(http.server.BaseHTTPRequestHandler):
    seen: list[dict] = []

    def do_GET(self):  # noqa: N802
        _Handler.seen.append({"path": self.path, "headers": dict(self.headers)})
        if self.path == "/latest.json":
            body = enc(GOOD)
            self.send_response(200)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/redir":
            self.send_response(302)
            self.send_header("Location", "https://example.com/evil")
            self.end_headers()
        elif self.path == "/huge":
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"x" * 200_000)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, *args):
        pass


@pytest.fixture
def server():
    httpd = http.server.HTTPServer(("127.0.0.1", 0), _Handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    _Handler.seen.clear()
    yield f"http://127.0.0.1:{httpd.server_port}"
    httpd.shutdown()


def test_real_fetch_sends_only_a_generic_user_agent(server):
    info = us.check_for_update(lambda: us.fetch_manifest(server + "/latest.json"))
    assert info.version == "9.9.9"
    headers = {k.lower(): v for k, v in _Handler.seen[0]["headers"].items()}
    assert headers["user-agent"] == f"Sorot/{__version__}"
    assert not {"cookie", "authorization", "referer"} & set(headers)


def test_redirects_missing_files_and_huge_answers_are_refused(server):
    with pytest.raises(us.UpdateError, match="galat 302"):
        us.fetch_manifest(server + "/redir")
    with pytest.raises(us.UpdateError, match="Belum ada"):
        us.fetch_manifest(server + "/nope")
    with pytest.raises(us.UpdateError, match="terlalu besar"):
        us.check_for_update(lambda: us.fetch_manifest(server + "/huge"))


def test_remote_plain_http_and_unreachable_servers_are_refused():
    with pytest.raises(us.UpdateError, match="HTTPS"):
        us.fetch_manifest("http://example.com/latest.json")
    with pytest.raises(us.UpdateError, match="Tidak dapat menghubungi"):
        us.fetch_manifest("http://127.0.0.1:9/latest.json")


def test_default_url_points_at_the_project_repository():
    assert us.DEFAULT_MANIFEST_URL == "https://raw.githubusercontent.com/M-TamDre07/Linux-Software-Lab/main/apps/sorot/latest.json"


def test_nothing_in_the_package_contacts_the_update_server_on_its_own():
    """The check must stay opt-in: only the menu action may import-and-call it."""
    import pathlib
    import re

    root = pathlib.Path(us.__file__).resolve().parents[1]
    callers = [p.name for p in root.rglob("*.py") if re.search(r"check_for_update\(|fetch_manifest\(", p.read_text(encoding="utf-8")) and p.name != "update_service.py"]
    assert callers == ["main_window.py"], callers
