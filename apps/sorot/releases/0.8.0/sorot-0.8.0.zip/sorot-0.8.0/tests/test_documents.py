"""Opening scripts from Word, OpenDocument, RTF, HTML, PDF and odd encodings, including hostile files."""
from __future__ import annotations

import zipfile

import pytest

from sorot.core.documents import LoadedScript, is_supported, load_script_file
from sorot.core.fileio import ScriptFileError

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"


def docx(path, paragraphs, *, doctype=""):
    body = "".join(f"<w:p><w:r><w:t xml:space=\"preserve\">{p}</w:t></w:r></w:p>" for p in paragraphs)
    xml = f'<?xml version="1.0" encoding="UTF-8"?>{doctype}<w:document xmlns:w="{W}"><w:body>{body}</w:body></w:document>'
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", "<Types/>")
        zf.writestr("word/document.xml", xml)
    return path


def test_docx_paragraphs_tabs_and_breaks(tmp_path):
    path = tmp_path / "a.docx"
    xml = (f'<w:document xmlns:w="{W}"><w:body><w:p><w:r><w:t>Halo</w:t></w:r><w:r><w:tab/></w:r><w:r><w:t>dunia</w:t></w:r></w:p>'
           f'<w:p><w:r><w:t>Baris</w:t><w:br/><w:t>dua ✓</w:t></w:r></w:p></w:body></w:document>')
    with zipfile.ZipFile(path, "w") as zf:
        zf.writestr("word/document.xml", xml)
    loaded = load_script_file(path)
    assert loaded.text == "Halo\tdunia\nBaris\ndua ✓\n" and loaded.format == "docx" and loaded.converted
    assert any("Simpan sebagai berkas baru" in n for n in loaded.notes)


def test_odt(tmp_path):
    path = tmp_path / "a.odt"
    xml = ('<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0">'
           '<office:body><office:text><text:h>Judul</text:h><text:p>Satu<text:s text:c="3"/>dua<text:line-break/>tiga <text:span>tebal</text:span></text:p></office:text></office:body></office:document-content>')
    with zipfile.ZipFile(path, "w") as zf:
        zf.writestr("content.xml", xml)
    assert load_script_file(path).text == "Judul\nSatu   dua\ntiga tebal\n"


def test_rtf_groups_unicode_and_escapes(tmp_path):
    path = tmp_path / "a.rtf"
    path.write_bytes(rb"{\rtf1\ansi{\fonttbl{\f0 Arial;}}{\*\generator Word;}\pard Halo \b dunia\b0\par Caf\'e9 \u8212? ok \{x\}\par}")
    assert load_script_file(path).text == "Halo dunia\nCafé — ok {x}\n"


def test_html_ignores_scripts_and_decodes_entities(tmp_path):
    path = tmp_path / "a.html"
    path.write_text("<html><head><title>x</title><style>p{}</style></head><body><h1>Judul</h1><p>A &amp; B</p><script>alert(1)</script><p>Dua<br>baris</p></body></html>", encoding="utf-8")
    assert load_script_file(path).text == "Judul\n\nA & B\n\nDua\nbaris\n"  # paragraphs stay separated by a blank line


def test_pdf_text(tmp_path):
    pytest.importorskip("pypdf")
    stream = b"BT /F1 18 Tf 72 700 Td (Halo dari PDF) Tj ET"
    objects = [b"<< /Type /Catalog /Pages 2 0 R >>", b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
               b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
               b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream", b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"]
    out, offsets = bytearray(b"%PDF-1.4\n"), []
    for i, body in enumerate(objects, 1):
        offsets.append(len(out))
        out += b"%d 0 obj\n" % i + body + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objects) + 1) + b"".join(b"%010d 00000 n \n" % o for o in offsets)
    out += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objects) + 1, xref)
    path = tmp_path / "a.pdf"
    path.write_bytes(bytes(out))
    assert "Halo dari PDF" in load_script_file(path).text


def test_pdf_without_pypdf_explains_how_to_install(tmp_path, monkeypatch):
    import builtins
    real = builtins.__import__
    monkeypatch.setattr(builtins, "__import__", lambda name, *a, **k: (_ for _ in ()).throw(ImportError("x")) if name == "pypdf" else real(name, *a, **k))
    path = tmp_path / "a.pdf"
    path.write_bytes(b"%PDF-1.4")
    with pytest.raises(ScriptFileError, match="pypdf"):
        load_script_file(path)


@pytest.mark.parametrize("data,expected,note", [
    ("halo ✓".encode("utf-8-sig"), "halo ✓", False),
    ("halo ✓".encode("utf-16"), "halo ✓", True),
    ("café".encode("cp1252"), "café", True),
    (b"a\r\nb\rc\n\n\n\n\nd\n", "a\nb\nc\n\n\n\n\nd\n", False),  # plain text is not tidied
])
def test_text_encodings_and_line_endings(tmp_path, data, expected, note):
    path = tmp_path / "a.txt"
    path.write_bytes(data)
    loaded = load_script_file(path)
    assert loaded.text == expected and bool(loaded.notes) is note and not loaded.converted


def test_markdown_and_plain_text_are_not_marked_converted(tmp_path):
    (tmp_path / "a.md").write_text("# Judul\n", encoding="utf-8")
    assert load_script_file(tmp_path / "a.md").format == "md"


@pytest.mark.parametrize("doctype", ['<!DOCTYPE d [<!ENTITY a "aaaa">]>', "<!ENTITY x 'y'>"])
def test_xml_entity_declarations_are_refused(tmp_path, doctype):
    path = docx(tmp_path / "evil.docx", ["&a;"], doctype=doctype)
    with pytest.raises(ScriptFileError, match="DOCTYPE|ENTITY"):
        load_script_file(path)


def test_zip_bomb_member_is_refused_before_reading(tmp_path):
    path = tmp_path / "bomb.docx"
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("word/document.xml", b"<a>" + b"x" * 40_000_000 + b"</a>")
    assert path.stat().st_size < 1_000_000
    with pytest.raises(ScriptFileError, match="terlalu besar"):
        load_script_file(path)


@pytest.mark.parametrize("name,data", [("bad.docx", b"not a zip"), ("bad.odt", b"PK\x03\x04junk"), ("bad.rtf", b"plain text"), ("empty.docx", b""),
                                       ("bad.pdf", b"%PDF-1.4 garbage"), ("empty.txt", b"  \n\n")])
def test_broken_files_raise_a_clear_error_never_crash(tmp_path, name, data):
    path = tmp_path / name
    path.write_bytes(data)
    with pytest.raises(ScriptFileError):
        load_script_file(path)


def test_missing_and_directory_paths(tmp_path):
    with pytest.raises(ScriptFileError):
        load_script_file(tmp_path / "tidak-ada.docx")
    with pytest.raises(ScriptFileError):
        load_script_file(tmp_path)


def test_oversized_result_is_refused(tmp_path):
    path = docx(tmp_path / "big.docx", ["x" * 1000] * 6000)
    with pytest.raises(ScriptFileError, match="terlalu besar"):
        load_script_file(path)


def test_supported_suffixes():
    assert all(is_supported(f"a{s}") for s in (".TXT", ".docx", ".pdf", ".odt", ".rtf", ".html", ".md"))
    assert not is_supported("a.exe") and isinstance(LoadedScript("x", "txt"), LoadedScript)


@pytest.mark.parametrize("data", [b"\xff\xfe\xfa", b"\xfe\xff\x00", b"\xff\xfe\x00\x00\x01", b"\x00\x00\xfe\xff\xff"])
def test_a_broken_utf16_or_utf32_file_is_an_error_not_a_crash(tmp_path, data):
    path = tmp_path / "a.txt"
    path.write_bytes(data)
    with pytest.raises(ScriptFileError, match="rusak"):
        load_script_file(path)
