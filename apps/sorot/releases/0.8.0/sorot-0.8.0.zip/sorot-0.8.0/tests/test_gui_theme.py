"""Theme assets: the checkbox tick must not depend on an optional Qt image plugin."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

pytest.importorskip("PySide6")

pytestmark = pytest.mark.gui

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "src" / "sorot" / "ui" / "assets"

_PROBE = """
import re, sys
from PySide6.QtCore import QCoreApplication
from PySide6.QtGui import QImageReader
from PySide6.QtWidgets import QApplication, QCheckBox
sys.path.insert(0, sys.argv[2])
QCoreApplication.setLibraryPaths([sys.argv[1]])
app = QApplication([])
from sorot.ui import theme
assert b"svg" not in QImageReader.supportedImageFormats(), "the SVG plugin should be absent in this probe"
palette = theme.LIGHT if sys.argv[3] == "light" else theme.DARK


def render(sheet):
    app.setStyleSheet(sheet)
    box = QCheckBox()
    box.setChecked(True)
    box.resize(30, 30)
    box.show()
    app.processEvents()
    image = box.grab().toImage()
    box.close()
    return image


full = theme.build_stylesheet(palette)
assert "image: url(" in full
bare = re.sub(r"image: url\\([^)]*\\);", "", full)
with_tick, without_tick = render(full), render(bare)
print(sum(1 for y in range(30) for x in range(30) if with_tick.pixel(x, y) != without_tick.pixel(x, y)))
"""


def _plugins_without_svg(tmp_path: Path) -> Path:
    import PySide6

    source = Path(PySide6.__file__).parent / "Qt" / "plugins"
    if not (source / "imageformats").is_dir() or not (source / "platforms").is_dir():
        pytest.skip("PySide6 de distro memakai tata letak plugin lain; pengujian tanpa plugin SVG dilewati")
    target = tmp_path / "plugins"
    (target / "imageformats").mkdir(parents=True)
    for plugin in (source / "imageformats").iterdir():
        if "svg" not in plugin.name.lower():
            shutil.copy2(plugin, target / "imageformats" / plugin.name)
    shutil.copytree(source / "platforms", target / "platforms")
    return target


@pytest.mark.parametrize("tone", ["dark", "light"])
def test_checked_box_shows_its_tick_even_without_the_qt_svg_plugin(tmp_path, tone):
    """Regression (0.7.0): the tick was an SVG; without libqsvg it vanished and a checked box looked like a plain filled square."""
    plugins = _plugins_without_svg(tmp_path)
    env = {**os.environ, "QT_QPA_PLATFORM": "offscreen"}
    run = subprocess.run([sys.executable, "-I", "-c", _PROBE, str(plugins), str(ROOT / "src"), tone], capture_output=True, text=True, env=env, timeout=60)
    assert run.returncode == 0, run.stderr
    tick_pixels = int(run.stdout.strip().splitlines()[-1])
    # Pixels that differ between the full style sheet and the same sheet without its ``image:`` rule are the tick itself.
    assert tick_pixels > 10, f"tanda centang tidak tergambar ({tick_pixels} piksel)"


def test_theme_icons_are_png_and_have_hidpi_variants():
    from PySide6.QtGui import QImage

    from sorot.ui import theme

    for palette in (theme.DARK, theme.LIGHT):
        path = Path(theme._check_icon(palette))
        assert path.suffix == ".png" and path.is_file()
        one, two = QImage(str(path)), QImage(str(path.with_name(path.stem + "@2x.png")))
        assert not one.isNull() and not two.isNull()
        assert (two.width(), two.height()) == (one.width() * 2, one.height() * 2)
    assert 'url("' in theme.build_stylesheet(theme.DARK) and ".svg" not in theme.build_stylesheet(theme.DARK)
