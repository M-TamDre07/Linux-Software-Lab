"""The signed apt repository: apt must accept the genuine one and refuse a tampered index or a wrong key."""
from __future__ import annotations

import gzip
import os
import shutil
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ("apt-get", "apt-ftparchive", "gpg", "dpkg-deb")
pytestmark = pytest.mark.skipif(any(shutil.which(t) is None for t in TOOLS), reason="needs apt, apt-utils, gnupg, dpkg")


def _run(cmd, env=None, check=True):
    return subprocess.run(cmd, env=env, capture_output=True, text=True, check=check, timeout=120)


def _key(home: Path, name: str) -> str:
    home.mkdir(mode=0o700)
    env = {**os.environ, "GNUPGHOME": str(home)}
    _run(["gpg", "--batch", "--pinentry-mode", "loopback", "--passphrase", "", "--quick-gen-key", f"{name} <t@example.com>", "ed25519", "sign", "never"], env)
    out = _run(["gpg", "--batch", "--with-colons", "--fingerprint", name], env).stdout
    return next(line.split(":")[9] for line in out.splitlines() if line.startswith("fpr:"))


def _fake_deb(folder: Path) -> None:
    tree = folder / "tree"
    (tree / "DEBIAN").mkdir(parents=True)
    (tree / "DEBIAN" / "control").write_text("Package: sorot\nVersion: 9.9.9\nArchitecture: all\nMaintainer: Uji <t@example.com>\nDescription: uji\n", encoding="utf-8")
    _run(["dpkg-deb", "--root-owner-group", "-b", str(tree), str(folder / "sorot_9.9.9_all.deb")])


def _apt_update(base: Path, source_text: str) -> subprocess.CompletedProcess:
    (base / "src.d").mkdir(parents=True)
    (base / "state" / "lists" / "partial").mkdir(parents=True)
    (base / "cache" / "archives" / "partial").mkdir(parents=True)
    (base / "src.d" / "sorot.sources").write_text(source_text, encoding="utf-8")
    return _run(["apt-get", "-o", "Dir::Etc::sourcelist=/dev/null", "-o", f"Dir::Etc::sourceparts={base / 'src.d'}", "-o", f"Dir::State={base / 'state'}",
                 "-o", f"Dir::Cache={base / 'cache'}", "-o", "Dir::Etc::trusted=/dev/null", "-o", "Dir::Etc::trustedparts=/dev/null",
                 "-o", "APT::Sandbox::User=root", "update"], check=False)


def test_apt_accepts_the_genuine_repository_and_rejects_tampering_and_wrong_keys(tmp_path):
    tmp_path.chmod(0o755)
    fingerprint = _key(tmp_path / "gnupg", "Sorot Uji")
    env = {**os.environ, "GNUPGHOME": str(tmp_path / "gnupg")}
    debs = tmp_path / "debs"
    debs.mkdir()
    _fake_deb(debs)
    repo = tmp_path / "repo"
    result = _run(["bash", str(ROOT / "scripts" / "make-apt-repo.sh"), "--key", fingerprint, "--url", f"file://{repo}", "--debs", str(debs), "--out", str(repo)], env)
    assert fingerprint in result.stdout
    assert (repo / "dists/stable/InRelease").is_file() and (repo / "sorot-archive-keyring.asc").is_file()
    assert fingerprint in (repo / "PASANG.txt").read_text(encoding="utf-8")

    def source(uri: Path, key: Path) -> str:
        return f"Types: deb\nURIs: file://{uri}\nSuites: stable\nComponents: main\nSigned-By: {key}\n"

    good = _apt_update(tmp_path / "ok", source(repo, repo / "sorot-archive-keyring.asc"))
    assert good.returncode == 0, good.stderr
    policy = _run(["apt-cache", "-o", f"Dir::Etc::sourceparts={tmp_path / 'ok' / 'src.d'}", "-o", "Dir::Etc::sourcelist=/dev/null",
                   "-o", f"Dir::State={tmp_path / 'ok' / 'state'}", "-o", f"Dir::Cache={tmp_path / 'ok' / 'cache'}", "policy", "sorot"]).stdout
    assert "Candidate: 9.9.9" in policy

    evil = tmp_path / "evil"
    shutil.copytree(repo, evil)
    index = evil / "dists/stable/main/binary-all/Packages"
    original = index.read_text(encoding="utf-8")
    forged = original.replace("Maintainer: Uji", "Maintainer: Penyerang")
    assert forged != original, "tes hampa: indeks tidak berubah"
    index.write_text(forged, encoding="utf-8")
    with gzip.open(evil / "dists/stable/main/binary-all/Packages.gz", "wt", encoding="utf-8") as handle:  # apt may fetch either form
        handle.write(forged)
    assert _apt_update(tmp_path / "evil-client", source(evil, repo / "sorot-archive-keyring.asc")).returncode != 0

    other = _key(tmp_path / "gnupg2", "Orang Lain")
    stranger = _run(["gpg", "--armor", "--export", other], {**os.environ, "GNUPGHOME": str(tmp_path / "gnupg2")}).stdout
    (tmp_path / "other.asc").write_text(stranger, encoding="utf-8")
    refused = _apt_update(tmp_path / "wrong-key", source(repo, tmp_path / "other.asc"))
    assert refused.returncode != 0 and "not signed" in refused.stderr
