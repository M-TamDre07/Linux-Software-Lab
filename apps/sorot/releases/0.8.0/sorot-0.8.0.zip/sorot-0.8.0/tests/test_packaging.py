"""Release consistency and packaging: what ships must agree with itself and contain what the app needs."""
from __future__ import annotations

import gzip
import hashlib
import importlib.util
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
CONTACT = "muhammadandreatama@outlook.com"
VER = re.search(r'__version__ = "([^"]+)"', (ROOT / "src/sorot/__init__.py").read_text(encoding="utf-8")).group(1)
_DATE_FILE = ROOT / "packaging" / "RELEASE_DATE"
DATE = _DATE_FILE.read_text(encoding="utf-8").strip() if _DATE_FILE.is_file() else ""
OLDER = "0.0.1"
_IGNORE = shutil.ignore_patterns(".git", "dist", "build", "__pycache__", ".venv", ".pytest_cache", ".mypy_cache", ".ruff_cache", "*.egg-info")


def _load_release():
    path = ROOT / "scripts" / "release.py"
    if not path.is_file():
        pytest.skip("scripts/release.py tidak ada (bukan pohon sumber lengkap)")
    spec = importlib.util.spec_from_file_location("sorot_release_tool", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _copy_tree(tmp_path: Path) -> Path:
    target = tmp_path / "tree"
    shutil.copytree(ROOT, target, ignore=_IGNORE)
    return target


def _edit(root: Path, rel: str, old: str, new: str) -> None:
    path = root / rel
    text = path.read_text(encoding="utf-8")
    assert old in text, f"{rel}: pola uji tidak ditemukan"
    path.write_text(text.replace(old, new, 1), encoding="utf-8")


def _render_pkgbuild(release, version: str = "9.9.9", sha: str = "a" * 64) -> str:
    template = (ROOT / "packaging" / "arch" / "PKGBUILD.in").read_text(encoding="utf-8")
    return template.replace("@VERSION@", version).replace("@SHA256@", sha)


# --------------------------------------------------------------------------- consistency
def test_release_files_agree_with_each_other():
    release = _load_release()
    assert release.check(ROOT) == []


@pytest.mark.parametrize(("rel", "old", "new", "expect"), [
    ("src/sorot/__init__.py", f'VERSION_LABEL = "{VER} Beta"', f'VERSION_LABEL = "{OLDER} Beta"', "VERSION_LABEL"),
    ("packaging/RELEASE_DATE", DATE, "kemarin", "RELEASE_DATE"),
    ("CHANGELOG.md", f"## [{VER} Beta] — {DATE}", f"## [{OLDER} Beta] — {DATE}", "CHANGELOG.md"),
    ("packaging/debian-changelog", f"sorot ({VER}) stable", f"sorot ({OLDER}) stable", "debian-changelog"),
    ("packaging/control.in", "Muhammad Andreatama <muhammadandreatama@outlook.com>", "Muhammad Andreatama <maintainer@sorot.invalid>", "control.in"),
    ("README.md", f"sorot_{VER}_all.deb", f"sorot_{OLDER}_all.deb", "README.md"),
    ("packaging/sorot.1", '"@DATE@" "@VERSION@"', '"2026-10-26" "0.6.0"', "sorot.1"),
    ("packaging/arch/PKGBUILD.in", "pkgver=@VERSION@", f"pkgver={VER}", "PKGBUILD.in"),
    ("pyproject.toml", '"sorot.ui" = ["assets/*.png"]', '"sorot.ui" = []', "package-data"),
    # Anchored on the top entry's own heading, which always exists (a section name like "### Ditambahkan" may not).
    ("CHANGELOG.md", f"## [{VER} Beta] — {DATE}\n", f"## [{VER} Beta] — {DATE}\n\n- TODO: nanti\n", "TODO"),
    ("packaging/sorot.metainfo.xml", f'<release version="{VER}"', '<release version="0.0.1"', "metainfo"),
    ("packaging/sorot.metainfo.xml", "<project_license>MIT</project_license>", "<project_license>GPL-3.0</project_license>", "lisensi"),
])
def test_each_kind_of_drift_is_caught(tmp_path, rel, old, new, expect):
    release = _load_release()
    tree = _copy_tree(tmp_path)
    _edit(tree, rel, old, new)
    problems = release.check(tree)
    assert any(expect in problem for problem in problems), problems


def test_placeholder_addresses_anywhere_are_caught(tmp_path):
    release = _load_release()
    tree = _copy_tree(tmp_path)
    (tree / "docs" / "CATATAN.md").write_text("hubungi saya@sorot.invalid", encoding="utf-8")
    assert any("CATATAN.md" in problem and "invalid" in problem for problem in release.check(tree))


def test_an_unlisted_asset_type_is_caught(tmp_path):
    release = _load_release()
    tree = _copy_tree(tmp_path)
    (tree / "src/sorot/ui/assets/ikon.bmp").write_bytes(b"BM")
    assert any("ikon.bmp" in problem for problem in release.check(tree))


def test_bump_updates_every_mechanical_place_and_check_demands_the_changelog(tmp_path):
    release = _load_release()
    tree = _copy_tree(tmp_path)
    notes = release.bump("98.7.6", "2099-11-01", tree)
    assert any("TODO" in note for note in notes)
    assert release.package_version(tree) == "98.7.6"
    assert (tree / "packaging/RELEASE_DATE").read_text(encoding="utf-8").strip() == "2099-11-01"
    problems = release.check(tree)
    assert problems and all("TODO" in problem for problem in problems), problems  # only the unwritten changelog remains
    assert "98.7.6" in (tree / "packaging/sorot.metainfo.xml").read_text(encoding="utf-8")
    for rel in ("CHANGELOG.md", "packaging/debian-changelog", "packaging/sorot.metainfo.xml"):
        path = tree / rel
        text = path.read_text(encoding="utf-8")
        path.write_text(text.replace("TODO: tulis ringkasan perubahan", "Perbaikan kecil.").replace("TODO: write the change summary", "Small fix.").replace("TODO: ringkasan rilis", "Small fix."), encoding="utf-8")
    assert release.check(tree) == []


def test_bump_rejects_malformed_versions(tmp_path):
    release = _load_release()
    tree = _copy_tree(tmp_path)
    for bad in ("1", "1.2", "v1.2.3", "1.2.3-beta", ""):
        with pytest.raises(SystemExit):
            release.bump(bad, "2099-11-01", tree)


def test_version_cli_prints_the_single_source():
    out = subprocess.run([sys.executable, str(ROOT / "scripts" / "release.py"), "version"], capture_output=True, text=True, check=True).stdout.strip()
    sys.path.insert(0, str(ROOT / "src"))
    import sorot

    assert out == sorot.__version__


# --------------------------------------------------------------------------- Arch templates
def test_pkgbuild_renders_without_placeholders_and_parses_as_bash():
    release = _load_release()
    text = _render_pkgbuild(release)
    assert "@" not in text.replace(CONTACT, "")
    bash = shutil.which("bash")
    if bash is None:
        pytest.skip("bash tidak tersedia")
    result = subprocess.run([bash, "-n", "/dev/stdin"], input=text, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr


def test_pkgbuild_values_evaluate_the_way_srcinfo_claims(tmp_path):
    """Source the rendered PKGBUILD in bash and compare with what our .SRCINFO generator reports."""
    release = _load_release()
    bash = shutil.which("bash")
    if bash is None:
        pytest.skip("bash tidak tersedia")
    text = _render_pkgbuild(release)
    file = tmp_path / "PKGBUILD"
    file.write_text(text, encoding="utf-8")
    script = f'. "{file}"; echo "$pkgname|$pkgver|${{depends[*]}}|${{#optdepends[@]}}|${{source[0]}}|${{sha256sums[0]}}|${{arch[*]}}|${{license[*]}}"'
    out = subprocess.run([bash, "-c", script], capture_output=True, text=True, check=True).stdout.strip().split("|")
    info = release.srcinfo(text)
    assert out[0] == "sorot" and out[1] == "9.9.9"
    assert f"\tpkgver = {out[1]}" in info
    for dep in out[2].split():
        assert f"\tdepends = {dep}" in info
    assert info.count("\toptdepends = ") == int(out[3]) == 5
    assert f"\tsource = {out[4]}" in info and out[4] == "sorot-9.9.9.tar.gz"
    assert f"\tsha256sums = {out[5]}" in info
    assert f"\tarch = {out[6]}" in info and f"\tlicense = {out[7]}" in info


def test_srcinfo_has_the_required_structure():
    release = _load_release()
    info = release.srcinfo(_render_pkgbuild(release))
    lines = info.splitlines()
    assert lines[0] == "pkgbase = sorot" and lines[-1] == "pkgname = sorot"
    assert all(line.startswith("\t") or not line or line.startswith(("pkgbase", "pkgname")) for line in lines)
    for needed in ("depends = python", "depends = pyside6", "makedepends = python-build", "makedepends = python-installer", "arch = any", "license = MIT"):
        assert f"\t{needed}" in lines
    assert "\toptdepends = rclone: buka dan simpan naskah di Google Drive" in lines
    assert info.endswith("\n")


def test_pkgbuild_depends_on_what_the_wheel_build_needs():
    text = (ROOT / "packaging" / "arch" / "PKGBUILD.in").read_text(encoding="utf-8")
    assert "python -m build --wheel --no-isolation" in text and "python -m installer --destdir=\"$pkgdir\"" in text
    assert "install-files.sh --layout arch" in text
    assert "-m 'not gui'" in text, "check() must not need a display"


# --------------------------------------------------------------------------- scripts and layout
def test_all_shell_scripts_parse():
    bash = shutil.which("bash")
    if bash is None:
        pytest.skip("bash tidak tersedia")
    scripts = sorted((ROOT / "scripts").glob("*.sh"))
    if not scripts:
        pytest.skip("skrip tidak ada")
    for script in scripts:
        result = subprocess.run([bash, "-n", str(script)], capture_output=True, text=True)
        assert result.returncode == 0, f"{script.name}: {result.stderr}"
    for name in ("postinst", "postrm", "prerm", "sorot.sh"):
        result = subprocess.run(["sh", "-n", str(ROOT / "packaging" / name)], capture_output=True, text=True)
        assert result.returncode == 0, f"{name}: {result.stderr}"


def _install(layout: str, dest: Path, prefix: str = "/usr") -> subprocess.CompletedProcess:
    script = ROOT / "scripts" / "install-files.sh"
    if not script.is_file() or shutil.which("bash") is None:
        pytest.skip("install-files.sh atau bash tidak tersedia")
    return subprocess.run([str(script), "--layout", layout, str(dest), prefix], capture_output=True, text=True)


@pytest.mark.parametrize("layout", ["deb", "arch", "generic"])
def test_install_files_layouts(tmp_path, layout):
    result = _install(layout, tmp_path / "pkg")
    assert result.returncode == 0, result.stderr
    usr = tmp_path / "pkg" / "usr"
    for rel in ("share/applications/sorot.desktop", "share/icons/hicolor/scalable/apps/sorot.svg", "share/man/man1/sorot.1.gz",
                "share/doc/sorot/README.md", "share/doc/sorot/docs/UPGRADING.md", "share/doc/sorot/docs/PACKAGING.md",
                "share/doc/sorot/examples/extensions/contoh.rapikan-teks/main.py", "share/sorot/extensions/README",
                "share/metainfo/sorot.metainfo.xml", "share/icons/hicolor/64x64/apps/sorot.png", "share/icons/hicolor/256x256/apps/sorot.png"):
        assert (usr / rel).is_file(), rel
    sys.path.insert(0, str(ROOT / "src"))
    import sorot

    man = gzip.decompress((usr / "share/man/man1/sorot.1.gz").read_bytes()).decode()
    assert f'"{sorot.__version__}"' in man and "@VERSION@" not in man and "@DATE@" not in man
    assert r"\-\-backup" in man and r"\-\-upgrade\-info" in man and CONTACT in man
    if layout == "deb":
        assert (usr / "share/doc/sorot/copyright").is_file() and not (usr / "share/licenses").exists()
    else:
        assert (usr / "share/licenses/sorot/LICENSE").is_file() and (usr / "share/doc/sorot/CHANGELOG.md").is_file()
        assert not (usr / "share/doc/sorot/copyright").exists()
    for path in (tmp_path / "pkg").rglob("*"):
        if path.is_file():
            assert path.stat().st_mode & 0o777 == 0o644, f"{path}: izin tidak sesuai"
    # ``home`` is the conftest's isolated HOME; the script must neither add siblings nor write into that HOME.
    assert {p.name for p in tmp_path.iterdir()} - {"home"} == {"pkg"}, "tidak boleh menulis di luar DESTDIR"
    assert not any((tmp_path / "home").rglob("*")), "tidak boleh menulis ke HOME"


def test_install_files_honours_a_custom_prefix_and_rejects_bad_arguments(tmp_path):
    assert _install("generic", tmp_path / "pkg", "/usr/local").returncode == 0
    assert (tmp_path / "pkg/usr/local/share/applications/sorot.desktop").is_file()
    assert _install("generic", tmp_path / "x", "relatif").returncode == 2
    assert _install("rpm", tmp_path / "x").returncode == 2
    assert not (tmp_path / "x").exists()


def test_desktop_entry_and_icon_names_match():
    desktop = (ROOT / "packaging" / "sorot.desktop").read_text(encoding="utf-8")
    assert "Exec=sorot" in desktop and "Icon=sorot" in desktop
    assert (ROOT / "packaging" / "sorot.svg").is_file()
    assert "StartupWMClass" not in desktop or "sorot" in desktop.lower()


def test_wheel_ships_assets_entry_point_and_no_tests(tmp_path):
    script = ROOT / "scripts" / "build-wheel.sh"
    if not script.is_file() or shutil.which("bash") is None:
        pytest.skip("build-wheel.sh atau bash tidak tersedia")
    if importlib.util.find_spec("setuptools") is None or importlib.util.find_spec("wheel") is None:
        pytest.skip("setuptools/wheel tidak terpasang")
    out = tmp_path / "out"
    result = subprocess.run([str(script), str(out)], capture_output=True, text=True)
    if result.returncode != 0 and "No matching distribution" in result.stderr:
        pytest.skip("pip tidak dapat membangun tanpa jaringan di lingkungan ini")
    assert result.returncode == 0, result.stderr
    wheel = next(out.glob("sorot-*.whl"))
    with zipfile.ZipFile(wheel) as archive:
        names = archive.namelist()
        entry = archive.read(next(n for n in names if n.endswith("entry_points.txt"))).decode()
        metadata = archive.read(next(n for n in names if n.endswith("METADATA"))).decode()
    assert {f"sorot/ui/assets/check-{tone}{scale}.png" for tone in ("dark", "light") for scale in ("", "@2x")} <= set(names)
    assert "sorot/core/upgrade.py" in names
    assert "sorot = sorot.app:main" in entry
    assert CONTACT in metadata and "License: MIT" in metadata
    assert not any(n.startswith(("tests/", "scripts/")) for n in names)


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_deb_builds_reproducibly_and_has_the_right_metadata(tmp_path):
    script = ROOT / "scripts" / "build-deb.sh"
    if not script.is_file() or shutil.which("dpkg-deb") is None or shutil.which("bash") is None:
        pytest.skip("build-deb.sh, bash atau dpkg-deb tidak tersedia")
    sys.path.insert(0, str(ROOT / "src"))
    import sorot

    first, second = tmp_path / "a", tmp_path / "b"
    for out in (first, second):
        result = subprocess.run([str(script), str(out)], capture_output=True, text=True)
        assert result.returncode == 0, result.stderr
    deb_a, deb_b = first / f"sorot_{sorot.__version__}_all.deb", second / f"sorot_{sorot.__version__}_all.deb"
    assert _sha(deb_a) == _sha(deb_b), "dua build harus identik"
    control = subprocess.run(["dpkg-deb", "-f", str(deb_a)], capture_output=True, text=True, check=True).stdout
    assert f"Version: {sorot.__version__}" in control and f"Maintainer: Muhammad Andreatama <{CONTACT}>" in control
    assert ".invalid" not in control
    listing = subprocess.run(["dpkg-deb", "-c", str(deb_a)], capture_output=True, text=True, check=True).stdout
    for needed in ("usr/lib/sorot/sorot/core/upgrade.py", "usr/lib/sorot/sorot/ui/assets/check-dark.png", "usr/lib/sorot/sorot/ui/assets/check-light@2x.png", "usr/bin/sorot",
                   "usr/share/doc/sorot/copyright", "usr/share/doc/sorot/changelog.gz", "usr/share/man/man1/sorot.1.gz",
                   "usr/share/doc/sorot/docs/UPGRADING.md"):
        assert needed in listing, needed


def test_source_archives_are_reproducible_and_exclude_junk(tmp_path):
    script = ROOT / "scripts" / "build-source.sh"
    if not script.is_file() or shutil.which("bash") is None or shutil.which("zip") is None:
        pytest.skip("build-source.sh, bash atau zip tidak tersedia")
    hashes = []
    for name in ("a", "b"):
        out = tmp_path / name
        result = subprocess.run([str(script), str(out)], capture_output=True, text=True)
        assert result.returncode == 0, result.stderr
        hashes.append({p.name: _sha(p) for p in out.iterdir()})
    assert hashes[0] == hashes[1] and len(hashes[0]) == 2
    zipped = next((tmp_path / "a").glob("*.zip"))
    with zipfile.ZipFile(zipped) as archive:
        names = archive.namelist()
    assert any(n.endswith("packaging/arch/PKGBUILD.in") for n in names)
    assert not any("__pycache__" in n or ".egg-info" in n or n.endswith(".pyc") for n in names)
    assert all(n.startswith("sorot-") for n in names)


def test_arch_build_renders_a_matching_pkgbuild_and_srcinfo(tmp_path):
    script = ROOT / "scripts" / "build-arch.sh"
    if not script.is_file() or shutil.which("bash") is None or shutil.which("zip") is None:
        pytest.skip("build-arch.sh, bash atau zip tidak tersedia")
    env = dict(os.environ, PATH=os.environ["PATH"])
    result = subprocess.run([str(script), str(tmp_path / "out")], capture_output=True, text=True, env=env)
    assert result.returncode == 0, result.stderr
    arch = tmp_path / "out" / "arch"
    sys.path.insert(0, str(ROOT / "src"))
    import sorot

    tarball = arch / f"sorot-{sorot.__version__}.tar.gz"
    assert tarball.is_file() and not list(arch.glob("*.zip"))
    pkgbuild = (arch / "PKGBUILD").read_text(encoding="utf-8")
    srcinfo = (arch / ".SRCINFO").read_text(encoding="utf-8")
    assert f"pkgver={sorot.__version__}" in pkgbuild
    assert f"'{_sha(tarball)}'" in pkgbuild, "PKGBUILD must pin the hash of the tarball sitting next to it"
    assert f"\tsha256sums = {_sha(tarball)}" in srcinfo and f"\tpkgver = {sorot.__version__}" in srcinfo
    assert "@VERSION@" not in pkgbuild and "@SHA256@" not in pkgbuild


def test_desktop_file_name_follows_flatpak_id():
    from sorot.app import desktop_file_name

    assert desktop_file_name({}) == "sorot"
    assert desktop_file_name({"FLATPAK_ID": "io.github.M_TamDre07.Sorot"}) == "io.github.M_TamDre07.Sorot"
    assert desktop_file_name({"FLATPAK_ID": "bad id; rm"}) == "sorot"


def test_flatpak_manifest_is_valid_and_pins_the_release_files(tmp_path):
    import hashlib
    import json

    run = subprocess.run(["bash", str(ROOT / "scripts" / "build-flatpak.sh"), str(tmp_path)], capture_output=True, text=True, timeout=300, env={**os.environ, "PATH": f"{Path(sys.executable).parent}:{os.environ['PATH']}"})
    assert run.returncode == 0, run.stderr
    manifest = json.loads((tmp_path / "flatpak" / "io.github.M_TamDre07.Sorot.json").read_text(encoding="utf-8"))
    assert manifest["app-id"] == "io.github.M_TamDre07.Sorot" and manifest["command"] == "sorot"
    sources = {s["path"]: s["sha256"] for s in manifest["modules"][0]["sources"]}
    assert len(sources) == 2
    for name, digest in sources.items():
        assert hashlib.sha256((tmp_path / "flatpak" / name).read_bytes()).hexdigest() == digest
    args = manifest["finish-args"]
    assert "--filesystem=host" not in args and "--filesystem=home" not in args, "izin berkas terlalu luas"
    assert "--share=network" in args  # optional AI feature; documented in docs/FLATPAK.md


def test_update_manifest_is_generated_from_real_files_and_accepted_by_the_app(tmp_path):
    import json

    spec = importlib.util.spec_from_file_location("release_tool_m", ROOT / "scripts" / "release.py")
    tool = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tool)
    version = tool.package_version(ROOT)
    deb = tmp_path / f"sorot_{version}_all.deb"
    deb.write_bytes(b"isi deb")
    doc = json.loads(tool.manifest("https://example.com/r/", tmp_path, ROOT))
    assert doc["version"] == version and doc["files"][deb.name]["sha256"] == hashlib.sha256(b"isi deb").hexdigest()
    assert doc["files"][deb.name]["url"] == f"https://example.com/r/{deb.name}"
    assert doc["notes"], "catatan rilis harus diambil dari CHANGELOG"
    with pytest.raises(SystemExit):
        tool.manifest("https://example.com/r", tmp_path / "kosong", ROOT)
