"""Shared fixtures. Every test runs against a throw-away home directory."""
from __future__ import annotations

import faulthandler
import os
import sys
from pathlib import Path

import pytest

SRC = Path(__file__).resolve().parents[1] / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))


@pytest.fixture(autouse=True)
def isolated_home(tmp_path, monkeypatch):
    """Never touch the developer's real configuration, scripts, or keyring."""
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    for name in ("XDG_CONFIG_HOME", "XDG_DATA_HOME", "XDG_STATE_HOME"):
        monkeypatch.setenv(name, str(home / name.lower()))
    monkeypatch.delenv("SOROT_API_KEY", raising=False)
    monkeypatch.delenv("SOROT_QT_PLATFORM", raising=False)
    monkeypatch.delenv("QT_QPA_PLATFORM", raising=False)
    return home


def pytest_collection_modifyitems(config, items):
    """GUI tests need PySide6 and an offscreen platform; skip cleanly when absent."""
    try:
        import PySide6  # noqa: F401
        import pytestqt  # noqa: F401
    except ImportError:
        skip = pytest.mark.skip(reason="PySide6/pytest-qt tidak terpasang")
        for item in items:
            if "gui" in item.keywords:
                item.add_marker(skip)


os.environ.setdefault("QT_QPA_PLATFORM", os.environ.get("SOROT_TEST_QPA", "offscreen"))


@pytest.fixture(autouse=True)
def hang_watchdog():
    """A modal dialog nobody answers would hang the run forever: abort with a traceback instead."""
    faulthandler.dump_traceback_later(90, exit=True)
    yield
    faulthandler.cancel_dump_traceback_later()


def skip_without_wayland_seat() -> None:
    """Keyboard focus and the clipboard need an input seat. A headless compositor (e.g. ``weston --backend=headless``)
    has none, so those tests cannot say anything there; skip with the reason rather than fail."""
    try:
        from PySide6.QtGui import QGuiApplication, QInputDevice
    except ImportError:
        return
    if QGuiApplication.platformName() == "wayland" and not any(d.type() == QInputDevice.DeviceType.Keyboard for d in QInputDevice.devices()):
        pytest.skip("compositor Wayland tanpa seat (tidak ada keyboard): fokus dan clipboard tidak dapat diuji")


@pytest.fixture(autouse=True, scope="session")
def _main_thread_gc_for_gui_tests(request):
    """GUI tests run with the same GC policy as the application (see sorot/gc_guard.py).

    Without it a worker thread (extension discovery, ...) could run an automatic collection that traverses PySide
    wrapper objects while the GUI thread deletes them: a rare, timing-dependent segfault that was seen on Wayland.
    Created lazily so non-GUI test runs never need a QApplication."""
    state: dict = {}

    def ensure() -> None:
        if "guard" in state:
            return
        qapp = request.getfixturevalue("qapp")
        from sorot.gc_guard import MainThreadGC

        state["guard"] = MainThreadGC(qapp)

    request.session._ensure_main_thread_gc = ensure  # type: ignore[attr-defined]
    yield
    guard = state.get("guard")
    if guard is not None:
        guard.stop()


@pytest.fixture(autouse=True)
def _install_main_thread_gc(request):
    if request.node.get_closest_marker("gui") is not None:
        request.session._ensure_main_thread_gc()  # type: ignore[attr-defined]
    yield
