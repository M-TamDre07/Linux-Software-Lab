"""Automatic GC must never run on a worker thread (rare PySide segfault; see sorot/gc_guard.py)."""
from __future__ import annotations

import gc
import threading
import weakref

import pytest

pytest.importorskip("PySide6")
pytest.importorskip("pytestqt")

pytestmark = pytest.mark.gui

from sorot.gc_guard import MainThreadGC  # noqa: E402


class Cyclic:
    def __init__(self) -> None:
        self.me = self


@pytest.fixture()
def guard(qapp):
    instance = MainThreadGC(qapp, interval_ms=10)
    yield instance
    instance.stop()


def test_automatic_collection_is_off_while_the_guard_is_installed(guard):
    assert not gc.isenabled()


def test_a_worker_thread_creating_garbage_triggers_no_automatic_collection(guard, qtbot):
    before = sum(stat["collections"] for stat in gc.get_stats())
    gc.set_threshold(10, 1, 1)  # would collect constantly if automatic GC were on
    try:
        def churn() -> None:
            for _ in range(20000):
                Cyclic()

        worker = threading.Thread(target=churn)
        worker.start()
        worker.join()
    finally:
        gc.set_threshold(700, 10, 10)
    assert sum(stat["collections"] for stat in gc.get_stats()) == before, "a worker thread ran a collection"


def test_the_timer_collects_cyclic_garbage_on_the_main_thread(guard, qtbot):
    seen_threads: list[int] = []
    original = gc.collect

    def spy(*args):
        seen_threads.append(threading.get_ident())
        return original(*args)

    obj = Cyclic()
    ref = weakref.ref(obj)
    del obj
    gc.collect = spy  # type: ignore[assignment]
    try:
        qtbot.waitUntil(lambda: ref() is None, timeout=2000)
    finally:
        gc.collect = original  # type: ignore[assignment]
    assert seen_threads and set(seen_threads) == {threading.main_thread().ident}


def test_collect_called_from_another_thread_is_refused_and_counted(guard):
    results: list[int] = []
    worker = threading.Thread(target=lambda: results.append(guard.collect()))
    worker.start()
    worker.join()
    assert results == [0] and guard.collections_on_other_threads == 1


def test_stop_hands_collection_back_to_python(qapp):
    session_policy = gc.isenabled()  # the test session itself runs with the guard's policy (GC off)
    gc.enable()
    try:
        instance = MainThreadGC(qapp, interval_ms=10)
        assert not gc.isenabled()
        instance.stop()
        assert gc.isenabled()
    finally:
        if not session_policy:
            gc.disable()


def test_stop_leaves_gc_off_if_it_was_already_off(qapp):
    gc.disable()
    instance = MainThreadGC(qapp, interval_ms=10)
    instance.stop()
    assert not gc.isenabled()


def test_the_real_application_start_up_installs_the_guard(tmp_path):
    """app.main must put the guard in place before the event loop runs (checked in a subprocess with a no-op event loop)."""
    import os
    import subprocess
    import sys
    from pathlib import Path

    script = (
        "import gc, sys\n"
        "from PySide6.QtWidgets import QApplication\n"
        "from sorot.gc_guard import MainThreadGC\n"
        "QApplication.exec = lambda self: print('GC_ENABLED=%s GUARDS=%d' % (gc.isenabled(), len(self.findChildren(MainThreadGC)))) or 0\n"
        "from sorot import app\n"
        "raise SystemExit(app.main(['--allow-multiple']))\n"
    )
    home = tmp_path / "appdata"  # the autouse isolated_home fixture already owns tmp_path/home
    home.mkdir()
    env = {**os.environ, "HOME": str(home), "XDG_CONFIG_HOME": str(home / "c"), "XDG_DATA_HOME": str(home / "d"),
           "XDG_STATE_HOME": str(home / "s"), "QT_QPA_PLATFORM": "offscreen"}
    src = Path(__file__).resolve().parents[1] / "src"
    run = subprocess.run([sys.executable, "-I", "-c", f"import sys; sys.path.insert(0, {str(src)!r})\n" + script],
                         capture_output=True, text=True, env=env, timeout=60)
    assert "GC_ENABLED=False GUARDS=1" in run.stdout, run.stdout + run.stderr
