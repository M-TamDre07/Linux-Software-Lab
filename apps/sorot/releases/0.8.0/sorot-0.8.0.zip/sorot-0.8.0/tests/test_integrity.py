"""Data-integrity regressions: hostile text must never make a save fail, and backups are never partial."""
from __future__ import annotations

import json

from sorot.core.config import ConfigStore
from sorot.core.fileio import atomic_write_text, scrub_text
from sorot.core.scripts import DraftStore

LONE = "A\ud800B\udc00C"


def test_scrub_text_replaces_only_lone_surrogates():
    assert scrub_text(LONE) == "A�B�C"
    assert scrub_text("sudah baik — ✓ 😀") == "sudah baik — ✓ 😀"


def test_atomic_write_never_fails_on_unencodable_text(tmp_path):
    target = tmp_path / "x.txt"
    atomic_write_text(target, LONE)
    assert target.read_text(encoding="utf-8") in {"A?B?C", "A\ufffdB\ufffdC"}
    assert not list(tmp_path.glob(".*.tmp"))


def test_draft_with_lone_surrogates_is_saved(tmp_path):
    draft = DraftStore(tmp_path / "draft.txt")
    draft.save("halo " + LONE)
    assert draft.load().startswith("halo ")


def test_config_with_json_surrogate_escapes_loads_and_saves(tmp_path):
    path = tmp_path / "config.json"
    path.write_text(json.dumps({"schema_version": 4, "font_family": LONE, "last_directory": LONE}), encoding="utf-8")
    store = ConfigStore(path)
    loaded = store.load()
    assert "\ud800" not in loaded.config.font_family
    store.save(loaded.config)  # used to raise UnicodeEncodeError on every save
    assert json.loads(path.read_text(encoding="utf-8"))["font_family"] == loaded.config.font_family


def test_config_backup_is_a_complete_copy_and_leaves_no_temp_file(tmp_path):
    path = tmp_path / "config.json"
    store = ConfigStore(path)
    config = store.load().config
    store.save(config)
    config.font_size += 1
    store.save(config)
    assert json.loads(store.backup_path.read_text(encoding="utf-8"))["font_size"] == config.font_size - 1
    assert not list(tmp_path.glob(".*.tmp"))
