"""GUI tests against the real widgets using Qt's offscreen platform.

They exercise application logic and widget wiring. They do NOT prove behaviour
on a real GNOME/KDE compositor (always-on-top, click-through, native Wayland
placement); those remain manual checks, see docs/MANUAL-TESTING.md.
"""
from __future__ import annotations

import hashlib
import json

import pytest

pytest.importorskip("PySide6")
pytest.importorskip("pytestqt")

from conftest import skip_without_wayland_seat  # noqa: E402
from PySide6.QtCore import QRect, Qt, QTimer  # noqa: E402
from PySide6.QtTest import QTest  # noqa: E402
from PySide6.QtWidgets import QApplication, QFileDialog, QMessageBox, QPushButton  # noqa: E402

from sorot import __version__  # noqa: E402
from sorot.core import paths  # noqa: E402
from sorot.core.config import AppConfig, ConfigStore  # noqa: E402
from sorot.core.scripts import DraftStore, ScriptLibrary  # noqa: E402
from sorot.ui.main_window import MainWindow  # noqa: E402

pytestmark = pytest.mark.gui


def make_window(qtbot, **kwargs) -> MainWindow:
    window = MainWindow(ConfigStore(), DraftStore(), ScriptLibrary(), **kwargs)
    # A window with typed text asks "discard changes?" on close; unanswered, that modal dialog hangs teardown.
    qtbot.addWidget(window, before_close_func=lambda w: w.editor.document().setModified(False))
    window.show()
    qtbot.waitExposed(window)
    return window


def type_text(window: MainWindow, text: str) -> None:
    window.editor.insertPlainText(text)  # unlike setPlainText this marks the document modified


def choose_profile(window: MainWindow, name: str) -> None:
    """Pick a profile like a user does: change the combo, then the ``activated`` signal fires the handler."""
    index = window.profile_combo.findData(name)
    assert index > 0, f"profil {name!r} tidak ada"
    window.profile_combo.setCurrentIndex(index)
    window.profile_combo.activated.emit(index)


def click_dialog_button(label: str, delay: int = 60) -> None:
    """Press a button on whichever modal dialog appears next."""

    def press():
        modal = QApplication.activeModalWidget()
        assert modal is not None, "tidak ada dialog modal"
        for button in modal.findChildren(QPushButton):
            if button.text().replace("&", "") == label:
                button.click()
                return
        raise AssertionError(f"tombol {label!r} tidak ada: {[b.text() for b in modal.findChildren(QPushButton)]}")

    QTimer.singleShot(delay, press)


# ------------------------------------------------------------------ lifecycle
def test_window_starts_and_closes_cleanly(qtbot):
    window = make_window(qtbot)
    assert __version__ in window.windowTitle()
    window.show_overlay()
    assert window.overlay.isVisible()
    window.close()
    assert not window.overlay.isVisible()


def test_minimum_size_fits_a_1366x768_screen(qtbot):
    window = make_window(qtbot)
    hint = window.minimumSizeHint()
    assert hint.width() <= 900 and hint.height() <= 600


# ---------------------------------------------------------------- persistence
def test_settings_survive_restart(qtbot):
    first = make_window(qtbot)
    first.font_spin.setValue(44)
    first.margin_spin.setValue(30)
    first.opacity_slider.setValue(33)
    first.speed_spin.setValue(55)
    first.wpm_spin.setValue(160)
    first.text_color_btn.set_color("#123456", emit=True)
    first.align_seg.setValue("center")
    first.clickthrough_check.setChecked(True)
    first.close()
    saved = json.loads(paths.config_file().read_text())
    assert saved["font_size"] == 44 and saved["text_color"] == "#123456" and saved["click_through"] is True
    second = make_window(qtbot)
    assert second.font_spin.value() == 44 and second.margin_spin.value() == 30
    assert second.speed_spin.value() == 55 and second.wpm_spin.value() == 160
    assert second.text_color_btn.color == "#123456" and second.align_seg.value() == "center"
    assert second.clickthrough_check.isChecked()
    second.close()


def test_manual_overlay_position_is_restored_after_restart(qtbot):
    """Regression: 0.3.0 saved overlay_x/y but never loaded them."""
    ConfigStore().save(AppConfig(position="manual", overlay_x=37, overlay_y=53, overlay_width=500, overlay_height=180))
    window = make_window(qtbot)
    window.show_overlay()
    geometry = window.overlay.geometry()
    assert (geometry.x(), geometry.y(), geometry.width(), geometry.height()) == (37, 53, 500, 180)
    window.close()


def test_offscreen_manual_position_falls_back_to_a_preset(qtbot):
    ConfigStore().save(AppConfig(position="manual", overlay_x=99999, overlay_y=99999))
    window = make_window(qtbot)
    window.show_overlay()
    screen = window.overlay.screen().availableGeometry()
    assert screen.intersects(window.overlay.geometry())
    window.close()


def test_user_move_and_resize_are_remembered(qtbot):
    window = make_window(qtbot)
    window.show_overlay()
    from PySide6.QtGui import QGuiApplication

    if QGuiApplication.platformName() == "wayland":
        # A Wayland client cannot place or even read its own position: only the size is remembered and the
        # position preset is left alone (the Tampilan page says so under "Jendela overlay").
        before = window.config.position
        window.overlay.setGeometry(QRect(70, 80, 640, 210))
        qtbot.waitUntil(lambda: window.config.overlay_width == 640, timeout=3000)
        assert (window.config.overlay_width, window.config.overlay_height) == (640, 210)
        assert window.config.position == before and window.config.overlay_x is None
        window.close()
        return
    window.overlay.setGeometry(QRect(70, 80, 640, 210))
    qtbot.waitUntil(lambda: window.config.position == "manual", timeout=3000)
    assert (window.config.overlay_x, window.config.overlay_y) == (70, 80)
    assert (window.config.overlay_width, window.config.overlay_height) == (640, 210)
    assert window.width_spin.value() == 640
    window.close()


def test_draft_is_written_while_typing_for_crash_recovery(qtbot):
    window = make_window(qtbot)
    type_text(window, "Naskah penting")
    qtbot.waitUntil(lambda: DraftStore().load() == "Naskah penting", timeout=3000)
    # Simulate a crash: no closeEvent. A fresh window must see the text.
    other = make_window(qtbot)
    assert other.editor.toPlainText() == "Naskah penting"
    assert not other.editor.document().isModified()
    window.editor.document().setModified(False)  # avoid the prompt on teardown
    window.close()
    other.close()


def test_corrupt_config_does_not_prevent_startup(qtbot):
    paths.config_file().parent.mkdir(parents=True)
    paths.config_file().write_text("{rusak")
    store = ConfigStore()
    loaded = store.load()
    window = MainWindow(store, DraftStore(), ScriptLibrary(), startup_notices=loaded.notices)
    qtbot.addWidget(window)
    window.show()
    assert "rusak" in window.status_label.text()
    window.close()


# --------------------------------------------------------------------- editor
def test_stats_update_and_empty_state(qtbot):
    window = make_window(qtbot)
    assert window.stat_chars.text() == "0" and window.stat_words.text() == "0" and window.stat_time.text() == "00:00"
    type_text(window, "satu dua tiga")
    qtbot.waitUntil(lambda: window.stat_words.text() == "3", timeout=2000)
    window.editor.document().setModified(False)
    window.close()


def test_long_script_is_handled(qtbot):
    window = make_window(qtbot)
    window._replace_editor_text("kata " * 100_000, modified=False)
    assert window.stat_words.text() == "100.000"
    window.close()


def test_ai_replace_is_undoable(qtbot):
    window = make_window(qtbot)
    window._replace_editor_text("naskah asli", modified=False)
    window._apply_ai_result("replace", "hasil AI")
    assert window.editor.toPlainText() == "hasil AI"
    window.editor.undo()
    assert window.editor.toPlainText() == "naskah asli"
    window.editor.document().setModified(False)
    window.close()


def test_ai_append_keeps_original(qtbot):
    window = make_window(qtbot)
    window._replace_editor_text("awal", modified=False)
    window._apply_ai_result("append", "tambahan")
    assert window.editor.toPlainText() == "awal\n\ntambahan"
    window.editor.document().setModified(False)
    window.close()


# ------------------------------------------------------------ unsaved changes
def test_close_with_unsaved_changes_can_be_cancelled(qtbot):
    window = make_window(qtbot)
    type_text(window, "belum disimpan")
    click_dialog_button("Batal")
    window.close()
    assert window.isVisible(), "jendela harus tetap terbuka setelah Batal"
    window.editor.document().setModified(False)
    window.close()


def test_open_file_asks_before_discarding_and_respects_cancel(qtbot, tmp_path, monkeypatch):
    target = tmp_path / "lain.txt"
    target.write_text("isi lain")
    opened = []
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (opened.append(1), (str(target), ""))[1])
    window = make_window(qtbot)
    type_text(window, "perubahan saya")
    click_dialog_button("Batal")
    window.open_file()
    assert window.editor.toPlainText() == "perubahan saya" and not opened
    click_dialog_button("Lanjutkan tanpa menyimpan")
    window.open_file()
    assert window.editor.toPlainText() == "isi lain" and window.current_file == target
    assert not window.editor.document().isModified()
    window.close()


def test_discarded_text_can_be_recovered_with_undo(qtbot, tmp_path, monkeypatch):
    target = tmp_path / "lain.txt"
    target.write_text("isi lain")
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (str(target), ""))
    window = make_window(qtbot)
    type_text(window, "jangan hilang")
    click_dialog_button("Lanjutkan tanpa menyimpan")
    window.open_file()
    window.editor.undo()
    assert window.editor.toPlainText() == "jangan hilang"
    window.editor.document().setModified(False)
    window.close()


def test_save_then_close_without_prompt(qtbot, tmp_path, monkeypatch):
    target = tmp_path / "hasil.txt"
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **k: (str(target), "Berkas teks (*.txt)"))
    window = make_window(qtbot)
    type_text(window, "tersimpan ✓")
    assert window.editor.document().isModified()
    assert window.save_file() is True
    assert target.read_text(encoding="utf-8") == "tersimpan ✓"
    assert (target.stat().st_mode & 0o777) == 0o644
    window.close()
    assert not window.isVisible()


def test_save_dialog_adds_extension_by_selected_filter(qtbot, tmp_path, monkeypatch):
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **k: (str(tmp_path / "catatan"), "Markdown (*.md)"))
    window = make_window(qtbot)
    type_text(window, "# judul")
    assert window.save_file_as()
    assert (tmp_path / "catatan.md").read_text() == "# judul"
    window.close()


def test_open_invalid_utf8_shows_error_and_keeps_text(qtbot, tmp_path, monkeypatch):
    bad = tmp_path / "rusak.txt"
    bad.write_bytes(b"\xff\xfe\xfa")  # a UTF-16 marker followed by a half character
    warnings = []
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (str(bad), ""))
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: warnings.append(a[2]))
    window = make_window(qtbot)
    window._replace_editor_text("aman", modified=False)
    window.open_file()
    assert warnings and "rusak" in warnings[0]
    assert window.editor.toPlainText() == "aman"
    window.close()


def test_a_latin1_file_opens_with_a_visible_note(qtbot, tmp_path, monkeypatch):
    legacy = tmp_path / "lama.txt"
    legacy.write_bytes("café".encode("cp1252"))
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (str(legacy), ""))
    window = make_window(qtbot)
    window.open_file()
    assert window.editor.toPlainText() == "café"
    assert "Windows-1252" in window.status_label.text()


def test_library_open_replaces_text_via_signal(qtbot):
    library = ScriptLibrary()
    library.save("Pembuka", "Halo semuanya")
    window = make_window(qtbot)
    window._open_from_library("Pembuka")
    assert window.editor.toPlainText() == "Halo semuanya"
    window.close()


# --------------------------------------------------------------------- scroll
def test_scroll_start_pause_reset_and_end(qtbot):
    window = make_window(qtbot)
    window._replace_editor_text("baris panjang\n" * 40, modified=False)
    window.speed_mode_seg.setValue("pps")
    window.speed_spin.setValue(400)
    window.show_overlay()
    assert window.overlay.is_scrolling()
    bar = window.overlay.text_view.verticalScrollBar()
    qtbot.waitUntil(lambda: bar.value() > 50, timeout=4000)
    window.toggle_scroll()
    assert not window.overlay.is_scrolling()
    qtbot.waitUntil(lambda: not window.overlay.tick_timer.isActive(), timeout=2000)  # eased to a stop
    paused_at = bar.value()
    qtbot.wait(150)
    assert bar.value() == paused_at
    window.reset_scroll()
    assert bar.value() == 0
    window.toggle_scroll()
    qtbot.waitUntil(lambda: window.overlay.at_end() and not window.overlay.is_scrolling(), timeout=20000)
    assert "akhir" in window.status_label.text()
    window.toggle_scroll()  # at the end, play restarts from the top
    assert bar.value() < bar.maximum() and window.overlay.is_scrolling()
    window.close()


def test_zero_pixel_speed_explains_instead_of_silently_doing_nothing(qtbot):
    window = make_window(qtbot)
    window._replace_editor_text("ada isi naskah", modified=False)
    window.show_overlay()
    window.speed_mode_seg.setValue("pps")
    window.speed_spin.setValue(0)
    window.overlay.pause_scrolling()
    window.toggle_scroll()
    assert "Kecepatan gulir 0" in window.status_label.text()
    window.close()


def test_empty_script_cannot_scroll_and_says_so(qtbot):
    window = make_window(qtbot)
    window.show_overlay()
    window.toggle_scroll()
    assert "kosong" in window.status_label.text() and not window.overlay.is_scrolling()
    window.close()


def test_overlay_buttons_drive_the_application(qtbot):
    window = make_window(qtbot)
    window._replace_editor_text("isi naskah untuk diuji", modified=False)
    window.show_overlay()
    before = window.wpm_spin.value()
    window.overlay.faster_button.click()
    assert window.wpm_spin.value() == before + 5
    window.overlay.slower_button.click()
    assert window.wpm_spin.value() == before
    window.overlay.play_button.click()
    assert not window.overlay.is_scrolling()
    window.overlay.reset_button.click()
    window.overlay.hide_button.click()
    assert not window.overlay.isVisible()
    window.close()


def test_speed_buttons_follow_the_active_mode(qtbot):
    window = make_window(qtbot)
    window.speed_mode_seg.setValue("duration")
    window.target_spin.setValue(120)
    window.adjust_speed(+1)  # faster = shorter
    assert window.target_spin.value() == 105
    window.speed_mode_seg.setValue("pps")
    window.speed_spin.setValue(40)
    window.adjust_speed(+1)
    assert window.speed_spin.value() == 48
    window.close()


def test_default_keyboard_shortcuts_work_with_editor_focused(qtbot):
    skip_without_wayland_seat()
    window = make_window(qtbot)
    window.editor.setFocus()
    qtbot.waitUntil(window.editor.hasFocus, timeout=2000)
    QTest.keyClick(window.editor, Qt.Key.Key_Return, Qt.KeyboardModifier.ControlModifier)
    assert window.overlay.isVisible()
    QTest.keyClick(window.editor, Qt.Key.Key_Space, Qt.KeyboardModifier.ControlModifier)
    assert not window.overlay.is_scrolling()
    speed = window.wpm_spin.value()
    QTest.keyClick(window.editor, Qt.Key.Key_Up, Qt.KeyboardModifier.AltModifier)
    assert window.wpm_spin.value() == speed + 5
    QTest.keyClick(window.editor, Qt.Key.Key_Escape)
    assert not window.overlay.isVisible()
    window.close()


def test_custom_shortcut_is_applied_and_persisted(qtbot):
    skip_without_wayland_seat()
    window = make_window(qtbot)
    window.config.shortcuts["hide_overlay"] = "Ctrl+Shift+H"
    window._apply_shortcuts()
    window.show_overlay()
    window.activateWindow()
    window.editor.setFocus()
    qtbot.waitUntil(window.editor.hasFocus, timeout=2000)
    QTest.keyClick(window.editor, Qt.Key.Key_H, Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier)
    assert not window.overlay.isVisible()
    window.close()
    assert json.loads(paths.config_file().read_text())["shortcuts"]["hide_overlay"] == "Ctrl+Shift+H"


# ------------------------------------------------------------- window options
def test_click_through_and_frame_toggles_keep_geometry_and_visibility(qtbot):
    window = make_window(qtbot)
    window.show_overlay()
    before = window.overlay.geometry()
    window.clickthrough_check.setChecked(True)
    assert window.overlay.windowFlags() & Qt.WindowType.WindowTransparentForInput
    assert window.overlay.isVisible() and window.overlay.geometry() == before
    window.clickthrough_check.setChecked(False)
    window.frameless_check.setChecked(False)
    assert not (window.overlay.windowFlags() & Qt.WindowType.FramelessWindowHint)
    window.aot_check.setChecked(False)
    assert not (window.overlay.windowFlags() & Qt.WindowType.WindowStaysOnTopHint)
    assert window.overlay.windowFlags() & Qt.WindowType.WindowDoesNotAcceptFocus
    assert window.overlay.isVisible()
    window.close()


def test_preset_changes_all_three_values_and_custom_edit_returns_to_custom(qtbot):
    window = make_window(qtbot)
    window.preset_combo.setCurrentText("Terang (hitam di putih)")
    window._on_preset_chosen(0)
    assert (window.text_color_btn.color, window.bg_color_btn.color) == ("#111827", "#FFFFFF")
    window.text_color_btn.set_color("#010203", emit=True)
    assert window.preset_combo.currentText() == "Kustom"
    window.close()


def test_diagnostics_tab_reports_environment_without_secrets(qtbot, monkeypatch):
    monkeypatch.setenv("SOROT_API_KEY", "sk-jangan-bocor-1234567890")
    window = make_window(qtbot)
    window.show_diagnostics()
    report = window.report_view.toPlainText()
    assert "Diagnostik Sistem" in report and "jangan-bocor" not in report
    window.close()


def test_restore_settings_backup(qtbot, monkeypatch):
    store = ConfigStore()
    store.save(AppConfig(font_size=30))
    store.save(AppConfig(font_size=50))
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **k: QMessageBox.StandardButton.Yes)
    window = make_window(qtbot)
    assert window.font_spin.value() == 50
    window.restore_settings_backup()
    assert window.font_spin.value() == 30
    window.close()


# ------------------------------------------------------------------ migration
def test_legacy_settings_are_imported_without_touching_the_old_file(qtbot):
    from PySide6.QtCore import QSettings

    from sorot.legacy_import import import_legacy

    legacy = paths.legacy_qsettings_file()
    legacy.parent.mkdir(parents=True)
    old = QSettings(str(legacy), QSettings.Format.IniFormat)
    old.setValue("text", "Naskah dari 0.3.0")
    old.setValue("font_size", 40)
    old.setValue("text_color_name", "Hijau muda")
    old.setValue("position", "Bawah kiri")
    old.setValue("click_through", True)
    old.sync()
    digest = hashlib.sha256(legacy.read_bytes()).hexdigest()
    store, draft = ConfigStore(), DraftStore()
    config, text = import_legacy(store, draft)
    assert text == "Naskah dari 0.3.0" and draft.load() == text
    assert config.font_size == 40 and config.text_color == "#B8F7D4" and config.position == "bottom-left" and config.click_through
    assert store.load().config.font_size == 40
    assert hashlib.sha256(legacy.read_bytes()).hexdigest() == digest


def test_no_legacy_file_means_no_import():
    from sorot.legacy_import import import_legacy

    assert import_legacy(ConfigStore(), DraftStore()) is None
    assert not paths.config_file().exists()


def test_shortcut_dialog_rejects_conflicts_and_typing_keys(qtbot):
    from PySide6.QtGui import QKeySequence

    from sorot.core.config import DEFAULT_SHORTCUTS
    from sorot.ui.dialogs import ShortcutsDialog, shortcut_problem

    assert shortcut_problem("Ctrl+H") and shortcut_problem("Ctrl+S") and shortcut_problem("A") and shortcut_problem("")
    assert shortcut_problem("Ctrl+Shift+H") is None and shortcut_problem("Alt+Up") is None and shortcut_problem("F5") is None
    dialog = ShortcutsDialog(dict(DEFAULT_SHORTCUTS))
    qtbot.addWidget(dialog)
    dialog.edits["hide_overlay"].setKeySequence(QKeySequence("Ctrl+Space"))  # duplicates toggle_scroll
    dialog._accept()
    assert dialog.result() == 0 and "ganda" in dialog.error.text()
    dialog.edits["hide_overlay"].setKeySequence(QKeySequence("Ctrl+H"))
    dialog._accept()
    assert "bentrok" in dialog.error.text() and dialog.result() == 0
    dialog.edits["hide_overlay"].setKeySequence(QKeySequence("F6"))
    dialog._accept()
    assert dialog.result() == 1 and dialog.values()["hide_overlay"] == "F6"


def test_untouched_font_choice_is_not_written_to_config(qtbot):
    window = make_window(qtbot)
    window.font_spin.setValue(36)
    assert window.config.font_family == ""
    window.font_combo.activated.emit(0)
    window.font_spin.setValue(37)
    assert window.config.font_family == window.font_combo.currentFont().family()
    window.close()


def test_loading_a_draft_or_changing_theme_does_not_mark_the_script_unsaved(qtbot):
    """Regression: re-colouring the markup used to flip the document to 'modified'."""
    DraftStore().save("Naskah lama\n[jeda 2]\n// catatan")
    window = make_window(qtbot)
    assert window.editor.toPlainText().startswith("Naskah lama")
    assert not window.editor.document().isModified()
    window.theme_seg.setValue("light")
    window.theme_seg.setValue("dark")
    assert not window.editor.document().isModified()
    window.close()
    assert not window.isVisible(), "menutup tanpa perubahan tidak boleh memunculkan dialog"


# --------------------------------------------------------------------- 0.7.0 profiles and countdown
def test_choosing_a_profile_applies_it_and_updates_every_widget(qtbot):
    w = make_window(qtbot)
    index = w.profile_combo.findData("Rig cermin")
    assert index > 0
    choose_profile(w, "Rig cermin")
    assert w.config.mirror is True and w.config.profile == "Rig cermin" and w.config.start_delay == 3
    assert w.mirror_check.isChecked() and w.delay_spin.value() == 3 and w.font_spin.value() == 48
    assert w.overlay.text_view.graphicsEffect() is not None
    assert w.profile_combo.currentData() == "Rig cermin"


def test_profile_never_touches_window_or_behaviour_settings(qtbot):
    w = make_window(qtbot)
    w.width_spin.setValue(900)
    w.aot_check.setChecked(False)
    w.wpm_spin.setValue(111)
    before = (w.config.text_color, w.config.background_color)
    choose_profile(w, "Kontras tinggi")
    assert (w.config.text_color, w.config.background_color) != before, "the profile must really have been applied"
    assert (w.config.overlay_width, w.config.always_on_top, w.config.wpm) == (900, False, 111)


def test_editing_a_setting_moves_the_combo_to_custom_and_back(qtbot):
    w = make_window(qtbot)
    choose_profile(w, "Kertas terang")
    assert w.profile_combo.currentData() == "Kertas terang"
    size = w.font_spin.value()  # font_size is listed by the profile, so changing it must leave the profile
    w.font_spin.setValue(size + 2)
    assert w.profile_combo.currentData() == "" and "tidak sama" in w.profile_note.text()
    w.font_spin.setValue(size)
    assert w.profile_combo.currentData() == "Kertas terang"


def test_save_import_export_delete_profile_round_trip(qtbot, monkeypatch, tmp_path):
    from PySide6.QtWidgets import QInputDialog

    w = make_window(qtbot)
    w.font_spin.setValue(52)
    monkeypatch.setattr(QInputDialog, "getText", staticmethod(lambda *a, **k: ("Milik saya", True)))
    w._save_profile()
    assert w.profile_combo.currentData() == "Milik saya" and w.profile_delete_btn.isEnabled()
    target = tmp_path / "saya.json"
    monkeypatch.setattr(QFileDialog, "getSaveFileName", staticmethod(lambda *a, **k: (str(target), "")))
    w._export_profile()
    assert json.loads(target.read_text(encoding="utf-8"))["name"] == "Milik saya"
    monkeypatch.setattr(QMessageBox, "question", staticmethod(lambda *a, **k: QMessageBox.StandardButton.Yes))
    w._delete_profile()
    assert w.profile_combo.findData("Milik saya") == -1
    renamed = tmp_path / "impor.json"
    renamed.write_text(target.read_text(encoding="utf-8").replace("Milik saya", "Diimpor"), encoding="utf-8")
    monkeypatch.setattr(QFileDialog, "getOpenFileName", staticmethod(lambda *a, **k: (str(renamed), "")))
    w._import_profile()
    assert w.profile_combo.findData("Diimpor") > 0


def test_bad_profile_file_shows_a_warning_and_changes_nothing(qtbot, monkeypatch, tmp_path):
    w = make_window(qtbot)
    bad = tmp_path / "rusak.json"
    bad.write_text("{bukan json", encoding="utf-8")
    warned = []
    monkeypatch.setattr(QFileDialog, "getOpenFileName", staticmethod(lambda *a, **k: (str(bad), "")))
    monkeypatch.setattr(QMessageBox, "warning", staticmethod(lambda *a, **k: warned.append(a[2])))
    before = w.profile_combo.count()
    w._import_profile()
    assert warned and w.profile_combo.count() == before


def test_countdown_shows_ticks_down_and_is_cleared_when_scrolling_starts(qtbot):
    w = make_window(qtbot)
    type_text(w, "Satu dua tiga empat lima enam tujuh delapan sembilan sepuluh.\n" * 6)
    w.delay_spin.setValue(3)
    w.countdown_check.setChecked(True)
    w.show_overlay()
    assert w.overlay.countdown_label.isVisible() and w.overlay.countdown_label.text() == "3"
    w._countdown_tick()
    assert w.overlay.countdown_label.text() == "2"
    w._delayed_start()
    assert not w.overlay.countdown_label.isVisible() and not w.countdown_timer.isActive()
    w.hide_overlay()


def test_countdown_can_be_disabled_and_is_cancelled_by_hiding(qtbot):
    w = make_window(qtbot)
    type_text(w, "Satu dua tiga empat lima enam tujuh delapan sembilan sepuluh.\n" * 6)
    w.delay_spin.setValue(3)
    w.countdown_check.setChecked(False)
    w.show_overlay()
    assert not w.overlay.countdown_label.isVisible() and not w.countdown_timer.isActive()
    w.hide_overlay()
    w.countdown_check.setChecked(True)
    w.show_overlay()
    assert w.countdown_timer.isActive()
    w.hide_overlay()
    assert not w.countdown_timer.isActive() and not w.overlay.countdown_label.isVisible()


def test_no_page_scrolls_sideways_at_the_default_window_size(qtbot):
    """Regression (0.7.0): the Tampilan page needed ~1000 px, so the default 1100 px window opened with a horizontal scrollbar."""
    from PySide6.QtWidgets import QScrollArea

    w = make_window(qtbot)
    w.resize(w.config.window_width, w.config.window_height)
    for index in range(w.pages.count()):
        w.pages.setCurrentIndex(index)
        qtbot.wait(30)
        page = w.pages.currentWidget()
        areas = [page] if isinstance(page, QScrollArea) else page.findChildren(QScrollArea)
        for area in areas:
            assert area.horizontalScrollBar().maximum() == 0, f"halaman {index} ({w.nav_buttons[index].text()}) bergulir ke samping"


def test_the_requested_qt_platform_is_really_the_one_in_use(qtbot):
    """Guards the CI job that sets SOROT_TEST_QPA=xcb: without this it could silently run on offscreen."""
    import os

    from PySide6.QtGui import QGuiApplication

    wanted = os.environ.get("SOROT_TEST_QPA")
    if not wanted:
        pytest.skip("SOROT_TEST_QPA tidak diatur")
    assert QGuiApplication.platformName() == wanted


def _docx(path, text):
    import zipfile

    ns = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    with zipfile.ZipFile(path, "w") as zf:
        zf.writestr("word/document.xml", f'<w:document xmlns:w="{ns}"><w:body><w:p><w:r><w:t>{text}</w:t></w:r></w:p></w:body></w:document>')
    return path


def test_opening_a_word_file_converts_it_and_never_targets_the_original(qtbot, tmp_path, monkeypatch):
    source = _docx(tmp_path / "naskah.docx", "Halo dari Word")
    window = make_window(qtbot)
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (str(source), ""))
    window.open_file()
    assert window.editor.toPlainText().strip() == "Halo dari Word"
    assert window.current_file is None, "Simpan akan menimpa berkas Word asli"
    assert window.editor.document().isModified()
    assert "DOCX" in window.status_label.text()


def _drop(window, paths):
    from PySide6.QtCore import QMimeData, QPoint, Qt, QUrl
    from PySide6.QtGui import QDragEnterEvent, QDropEvent

    mime = QMimeData()
    mime.setUrls([QUrl.fromLocalFile(str(p)) for p in paths])
    enter = QDragEnterEvent(QPoint(5, 5), Qt.DropAction.CopyAction, mime, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
    window.dragEnterEvent(enter)
    drop = QDropEvent(QPoint(5, 5), Qt.DropAction.CopyAction, mime, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
    window.dropEvent(drop)
    return enter.isAccepted()


def test_dropping_a_supported_file_opens_it(qtbot, tmp_path):
    source = tmp_path / "a.txt"
    source.write_text("dari seret lepas", encoding="utf-8")
    window = make_window(qtbot)
    assert _drop(window, [source]) is True
    assert window.editor.toPlainText().strip() == "dari seret lepas" and window.current_file == source


def test_dropping_unsupported_or_several_files_is_ignored(qtbot, tmp_path):
    exe, one, two = tmp_path / "x.exe", tmp_path / "1.txt", tmp_path / "2.txt"
    for f in (exe, one, two):
        f.write_text("isi", encoding="utf-8")
    window = make_window(qtbot)
    before = window.editor.toPlainText()
    assert _drop(window, [exe]) is False
    assert _drop(window, [one, two]) is False
    assert window.editor.toPlainText() == before


def test_a_broken_word_file_shows_a_message_and_keeps_the_script(qtbot, tmp_path, monkeypatch):
    bad = tmp_path / "rusak.docx"
    bad.write_bytes(b"bukan zip")
    shown = []
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: shown.append(a[2]))
    window = make_window(qtbot)
    type_text(window, "naskahku")
    window._open_path(bad)
    assert shown and "valid" in shown[0]
    assert "naskahku" in window.editor.toPlainText()


def test_update_check_menu_reports_newer_same_and_failure(qtbot, monkeypatch):
    from sorot.services import update_service as us
    from sorot.ui import main_window as mw

    shown = []
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: shown.append(a[2]))

    class FakeBox:
        def __init__(self, *a, **k):
            self.texts = []
            FakeBox.last = self

        def __getattr__(self, name):  # accept every setter the dialog calls
            return lambda *a, **k: None

        def setText(self, text):  # noqa: N802
            self.texts.append(text)

        def addButton(self, label, role):  # noqa: N802
            return label

        def exec(self):
            return 0

        def clickedButton(self):  # noqa: N802
            return None

    monkeypatch.setattr(mw, "QMessageBox", type("QMB", (), {"Icon": QMessageBox.Icon, "ButtonRole": QMessageBox.ButtonRole, "information": QMessageBox.information, "warning": QMessageBox.warning, "__new__": lambda cls, *a, **k: FakeBox()}))
    window = make_window(qtbot)

    def run(doc_or_error):
        if isinstance(doc_or_error, Exception):
            monkeypatch.setattr(mw, "check_for_update", lambda: (_ for _ in ()).throw(doc_or_error))
        else:
            monkeypatch.setattr(mw, "check_for_update", lambda: us.parse_manifest(__import__("json").dumps(doc_or_error).encode()))
        window.check_for_updates()
        qtbot.waitUntil(lambda: window._update_task is not None and not window._update_task.running, timeout=5000)
        qtbot.wait(100)

    base = {"schema": 1, "name": "sorot", "date": "2030-01-01", "notes": "", "page": "https://example.com/r", "files": {}}
    run({**base, "version": "99.0.0"})
    assert "99.0.0" in FakeBox.last.texts[0] and "Pembaruan tersedia" in window.status_label.text()
    shown.clear()
    run({**base, "version": "0.0.1"})
    assert "terbaru" in window.status_label.text()
    run(us.UpdateError("Tidak dapat menghubungi server pembaruan."))
    assert "gagal" in window.status_label.text()
