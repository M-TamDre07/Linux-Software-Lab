# Kompatibilitas

Status di bawah dibedakan tegas antara **diuji otomatis**, **diharapkan** (berdasarkan dokumentasi Qt/perilaku umum), dan **BELUM DIUJI**. Tidak ada klaim kompatibilitas universal.

## Versi minimum

| Komponen | Minimum | Bukti |
|---|---|---|
| Python | 3.11 (kode memakai `StrEnum`) | Seluruh suite tes dijalankan pada Python 3.11.18 dan 3.13.18; wheel dipasang dan CLI dijalankan pada Python 3.12.3 (0.7.1). Python 3.13.5 juga **berjalan** pada laporan pengguna (0.4.0) |
| PySide6 / Qt | 6.8 (deb: `python3-pyside6.qtwidgets >= 6.8.2.1`) | Seluruh suite tes lulus pada PySide6 6.8.3 (Python 3.11) dan 6.12.0 (Python 3.13), keduanya wheel PyPI (0.7.1). Paket Debian 13 (6.8.2.1) sendiri **berjalan** pada laporan pengguna (0.4.0); suite belum dijalankan pada paket distro itu |
| Arsitektur paket | `all` (Python murni) | Benar: tidak ada kode native; dependensi PySide6 yang native ditarik lewat `Depends` |
| Platform build/uji | Ubuntu 24.04 x86_64; Qt `offscreen`, dan `xcb` pada Xvfb dengan window manager openbox | Lihat laporan tes |

## Laporan lapangan

Pengguna melaporkan (tangkapan layar tab Sistem, versi 0.4.0 / saat itu bernama Tama Prompter) aplikasi **berjalan** di **Debian GNU/Linux 13 (trixie), kernel 6.12.111+deb13-amd64, KDE Plasma, sesi Wayland, backend Qt `xcb` melalui XWayland, Python 3.13.5, PySide6 6.8.2.1**, dengan impor data 0.3.x berhasil. Ini membuktikan *peluncuran dan dependensi paket* pada konfigurasi itu. Perilaku overlay (selalu-di-atas, klik-tembus, geser/ubah ukuran) pada sesi tersebut **belum dilaporkan**.

## Desktop dan backend

| Target | Status |
|---|---|
| Debian 13, GNOME Wayland (lewat XWayland, pilihan otomatis) | **BELUM DIUJI** pada sesi nyata |
| KDE Plasma, sesi Wayland, backend xcb (XWayland) | aplikasi **berjalan**, pemasangan `.deb` dan upgrade 0.7.0→0.7.2 berhasil dengan cadangan otomatis, jendela dan dialog tampil (tangkapan layar pengguna, 0.7.2; dari situ ditemukan dan diperbaiki dialog Dukung yang terpotong). Overlay selalu-di-atas/klik-tembus/transparansi **BELUM DIUJI** secara manual |
| Wayland asli pada **weston headless** (Ubuntu 24.04, tanpa seat) | 124 tes GUI lulus (4 dilewati: fokus/clipboard); latar transparan terkomposit terbukti lewat tangkapan compositor; segfault acak ditemukan dan diperbaiki (lihat CHANGELOG). Selalu-di-atas dan posisi tidak dapat dibuktikan di sana |
| Debian 13, GNOME Wayland asli (`SOROT_QT_PLATFORM=wayland`) | **BELUM DIUJI** pada desktop nyata |
| KDE Plasma X11, Wayland asli | **BELUM DIUJI** |
| X11 dengan window manager (diuji: Xvfb + openbox, **tanpa compositor**) | Terverifikasi lewat properti jendela di X server: `_NET_WM_STATE_ABOVE` aktif, dekorasi dimatikan (Motif hints), posisi dan ukuran sama dengan yang dihitung aplikasi, *input shape* kosong saat klik-tembus aktif dan penuh saat dimatikan, seluruh 128 tes GUI lulus. **Transparansi nyata** (butuh compositor) dan desktop Xfce/Cinnamon/KDE/GNOME **BELUM DIUJI** |
| Ubuntu 24.04 | Paket `.deb` **tidak dapat dipasang** (`apt install -s` gagal: `python3-pyside6.qtwidgets` tidak ada; Ubuntu 24.04 hanya punya PySide2). Wheel dipasang di venv Python 3.12 dan `sorot --version`/`--upgrade-info` berjalan. Ubuntu rilis lebih baru dan Linux Mint: **BELUM DIUJI** |
| Fedora 40+ (`.rpm`) | RPM noarch **dibangun** dan isinya dijalankan (`sorot --version`); **BELUM dipasang** di Fedora; `rpmlint` belum dijalankan |
| Flatpak | manifes dihasilkan dan terbaca `flatpak-builder`; **BELUM dibangun** (runtime Flathub tidak terjangkau); integrasi Drive tidak tersedia di sandbox |
| Arch Linux (dan turunannya), paket dari `PKGBUILD` | **BELUM DIUJI** — `makepkg` belum pernah dijalankan; nama paket `pyside6` dan hasil `namcap` belum diverifikasi (lihat [PACKAGING.md](PACKAGING.md)) |
| Instalasi lewat wheel (pip/pipx) pada distro mana pun | Wheel dibangun, isinya diperiksa (termasuk aset PNG), dipasang di venv Ubuntu 24.04/Python 3.12 dan CLI-nya berjalan; **dijalankan** pada desktop nyata: BELUM DIUJI |

## Kemampuan overlay yang diharapkan per backend

| Kemampuan | xcb (X11/XWayland) | wayland asli |
|---|---|---|
| Transparansi latar | didukung (butuh compositing) | didukung |
| Posisi diatur aplikasi | didukung | **tidak tersedia** — compositor memutuskan; preset posisi dan pilihan monitor dapat diabaikan |
| Selalu di atas | didukung (bergantung window manager) | **terbatas** — tidak ada mekanisme standar; sebagian compositor (mis. GNOME) mengabaikannya |
| Klik-tembus | didukung (input shape) | tidak diketahui — umumnya memakai input region kosong |
| Geser / ubah ukuran | didukung | didukung via permintaan geser/ubah ukuran compositor |
| Pilih monitor | didukung | terbatas |
| Layar penuh eksklusif | overlay dapat tertutup | overlay dapat tertutup |

Aplikasi menampilkan tabel ini (berdasarkan backend aktif) di tab Sistem dan di bawah pengaturan jendela. Pada backend selain xcb/wayland semuanya ditandai “tidak diketahui”.

## Pemilihan backend

Urutan prioritas: `SOROT_QT_PLATFORM` → pengaturan tab Sistem → kebijakan otomatis.

Kebijakan otomatis: jika `QT_QPA_PLATFORM` sudah diatur pengguna, dihormati. Pada sesi Wayland dengan `DISPLAY` tersedia dan plugin xcb ada → `xcb` (XWayland, posisi lebih terkontrol). Jika xcb tidak ada tetapi plugin wayland ada → `wayland`. Selainnya Qt memilih sendiri. Jika backend yang dipilih eksplisit tidak ditemukan, aplikasi tidak memaksanya dan Qt memilih sendiri (daripada berhenti tanpa pesan).

Aplikasi tidak memasang paket, ekstensi desktop, atau driver, dan tidak mengubah pengaturan sistem.
