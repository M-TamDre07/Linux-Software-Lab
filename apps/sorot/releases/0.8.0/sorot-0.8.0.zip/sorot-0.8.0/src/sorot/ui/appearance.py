"""Shared rendering helpers so the overlay and the settings preview always match."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont, QPainter, QTextBlockFormat, QTextCursor, QTextDocument, QTextOption
from PySide6.QtWidgets import QGraphicsEffect

_ALIGNMENTS = {
    "left": Qt.AlignmentFlag.AlignLeft,
    "center": Qt.AlignmentFlag.AlignHCenter,
    "right": Qt.AlignmentFlag.AlignRight,
    "justify": Qt.AlignmentFlag.AlignJustify,
}


def panel_stylesheet(background: str, opacity_percent: int, *, rounded: bool) -> str:
    color = QColor(background)
    alpha = max(0, min(100, opacity_percent)) * 255 // 100
    radius = 14 if rounded else 0
    border = "1px solid rgba(180, 202, 238, 95)" if rounded else "none"
    return (
        "QFrame#panel {"
        f"background-color: rgba({color.red()}, {color.green()}, {color.blue()}, {alpha});"
        f"border: {border}; border-radius: {radius}px; }}"
    )


def text_stylesheet(text_color: str) -> str:
    return (
        "QTextEdit { background: transparent; border: none;"
        f"color: {text_color}; selection-background-color: rgba(71,124,250,120); }}"
    )


_WEIGHTS = {"normal": QFont.Weight.Normal, "demibold": QFont.Weight.DemiBold, "bold": QFont.Weight.Bold}


def make_font(family: str, size: int, weight: str = "demibold", letter_spacing: int = 0) -> QFont:
    """``letter_spacing`` is the percentage added to the normal spacing (0 = untouched)."""
    font = QFont(family or "Noto Sans")
    font.setPointSize(max(6, size))
    font.setWeight(_WEIGHTS.get(weight, QFont.Weight.DemiBold))
    if letter_spacing > 0:
        font.setLetterSpacing(QFont.SpacingType.PercentageSpacing, 100 + letter_spacing)
    return font


def apply_line_spacing(document: QTextDocument, percent: int) -> None:
    """Proportional line height for every block (100 = the font's natural height). Re-apply after ``setPlainText``."""
    cursor = QTextCursor(document)
    cursor.select(QTextCursor.SelectionType.Document)
    fmt = QTextBlockFormat()
    fmt.setLineHeight(float(max(100, percent)), QTextBlockFormat.LineHeightTypes.ProportionalHeight.value)
    cursor.mergeBlockFormat(fmt)


class FlipEffect(QGraphicsEffect):
    """Mirrors a widget left-to-right (for beam-splitter teleprompter rigs). Display only; input is not mirrored."""

    def draw(self, painter: QPainter) -> None:  # noqa: N802
        # PySide6 returns only the QPixmap (the C++ ``offset`` out-parameter is not exposed), so the
        # offset is recomputed from the effect's bounding rect. 0.7.0 unpacked a tuple here and raised
        # TypeError on the first real paint, i.e. mirror mode never worked.
        coords = Qt.CoordinateSystem.LogicalCoordinates
        pixmap = self.sourcePixmap(coords)
        if pixmap.isNull():
            return
        offset = self.boundingRectFor(self.sourceBoundingRect(coords)).toAlignedRect().topLeft()
        width = pixmap.deviceIndependentSize().width()
        painter.save()
        painter.translate(offset.x() * 2 + width, 0)
        painter.scale(-1, 1)
        painter.drawPixmap(offset, pixmap)
        painter.restore()


def set_mirrored(widget, mirrored: bool) -> None:
    """Idempotently attach or remove the flip effect."""
    has_effect = widget.graphicsEffect() is not None
    if mirrored and not has_effect:
        widget.setGraphicsEffect(FlipEffect(widget))
    elif not mirrored and has_effect:
        widget.setGraphicsEffect(None)


def text_option(alignment: str) -> QTextOption:
    option = QTextOption()
    option.setAlignment(_ALIGNMENTS.get(alignment, Qt.AlignmentFlag.AlignLeft))
    option.setWrapMode(QTextOption.WrapMode.WordWrap)
    return option
