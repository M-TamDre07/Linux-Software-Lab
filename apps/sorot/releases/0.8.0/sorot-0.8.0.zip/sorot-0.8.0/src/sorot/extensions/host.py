"""Application side of the extension protocol: one subprocess per approved code extension.

Isolation properties
--------------------
* Crash or hang in an extension never affects the application: calls have timeouts, a
  stuck process is killed, and a process that keeps failing is disabled for the session.
* The child gets a scrubbed environment (no API keys) and a private data directory.
* It is **not** a security sandbox: it runs with the user's permissions. That is why code
  extensions need explicit approval and why changed code loses its approval.
"""
from __future__ import annotations

import logging
import os
import queue
import signal
import subprocess
import sys
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from sorot.core.cancel import CancelToken, OperationCancelled
from sorot.core.redact import redact
from sorot.extensions import protocol
from sorot.extensions.discovery import ExtensionInfo, extension_data_dir
from sorot.extensions.manifest import ExtensionError

LOGGER = logging.getLogger(__name__)
MAX_RESTARTS = 3
_ENV_ALLOW = ("PATH", "HOME", "LANG", "LC_ALL", "LC_CTYPE", "TZ", "TMPDIR", "XDG_RUNTIME_DIR", "DISPLAY", "WAYLAND_DISPLAY")


class ExtensionTimeout(ExtensionError):
    pass


class ExtensionCrashed(ExtensionError):
    pass


@dataclass
class Capabilities:
    transforms: list[dict] = field(default_factory=list)
    importers: list[dict] = field(default_factory=list)
    exporters: list[dict] = field(default_factory=list)
    actions: list[dict] = field(default_factory=list)
    events: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> Capabilities:
        def listing(key: str) -> list[dict]:
            value = data.get(key, [])
            return [i for i in value if isinstance(i, dict) and isinstance(i.get("id"), str) and isinstance(i.get("label"), str)][:50] if isinstance(value, list) else []

        events = data.get("events", [])
        return cls(listing("transforms"), listing("importers"), listing("exporters"), listing("actions"),
                   [e for e in events if e in protocol.EVENT_NAMES] if isinstance(events, list) else [])


def scrubbed_environment(extra: dict[str, str] | None = None) -> dict[str, str]:
    env = {key: os.environ[key] for key in _ENV_ALLOW if key in os.environ}
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONUNBUFFERED"] = "1"
    env.update(extra or {})
    return env


def _kill_group(proc: subprocess.Popen[bytes]) -> None:
    """Kill the extension and every process it started (it leads its own session). Safe to call twice."""
    try:
        if hasattr(os, "killpg"):
            os.killpg(proc.pid, signal.SIGKILL)  # the pid is the group id because of start_new_session
            return
    except (ProcessLookupError, PermissionError, OSError):
        pass
    try:
        proc.kill()
    except OSError:
        pass


class ExtensionProcess:
    def __init__(self, info: ExtensionInfo, app_version: str, *, on_notify: Callable[[str, str], None] | None = None,
                 python: str | None = None) -> None:
        assert info.manifest is not None and info.manifest.has_code
        self.info = info
        self.app_version = app_version
        self.on_notify = on_notify
        self.python = python or sys.executable
        self.capabilities = Capabilities()
        self._proc: subprocess.Popen[bytes] | None = None
        self._pending: dict[int, dict[str, Any]] = {}
        self._next_id = 0
        self._lock = threading.Lock()
        self._writes: queue.Queue[bytes | None] = queue.Queue(maxsize=256)
        self._alive = False

    @property
    def ext_id(self) -> str:
        return self.info.ext_id

    @property
    def alive(self) -> bool:
        return self._alive and self._proc is not None and self._proc.poll() is None

    # ---- lifecycle -----------------------------------------------------------------
    def start(self) -> Capabilities:
        manifest = self.info.manifest
        assert manifest is not None
        if self._proc is not None:
            self.stop(kill=True)  # never reuse a half-dead process or its queues
        data_dir = extension_data_dir(manifest.ext_id)
        data_dir.mkdir(parents=True, exist_ok=True)
        self._writes = queue.Queue(maxsize=256)
        try:
            self._proc = subprocess.Popen(
                [self.python, "-B", "-X", "utf8", "-m", "sorot.extensions.runner", str(self.info.path), manifest.entry],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=self.info.path,
                env=scrubbed_environment({"PYTHONPATH": str(Path(__file__).resolve().parents[2])}),
                close_fds=True, start_new_session=True,  # own process group, so stop() can end anything the extension spawned
            )
        except OSError as exc:
            raise ExtensionCrashed(f"Proses ekstensi tidak dapat dimulai: {exc.strerror or exc}") from exc
        self._alive = True
        proc = self._proc
        threading.Thread(target=self._read_loop, args=(proc,), name=f"ext-{manifest.ext_id}-out", daemon=True).start()
        threading.Thread(target=self._err_loop, args=(proc,), name=f"ext-{manifest.ext_id}-err", daemon=True).start()
        threading.Thread(target=self._write_loop, args=(proc, self._writes), name=f"ext-{manifest.ext_id}-in", daemon=True).start()
        try:
            result = self.call("hello", {"app_version": self.app_version, "api": 1, "data_dir": str(data_dir)}, timeout=protocol.TIMEOUTS["hello"])
        except ExtensionError:
            self.stop(kill=True)
            raise
        self.capabilities = Capabilities.from_dict(result if isinstance(result, dict) else {})
        return self.capabilities

    def stop(self, *, kill: bool = False) -> None:
        proc, self._proc = self._proc, None
        was_alive, self._alive = self._alive, False
        if proc is None:
            return
        if was_alive and not kill and proc.poll() is None:
            try:
                self._writes.put_nowait(protocol.encode({"id": 0, "method": "shutdown"}))
                proc.wait(timeout=1.5)
            except (queue.Full, subprocess.TimeoutExpired, OSError):
                pass
        _kill_group(proc)
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            pass
        self._writes.put(None)
        for stream in (proc.stdin, proc.stdout, proc.stderr):
            try:
                if stream:
                    stream.close()
            except OSError:
                pass
        self._fail_pending(ExtensionCrashed("Ekstensi dihentikan."))

    # ---- messaging --------------------------------------------------------------------
    def call(self, method: str, params: dict[str, Any], *, timeout: float | None = None, cancel: CancelToken | None = None) -> Any:
        if method not in protocol.METHODS:
            raise ExtensionError(f"metode tidak dikenal: {method}")
        if not self.alive and method != "hello":
            raise ExtensionCrashed("Proses ekstensi tidak berjalan.")
        waiter = {"event": threading.Event(), "message": None}
        with self._lock:
            self._next_id += 1
            request_id = self._next_id
            self._pending[request_id] = waiter
        try:
            payload = protocol.encode({"id": request_id, "method": method, "params": params})
        except ValueError as exc:
            self._pending.pop(request_id, None)
            raise ExtensionError("Data terlalu besar untuk dikirim ke ekstensi.") from exc
        try:
            self._writes.put(payload, timeout=2)
        except queue.Full as exc:
            self._pending.pop(request_id, None)
            raise ExtensionCrashed("Antrean ke ekstensi penuh.") from exc
        deadline = time.monotonic() + (timeout if timeout is not None else protocol.TIMEOUTS.get(method, 30.0))
        event: threading.Event = waiter["event"]  # type: ignore[assignment]
        while not event.wait(0.1):
            if cancel is not None and cancel.cancelled:
                self._pending.pop(request_id, None)
                self.stop(kill=True)  # a cancelled call may leave the extension mid-work; restart fresh next time
                raise OperationCancelled()
            if time.monotonic() > deadline:
                self._pending.pop(request_id, None)
                self.stop(kill=True)
                raise ExtensionTimeout(f"Ekstensi “{self.info.manifest.name if self.info.manifest else self.ext_id}” tidak menjawab tepat waktu dan dihentikan.")
        message = waiter["message"]
        if isinstance(message, Exception):
            raise message
        assert isinstance(message, dict)
        if "error" in message:
            raise ExtensionError(f"Ekstensi melaporkan kesalahan: {redact(str(message['error']))}")
        return message.get("result")

    def send_event(self, name: str, data: dict[str, Any]) -> None:
        if not self.alive or name not in self.capabilities.events:
            return
        try:
            self._writes.put_nowait(protocol.encode({"event": name, "data": data}))
        except (queue.Full, ValueError):
            LOGGER.debug("Event %s untuk %s dibuang (antrean penuh)", name, self.ext_id)

    # ---- background threads -----------------------------------------------------------
    @staticmethod
    def _write_loop(proc: subprocess.Popen[bytes], writes: queue.Queue[bytes | None]) -> None:
        while True:
            item = writes.get()
            if item is None:
                return
            try:
                assert proc.stdin is not None
                proc.stdin.write(item)
                proc.stdin.flush()
            except (OSError, ValueError, AssertionError):
                return

    def _read_loop(self, proc: subprocess.Popen[bytes]) -> None:
        assert proc.stdout is not None
        try:
            while True:
                line = proc.stdout.readline(protocol.MAX_LINE_BYTES + 1)
                if not line:
                    break
                if len(line) > protocol.MAX_LINE_BYTES:
                    LOGGER.warning("Ekstensi %s mengirim pesan terlalu besar; dihentikan.", self.ext_id)
                    _kill_group(proc)
                    break
                try:
                    message = protocol.decode(line)
                except (ValueError, UnicodeDecodeError):
                    continue
                if "id" in message:
                    with self._lock:
                        waiter = self._pending.pop(message["id"], None) if isinstance(message["id"], int) else None
                    if waiter is not None:
                        waiter["message"] = message
                        waiter["event"].set()
                elif "notify" in message and self.on_notify:
                    self.on_notify(self.ext_id, str(message["notify"])[:300])
                elif "log" in message:
                    LOGGER.info("[ext %s] %s", self.ext_id, redact(str(message["log"])[:500]))
        except (OSError, ValueError):
            pass
        finally:
            if self._proc is proc or self._proc is None:  # a replaced process must not flag its successor dead
                self._alive = False
                self._fail_pending(ExtensionCrashed(f"Ekstensi “{self.ext_id}” berhenti tiba-tiba."))

    def _err_loop(self, proc: subprocess.Popen[bytes]) -> None:
        if proc.stderr is None:
            return
        try:
            for raw in proc.stderr:
                text = raw.decode("utf-8", errors="replace").rstrip()
                if text:
                    LOGGER.info("[ext %s stderr] %s", self.ext_id, redact(text[:500]))
        except (OSError, ValueError):
            pass

    def _fail_pending(self, error: Exception) -> None:
        with self._lock:
            waiters, self._pending = list(self._pending.values()), {}
        for waiter in waiters:
            waiter["message"] = error
            waiter["event"].set()


@dataclass
class HostEntry:
    process: ExtensionProcess
    failures: int = 0  # consecutive crashes/timeouts; reset by any successful call
    disabled_reason: str = ""


class ExtensionHost:
    """Owns the processes of all approved code extensions."""

    def __init__(self, app_version: str, on_notify: Callable[[str, str], None] | None = None, python: str | None = None) -> None:
        self.app_version = app_version
        self.on_notify = on_notify
        self.python = python
        self.entries: dict[str, HostEntry] = {}
        self.errors: dict[str, str] = {}
        self._lock = threading.Lock()

    def sync(self, approved: list[ExtensionInfo]) -> None:
        """Start missing extensions and stop ones that are no longer approved or whose code changed."""
        wanted = {info.ext_id: info for info in approved}
        with self._lock:
            for ext_id in list(self.entries):
                entry = self.entries[ext_id]
                if ext_id not in wanted or entry.process.info.code_hash != wanted[ext_id].code_hash:
                    entry.process.stop()
                    del self.entries[ext_id]
            for ext_id in list(self.errors):
                if ext_id not in wanted:
                    del self.errors[ext_id]
        for ext_id, info in wanted.items():
            if ext_id not in self.entries:
                self._start(info)

    def _start(self, info: ExtensionInfo) -> None:
        process = ExtensionProcess(info, self.app_version, on_notify=self.on_notify, python=self.python)
        try:
            process.start()
        except ExtensionError as exc:
            self.errors[info.ext_id] = str(exc)
            LOGGER.warning("Ekstensi %s gagal dimulai: %s", info.ext_id, exc)
            return
        self.errors.pop(info.ext_id, None)
        self.entries[info.ext_id] = HostEntry(process)

    def status(self, ext_id: str) -> str:
        entry = self.entries.get(ext_id)
        if entry is not None:
            return entry.disabled_reason or ("berjalan" if entry.process.alive else "berhenti")
        return f"gagal: {self.errors[ext_id]}" if ext_id in self.errors else "tidak aktif"

    def capabilities(self) -> dict[str, Capabilities]:
        return {ext_id: entry.process.capabilities for ext_id, entry in self.entries.items() if not entry.disabled_reason}

    def call(self, ext_id: str, method: str, params: dict[str, Any], *, timeout: float | None = None, cancel: CancelToken | None = None) -> Any:
        entry = self.entries.get(ext_id)
        if entry is None:
            raise ExtensionError("Ekstensi tidak aktif.")
        if entry.disabled_reason:
            raise ExtensionError(entry.disabled_reason)
        if not entry.process.alive:
            if entry.failures >= MAX_RESTARTS:
                entry.disabled_reason = self._flaky_message()
                raise ExtensionError(entry.disabled_reason)
            entry.process.start()
        try:
            result = entry.process.call(method, params, timeout=timeout, cancel=cancel)
        except (ExtensionTimeout, ExtensionCrashed):
            entry.failures += 1
            if entry.failures >= MAX_RESTARTS:
                entry.disabled_reason = self._flaky_message()
            raise
        entry.failures = 0
        return result

    @staticmethod
    def _flaky_message() -> str:
        return f"Dinonaktifkan sementara setelah {MAX_RESTARTS} kegagalan beruntun; muat ulang ekstensi untuk mencoba lagi."

    def broadcast(self, event: str, data: dict[str, Any]) -> None:
        for entry in list(self.entries.values()):
            if not entry.disabled_reason:
                entry.process.send_event(event, data)

    def shutdown(self) -> None:
        with self._lock:
            entries, self.entries = list(self.entries.values()), {}
        for entry in entries:
            entry.process.stop()
