"""Upgrade path: version tracking, automatic backups, restore, and install-method hints.

Design notes
------------
* No Qt and no network. Everything here is plain files so it can run from the CLI
  (``sorot --backup`` / ``--restore`` / ``--upgrade-info``) and be tested without a display.
* A *backup* is a ZIP with a ``backup.json`` manifest (format, app version, schema version,
  SHA-256 of every file). Restore verifies the manifest and every hash before touching anything.
* Restore is additive: it overwrites files that exist in the backup and leaves everything
  else alone. The current state is backed up first, so a restore can itself be undone.
* Nothing is ever deleted except old *automatic* backups beyond ``AUTO_BACKUP_KEEP``.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import sys
import tempfile
import time
import zipfile
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any

from sorot.core import paths
from sorot.core.fileio import atomic_write_text

LOGGER = logging.getLogger(__name__)

BACKUP_FORMAT = 1
MANIFEST_NAME = "backup.json"
AUTO_BACKUP_KEEP = 5
#: Backups larger than this are not made automatically (a manual ``--backup`` has no limit).
AUTO_BACKUP_MAX_BYTES = 200 * 1024 * 1024
MAX_RESTORE_FILES = 20_000
MAX_RESTORE_BYTES = 1024 * 1024 * 1024

# Archive roots -> where they live on disk.
ROOT_CONFIG = "config"
ROOT_DATA = "data"
# Names under the data directory that are never part of a backup.
_DATA_EXCLUDE = frozenset({"backups"})
# Names that are skipped everywhere (editor/OS clutter, interpreter caches, partial writes).
_SKIP_PARTS = {"__pycache__"}


class BackupError(Exception):
    """A user-facing problem while creating or restoring a backup."""


# --------------------------------------------------------------------------
# Versions
# --------------------------------------------------------------------------
def parse_version(text: str) -> tuple[int, ...]:
    """``"0.6.0"`` / ``"0.6.0 Beta"`` / ``"v1.2"`` -> ``(0, 6, 0)``. Unknown text -> ``()``."""
    match = re.search(r"(\d+(?:\.\d+)*)", text or "")
    return tuple(int(part) for part in match.group(1).split(".")) if match else ()


def compare_versions(a: str, b: str) -> int:
    """Return -1, 0 or 1. Missing components count as zero (``1.0`` == ``1.0.0``)."""
    pa, pb = parse_version(a), parse_version(b)
    width = max(len(pa), len(pb))
    pa, pb = pa + (0,) * (width - len(pa)), pb + (0,) * (width - len(pb))
    return (pa > pb) - (pa < pb)


def version_stamp_file() -> Path:
    return paths.state_dir() / "version.json"


@dataclass(frozen=True)
class VersionChange:
    kind: str  # "fresh" | "same" | "upgrade" | "downgrade" | "unknown"
    previous: str | None
    current: str

    @property
    def changed(self) -> bool:
        return self.kind in ("upgrade", "downgrade")


def read_stamp(stamp: Path | None = None) -> dict:
    stamp = stamp or version_stamp_file()
    try:
        data = json.loads(stamp.read_text(encoding="utf-8"))
    except (OSError, ValueError, UnicodeDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def detect_change(current: str, stamp: Path | None = None) -> VersionChange:
    """Compare the running version with the one recorded by the last run."""
    previous = read_stamp(stamp).get("version")
    if not isinstance(previous, str) or not parse_version(previous):
        return VersionChange("fresh" if not read_stamp(stamp) else "unknown", None, current)
    order = compare_versions(previous, current)
    kind = "same" if order == 0 else ("upgrade" if order < 0 else "downgrade")
    return VersionChange(kind, previous, current)


def write_stamp(current: str, schema: int, stamp: Path | None = None) -> None:
    stamp = stamp or version_stamp_file()
    payload = {"version": current, "schema_version": schema, "updated": time.strftime("%Y-%m-%dT%H:%M:%S%z")}
    atomic_write_text(stamp, json.dumps(payload, indent=2, sort_keys=True) + "\n", mode=0o600)


# --------------------------------------------------------------------------
# Is another copy running? (pure Python: reads the QLockFile written by single_instance)
# --------------------------------------------------------------------------
def running_instance_pid(lock_path: Path | None = None) -> int | None:
    lock_path = lock_path or (paths.state_dir() / "sorot.lock")
    try:
        first = lock_path.read_text(encoding="utf-8", errors="replace").splitlines()[0].strip()
        pid = int(first)
    except (OSError, IndexError, ValueError):
        return None
    if pid <= 0:
        return None
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return None
    except PermissionError:
        return pid  # exists, owned by someone else
    except OSError:
        return None
    return pid


# --------------------------------------------------------------------------
# Backups
# --------------------------------------------------------------------------
def backups_dir() -> Path:
    return paths.data_dir() / "backups"


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _walk(root: Path, *, exclude_top: frozenset[str] = frozenset()) -> list[Path]:
    """Regular files under ``root`` (no symlinks, no clutter), sorted for stable archives."""
    if not root.is_dir():
        return []
    found: list[Path] = []
    for current, dirs, files in os.walk(root, followlinks=False):
        here = Path(current)
        if here == root:
            dirs[:] = [d for d in dirs if d not in exclude_top]
        dirs[:] = sorted(d for d in dirs if d not in _SKIP_PARTS and not (here / d).is_symlink())
        for name in sorted(files):
            candidate = here / name
            if candidate.is_symlink() or not candidate.is_file():
                continue
            if name.endswith(".tmp") or name == "sorot.lock":
                continue
            found.append(candidate)
    return found


def collect_files() -> list[tuple[str, Path]]:
    """``(archive name, path)`` pairs for everything a backup contains."""
    entries: list[tuple[str, Path]] = []
    cfg = paths.config_dir()
    for path in _walk(cfg):
        entries.append((f"{ROOT_CONFIG}/{path.relative_to(cfg).as_posix()}", path))
    data = paths.data_dir()
    for path in _walk(data, exclude_top=_DATA_EXCLUDE):
        entries.append((f"{ROOT_DATA}/{path.relative_to(data).as_posix()}", path))
    return entries


def has_user_data() -> bool:
    return bool(collect_files())


def _timestamp() -> str:
    return time.strftime("%Y%m%d-%H%M%S")


def create_backup(
    destination: Path | None = None,
    *,
    app_version: str,
    schema_version: int,
    label: str = "manual",
    max_bytes: int | None = None,
) -> Path:
    """Write a verified backup ZIP and return its path.

    ``destination`` may be a file path, a directory, or ``None`` (default backups folder).
    Raises ``BackupError`` if there is nothing to back up or the size limit is exceeded.
    """
    entries = collect_files()
    if not entries:
        raise BackupError("Belum ada data Sorot yang perlu dicadangkan.")
    total = sum(path.stat().st_size for _, path in entries)
    if max_bytes is not None and total > max_bytes:
        raise BackupError(f"Data terlalu besar untuk cadangan otomatis ({total / 1_000_000:.0f} MB). Jalankan `sorot --backup` secara manual.")
    name = f"sorot-backup-{label}-{app_version}-{_timestamp()}.zip"
    if destination is None:
        target = backups_dir() / name
    else:
        destination = Path(destination)
        target = destination / name if destination.is_dir() else destination
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise BackupError(f"Berkas sudah ada dan tidak ditimpa: {target}")

    files: dict[str, dict[str, Any]] = {}
    manifest: dict[str, Any] = {
        "format": BACKUP_FORMAT,
        "app": "sorot",
        "app_version": app_version,
        "schema_version": schema_version,
        "created": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "files": files,
    }
    fd, tmp_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=target.parent)
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as archive:
            for arcname, path in entries:
                files[arcname] = {"sha256": _sha256_file(path), "size": path.stat().st_size}
                archive.write(path, arcname)
            archive.writestr(MANIFEST_NAME, json.dumps(manifest, indent=2, sort_keys=True))
        os.chmod(tmp, 0o600)
        os.replace(tmp, target)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise
    LOGGER.info("Cadangan dibuat: %s (%d berkas)", target.name, len(entries))
    return target


def prune_auto_backups(keep: int = AUTO_BACKUP_KEEP) -> list[Path]:
    """Delete the oldest *automatic* backups beyond ``keep``. Manual backups are never touched."""
    removed: list[Path] = []
    autos = sorted(backups_dir().glob("sorot-backup-auto-*.zip"), key=lambda p: (p.stat().st_mtime, p.name))
    for old in autos[: max(0, len(autos) - keep)]:
        try:
            old.unlink()
            removed.append(old)
        except OSError:
            LOGGER.warning("Cadangan lama tidak dapat dihapus: %s", old.name)
    return removed


def list_backups() -> list[Path]:
    return sorted(backups_dir().glob("sorot-backup-*.zip"), key=lambda p: (p.stat().st_mtime, p.name), reverse=True)


@dataclass
class BackupInfo:
    app_version: str
    schema_version: int
    created: str
    files: dict[str, dict] = field(default_factory=dict)


def _safe_member(name: str) -> PurePosixPath:
    """Validate an archive member name. Only ``config/…`` and ``data/…`` relative paths pass."""
    if not name or "\\" in name or "\x00" in name:
        raise BackupError(f"Nama berkas tidak aman dalam cadangan: {name!r}")
    pure = PurePosixPath(name)
    # ``PurePosixPath`` silently collapses "a//b" and "a/./b"; refuse any name that is not already canonical.
    if pure.as_posix() != name or pure.is_absolute() or ".." in pure.parts or len(pure.parts) < 2:
        raise BackupError(f"Nama berkas tidak aman dalam cadangan: {name!r}")
    if pure.parts[0] not in (ROOT_CONFIG, ROOT_DATA):
        raise BackupError(f"Lokasi tidak dikenal dalam cadangan: {name!r}")
    if pure.parts[0] == ROOT_DATA and pure.parts[1] in _DATA_EXCLUDE:
        raise BackupError(f"Lokasi tidak diizinkan dalam cadangan: {name!r}")
    return pure


def _destination(member: PurePosixPath) -> Path:
    base = paths.config_dir() if member.parts[0] == ROOT_CONFIG else paths.data_dir()
    target = base.joinpath(*member.parts[1:])
    resolved_base = base.resolve()
    if resolved_base not in target.resolve(strict=False).parents:
        raise BackupError(f"Jalur keluar dari folder data: {member}")
    return target


def inspect_backup(path: Path) -> BackupInfo:
    """Read and fully verify a backup (structure, names, sizes, SHA-256). Writes nothing."""
    path = Path(path)
    if not path.is_file():
        raise BackupError(f"Cadangan tidak ditemukan: {path}")
    try:
        archive = zipfile.ZipFile(path)
    except (zipfile.BadZipFile, OSError) as exc:
        raise BackupError(f"Berkas bukan cadangan Sorot yang valid: {exc}") from exc
    with archive:
        try:
            manifest = json.loads(archive.read(MANIFEST_NAME).decode("utf-8"))
        except (KeyError, ValueError, UnicodeDecodeError) as exc:
            raise BackupError("Cadangan tidak memiliki manifest yang valid.") from exc
        if not isinstance(manifest, dict) or manifest.get("app") != "sorot":
            raise BackupError("Berkas ini bukan cadangan Sorot.")
        if manifest.get("format") != BACKUP_FORMAT:
            raise BackupError(f"Format cadangan {manifest.get('format')!r} tidak didukung versi ini.")
        files = manifest.get("files")
        if not isinstance(files, dict) or len(files) > MAX_RESTORE_FILES:
            raise BackupError("Daftar berkas dalam cadangan tidak valid atau terlalu besar.")
        total = 0
        names = set(archive.namelist())
        for arcname, meta in files.items():
            _safe_member(arcname)
            if arcname not in names or not isinstance(meta, dict):
                raise BackupError(f"Berkas tercantum tetapi tidak ada dalam arsip: {arcname}")
            info = archive.getinfo(arcname)
            total += info.file_size
            if total > MAX_RESTORE_BYTES:
                raise BackupError("Isi cadangan terlalu besar.")
            digest = hashlib.sha256()
            with archive.open(info) as handle:
                for chunk in iter(lambda: handle.read(1 << 20), b""):
                    digest.update(chunk)
            if digest.hexdigest() != meta.get("sha256"):
                raise BackupError(f"Berkas rusak atau diubah (hash tidak cocok): {arcname}")
        extra = names - set(files) - {MANIFEST_NAME}
        if extra:
            raise BackupError(f"Arsip memuat berkas yang tidak tercantum di manifest: {sorted(extra)[0]}")
        return BackupInfo(
            str(manifest.get("app_version", "")),
            int(manifest.get("schema_version", 0) or 0),
            str(manifest.get("created", "")),
            files,
        )


def restore_backup(path: Path, *, app_version: str, schema_version: int) -> tuple[BackupInfo, Path | None]:
    """Verify then restore ``path``. Returns ``(info, safety_backup)``.

    Refuses while Sorot is running. Files in the backup overwrite same-named files;
    other files are left alone. The state before restoring is saved first.
    """
    pid = running_instance_pid()
    if pid is not None:
        raise BackupError(f"Sorot sedang berjalan (PID {pid}). Tutup aplikasi dulu sebelum memulihkan cadangan.")
    info = inspect_backup(path)  # verifies everything before any write
    safety: Path | None = None
    if has_user_data():
        safety = create_backup(app_version=app_version, schema_version=schema_version, label="pre-restore")
    staged: list[tuple[Path, Path]] = []
    try:
        with zipfile.ZipFile(path) as archive:
            for arcname in info.files:
                target = _destination(_safe_member(arcname))
                target.parent.mkdir(parents=True, exist_ok=True)
                fd, tmp_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=target.parent)
                with os.fdopen(fd, "wb") as out, archive.open(arcname) as src:
                    for chunk in iter(lambda: src.read(1 << 20), b""):
                        out.write(chunk)
                os.chmod(tmp_name, 0o600)
                staged.append((Path(tmp_name), target))
        for tmp, target in staged:  # commit only after every file was written successfully
            os.replace(tmp, target)
        staged.clear()
    finally:
        for tmp, _ in staged:
            tmp.unlink(missing_ok=True)
    LOGGER.info("Cadangan dipulihkan: %s (%d berkas)", Path(path).name, len(info.files))
    return info, safety


# --------------------------------------------------------------------------
# Install method detection and per-method upgrade instructions
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class InstallMethod:
    key: str
    label: str
    how_to_upgrade: str


_UPGRADE_HINTS = {
    "deb": ("Paket Debian/Ubuntu (.deb)", "sudo apt install ./sorot_<versi>_all.deb   (paket baru menggantikan yang lama; data pengguna tidak disentuh)"),
    "pacman": ("Paket Arch Linux (pacman)", "bangun ulang dengan `makepkg -si` di folder PKGBUILD baru, atau `sudo pacman -U sorot-<versi>-1-any.pkg.tar.zst`"),
    "user-script": ("Skrip pemasang pengguna (~/.local)", "jalankan ./scripts/install-user.sh dari sumber versi baru (aman diulang; data pengguna tidak disentuh)"),
    "pipx": ("pipx", "pipx install --force ./sorot-<versi>-py3-none-any.whl"),
    "pip-venv": ("pip dalam virtual environment", "python -m pip install --upgrade ./sorot-<versi>-py3-none-any.whl"),
    "source": ("Salinan sumber / mode pengembangan", "git pull (atau ambil arsip sumber baru), lalu python -m pip install -e '.[dev]'"),
    "unknown": ("Tidak dikenali", "pasang versi baru dengan cara yang sama seperti memasang yang lama; lihat docs/UPGRADING.md"),
}


def detect_install_method(
    module_file: Path | str | None = None,
    *,
    root: Path = Path("/"),
    prefix: str | None = None,
    base_prefix: str | None = None,
) -> InstallMethod:
    """Best-effort guess of how Sorot was installed. Pure function of its inputs (tested)."""
    module = Path(module_file or __file__).resolve()
    text = module.as_posix()
    prefix = sys.prefix if prefix is None else prefix
    base_prefix = sys.base_prefix if base_prefix is None else base_prefix

    def hint(key: str) -> InstallMethod:
        label, how = _UPGRADE_HINTS[key]
        return InstallMethod(key, label, how)

    if "/pipx/venvs/" in text:
        return hint("pipx")
    if "/sorot/venv/" in text:
        return hint("user-script")
    if text.startswith("/usr/lib/sorot/") and (root / "var/lib/dpkg/info/sorot.list").exists():
        return hint("deb")
    pacman_db = root / "var/lib/pacman/local"
    if text.startswith("/usr/lib/") and "site-packages" in text and pacman_db.is_dir() and any(pacman_db.glob("sorot-*")):
        return hint("pacman")
    checkout = module.parents[3] if len(module.parents) > 3 else None  # <root>/src/sorot/core/upgrade.py
    if checkout is not None and (checkout / "pyproject.toml").is_file() and (checkout / "src" / "sorot").is_dir():
        return hint("source")
    if prefix != base_prefix:
        return hint("pip-venv")
    return hint("unknown")


def describe(current: str, schema_supported: int, config_path: Path | None = None) -> str:
    """Human-readable report for ``sorot --upgrade-info``."""
    change = detect_change(current)
    method = detect_install_method()
    on_disk: object = "tidak ada"
    cfg = config_path or paths.config_file()
    try:
        value = json.loads(cfg.read_text(encoding="utf-8")).get("schema_version")
        on_disk = value if isinstance(value, int) else "tidak tercatat"
    except (OSError, ValueError, UnicodeDecodeError, AttributeError):
        pass
    legacy = change.kind == "fresh" and has_user_data()
    previous = {
        "fresh": "belum pernah dijalankan (instalasi baru)",
        "unknown": "tidak diketahui",
    }.get(change.kind, change.previous or "tidak diketahui")
    status = _STATUS_LABELS["legacy"] if legacy else _STATUS_LABELS[change.kind]
    if legacy:
        previous = "versi sebelum 0.6.0 (belum ada catatan versi)"
    lines = [
        f"Sorot {current}",
        f"  Dijalankan terakhir dengan : {previous}",
        f"  Status                     : {status}",
        f"  Skema pengaturan           : di disk {on_disk}, didukung versi ini {schema_supported}",
        f"  Cara pemasangan            : {method.label}",
        f"  Cara memperbarui           : {method.how_to_upgrade}",
        "",
        "Cadangan:",
    ]
    backups = list_backups()
    if backups:
        lines += [f"  {item}" for item in backups[:5]]
        if len(backups) > 5:
            lines.append(f"  … dan {len(backups) - 5} lainnya di {backups_dir()}")
    else:
        lines.append(f"  (belum ada) folder: {backups_dir()}")
    lines += [
        "",
        "Perintah terkait:",
        "  sorot --backup [BERKAS|FOLDER]   buat cadangan manual",
        "  sorot --restore BERKAS           pulihkan cadangan (aplikasi harus tertutup)",
        "Panduan lengkap: docs/UPGRADING.md",
    ]
    return "\n".join(lines)


_STATUS_LABELS = {
    "legacy": "data dari versi lama ditemukan; cadangan otomatis dibuat saat Sorot dijalankan berikutnya",
    "fresh": "instalasi baru",
    "same": "versi sama dengan terakhir kali",
    "upgrade": "baru diperbarui (cadangan otomatis dibuat saat dijalankan)",
    "downgrade": "DITURUNKAN ke versi lebih lama (pengaturan dari versi lebih baru dipertahankan)",
    "unknown": "tidak diketahui",
}


# --------------------------------------------------------------------------
# Startup hook
# --------------------------------------------------------------------------
def on_startup(current: str, schema_version: int) -> list[str]:
    """Called once per launch, before the window exists. Never raises; returns user notices.

    On the first launch after an upgrade or downgrade an automatic backup is written
    *before* anything is saved in the new format, then the version stamp is updated.
    """
    notices: list[str] = []
    try:
        change = detect_change(current)
        if change.kind == "fresh" and has_user_data():
            # Data exists but no version was ever recorded: it comes from a release before
            # version tracking existed (<= 0.5.x). This is the most important upgrade to protect.
            change = VersionChange("upgrade", "sebelum 0.6.0 (tanpa catatan versi)", current)
        if change.changed:
            verb = "diperbarui dari" if change.kind == "upgrade" else "diturunkan dari"
            message = f"Sorot {verb} versi {change.previous} ke {change.current}."
            if has_user_data():
                try:
                    backup = create_backup(app_version=current, schema_version=schema_version, label="auto", max_bytes=AUTO_BACKUP_MAX_BYTES)
                    prune_auto_backups()
                    message += f" Cadangan otomatis: {backup.name}."
                except (BackupError, OSError) as exc:
                    LOGGER.warning("Cadangan otomatis dilewati: %s", exc)
                    message += " Cadangan otomatis tidak dapat dibuat; lihat log."
            if change.kind == "downgrade":
                message += " Pengaturan dari versi yang lebih baru dipertahankan, tetapi sebagian mungkin diabaikan."
            notices.append(message)
        if change.kind != "same":
            write_stamp(current, schema_version)
    except Exception as exc:  # noqa: BLE001 - upgrade bookkeeping must never stop the app from starting
        LOGGER.warning("Pencatatan versi gagal: %s", type(exc).__name__)
    return notices
