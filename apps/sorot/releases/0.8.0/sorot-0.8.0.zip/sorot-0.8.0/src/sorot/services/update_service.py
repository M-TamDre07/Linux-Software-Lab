"""Optional "is there a newer Sorot?" check.

Privacy contract (same as the rest of Sorot): nothing is contacted until the user chooses
*Bantuan → Periksa pembaruan*. One HTTPS GET of a small JSON file; no identifiers are sent
(only ``User-Agent: Sorot/<version>``), redirects are refused, the answer is size-limited and
strictly validated. Sorot never downloads or installs anything itself: updates come through the
package manager (``apt``/Discover, ``dnf``, ``pacman``, Flatpak) or a file the user chooses to download.
"""
from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Callable
from dataclasses import dataclass, field

from sorot import SOURCE_URL, __version__

DEFAULT_MANIFEST_URL = SOURCE_URL.replace("https://github.com/", "https://raw.githubusercontent.com/") + "/main/apps/sorot/latest.json"
MAX_MANIFEST_BYTES = 65_536
TIMEOUT_SECONDS = 10
_VERSION = re.compile(r"^\d{1,4}\.\d{1,4}\.\d{1,4}$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")


class UpdateError(Exception):
    """A problem with the update check whose message is safe to show to the user."""


@dataclass(frozen=True)
class UpdateInfo:
    version: str
    date: str
    notes: str
    page: str
    files: dict[str, tuple[str, str]] = field(default_factory=dict)  # name -> (url, sha256)

    def is_newer_than(self, current: str) -> bool:
        return version_key(self.version) > version_key(current)


def version_key(version: str) -> tuple[int, int, int]:
    """``0.8.0`` / ``0.8.0 Beta`` -> (0, 8, 0). Anything unparsable sorts lowest."""
    match = re.match(r"\s*(\d{1,4})\.(\d{1,4})\.(\d{1,4})", version or "")
    return (int(match.group(1)), int(match.group(2)), int(match.group(3))) if match else (-1, -1, -1)


def manifest_url() -> str:
    override = os.environ.get("SOROT_UPDATE_URL", "").strip()
    return override or DEFAULT_MANIFEST_URL


def _safe_url(value: object, *, what: str) -> str:
    if not isinstance(value, str) or len(value) > 500:
        raise UpdateError(f"Jawaban pembaruan tidak valid ({what}).")
    parsed = urllib.parse.urlparse(value)
    local = parsed.hostname in {"127.0.0.1", "localhost"}
    if parsed.scheme != "https" and not (local and parsed.scheme == "http") or not parsed.hostname:
        raise UpdateError(f"Jawaban pembaruan tidak valid ({what}: hanya HTTPS).")
    return value


def parse_manifest(data: bytes) -> UpdateInfo:
    if len(data) > MAX_MANIFEST_BYTES:
        raise UpdateError("Jawaban pembaruan terlalu besar.")
    try:
        doc = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise UpdateError("Jawaban pembaruan bukan JSON yang valid.") from exc
    if not isinstance(doc, dict) or doc.get("schema") != 1 or doc.get("name") != "sorot":
        raise UpdateError("Jawaban pembaruan bukan untuk Sorot atau memakai format yang belum dikenal.")
    version, date, notes = doc.get("version"), doc.get("date"), doc.get("notes", "")
    if not isinstance(version, str) or not _VERSION.match(version):
        raise UpdateError("Jawaban pembaruan tidak valid (versi).")
    if not isinstance(date, str) or not re.match(r"^\d{4}-\d{2}-\d{2}$", date):
        raise UpdateError("Jawaban pembaruan tidak valid (tanggal).")
    if not isinstance(notes, str):
        raise UpdateError("Jawaban pembaruan tidak valid (catatan).")
    page = _safe_url(doc.get("page"), what="halaman")
    files: dict[str, tuple[str, str]] = {}
    raw_files = doc.get("files", {})
    if not isinstance(raw_files, dict) or len(raw_files) > 20:
        raise UpdateError("Jawaban pembaruan tidak valid (berkas).")
    for name, entry in raw_files.items():
        if not isinstance(name, str) or not re.match(r"^[A-Za-z0-9._-]{1,120}$", name) or not isinstance(entry, dict):
            raise UpdateError("Jawaban pembaruan tidak valid (nama berkas).")
        digest = entry.get("sha256")
        if not isinstance(digest, str) or not _SHA256.match(digest):
            raise UpdateError("Jawaban pembaruan tidak valid (sha256).")
        files[name] = (_safe_url(entry.get("url"), what="unduhan"), digest)
    return UpdateInfo(version, date, notes.strip()[:2000], page, files)


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: ANN001
        return None


_OPENER = urllib.request.build_opener(_NoRedirect)


def fetch_manifest(url: str | None = None) -> bytes:
    target = _safe_url(url or manifest_url(), what="alamat")
    request = urllib.request.Request(target, headers={"User-Agent": f"Sorot/{__version__}", "Accept": "application/json"})
    try:
        with _OPENER.open(request, timeout=TIMEOUT_SECONDS) as response:
            return response.read(MAX_MANIFEST_BYTES + 1)
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise UpdateError("Belum ada informasi pembaruan yang diterbitkan.") from exc
        raise UpdateError(f"Server pembaruan menjawab galat {exc.code}.") from exc
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise UpdateError("Tidak dapat menghubungi server pembaruan. Periksa sambungan internet.") from exc


def check_for_update(fetch: Callable[[], bytes] | None = None) -> UpdateInfo:
    """Returns the latest published release (which may be the one already installed)."""
    return parse_manifest((fetch or fetch_manifest)())
