"""Small utility dialogs: keyboard shortcuts and the local script library."""
from __future__ import annotations

from PySide6.QtCore import Qt, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QKeySequence
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QInputDialog,
    QKeySequenceEdit,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
)

from sorot.core.config import DEFAULT_SHORTCUTS, SHORTCUT_LABELS
from sorot.core.fileio import ScriptFileError
from sorot.core.scripts import ScriptLibrary, format_modified

# Keys the text editor (or the File menu) already uses; a window shortcut on them
# would either be swallowed by the editor or hide the editing behaviour.
RESERVED_SEQUENCES = frozenset({
    "Ctrl+A", "Ctrl+C", "Ctrl+V", "Ctrl+X", "Ctrl+Z", "Ctrl+Y", "Ctrl+H", "Ctrl+D", "Ctrl+K", "Ctrl+E", "Ctrl+B", "Ctrl+F",
    "Ctrl+Home", "Ctrl+End", "Ctrl+Up", "Ctrl+Down", "Ctrl+Left", "Ctrl+Right", "Ctrl+Backspace", "Ctrl+Delete",
    "Ctrl+N", "Ctrl+O", "Ctrl+L", "Ctrl+S", "Ctrl+Shift+S", "Ctrl+Q",
})


def shortcut_problem(sequence: str) -> str | None:
    """Why ``sequence`` cannot be used as an overlay shortcut, or ``None`` if it is fine."""
    if not sequence:
        return "tidak boleh kosong"
    if sequence in RESERVED_SEQUENCES:
        return "bentrok dengan penyuntingan teks atau menu Berkas"
    has_modifier = any(part in sequence.split("+")[:-1] for part in ("Ctrl", "Alt", "Meta"))
    if not has_modifier and not (sequence == "Esc" or (sequence.startswith("F") and sequence[1:].isdigit())):
        return "harus memakai Ctrl/Alt (tanpa itu tombol ini dipakai untuk mengetik)"
    return None


class ShortcutsDialog(QDialog):
    """Edit in-app shortcuts. These work only while a Sorot window has focus."""

    def __init__(self, shortcuts: dict[str, str], parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Pintasan keyboard")
        self.setMinimumWidth(460)
        layout = QVBoxLayout(self)
        note = QLabel(
            "Pintasan ini hanya bekerja ketika jendela utama Sorot sedang aktif. Pintasan global antar-aplikasi "
            "tidak tersedia secara andal di Wayland, jadi gunakan tombol pada overlay saat overlay berada di atas aplikasi lain."
        )
        note.setWordWrap(True)
        note.setObjectName("hint")
        layout.addWidget(note)
        form = QFormLayout()
        self.edits: dict[str, QKeySequenceEdit] = {}
        for key, label in SHORTCUT_LABELS.items():
            edit = QKeySequenceEdit(QKeySequence(shortcuts.get(key, DEFAULT_SHORTCUTS[key])))
            edit.setMaximumSequenceLength(1)
            edit.setAccessibleName(label)
            self.edits[key] = edit
            form.addRow(label, edit)
        layout.addLayout(form)
        self.error = QLabel("")
        self.error.setObjectName("warning")
        self.error.setWordWrap(True)
        self.error.hide()
        layout.addWidget(self.error)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        defaults = buttons.addButton("Kembalikan bawaan", QDialogButtonBox.ButtonRole.ResetRole)
        defaults.clicked.connect(self._reset)
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _reset(self) -> None:
        for key, edit in self.edits.items():
            edit.setKeySequence(QKeySequence(DEFAULT_SHORTCUTS[key]))

    def values(self) -> dict[str, str]:
        return {key: edit.keySequence().toString(QKeySequence.SequenceFormat.PortableText) for key, edit in self.edits.items()}

    def _accept(self) -> None:
        values = self.values()
        for key, value in values.items():
            problem = shortcut_problem(value)
            if problem:
                self._show_error(f"“{SHORTCUT_LABELS[key]}”: {problem}.")
                return
        seen: dict[str, str] = {}
        for key, value in values.items():
            if value in seen:
                self._show_error(f"Pintasan “{value}” dipakai ganda oleh “{SHORTCUT_LABELS[seen[value]]}” dan “{SHORTCUT_LABELS[key]}”.")
                return
            seen[value] = key
        self.accept()

    def _show_error(self, message: str) -> None:
        self.error.setText(message)
        self.error.show()


class ScriptLibraryDialog(QDialog):
    """Browse, save, open, and delete scripts stored privately on this computer."""

    openRequested = Signal(str)

    def __init__(self, library: ScriptLibrary, current_text: str, parent=None) -> None:
        super().__init__(parent)
        self.library = library
        self.current_text = current_text
        self.setWindowTitle("Naskah lokal")
        self.resize(520, 420)
        layout = QVBoxLayout(self)
        info = QLabel(f"Disimpan hanya di komputer ini:\n{library.directory}")
        info.setWordWrap(True)
        info.setObjectName("hint")
        layout.addWidget(info)
        self.list = QListWidget()
        self.list.setAccessibleName("Daftar naskah lokal")
        self.list.itemDoubleClicked.connect(lambda _item: self._open())
        layout.addWidget(self.list, 1)
        self.message = QLabel("")
        self.message.setObjectName("hint")
        layout.addWidget(self.message)
        row = QHBoxLayout()
        self.open_btn = QPushButton("Buka")
        self.open_btn.setObjectName("primary")
        self.save_btn = QPushButton("Simpan naskah saat ini…")
        self.delete_btn = QPushButton("Hapus…")
        self.folder_btn = QPushButton("Buka folder")
        close_btn = QPushButton("Tutup")
        for button in (self.open_btn, self.save_btn, self.delete_btn, self.folder_btn):
            row.addWidget(button)
        row.addStretch(1)
        row.addWidget(close_btn)
        layout.addLayout(row)
        self.open_btn.clicked.connect(self._open)
        self.save_btn.clicked.connect(self._save)
        self.delete_btn.clicked.connect(self._delete)
        self.folder_btn.clicked.connect(self._open_folder)
        close_btn.clicked.connect(self.accept)
        self.list.itemSelectionChanged.connect(self._update_buttons)
        self.refresh()

    def refresh(self, select: str | None = None) -> None:
        self.list.clear()
        for entry in self.library.list():
            item = QListWidgetItem(f"{entry.name}    ·    {format_modified(entry.modified)}    ·    {entry.size:,} B".replace(",", "."))
            item.setData(256, entry.name)
            self.list.addItem(item)
            if select == entry.name:
                self.list.setCurrentItem(item)
        if self.list.count() and self.list.currentRow() < 0:
            self.list.setCurrentRow(0)
        self.message.setText("" if self.list.count() else "Belum ada naskah tersimpan.")
        self._update_buttons()

    def _selected(self) -> str | None:
        item = self.list.currentItem()
        return item.data(256) if item else None

    def _update_buttons(self) -> None:
        has = self._selected() is not None
        self.open_btn.setEnabled(has)
        self.delete_btn.setEnabled(has)
        self.save_btn.setEnabled(bool(self.current_text.strip()))

    def _open(self) -> None:
        name = self._selected()
        if name:
            self.openRequested.emit(name)
            self.accept()

    def _save(self) -> None:
        name, ok = QInputDialog.getText(self, "Simpan naskah lokal", "Nama naskah:", text="Naskah baru")
        if not ok or not name.strip():
            return
        try:
            if self.library.exists(name) and QMessageBox.question(
                self, "Timpa naskah?", f"Naskah “{name.strip()}” sudah ada. Timpa isinya?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No,
            ) != QMessageBox.StandardButton.Yes:
                return
            path = self.library.save(name, self.current_text)
        except ScriptFileError as exc:
            QMessageBox.warning(self, "Naskah lokal", str(exc))
            return
        self.refresh(select=path.stem)
        self.message.setText(f"Tersimpan: {path.name}")

    def _delete(self) -> None:
        name = self._selected()
        if not name:
            return
        if QMessageBox.warning(
            self, "Hapus naskah?", f"Hapus naskah “{name}” dari komputer ini? Tindakan ini tidak dapat dibatalkan.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No,
        ) != QMessageBox.StandardButton.Yes:
            return
        try:
            self.library.delete(name)
        except ScriptFileError as exc:
            QMessageBox.warning(self, "Naskah lokal", str(exc))
        self.refresh()

    def _open_folder(self) -> None:
        self.library.directory.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.library.directory)))


class SnapshotDialog(QDialog):
    """Roll back to an earlier automatic snapshot of the working draft."""

    restoreRequested = Signal(str)

    def __init__(self, draft, parent=None) -> None:  # noqa: ANN001
        super().__init__(parent)
        self.draft = draft
        self.setWindowTitle("Riwayat draf")
        self.resize(560, 440)
        layout = QVBoxLayout(self)
        note = QLabel("Salinan otomatis naskah kerja (maksimal 20) disimpan di komputer ini. Memulihkan hanya mengisi editor; tidak menghapus apa pun.")
        note.setWordWrap(True)
        note.setProperty("role", "muted")
        layout.addWidget(note)
        self.list = QListWidget()
        self.list.setAccessibleName("Daftar snapshot draf")
        layout.addWidget(self.list, 1)
        self.preview = QLabel("")
        self.preview.setWordWrap(True)
        self.preview.setProperty("role", "note")
        layout.addWidget(self.preview)
        row = QHBoxLayout()
        self.restore_btn = QPushButton("Pulihkan ke editor")
        self.restore_btn.setProperty("role", "primary")
        close_btn = QPushButton("Tutup")
        row.addWidget(self.restore_btn)
        row.addStretch(1)
        row.addWidget(close_btn)
        layout.addLayout(row)
        self.restore_btn.clicked.connect(self._restore)
        close_btn.clicked.connect(self.accept)
        self.list.currentItemChanged.connect(self._show_preview)
        self.list.itemDoubleClicked.connect(lambda _item: self._restore())
        for snap in draft.snapshots():
            item = QListWidgetItem(f"{format_modified(snap.modified)}    ·    {snap.size:,} B".replace(",", "."))
            item.setData(256, snap.name)
            self.list.addItem(item)
        if self.list.count():
            self.list.setCurrentRow(0)
        else:
            self.preview.setText("Belum ada snapshot. Salinan dibuat otomatis saat kamu berhenti mengetik dan sebelum naskah diganti.")
        self.restore_btn.setEnabled(self.list.count() > 0)

    def _show_preview(self, current, _previous=None) -> None:  # noqa: ANN001
        if current is None:
            return
        try:
            text = self.draft.load_snapshot(current.data(256))
        except ScriptFileError as exc:
            self.preview.setText(str(exc))
            return
        words = len(text.split())
        excerpt = " ".join(text.split())[:220]
        self.preview.setText(f"{words} kata — “{excerpt}{'…' if len(text) > 220 else ''}”")

    def _restore(self) -> None:
        item = self.list.currentItem()
        if item is not None:
            self.restoreRequested.emit(item.data(256))
            self.accept()


class AboutDialog(QDialog):
    """Name, version, credit, and licence."""

    supportRequested = Signal()

    def __init__(self, environment: str, parent=None) -> None:  # noqa: ANN001
        super().__init__(parent)
        from sorot import APP_NAME, AUTHOR, CONTACT_EMAIL, COPYRIGHT, HOMEPAGE_URL, LICENSE_NAME, TAGLINE, VERSION_LABEL
        from sorot.support import CONTACT_NOTE

        self.contact_email = CONTACT_EMAIL
        self.setWindowTitle(f"Tentang {APP_NAME}")
        self.setMinimumWidth(460)
        layout = QVBoxLayout(self)
        layout.setSpacing(6)
        title = QLabel(APP_NAME)
        title.setProperty("role", "title")
        layout.addWidget(title)
        sub = QLabel(f"{TAGLINE} · versi {VERSION_LABEL}")
        sub.setProperty("role", "muted")
        layout.addWidget(sub)
        layout.addSpacing(8)
        credit = QLabel(f"Dibuat oleh <b>{AUTHOR}</b>")
        layout.addWidget(credit)
        layout.addWidget(QLabel(COPYRIGHT))
        licence = QLabel(f"Perangkat lunak bebas berlisensi {LICENSE_NAME}. Naskah dan pengaturan tersimpan hanya di komputer ini; AI dan Google Drive bersifat opsional dan hanya berjalan atas tindakanmu.")
        licence.setWordWrap(True)
        licence.setProperty("role", "muted")
        layout.addWidget(licence)
        project = QLabel(f"Kode sumber dan laporan masalah: {HOMEPAGE_URL}")  # shown as text; nothing is opened or contacted unless the user copies it
        project.setWordWrap(True)
        project.setProperty("role", "muted")
        project.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(project)
        layout.addSpacing(6)
        contact_head = QLabel("KONTAK PROFESIONAL")
        contact_head.setProperty("role", "caps")
        layout.addWidget(contact_head)
        self.email_label = QLabel(CONTACT_EMAIL)
        self.email_label.setProperty("role", "mono")
        self.email_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.email_label.setAccessibleName("Alamat email kontak")
        layout.addWidget(self.email_label)
        contact_note = QLabel(CONTACT_NOTE)
        contact_note.setWordWrap(True)
        contact_note.setProperty("role", "muted")
        layout.addWidget(contact_note)
        contact_row = QHBoxLayout()
        self.copy_email_btn = QPushButton("Salin email")
        self.send_email_btn = QPushButton("Tulis email…")
        self.copy_email_btn.clicked.connect(self._copy_email)
        self.send_email_btn.clicked.connect(self._open_mailto)
        contact_row.addWidget(self.copy_email_btn)
        contact_row.addWidget(self.send_email_btn)
        contact_row.addStretch(1)
        layout.addLayout(contact_row)
        self.contact_feedback = QLabel("")
        self.contact_feedback.setProperty("role", "muted")
        layout.addWidget(self.contact_feedback)
        env = QLabel(environment)
        env.setProperty("role", "mono")
        env.setWordWrap(True)
        layout.addSpacing(6)
        layout.addWidget(env)
        row = QHBoxLayout()
        self.support_btn = QPushButton("Dukung pengembangan…")
        self.support_btn.setProperty("role", "ghost")
        self.support_btn.clicked.connect(self.supportRequested.emit)
        close_btn = QPushButton("Tutup")
        close_btn.clicked.connect(self.accept)
        row.addWidget(self.support_btn)
        row.addStretch(1)
        row.addWidget(close_btn)
        layout.addLayout(row)

    def _copy_email(self) -> None:
        from PySide6.QtGui import QGuiApplication

        QGuiApplication.clipboard().setText(self.contact_email)
        self.contact_feedback.setText("Alamat email disalin.")

    def _open_mailto(self) -> None:
        # Only ever runs from a button click; nothing is contacted or opened before that.
        from sorot.support import contact_mailto

        QDesktopServices.openUrl(QUrl(contact_mailto(self.contact_email, "Sorot")))
        self.contact_feedback.setText("Membuka aplikasi email…")


class SupportDialog(QDialog):
    """A calm, optional page with the ways to support the author."""

    def __init__(self, parent=None) -> None:  # noqa: ANN001
        super().__init__(parent)
        from sorot import APP_NAME
        from sorot.support import INTRO, PROMISE, support_info

        self.info = support_info()
        self.setWindowTitle(f"Dukung pengembangan {APP_NAME}")
        self.setMinimumWidth(500)
        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        title = QLabel("Dukung pengembangan")
        title.setProperty("role", "title")
        layout.addWidget(title)
        intro = QLabel(INTRO)
        intro.setWordWrap(True)
        layout.addWidget(intro)
        promise = QLabel(PROMISE)
        promise.setWordWrap(True)
        promise.setProperty("role", "note")
        layout.addWidget(promise)
        layout.addSpacing(6)

        saweria = QFrame()
        saweria.setProperty("role", "panel")
        sl = QVBoxLayout(saweria)
        sl.setContentsMargins(14, 10, 14, 12)
        head = QLabel("SAWERIA")
        head.setProperty("role", "caps")
        sl.addWidget(head)
        url = QLabel(self.info.saweria_url)
        url.setProperty("role", "mono")
        url.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        sl.addWidget(url)
        row = QHBoxLayout()
        self.open_btn = QPushButton("Buka Saweria")
        self.open_btn.setProperty("role", "primary")
        self.copy_link_btn = QPushButton("Salin tautan")
        row.addWidget(self.open_btn)
        row.addWidget(self.copy_link_btn)
        row.addStretch(1)
        sl.addLayout(row)
        layout.addWidget(saweria)

        gopay = QFrame()
        gopay.setProperty("role", "panel")
        gl = QVBoxLayout(gopay)
        gl.setContentsMargins(14, 10, 14, 12)
        ghead = QLabel("GOPAY")
        ghead.setProperty("role", "caps")
        gl.addWidget(ghead)
        self.number_label = QLabel(self.info.gopay_display)
        self.number_label.setProperty("role", "stat")
        self.number_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.number_label.setAccessibleName("Nomor GoPay")
        gl.addWidget(self.number_label)
        hint = QLabel(f"Atas nama {self.info.author}. Periksa nama penerima di aplikasi sebelum mengirim.")
        hint.setProperty("role", "muted")
        hint.setWordWrap(True)
        gl.addWidget(hint)
        grow = QHBoxLayout()
        self.copy_number_btn = QPushButton("Salin nomor")
        grow.addWidget(self.copy_number_btn)
        grow.addStretch(1)
        gl.addLayout(grow)
        layout.addWidget(gopay)

        self.feedback = QLabel("")
        self.feedback.setProperty("role", "muted")
        layout.addWidget(self.feedback)
        thanks = QLabel("Terima kasih sudah memakai Sorot.")
        thanks.setProperty("role", "muted")
        layout.addWidget(thanks)
        close_btn = QPushButton("Tutup")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn, 0, Qt.AlignmentFlag.AlignRight)

        self.feedback.setMinimumHeight(self.feedback.fontMetrics().height() + 4)  # reserve the line so copying never changes the layout
        self.open_btn.clicked.connect(self._open_saweria)
        self.copy_link_btn.clicked.connect(lambda: self._copy(self.info.saweria_url, "Tautan Saweria disalin."))
        self.copy_number_btn.clicked.connect(lambda: self._copy(self.info.gopay_number, "Nomor GoPay disalin."))

    def _fit_height(self) -> None:
        """Qt's minimum height ignores word-wrapped labels, so larger fonts squeezed the cards (the GoPay number was cut off)."""
        layout = self.layout()
        needed = layout.totalHeightForWidth(self.width()) if layout is not None else 0
        if needed > 0:
            self.setMinimumHeight(needed)
            if self.height() < needed:
                self.resize(self.width(), needed)

    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        self._fit_height()

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self._fit_height()

    def _open_saweria(self) -> None:
        QDesktopServices.openUrl(QUrl(self.info.saweria_url))
        self.feedback.setText("Membuka Saweria di browser…")

    def _copy(self, text: str, message: str) -> None:
        from PySide6.QtGui import QGuiApplication

        QGuiApplication.clipboard().setText(text)
        self.feedback.setText(message)
