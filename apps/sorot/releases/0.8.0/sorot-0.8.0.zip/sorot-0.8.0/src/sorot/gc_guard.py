"""Run Python's cyclic garbage collector on the Qt main thread only.

Why: Sorot does slow work (extension discovery, AI, rclone) on worker threads. CPython runs an *automatic*
collection in whichever thread happens to trigger it, so a worker thread could traverse Shiboken (PySide)
wrapper objects while the GUI thread, which holds no GIL while it is inside Qt, creates, reparents or deletes
them. A gdb backtrace of a real crash showed exactly that::

    visit_decref <- libshiboken6 (object traverse) <- gc_collect_main <- worker thread

It was rare (about one run in three on a freshly started Wayland compositor, never seen on X11/offscreen) and
non-deterministic, which is why it never showed up as a failing test. With automatic collection disabled and
all collections issued from a ``QTimer`` on the GUI thread, a worker can never be the one traversing wrappers.
"""
from __future__ import annotations

import gc
import threading

from PySide6.QtCore import QObject, QTimer

INTERVAL_MS = 1000
FULL_EVERY = 30  # every Nth tick collects all generations, the others only the young ones


class MainThreadGC(QObject):
    """Disable automatic GC and collect from the thread this object lives in (create it on the GUI thread)."""

    def __init__(self, parent: QObject | None = None, interval_ms: int = INTERVAL_MS) -> None:
        super().__init__(parent)
        self._was_enabled = gc.isenabled()
        self._ticks = 0
        self.collections_on_other_threads = 0
        self._owner = threading.get_ident()
        gc.disable()
        self._timer = QTimer(self)
        self._timer.setInterval(interval_ms)
        self._timer.timeout.connect(self.collect)
        self._timer.start()

    def collect(self) -> int:
        """One collection pass; returns the number of unreachable objects found."""
        if threading.get_ident() != self._owner:  # never from a worker: that is the bug this class prevents
            self.collections_on_other_threads += 1
            return 0
        self._ticks += 1
        return gc.collect(2 if self._ticks % FULL_EVERY == 0 else 1)

    def stop(self) -> None:
        """Hand collection back to CPython (used at shutdown and by tests)."""
        self._timer.stop()
        if self._was_enabled:
            gc.enable()
