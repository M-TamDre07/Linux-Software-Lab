"""Run slow work (network, rclone) off the GUI thread with cancellation.

Daemon threads are used on purpose: a request that is still waiting on a slow
server must never keep the application alive after the user closes it, which
is what ``QThreadPool`` would do at shutdown.
"""
from __future__ import annotations

import logging
import threading
from collections.abc import Callable
from typing import Any

from PySide6.QtCore import QObject, Signal

from sorot.core.cancel import CancelToken, OperationCancelled
from sorot.core.redact import redact
from sorot.extensions.manifest import ExtensionError
from sorot.services.ai_service import AIError, AIErrorKind
from sorot.services.drive_service import DriveIntegrationError
from sorot.services.update_service import UpdateError

LOGGER = logging.getLogger(__name__)


class BackgroundTask(QObject):
    """Executes ``function(cancel_token)`` in a daemon thread.

    Exactly one of ``succeeded``, ``failed``, or ``cancelled`` is emitted, always
    delivered to the GUI thread through Qt's queued connections. If the user
    cancelled, a late result is discarded.
    """

    succeeded = Signal(object)
    failed = Signal(str)
    cancelled = Signal()

    def __init__(self, function: Callable[[CancelToken], Any], parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._function = function
        self.token = CancelToken()
        self._thread: threading.Thread | None = None
        self._finished = False

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, name="sorot-task", daemon=True)
        self._thread.start()

    def cancel(self) -> None:
        self.token.cancel()

    @property
    def running(self) -> bool:
        return self._thread is not None and not self._finished

    def _run(self) -> None:
        try:
            result = self._function(self.token)
        except OperationCancelled:
            self._finish(self.cancelled)
        except AIError as exc:
            if exc.kind is AIErrorKind.CANCELLED:
                self._finish(self.cancelled)
            else:
                self._finish(self.failed, str(exc))
        except (DriveIntegrationError, ExtensionError, UpdateError) as exc:
            self._finish(self.failed, str(exc))
        except Exception as exc:  # noqa: BLE001 - last line of defence for a worker thread
            LOGGER.exception("Tugas latar belakang gagal secara tak terduga")
            self._finish(self.failed, f"Terjadi kesalahan tak terduga ({type(exc).__name__}): {redact(str(exc))[:200]}")
        else:
            if self.token.cancelled:
                self._finish(self.cancelled)
            else:
                self._finish(self.succeeded, result)

    def _finish(self, signal: Any, *args: Any) -> None:
        self._finished = True
        try:
            signal.emit(*args)
        except RuntimeError:
            # The owner (e.g. a closed dialog) was destroyed while we were running.
            LOGGER.debug("Hasil tugas diabaikan karena pemiliknya sudah ditutup.")
