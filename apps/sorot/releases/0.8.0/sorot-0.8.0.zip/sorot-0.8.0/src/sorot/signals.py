"""Close Sorot cleanly on SIGTERM, SIGHUP and SIGINT.

Without this a logout, ``kill`` or Ctrl+C either killed the process with no save
(settings changed in the last moments were lost, extension processes were
orphaned) or, for SIGINT, left it hanging because Python's handler never runs
while Qt's loop is blocked in C++. A short idle timer lets the interpreter run
the handler; the handler then closes the window through the normal path.
"""
from __future__ import annotations

import logging
import os
import signal
from collections.abc import Callable

from PySide6.QtCore import QObject, QTimer

LOGGER = logging.getLogger(__name__)
SIGNALS = tuple(s for s in (getattr(signal, n, None) for n in ("SIGINT", "SIGTERM", "SIGHUP")) if s is not None)


class SignalBridge(QObject):
    """Parent it to the QApplication. ``close_window`` must save and quit without asking anything."""

    def __init__(self, close_window: Callable[[], None], parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._close_window = close_window
        self._received = 0
        self._previous: dict[int, object] = {}
        for sig in SIGNALS:
            try:
                self._previous[sig] = signal.signal(sig, self._handle)
            except (ValueError, OSError):  # not the main thread / unsupported
                LOGGER.debug("Sinyal %s tidak dapat dipasang", sig)
        self._tick = QTimer(self)
        self._tick.setInterval(200)
        self._tick.timeout.connect(lambda: None)  # wakes the interpreter so it can run the handler
        self._tick.start()

    def _handle(self, signum: int, _frame: object) -> None:
        self._received += 1
        if self._received > 1:  # second signal: the user really wants out
            LOGGER.warning("Sinyal %s kedua; keluar segera.", signum)
            os._exit(128 + signum)
        LOGGER.info("Sinyal %s diterima; menutup dengan rapi.", signum)
        try:
            self._close_window()
        except Exception:  # noqa: BLE001 - never let shutdown code swallow the signal
            LOGGER.exception("Penutupan lewat sinyal gagal")
            os._exit(128 + signum)

    def restore(self) -> None:
        self._tick.stop()
        for sig, handler in self._previous.items():
            try:
                signal.signal(sig, handler)  # type: ignore[arg-type]
            except (ValueError, OSError, TypeError):
                pass
