"""Open scripts from the formats people actually have: text, Markdown, Word, OpenDocument, RTF, HTML and PDF.

Only plain text comes back. Nothing is executed, no network is used, and every format has a size limit.
Office files are ZIP archives, so their members are size-checked before reading, and XML that declares a
DOCTYPE/ENTITY (the "billion laughs" family) is refused instead of parsed. PDF needs the optional ``pypdf``.
"""
from __future__ import annotations

import html
import re
import zipfile
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from xml.etree import ElementTree as ET

from sorot.core.fileio import MAX_SCRIPT_BYTES, ScriptFileError, scrub_text

TEXT_SUFFIXES = {".txt", ".text", ".md", ".markdown"}
SUFFIXES = TEXT_SUFFIXES | {".docx", ".odt", ".rtf", ".html", ".htm", ".pdf"}
MAX_FILE_BYTES = 25_000_000          # the file itself (a script of 2 MB can sit in a larger Word file)
MAX_MEMBER_BYTES = 30_000_000        # one archive member after decompression
MAX_PDF_PAGES = 400

FILE_DIALOG_FILTER = "Naskah (*.txt *.md *.docx *.odt *.rtf *.html *.htm *.pdf);;Berkas teks (*.txt *.md);;Semua berkas (*)"


@dataclass
class LoadedScript:
    text: str
    format: str
    notes: list[str] = field(default_factory=list)

    @property
    def converted(self) -> bool:
        """True when the text was extracted from another format (so saving must not overwrite the original)."""
        return self.format not in {"txt", "md"}


def is_supported(path: Path) -> bool:
    return Path(path).suffix.lower() in SUFFIXES


def load_script_file(path: Path) -> LoadedScript:
    path = Path(path)
    try:
        info = path.stat()
    except OSError as exc:
        raise ScriptFileError(f"Berkas tidak dapat diakses: {exc.strerror or exc}") from exc
    if not path.is_file():
        raise ScriptFileError("Jalur yang dipilih bukan berkas biasa.")
    suffix = path.suffix.lower()
    if suffix in TEXT_SUFFIXES or suffix not in SUFFIXES:
        return _load_text(path, info.st_size, "md" if suffix in {".md", ".markdown"} else "txt")
    if info.st_size > MAX_FILE_BYTES:
        raise ScriptFileError(f"Berkas terlalu besar ({info.st_size / 1_000_000:.0f} MB; batas {MAX_FILE_BYTES // 1_000_000} MB).")
    try:
        data = path.read_bytes()
    except OSError as exc:
        raise ScriptFileError(f"Berkas tidak dapat dibaca: {exc.strerror or exc}") from exc
    if suffix == ".docx":
        result = LoadedScript(_docx_text(path), "docx")
    elif suffix == ".odt":
        result = LoadedScript(_odt_text(path), "odt")
    elif suffix == ".rtf":
        text, notes = _decode_text(data)
        result = LoadedScript(_rtf_text(text), "rtf", notes)
    elif suffix in {".html", ".htm"}:
        text, notes = _decode_text(data)
        result = LoadedScript(_html_text(text), "html", notes)
    else:
        result = LoadedScript(_pdf_text(path), "pdf")
    return _finish(result)


# ------------------------------------------------------------------------------ plain text
def _load_text(path: Path, size: int, kind: str) -> LoadedScript:
    if size > MAX_SCRIPT_BYTES:
        raise ScriptFileError(f"Berkas terlalu besar ({size / 1_000_000:.1f} MB). Batas untuk naskah adalah {MAX_SCRIPT_BYTES / 1_000_000:.0f} MB.")
    try:
        data = path.read_bytes()
    except OSError as exc:
        raise ScriptFileError(f"Berkas tidak dapat dibaca: {exc.strerror or exc}") from exc
    text, notes = _decode_text(data)
    return _finish(LoadedScript(text, kind, notes))


def _decode_text(data: bytes) -> tuple[str, list[str]]:
    """UTF-8 (with or without BOM) first; UTF-16/32 by BOM; otherwise Windows-1252 with a visible note."""
    for bom, codec, label in ((b"\xff\xfe\x00\x00", "utf-32", "UTF-32"), (b"\x00\x00\xfe\xff", "utf-32", "UTF-32"),
                              (b"\xff\xfe", "utf-16", "UTF-16"), (b"\xfe\xff", "utf-16", "UTF-16")):
        if data.startswith(bom):
            try:
                return data.decode(codec), [f"Berkas berenkoding {label}; dikonversi."]
            except UnicodeDecodeError as exc:
                raise ScriptFileError(f"Berkas diawali penanda {label} tetapi isinya rusak.") from exc
    try:
        return data.decode("utf-8-sig"), []
    except UnicodeDecodeError:
        return data.decode("cp1252", errors="replace"), ["Berkas bukan UTF-8; dibaca sebagai Windows-1252. Periksa huruf bertanda baca, lalu simpan ulang sebagai UTF-8."]


def _finish(result: LoadedScript) -> LoadedScript:
    text = scrub_text(result.text).replace("\r\n", "\n").replace("\r", "\n").replace("\x00", "")
    if result.converted:  # extracted text gets tidied; a plain text file is left exactly as the author wrote it
        text = re.sub(r"\n{4,}", "\n\n\n", text).strip("\n") + ("\n" if text.strip() else "")
    if not text.strip():
        raise ScriptFileError("Berkas tidak berisi teks yang dapat dibaca." + (" Jika ini PDF hasil pindai, teksnya berupa gambar." if result.format == "pdf" else ""))
    if len(text.encode("utf-8")) > MAX_SCRIPT_BYTES:
        raise ScriptFileError(f"Teks hasil impor terlalu besar (batas {MAX_SCRIPT_BYTES / 1_000_000:.0f} MB).")
    if result.converted:
        result.notes.insert(0, f"Teks diambil dari berkas {result.format.upper()}; pemformatan tidak dibawa. Simpan sebagai berkas baru.")
    return LoadedScript(text, result.format, result.notes)


# ------------------------------------------------------------------------------ office archives
def _read_member(archive: zipfile.ZipFile, name: str) -> bytes:
    try:
        info = archive.getinfo(name)
    except KeyError as exc:
        raise ScriptFileError("Berkas rusak: isi dokumen tidak ditemukan.") from exc
    if info.file_size > MAX_MEMBER_BYTES:
        raise ScriptFileError("Dokumen terlalu besar setelah diekstrak.")
    with archive.open(info) as handle:
        data = handle.read(MAX_MEMBER_BYTES + 1)
    if len(data) > MAX_MEMBER_BYTES:
        raise ScriptFileError("Dokumen terlalu besar setelah diekstrak.")
    return data


def _parse_xml(data: bytes) -> ET.Element:
    head = data[:4096].upper()
    if b"<!DOCTYPE" in head or b"<!ENTITY" in data[:65536].upper():
        raise ScriptFileError("Dokumen ditolak: memuat deklarasi DOCTYPE/ENTITY yang tidak aman.")
    try:
        return ET.fromstring(data)
    except ET.ParseError as exc:
        raise ScriptFileError("Dokumen rusak: isi XML tidak valid.") from exc


def _open_zip(path: Path) -> zipfile.ZipFile:
    try:
        archive = zipfile.ZipFile(path)
    except (zipfile.BadZipFile, OSError) as exc:
        raise ScriptFileError("Berkas bukan dokumen yang valid atau rusak.") from exc
    if len(archive.infolist()) > 5000:
        archive.close()
        raise ScriptFileError("Dokumen berisi terlalu banyak bagian.")
    return archive


_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def _docx_text(path: Path) -> str:
    with _open_zip(path) as archive:
        root = _parse_xml(_read_member(archive, "word/document.xml"))
    lines: list[str] = []
    for paragraph in root.iter(f"{_W}p"):
        parts: list[str] = []
        for node in paragraph.iter():
            if node.tag == f"{_W}t":
                parts.append(node.text or "")
            elif node.tag == f"{_W}tab":
                parts.append("\t")
            elif node.tag in (f"{_W}br", f"{_W}cr"):
                parts.append("\n")
        lines.append("".join(parts))
    return "\n".join(lines)


_TEXT = "{urn:oasis:names:tc:opendocument:xmlns:text:1.0}"


def _odt_text(path: Path) -> str:
    with _open_zip(path) as archive:
        root = _parse_xml(_read_member(archive, "content.xml"))
    lines: list[str] = []

    def walk(node: ET.Element) -> str:
        out = [node.text or ""]
        for child in node:
            if child.tag == f"{_TEXT}line-break":
                out.append("\n")
            elif child.tag == f"{_TEXT}tab":
                out.append("\t")
            elif child.tag == f"{_TEXT}s":
                out.append(" " * min(int(child.get(f"{_TEXT}c", "1") or 1), 200))
            else:
                out.append(walk(child))
            out.append(child.tail or "")
        return "".join(out)

    for node in root.iter():
        if node.tag in (f"{_TEXT}p", f"{_TEXT}h"):
            lines.append(walk(node))
    return "\n".join(lines)


# ------------------------------------------------------------------------------ RTF
_RTF_SKIP = {"fonttbl", "colortbl", "stylesheet", "info", "pict", "header", "footer", "footnote", "object", "themedata", "colorschememapping", "latentstyles", "datastore"}
_RTF_TOKEN = re.compile(r"\\([a-zA-Z]+)(-?\d+)? ?|\\'([0-9a-fA-F]{2})|\\([^a-zA-Z])|([{}])|([^\\{}]+)")


def _rtf_text(source: str) -> str:
    if not source.lstrip().startswith("{\\rtf"):
        raise ScriptFileError("Berkas bukan RTF yang valid.")
    out: list[str] = []
    stack: list[bool] = []          # True = this group is being skipped
    skipping = False
    pending_star = False
    unicode_skip = 1
    skip_chars = 0
    for match in _RTF_TOKEN.finditer(source):
        word, number, hexa, symbol, brace, plain = match.groups()
        if brace == "{":
            stack.append(skipping)
            pending_star = True
        elif brace == "}":
            skipping = stack.pop() if stack else False
            pending_star = False
        elif plain is not None:
            if skip_chars:
                cut = min(skip_chars, len(plain))
                plain = plain[cut:]
                skip_chars -= cut
            if not skipping:
                out.append(plain.replace("\r", "").replace("\n", ""))
        elif hexa is not None:
            if not skipping:
                out.append(bytes([int(hexa, 16)]).decode("cp1252", errors="replace"))
        elif symbol is not None:
            if symbol == "*" and pending_star:
                skipping = True
            elif symbol in "\\{}" and not skipping:
                out.append(symbol)
            elif symbol == "~" and not skipping:
                out.append("\u00a0")
            pending_star = False
        elif word is not None:
            pending_star = False
            if word in _RTF_SKIP:
                skipping = True
            elif skipping:
                continue
            elif word in ("par", "line", "sect", "page"):
                out.append("\n")
            elif word == "tab":
                out.append("\t")
            elif word == "uc" and number:
                unicode_skip = max(0, min(int(number), 8))
            elif word == "u" and number:
                code = int(number)
                out.append(chr(code + 65536 if code < 0 else code) if 0 <= (code + 65536 if code < 0 else code) <= 0x10FFFF else "\ufffd")
                skip_chars = unicode_skip
            elif word in ("emdash", "endash", "lquote", "rquote", "ldblquote", "rdblquote", "bullet"):
                out.append({"emdash": "—", "endash": "–", "lquote": "‘", "rquote": "’", "ldblquote": "“", "rdblquote": "”", "bullet": "•"}[word])
    return "".join(out)


# ------------------------------------------------------------------------------ HTML
class _HTMLText(HTMLParser):
    BLOCKS = {"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "section", "article", "blockquote", "ul", "ol", "table", "pre"}
    SKIP = {"script", "style", "head", "template", "noscript"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self._skip = 0

    def handle_starttag(self, tag: str, attrs) -> None:  # noqa: ANN001
        if tag in self.SKIP:
            self._skip += 1
        elif tag in self.BLOCKS:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in self.SKIP:
            self._skip = max(0, self._skip - 1)
        elif tag in self.BLOCKS:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if not self._skip:
            self.parts.append(re.sub(r"[ \t\r\n]+", " ", data))


def _html_text(source: str) -> str:
    parser = _HTMLText()
    parser.feed(source)
    parser.close()
    text = html.unescape("".join(parser.parts))
    return "\n".join(line.strip() for line in text.split("\n"))


# ------------------------------------------------------------------------------ PDF (optional pypdf)
def _pdf_text(path: Path) -> str:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise ScriptFileError("Membuka PDF membutuhkan pustaka pypdf. Pasang dengan `sudo apt install python3-pypdf` atau `pip install pypdf`.") from exc
    import logging

    logging.getLogger("pypdf").setLevel(logging.CRITICAL)  # it prints warnings for every malformed file
    try:
        reader = PdfReader(str(path))
        if reader.is_encrypted:
            raise ScriptFileError("PDF terkunci dengan kata sandi; buka kuncinya dahulu.")
        pages = reader.pages[:MAX_PDF_PAGES]
        return "\n\n".join((page.extract_text() or "") for page in pages)
    except ScriptFileError:
        raise
    except Exception as exc:  # noqa: BLE001 - a malformed PDF can raise anything; report it, never crash
        raise ScriptFileError(f"PDF tidak dapat dibaca ({type(exc).__name__}).") from exc
