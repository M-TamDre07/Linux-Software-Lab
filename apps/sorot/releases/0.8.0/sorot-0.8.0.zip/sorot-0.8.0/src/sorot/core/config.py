"""Versioned, validated application configuration stored as JSON.

Design notes
------------
* Everything is sanitised on load: a hand-edited or partially corrupt file can
  never push an out-of-range value into the UI.
* Unknown keys are preserved so a downgrade does not silently drop settings
  written by a newer version.
* Writes are atomic and the previous file is kept as ``config.json.bak``.
* A corrupt file is moved aside (never deleted) and defaults are used.
* API keys are never part of the configuration.
"""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
import time
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from sorot.core import paths
from sorot.core.fileio import atomic_write_text, scrub_text
from sorot.core.script_stats import DEFAULT_WPM, MAX_WPM, MIN_WPM

LOGGER = logging.getLogger(__name__)

SCHEMA_VERSION = 4

POSITIONS = (
    "top-left", "top-center", "top-right", "center",
    "bottom-left", "bottom-center", "bottom-right", "manual",
)
POSITION_LABELS = {
    "top-left": "Atas kiri", "top-center": "Atas tengah", "top-right": "Atas kanan",
    "center": "Tengah", "bottom-left": "Bawah kiri", "bottom-center": "Bawah tengah",
    "bottom-right": "Bawah kanan", "manual": "Posisi manual",
}
ALIGNMENTS = ("left", "center", "right", "justify")
FONT_WEIGHTS = ("normal", "demibold", "bold")
ALIGNMENT_LABELS = {"left": "Kiri", "center": "Tengah", "right": "Kanan", "justify": "Rata kiri-kanan"}
THEMES = ("dark", "light", "system")
THEME_LABELS = {"dark": "Studio gelap", "light": "Kertas terang", "system": "Ikuti tema sistem"}
SPEED_MODES = ("pps", "wpm", "duration")
SPEED_MODE_LABELS = {"pps": "Piksel/detik", "wpm": "Kata/menit", "duration": "Durasi target"}
QT_PLATFORMS = ("auto", "xcb", "wayland")

DEFAULT_SHORTCUTS: dict[str, str] = {
    "show_overlay": "Ctrl+Return",
    "toggle_scroll": "Ctrl+Space",
    "hide_overlay": "Esc",
    "reset_scroll": "Ctrl+R",
    "speed_up": "Alt+Up",
    "speed_down": "Alt+Down",
}
SHORTCUT_LABELS = {
    "show_overlay": "Tampilkan overlay",
    "toggle_scroll": "Mulai / jeda gulir",
    "hide_overlay": "Sembunyikan overlay",
    "reset_scroll": "Kembali ke atas",
    "speed_up": "Percepat gulir",
    "speed_down": "Perlambat gulir",
}

# Appearance presets (text colour, background colour, background opacity).
COLOR_PRESETS: dict[str, tuple[str, str, int]] = {
    "Gelap (putih di biru tua)": ("#F7F9FC", "#0C121F", 58),
    "Terang (hitam di putih)": ("#111827", "#FFFFFF", 88),
    "Kontras tinggi (kuning di hitam)": ("#FFE94A", "#000000", 90),
    "Lembut (krem di abu gelap)": ("#FFE7A3", "#1B1F27", 70),
    "Hijau (hijau muda di hitam)": ("#B8F7D4", "#06130C", 75),
    "Amber (amber di hitam)": ("#FFB000", "#0A0804", 85),
}

LEGACY_COLOR_NAMES = {
    "Putih": "#F7F9FC", "Kuning lembut": "#FFE7A3", "Biru muda": "#BDEBFF",
    "Hitam": "#111827", "Hijau muda": "#B8F7D4",
}
LEGACY_POSITION_LABELS = {label: key for key, label in POSITION_LABELS.items()}

_HEX_COLOR = re.compile(r"#[0-9A-Fa-f]{6}")


# --------------------------------------------------------------------------
# Coercion helpers
# --------------------------------------------------------------------------
def _to_int(value: Any, default: int, low: int, high: int) -> int:
    if isinstance(value, bool):
        return default
    try:
        number = int(float(value))
    except (TypeError, ValueError, OverflowError):  # OverflowError: 1e999 / Infinity / ints too large for a float
        return default
    return max(low, min(high, number))


def _to_bool(value: Any, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"true", "1", "yes", "ya"}:
            return True
        if lowered in {"false", "0", "no", "tidak"}:
            return False
    return default


def _to_choice(value: Any, allowed: tuple[str, ...], default: str) -> str:
    return value if isinstance(value, str) and value in allowed else default


def _to_color(value: Any, default: str) -> str:
    if isinstance(value, str) and _HEX_COLOR.fullmatch(value.strip()):
        return value.strip().upper()
    return default


def _to_str(value: Any, default: str, max_len: int = 500) -> str:
    return scrub_text(value).strip()[:max_len] if isinstance(value, str) else default


def _to_optional_int(value: Any) -> int | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError, OverflowError):
        return None


_EXT_KEY = re.compile(r"[a-z0-9][a-z0-9._-]{2,63}")
_EXT_THEME = re.compile(r"[a-z0-9][a-z0-9._-]{2,63}/[a-z0-9][a-z0-9._-]{0,47}")
_SHA256 = re.compile(r"[0-9a-f]{64}")


def _to_extension_states(value: Any) -> dict[str, dict[str, Any]]:
    """``{ext_id: {"enabled": bool, "approved_hash": sha256-or-empty}}`` with junk dropped."""
    if not isinstance(value, dict):
        return {}
    cleaned: dict[str, dict[str, Any]] = {}
    for key, state in list(value.items())[:200]:
        if not (isinstance(key, str) and _EXT_KEY.fullmatch(key) and isinstance(state, dict)):
            continue
        digest = state.get("approved_hash", "")
        cleaned[key] = {
            "enabled": _to_bool(state.get("enabled"), False),
            "approved_hash": digest if isinstance(digest, str) and (digest == "" or _SHA256.fullmatch(digest)) else "",
        }
    return cleaned


def _to_str_list(value: Any, max_items: int = 50) -> list[str]:
    if not isinstance(value, list):
        return []
    return [scrub_text(item).strip()[:200] for item in value if isinstance(item, str) and item.strip()][:max_items]


# --------------------------------------------------------------------------
# Configuration object
# --------------------------------------------------------------------------
@dataclass
class AppConfig:
    # Overlay appearance
    font_family: str = ""
    font_size: int = 30
    text_color: str = "#F7F9FC"
    background_color: str = "#0C121F"
    background_opacity: int = 58
    text_align: str = "left"
    margin: int = 16
    font_weight: str = "demibold"  # 0.7.0
    line_spacing: int = 100  # percent of the font's natural line height (0.7.0)
    letter_spacing: int = 0  # percent added to the normal letter spacing (0.7.0)
    mirror: bool = False  # flip the text horizontally for beam-splitter rigs (0.7.0)
    show_countdown: bool = True  # show the start-delay countdown on the overlay (0.7.0)
    profile: str = ""  # name of the display profile last applied; informational (0.7.0)
    # Overlay window
    overlay_width: int = 760
    overlay_height: int = 230
    position: str = "top-center"
    screen_name: str = ""
    overlay_x: int | None = None
    overlay_y: int | None = None
    always_on_top: bool = True
    frameless: bool = True
    click_through: bool = False
    # Reading behaviour
    speed_mode: str = "wpm"
    scroll_speed: int = 28
    target_seconds: int = 180
    guide_enabled: bool = True
    guide_position: int = 33
    show_progress: bool = True
    start_delay: int = 0
    auto_stop_minutes: int = 0
    wpm: int = DEFAULT_WPM
    # Application
    theme: str = "dark"
    qt_platform: str = "auto"
    shortcuts: dict[str, str] = field(default_factory=lambda: dict(DEFAULT_SHORTCUTS))
    last_directory: str = ""
    window_width: int = 1100
    window_height: int = 680
    # Extensions: per-extension enable/approval state, and an optional extension theme ("ext_id/theme_id")
    extensions: dict[str, dict[str, Any]] = field(default_factory=dict)
    theme_ext: str = ""
    # Optional AI (never contains the API key)
    ai_base_url: str = "https://api.openai.com/v1"
    ai_model: str = "gpt-4.1-mini"
    ai_timeout: int = 60
    ai_confirmed_hosts: list[str] = field(default_factory=list)
    # Unknown keys from newer versions, kept so they survive a round trip.
    extra: dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> AppConfig:
        d = cls()
        known = {
            "font_family", "font_size", "text_color", "background_color", "background_opacity",
            "text_align", "margin", "overlay_width", "overlay_height", "position", "screen_name",
            "overlay_x", "overlay_y", "always_on_top", "frameless", "click_through", "scroll_speed",
            "extensions", "theme_ext", "speed_mode", "target_seconds", "guide_enabled", "guide_position", "show_progress", "window_width", "window_height",
            "start_delay", "auto_stop_minutes", "wpm", "theme", "qt_platform", "shortcuts",
            "last_directory", "ai_base_url", "ai_model", "ai_timeout", "ai_confirmed_hosts",
            "schema_version", "extra",
            "font_weight", "line_spacing", "letter_spacing", "mirror", "show_countdown", "profile",
        }
        get = data.get
        d.font_family = _to_str(get("font_family"), d.font_family, 120)
        d.font_size = _to_int(get("font_size"), d.font_size, 12, 120)
        d.text_color = _to_color(get("text_color"), d.text_color)
        d.background_color = _to_color(get("background_color"), d.background_color)
        d.background_opacity = _to_int(get("background_opacity"), d.background_opacity, 0, 95)
        d.text_align = _to_choice(get("text_align"), ALIGNMENTS, d.text_align)
        d.margin = _to_int(get("margin"), d.margin, 0, 120)
        d.font_weight = _to_choice(get("font_weight"), FONT_WEIGHTS, d.font_weight)
        d.line_spacing = _to_int(get("line_spacing"), d.line_spacing, 100, 250)
        d.letter_spacing = _to_int(get("letter_spacing"), d.letter_spacing, 0, 30)
        d.mirror = _to_bool(get("mirror"), d.mirror)
        d.show_countdown = _to_bool(get("show_countdown"), d.show_countdown)
        d.profile = _to_str(get("profile"), "", 60)
        d.overlay_width = _to_int(get("overlay_width"), d.overlay_width, 300, 4000)
        d.overlay_height = _to_int(get("overlay_height"), d.overlay_height, 100, 2400)
        d.position = _to_choice(get("position"), POSITIONS, d.position)
        d.screen_name = _to_str(get("screen_name"), "", 200)
        d.overlay_x = _to_optional_int(get("overlay_x"))
        d.overlay_y = _to_optional_int(get("overlay_y"))
        d.always_on_top = _to_bool(get("always_on_top"), d.always_on_top)
        d.frameless = _to_bool(get("frameless"), d.frameless)
        d.click_through = _to_bool(get("click_through"), d.click_through)
        d.speed_mode = _to_choice(get("speed_mode"), SPEED_MODES, d.speed_mode)
        d.scroll_speed = _to_int(get("scroll_speed"), d.scroll_speed, 0, 400)
        d.target_seconds = _to_int(get("target_seconds"), d.target_seconds, 10, 14400)
        d.guide_enabled = _to_bool(get("guide_enabled"), d.guide_enabled)
        d.guide_position = _to_int(get("guide_position"), d.guide_position, 10, 70)
        d.show_progress = _to_bool(get("show_progress"), d.show_progress)
        d.extensions = _to_extension_states(get("extensions"))
        theme_ext = get("theme_ext")
        d.theme_ext = theme_ext if isinstance(theme_ext, str) and _EXT_THEME.fullmatch(theme_ext) else ""
        d.window_width = _to_int(get("window_width"), d.window_width, 640, 4000)
        d.window_height = _to_int(get("window_height"), d.window_height, 480, 3000)
        d.start_delay = _to_int(get("start_delay"), d.start_delay, 0, 120)
        d.auto_stop_minutes = _to_int(get("auto_stop_minutes"), d.auto_stop_minutes, 0, 240)
        d.wpm = _to_int(get("wpm"), d.wpm, MIN_WPM, MAX_WPM)
        d.theme = _to_choice(get("theme"), THEMES, d.theme)
        d.qt_platform = _to_choice(get("qt_platform"), QT_PLATFORMS, d.qt_platform)
        shortcuts = dict(DEFAULT_SHORTCUTS)
        raw_shortcuts = get("shortcuts")
        if isinstance(raw_shortcuts, dict):
            for name in DEFAULT_SHORTCUTS:
                value = raw_shortcuts.get(name)
                if isinstance(value, str) and len(value) <= 40:
                    shortcuts[name] = value.strip()
        d.shortcuts = shortcuts
        d.last_directory = _to_str(get("last_directory"), "", 1000)
        d.ai_base_url = _to_str(get("ai_base_url"), d.ai_base_url, 500) or "https://api.openai.com/v1"
        d.ai_model = _to_str(get("ai_model"), d.ai_model, 200) or "gpt-4.1-mini"
        d.ai_timeout = _to_int(get("ai_timeout"), d.ai_timeout, 10, 180)
        d.ai_confirmed_hosts = _to_str_list(get("ai_confirmed_hosts"))
        extra = {k: v for k, v in data.items() if k not in known}
        previous_extra = get("extra")
        if isinstance(previous_extra, dict):
            extra = {**previous_extra, **extra}
        d.extra = extra
        return d

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {"schema_version": SCHEMA_VERSION}
        for name in self.__dataclass_fields__:
            if name == "extra":
                continue
            result[name] = getattr(self, name)
        result.update(self.extra)  # unknown keys never override known ones
        for name in self.__dataclass_fields__:
            if name != "extra":
                result[name] = getattr(self, name)
        result["schema_version"] = SCHEMA_VERSION
        return result


# --------------------------------------------------------------------------
# Schema upgrades (JSON -> JSON)
# --------------------------------------------------------------------------
def _migrate_2_to_3(data: dict[str, Any]) -> dict[str, Any]:
    """``scroll_speed`` always meant pixels/second, so existing users keep ``speed_mode = "pps"``
    and see no change in behaviour. New installs default to the speaking-speed mode."""
    if "speed_mode" not in data:
        data["speed_mode"] = "pps"
    return data


#: ``{from_version: step}``. Each step turns a dict of schema ``from_version`` into ``from_version + 1``.
#: Raising ``SCHEMA_VERSION`` WITHOUT adding the matching step here fails ``tests/test_config.py``.
#: Version 1 (no ``schema_version`` key) and 2 have no structural difference, so 1 -> 2 is the identity.
MIGRATIONS: dict[int, Any] = {
    1: lambda data: data,
    2: _migrate_2_to_3,
    3: lambda data: data,  # 0.7.0 only added keys (font_weight, line_spacing, mirror, ...) whose defaults reproduce the old look
}


def upgrade_schema(data: Mapping[str, Any]) -> dict[str, Any]:
    """Bring an older configuration dict up to ``SCHEMA_VERSION`` by applying ``MIGRATIONS`` in order.

    Input is never mutated. A dict already at (or above) ``SCHEMA_VERSION`` is returned unchanged,
    which is what lets a downgrade keep settings written by a newer version.
    """
    upgraded = dict(data)
    version = upgraded.get("schema_version")
    version = version if isinstance(version, int) and version >= 1 else 1
    while version < SCHEMA_VERSION:
        upgraded = MIGRATIONS[version](upgraded)
        version += 1
    return upgraded


# --------------------------------------------------------------------------
# Migration from Sorot 0.3.x (QSettings)
# --------------------------------------------------------------------------
def migrate_legacy_values(values: Mapping[str, Any]) -> tuple[AppConfig, str]:
    """Convert 0.3.x QSettings values to an ``AppConfig`` and the last script.

    The caller reads the old settings file (read-only) and passes a plain dict,
    which keeps this function independent of Qt and trivially testable.
    """
    data: dict[str, Any] = {}
    simple = (
        "font_size", "background_opacity", "overlay_width", "overlay_height", "scroll_speed",
        "start_delay", "auto_stop_minutes", "click_through", "overlay_x", "overlay_y",
        "ai_base_url", "ai_model",
    )
    for key in simple:
        if key in values:
            data[key] = values[key]
    color_name = values.get("text_color_name")
    if isinstance(color_name, str) and color_name in LEGACY_COLOR_NAMES:
        data["text_color"] = LEGACY_COLOR_NAMES[color_name]
    position = values.get("position")
    if isinstance(position, str) and position in LEGACY_POSITION_LABELS:
        data["position"] = LEGACY_POSITION_LABELS[position]
    data["speed_mode"] = "pps"  # 0.3.x speed was always pixels per second
    config = AppConfig.from_dict(data)
    # A manual position without stored coordinates cannot be honoured.
    if config.position == "manual" and (config.overlay_x is None or config.overlay_y is None):
        config.position = "top-center"
    text = values.get("text", "")
    return config, text if isinstance(text, str) else ""


# --------------------------------------------------------------------------
# Persistence
# --------------------------------------------------------------------------
@dataclass
class LoadResult:
    config: AppConfig
    notices: list[str] = field(default_factory=list)
    is_new: bool = False
    loaded_schema: int | None = None


class ConfigStore:
    def __init__(self, path: Path | None = None) -> None:
        self.path = Path(path) if path is not None else paths.config_file()

    @property
    def backup_path(self) -> Path:
        return self.path.with_name(self.path.name + ".bak")

    def load(self) -> LoadResult:
        if not self.path.exists():
            return LoadResult(AppConfig(), is_new=True)
        try:
            raw = self.path.read_text(encoding="utf-8")
            data = json.loads(raw)
            if not isinstance(data, dict):
                raise ValueError("isi konfigurasi bukan objek JSON")
        except (OSError, ValueError, UnicodeDecodeError) as exc:
            moved = self._quarantine()
            LOGGER.warning("Konfigurasi tidak dapat dibaca (%s); memakai nilai bawaan.", type(exc).__name__)
            where = f" Berkas lama disimpan sebagai {moved.name}." if moved else ""
            return LoadResult(
                AppConfig(),
                notices=[f"Berkas pengaturan rusak sehingga nilai bawaan dipakai.{where}"],
                is_new=True,
            )
        schema = data.get("schema_version")
        notices: list[str] = []
        if isinstance(schema, int) and schema > SCHEMA_VERSION:
            notices.append(
                "Pengaturan dibuat oleh versi Sorot yang lebih baru. Nilai yang dikenal tetap dipakai, "
                "sisanya dipertahankan saat menyimpan."
            )
        try:
            config = AppConfig.from_dict(upgrade_schema(data))
        except Exception as exc:  # defence in depth: a hostile or odd value must never stop the app starting
            moved = self._quarantine()
            LOGGER.warning("Konfigurasi tidak dapat diproses (%s); memakai nilai bawaan.", type(exc).__name__)
            where = f" Berkas lama disimpan sebagai {moved.name}." if moved else ""
            return LoadResult(AppConfig(), notices=[f"Isi berkas pengaturan tidak valid sehingga nilai bawaan dipakai.{where}"], is_new=True)
        return LoadResult(config, notices, loaded_schema=schema if isinstance(schema, int) else None)

    def save(self, config: AppConfig) -> None:
        payload = json.dumps(config.to_dict(), ensure_ascii=False, indent=2, sort_keys=True) + "\n"
        try:
            if self.path.exists() and self.path.read_text(encoding="utf-8") == payload:
                return
        except (OSError, UnicodeDecodeError):
            pass
        if self.path.exists():
            try:  # copy beside the target and rename, so a crash never leaves a truncated .bak
                partial = self.backup_path.with_name(f".{self.backup_path.name}.tmp")
                shutil.copy2(self.path, partial)
                os.replace(partial, self.backup_path)
            except OSError as exc:
                LOGGER.warning("Cadangan pengaturan gagal dibuat: %s", exc.strerror or exc)
        atomic_write_text(self.path, payload)

    def restore_backup(self) -> bool:
        """Replace the current configuration with the last backup, if valid."""
        try:
            data = json.loads(self.backup_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                return False
        except (OSError, ValueError, UnicodeDecodeError):
            return False
        try:
            restored = AppConfig.from_dict(upgrade_schema(data))
        except Exception:  # an unusable backup is reported as "no valid backup", never as a crash
            return False
        atomic_write_text(self.path, json.dumps(restored.to_dict(), ensure_ascii=False, indent=2, sort_keys=True) + "\n")
        return True

    def _quarantine(self) -> Path | None:
        target = self.path.with_name(f"{self.path.name}.corrupt-{time.strftime('%Y%m%d-%H%M%S')}")
        try:
            self.path.replace(target)
            return target
        except OSError:
            return None
