"""Floating, transparent prompt window.

Playback
--------
The text does not scroll at a fixed pixel speed. ``core.timeline`` converts the
script and the current line layout into a time -> position curve that follows
the speaker (words per minute, a target duration, or constant pixels/second),
including ``[jeda]`` cue holds. The overlay samples that curve from a monotonic
clock, so speed is exact even if the event loop stalls; start and stop are
eased; and scrolling by hand while playing re-anchors the clock to where the
reader actually is.

Window-system notes
-------------------
* Moving and resizing prefer ``QWindow.startSystemMove/Resize`` (the only way
  that works on native Wayland); a manual ``move()`` is only a fallback.
* The window never takes keyboard focus.
* "Always on top" and "click-through" are *requests*; see ``services.platform_info``.
"""
from __future__ import annotations

import math
import time
from typing import Any

from PySide6.QtCore import QEvent, QPoint, QPointF, QRect, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFontMetrics, QPainter, QPolygonF, QTextFrameFormat
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QSizeGrip, QTextEdit, QVBoxLayout, QWidget

from sorot.core.script_markup import ParsedScript, parse_script
from sorot.core.script_stats import format_clock
from sorot.core.timeline import LineBox, SpeedMode, Timeline, build_timeline
from sorot.ui import appearance, theme

PLACEHOLDER = "Naskah kamu akan muncul di sini."
RAMP_UP_SECONDS = 0.20
RAMP_DOWN_SECONDS = 0.14
TICK_MS = 16
PROGRESS_EMIT_SECONDS = 0.25
SCRUB_TOLERANCE_PX = 2


def _controls_qss() -> str:
    p = theme.palette()
    return (
        "QFrame#controls { background: rgba(10, 9, 7, 225); border: 1px solid rgba(235, 229, 214, 90); border-radius: 3px; }"
        "QFrame#controls QPushButton { background: rgba(255, 255, 255, 18); color: #EBE5D6; border: 1px solid rgba(235, 229, 214, 70);"
        " border-radius: 2px; padding: 3px 9px; font-size: 9pt; font-weight: 700; min-height: 18px; }"
        "QFrame#controls QPushButton:hover { background: #FFB000; color: #1B1300; border-color: #FFB000; }"
        "QLabel#grip { color: #FFB000; font-size: 9pt; font-weight: 800; padding: 2px 8px; background: transparent; }"
        f"QLabel#clock {{ color: #EBE5D6; font-family: {theme.FONT_MONO}; font-size: 9pt; font-weight: 700; padding: 0 6px; background: transparent; }}"
    ) + ("" if p else "")


class _DragHandle(QLabel):
    pressed = Signal()

    def mousePressEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self.pressed.emit()
            event.accept()
        else:
            super().mousePressEvent(event)


class _Decor(QWidget):
    """Reading guide, side markers, and progress line drawn over the text."""

    def __init__(self, parent: QWidget) -> None:
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.color = QColor("#F7F9FC")
        self.guide = True
        self.band_top = 0.0
        self.band_height = 40.0
        self.show_progress = True
        self.progress = 0.0
        self.clock = ""

    def paintEvent(self, _event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        if self.guide:
            fill = QColor(self.color)
            fill.setAlpha(30)
            painter.fillRect(QRect(6, int(self.band_top), self.width() - 12, int(self.band_height)), fill)
            mark = QColor(self.color)
            mark.setAlpha(210)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(mark)
            mid = self.band_top + self.band_height / 2
            painter.drawPolygon(QPolygonF([QPointF(1, mid - 6), QPointF(8, mid), QPointF(1, mid + 6)]))
            w = self.width()
            painter.drawPolygon(QPolygonF([QPointF(w - 1, mid - 6), QPointF(w - 8, mid), QPointF(w - 1, mid + 6)]))
        if self.show_progress:
            track = QColor(self.color)
            track.setAlpha(36)
            painter.fillRect(QRect(0, self.height() - 3, self.width(), 3), track)
            bar = QColor(self.color)
            bar.setAlpha(190)
            painter.fillRect(QRect(0, self.height() - 3, int(self.width() * max(0.0, min(1.0, self.progress))), 3), bar)


class PromptOverlay(QWidget):
    geometryChangedByUser = Signal()
    scrollingChanged = Signal(bool)
    progressChanged = Signal(float, float)  # elapsed seconds, total seconds
    playPauseRequested = Signal()
    resetRequested = Signal()
    hideRequested = Signal()
    speedAdjustRequested = Signal(int)  # +1 faster, -1 slower (steps)

    def __init__(self) -> None:
        super().__init__()
        self.always_on_top = True
        self.frameless = True
        self.click_through = False
        self._manual_origin: QPoint | None = None
        self._window_origin: QPoint | None = None
        self._last_programmatic = QRect()
        self._applied_flags: Qt.WindowType | None = None
        self._appearance: dict[str, Any] = {}

        # playback state
        self._parsed: ParsedScript = parse_script("")
        self._has_content = False
        self._mode = SpeedMode.WPM
        self._pps = 28.0
        self._wpm = 130.0
        self._target_seconds = 180.0
        self._guide = True
        self._guide_fraction = 0.33
        self._show_progress = True
        self._timeline: Timeline | None = None
        self._dirty = True
        self._playing = False
        self._finished = False
        self._elapsed = 0.0
        self._factor = 0.0
        self._last_tick: float | None = None
        self._last_value = 0
        self._last_progress_emit = 0.0

        self.tick_timer = QTimer(self)
        self.tick_timer.setInterval(TICK_MS)
        self.tick_timer.setTimerType(Qt.TimerType.PreciseTimer)
        self.tick_timer.timeout.connect(self._tick)
        self._geometry_timer = QTimer(self)
        self._geometry_timer.setSingleShot(True)
        self._geometry_timer.setInterval(350)
        self._geometry_timer.timeout.connect(self._maybe_emit_user_geometry)
        self._relayout_timer = QTimer(self)
        self._relayout_timer.setSingleShot(True)
        self._relayout_timer.setInterval(80)
        self._relayout_timer.timeout.connect(self._relayout)

        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setWindowTitle("Sorot — Overlay")
        self.setMinimumSize(QSize(300, 100))

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        self.panel = QFrame(self)
        self.panel.setObjectName("panel")
        self._inner = QVBoxLayout(self.panel)
        self.text_view = QTextEdit(self.panel)
        self.text_view.setReadOnly(True)
        self.text_view.setAcceptRichText(False)
        self.text_view.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.text_view.setFrameShape(QFrame.Shape.NoFrame)
        self.text_view.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        # No visible scrollbar (cleaner for presenting); the mouse wheel still scrolls by hand.
        self.text_view.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.text_view.setAccessibleName("Naskah teleprompter")
        self._inner.addWidget(self.text_view)
        outer.addWidget(self.panel)

        # Start-delay countdown, drawn over the text; transparent to the mouse.
        self.countdown_label = QLabel("", self.panel)
        self.countdown_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.countdown_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.countdown_label.setAccessibleName("Hitung mundur")
        self.countdown_label.hide()

        self.decor = _Decor(self.panel)
        self.controls = self._build_controls()
        self.controls.hide()
        self.grip = QSizeGrip(self.panel)
        self.grip.setFixedSize(16, 16)

        self.panel.installEventFilter(self)
        self.text_view.installEventFilter(self)
        self.text_view.viewport().installEventFilter(self)
        self.set_appearance()
        self.set_text("")
        self._apply_flags()

    # ------------------------------------------------------------------ build
    def _build_controls(self) -> QFrame:
        bar = QFrame(self.panel)
        bar.setObjectName("controls")
        bar.setStyleSheet(_controls_qss())
        row = QHBoxLayout(bar)
        row.setContentsMargins(6, 4, 6, 4)
        row.setSpacing(5)
        self.drag_handle = _DragHandle("⠿ GESER")
        self.drag_handle.setObjectName("grip")
        self.drag_handle.setCursor(Qt.CursorShape.SizeAllCursor)
        self.drag_handle.setToolTip("Tahan dan seret untuk memindahkan overlay")
        self.drag_handle.pressed.connect(self.begin_move)
        self.clock_label = QLabel("")
        self.clock_label.setObjectName("clock")
        self.play_button = QPushButton("MULAI")
        self.reset_button = QPushButton("AWAL")
        self.slower_button = QPushButton("−")
        self.faster_button = QPushButton("+")
        self.hide_button = QPushButton("TUTUP")
        for button, tip in (
            (self.play_button, "Mulai atau jeda gulir"), (self.reset_button, "Kembali ke awal naskah"),
            (self.slower_button, "Perlambat gulir"), (self.faster_button, "Percepat gulir"),
            (self.hide_button, "Sembunyikan overlay"),
        ):
            button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            button.setToolTip(tip)
            button.setAccessibleName(tip)
        row.addWidget(self.drag_handle)
        row.addWidget(self.clock_label)
        for button in (self.play_button, self.reset_button, self.slower_button, self.faster_button, self.hide_button):
            row.addWidget(button)
        self.play_button.clicked.connect(self.playPauseRequested)
        self.reset_button.clicked.connect(self.resetRequested)
        self.hide_button.clicked.connect(self.hideRequested)
        self.slower_button.clicked.connect(lambda: self.speedAdjustRequested.emit(-1))
        self.faster_button.clicked.connect(lambda: self.speedAdjustRequested.emit(1))
        bar.adjustSize()
        return bar

    # ------------------------------------------------------------- appearance
    def set_appearance(
        self, *, font_family: str = "", font_size: int = 30, text_color: str = "#F7F9FC",
        background_color: str = "#0C121F", background_opacity: int = 58, text_align: str = "left", margin: int = 16,
        font_weight: str = "demibold", line_spacing: int = 100, letter_spacing: int = 0, mirror: bool = False,
    ) -> None:
        self._appearance = {
            "font_family": font_family, "font_size": font_size, "text_color": text_color, "background_color": background_color,
            "background_opacity": background_opacity, "text_align": text_align, "margin": margin,
            "font_weight": font_weight, "line_spacing": line_spacing, "letter_spacing": letter_spacing, "mirror": mirror,
        }
        self._restyle()

    def _restyle(self) -> None:
        a = self._appearance
        self.panel.setStyleSheet(appearance.panel_stylesheet(a["background_color"], a["background_opacity"], rounded=self.frameless))
        self.text_view.setStyleSheet(appearance.text_stylesheet(a["text_color"]))
        self.text_view.setFont(appearance.make_font(a["font_family"], a["font_size"], a["font_weight"], a["letter_spacing"]))
        self.text_view.document().setDefaultTextOption(appearance.text_option(a["text_align"]))
        appearance.apply_line_spacing(self.text_view.document(), a["line_spacing"])
        appearance.set_mirrored(self.text_view, bool(a["mirror"]))
        appearance.set_mirrored(self.countdown_label, bool(a["mirror"]))
        # A near-opaque backdrop in the overlay's own colour: a bare digit drawn over moving script text was unreadable.
        backdrop = QColor(a["background_color"])
        backdrop_css = f"rgba({backdrop.red()}, {backdrop.green()}, {backdrop.blue()}, 235)"
        self.countdown_label.setStyleSheet(f"QLabel {{ background: {backdrop_css}; color: {a['text_color']}; }}")
        margin = a["margin"]
        self._inner.setContentsMargins(margin + 2, max(6, margin - 3), margin, max(6, margin - 3))
        self.decor.color = QColor(a["text_color"])
        self._mark_dirty()
        self._relayout_timer.start()

    # --------------------------------------------------------------- content
    def set_text(self, raw: str) -> None:
        self.set_script(parse_script(raw))

    def set_script(self, parsed: ParsedScript) -> None:
        bar = self.text_view.verticalScrollBar()
        previous = bar.value()
        self._parsed = parsed
        self._has_content = parsed.words > 0 or parsed.cue_seconds > 0
        self.text_view.setPlainText(parsed.display_text if self._has_content else PLACEHOLDER)
        appearance.apply_line_spacing(self.text_view.document(), self._appearance.get("line_spacing", 100))
        self._apply_frame_margins()
        bar.setValue(min(previous, bar.maximum()))
        self._last_value = bar.value()
        self._finished = False
        self._mark_dirty()

    def set_speed(self, mode: str, *, pps: float, wpm: float, target_seconds: float) -> None:
        self._mode = SpeedMode(mode) if mode in {m.value for m in SpeedMode} else SpeedMode.WPM
        self._pps, self._wpm, self._target_seconds = float(pps), float(wpm), float(target_seconds)
        self._mark_dirty()

    def set_guide(self, *, enabled: bool, position_percent: int, show_progress: bool) -> None:
        self._guide, self._guide_fraction = enabled, max(0.05, min(0.8, position_percent / 100))
        self._show_progress = show_progress
        self.decor.guide, self.decor.show_progress = enabled, show_progress
        self.clock_label.setVisible(show_progress)
        self._apply_frame_margins()
        self._mark_dirty()
        self.decor.update()

    # ----------------------------------------------------- layout and timeline
    def _band_offset(self) -> float:
        return self.text_view.viewport().height() * self._guide_fraction if self._guide else 0.0

    def _apply_frame_margins(self) -> None:
        """Leave room above the first line (so it starts at the guide) and below the last."""
        doc = self.text_view.document()
        frame = doc.rootFrame()
        fmt: QTextFrameFormat = frame.frameFormat()
        offset = self._band_offset()
        fmt.setTopMargin(offset)
        fmt.setBottomMargin(max(0.0, self.text_view.viewport().height() - offset))
        frame.setFrameFormat(fmt)
        metrics = QFontMetrics(self.text_view.font())
        origin = self.text_view.mapTo(self.panel, QPoint(0, 0)).y()
        self.decor.band_top = origin + offset
        self.decor.band_height = metrics.lineSpacing() * 1.1 * (self._appearance.get("line_spacing", 100) / 100)

    def _relayout(self) -> None:
        self._apply_frame_margins()
        self._mark_dirty()
        self._ensure_timeline()

    def _mark_dirty(self) -> None:
        self._dirty = True
        QTimer.singleShot(0, self._ensure_timeline)

    def _line_boxes(self) -> list[LineBox]:
        doc = self.text_view.document()
        layout = doc.documentLayout()
        offset = self._band_offset()
        boxes: list[LineBox] = []
        block = doc.begin()
        while block.isValid():
            rect = layout.blockBoundingRect(block)
            boxes.append(LineBox(rect.top() - offset, rect.bottom() - offset))
            block = block.next()
        return boxes

    def _ensure_timeline(self) -> Timeline | None:
        if not self._dirty:  # also when there is no timeline (empty script): never rebuild in a loop
            return self._timeline
        self._dirty = False
        if not self._has_content:
            self._timeline = None
            self._emit_progress(force=True)
            return None
        bar = self.text_view.verticalScrollBar()
        timeline = build_timeline(
            self._parsed.blocks, self._line_boxes(), mode=self._mode, wpm=self._wpm, pps=self._pps,
            target_seconds=self._target_seconds,
        )
        self._timeline = timeline
        # Keep the reader where they are: re-derive the clock from the current position.
        self._elapsed = timeline.time_at(bar.value()) if (self._playing or bar.value() > 0 or self._elapsed > 0) else 0.0
        self._elapsed = min(self._elapsed, timeline.duration)
        self._emit_progress(force=True)
        return timeline

    # ---------------------------------------------------------------- playback
    def is_scrolling(self) -> bool:
        return self._playing

    def can_scroll(self) -> bool:
        if not self._has_content:
            return False
        return not (self._mode is SpeedMode.PPS and self._pps <= 0)

    def at_end(self) -> bool:
        timeline = self._timeline
        if self._finished:
            return True
        return bool(timeline and timeline.duration > 0 and self._elapsed >= timeline.duration - 1e-6)

    def duration(self) -> float:
        timeline = self._ensure_timeline()
        return timeline.duration if timeline else 0.0

    def elapsed(self) -> float:
        return self._elapsed

    def effective_wpm(self) -> float:
        timeline = self._ensure_timeline()
        return timeline.effective_wpm if timeline else 0.0

    def start_scrolling(self) -> None:
        timeline = self._ensure_timeline()
        if timeline is None or timeline.duration <= 0 or not self.can_scroll():
            return
        bar = self.text_view.verticalScrollBar()
        if self._finished or self.at_end():
            self._finished = False
            self._elapsed = 0.0
            bar.setValue(0)
        else:
            self._elapsed = timeline.time_at(bar.value())  # resume from wherever the reader is
        self._last_value = bar.value()
        self._playing = True
        self._last_tick = None
        self.tick_timer.start()
        self._sync_play_button()
        self.scrollingChanged.emit(True)

    def pause_scrolling(self) -> None:
        if not self._playing:
            return
        self._playing = False  # the timer keeps running briefly to ease to a stop
        self._sync_play_button()
        self.scrollingChanged.emit(False)

    def reset_scroll(self) -> None:
        was_playing = self._playing
        self._playing = False
        self._factor = 0.0
        self._finished = False
        self._elapsed = 0.0
        self.tick_timer.stop()
        self.text_view.verticalScrollBar().setValue(0)
        self._last_value = 0
        self._sync_play_button()
        self._emit_progress(force=True)
        if was_playing:
            self.scrollingChanged.emit(False)

    def _tick(self) -> None:
        now = time.monotonic()
        dt = 0.0 if self._last_tick is None else max(0.0, min(now - self._last_tick, 0.1))
        self._last_tick = now
        timeline = self._ensure_timeline()
        if timeline is None:
            self.tick_timer.stop()
            return
        target = 1.0 if self._playing else 0.0
        tau = RAMP_UP_SECONDS if self._playing else RAMP_DOWN_SECONDS
        self._factor += (target - self._factor) * (1.0 - math.exp(-dt / tau))
        if not self._playing and self._factor < 0.02:
            self._factor = 0.0
            self.tick_timer.stop()
            self._emit_progress(force=True)
            return
        bar = self.text_view.verticalScrollBar()
        if abs(bar.value() - self._last_value) > SCRUB_TOLERANCE_PX:  # the reader scrolled by hand
            self._elapsed = timeline.time_at(bar.value())
        self._elapsed += dt * self._factor
        if self._elapsed >= timeline.duration:
            self._elapsed = timeline.duration
            self._finish(timeline)
            return
        bar.setValue(round(timeline.position_at(self._elapsed)))
        self._last_value = bar.value()
        self._emit_progress()

    def _finish(self, timeline: Timeline) -> None:
        bar = self.text_view.verticalScrollBar()
        bar.setValue(round(timeline.position_at(timeline.duration)))
        self._last_value = bar.value()
        was_playing = self._playing
        self._playing = False
        self._finished = True
        self._factor = 0.0
        self.tick_timer.stop()
        self._sync_play_button()
        self._emit_progress(force=True)
        if was_playing:
            self.scrollingChanged.emit(False)

    def _emit_progress(self, *, force: bool = False) -> None:
        now = time.monotonic()
        if not force and now - self._last_progress_emit < PROGRESS_EMIT_SECONDS:
            return
        self._last_progress_emit = now
        timeline = self._timeline
        total = timeline.duration if timeline else 0.0
        self.decor.progress = self._elapsed / total if total > 0 else 0.0
        self.clock_label.setText(f"−{format_clock(max(0.0, total - self._elapsed))}" if total > 0 else "")
        self.decor.update()
        self.progressChanged.emit(self._elapsed, total)

    def _sync_play_button(self) -> None:
        self.play_button.setText("JEDA" if self._playing else "MULAI")

    # --------------------------------------------------------------- window flags
    def configure_window(self, *, always_on_top: bool, frameless: bool, click_through: bool) -> None:
        changed = (always_on_top, frameless, click_through) != (self.always_on_top, self.frameless, self.click_through)
        self.always_on_top, self.frameless, self.click_through = always_on_top, frameless, click_through
        if changed or self._applied_flags is None:
            self._apply_flags()
        self._restyle()
        self._update_chrome()

    def set_click_through(self, enabled: bool) -> None:
        self.configure_window(always_on_top=self.always_on_top, frameless=self.frameless, click_through=enabled)

    def _compute_flags(self) -> Qt.WindowType:
        flags = Qt.WindowType.Tool | Qt.WindowType.FramelessWindowHint if self.frameless else Qt.WindowType.Window
        flags |= Qt.WindowType.WindowDoesNotAcceptFocus
        if self.always_on_top:
            flags |= Qt.WindowType.WindowStaysOnTopHint
        if self.click_through:
            flags |= Qt.WindowType.WindowTransparentForInput
        return flags

    def _apply_flags(self) -> None:
        flags = self._compute_flags()
        if flags == self._applied_flags:
            return
        was_visible = self.isVisible()
        geometry = self.geometry()
        self._applied_flags = flags
        self.setWindowFlags(flags)  # hides the window as a side effect
        self.apply_geometry(geometry)
        if was_visible:
            self.show()

    def _update_chrome(self) -> None:
        interactive = not self.click_through
        self.grip.setVisible(interactive and self.frameless)
        if not interactive:
            self.controls.hide()
        self._position_chrome()

    # ------------------------------------------------------------------ geometry
    def apply_geometry(self, rect: QRect) -> None:
        self._last_programmatic = QRect(rect)
        self.setGeometry(rect)

    def show_countdown(self, seconds: int) -> None:
        """Show ``seconds`` large over the text (the caller ticks it down once per second)."""
        font = self.countdown_label.font()
        font.setPixelSize(max(36, min(160, int(self.text_view.height() * 0.6))))
        font.setBold(True)
        self.countdown_label.setFont(font)
        self.countdown_label.setText(str(max(0, int(seconds))))
        self.countdown_label.setGeometry(self.text_view.geometry())
        self.countdown_label.show()
        self.countdown_label.raise_()
        self.grip.raise_()
        self.controls.raise_()

    def hide_countdown(self) -> None:
        self.countdown_label.hide()
        self.countdown_label.clear()

    def _position_chrome(self) -> None:
        if self.countdown_label.isVisible():
            self.countdown_label.setGeometry(self.text_view.geometry())
        self.decor.setGeometry(self.panel.rect())
        self.controls.adjustSize()
        self.controls.move(max(4, self.panel.width() - self.controls.width() - 8), 6)
        self.grip.move(self.panel.width() - self.grip.width() - 3, self.panel.height() - self.grip.height() - 3)
        self.decor.lower()
        self.decor.raise_()
        self.grip.raise_()
        self.controls.raise_()

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self._position_chrome()
        self._relayout_timer.start()
        self._queue_geometry_check()

    def moveEvent(self, event) -> None:  # noqa: N802
        super().moveEvent(event)
        self._queue_geometry_check()

    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        self._relayout_timer.start()

    def _queue_geometry_check(self) -> None:
        if self.isVisible():
            self._geometry_timer.start()

    def _maybe_emit_user_geometry(self) -> None:
        if self.isVisible() and self.geometry() != self._last_programmatic:
            self.geometryChangedByUser.emit()

    # ------------------------------------------------------------ move and hover
    def begin_move(self) -> None:
        handle = self.windowHandle()
        if handle is not None and handle.startSystemMove():
            return
        self._manual_origin = self.cursor().pos()
        self._window_origin = self.frameGeometry().topLeft()
        self.grabMouse()

    def enterEvent(self, event) -> None:  # noqa: N802
        if not self.click_through:
            self._position_chrome()
            self.controls.show()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        if self._manual_origin is None:
            self.controls.hide()
        super().leaveEvent(event)

    def eventFilter(self, watched, event) -> bool:  # noqa: N802
        kind = event.type()
        if kind == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.LeftButton:
            if event.modifiers() & Qt.KeyboardModifier.ControlModifier:
                self.begin_move()
                return True
        elif kind == QEvent.Type.MouseMove and self._manual_origin is not None and self._window_origin is not None:
            if event.buttons() & Qt.MouseButton.LeftButton:
                self.move(self._window_origin + (self.cursor().pos() - self._manual_origin))
                return True
        elif kind == QEvent.Type.MouseButtonRelease and self._manual_origin is not None:
            self._manual_origin = self._window_origin = None
            self.releaseMouse()
            self._queue_geometry_check()
            return True
        return super().eventFilter(watched, event)

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        if self._manual_origin is not None and self._window_origin is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self.move(self._window_origin + (self.cursor().pos() - self._manual_origin))
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        if self._manual_origin is not None:
            self._manual_origin = self._window_origin = None
            self.releaseMouse()
            self._queue_geometry_check()
            return
        super().mouseReleaseEvent(event)
