#!/bin/bash
# Fedora/RPM packaging: renders sorot.spec next to the source tarball and, when rpmbuild exists, builds a noarch RPM.
# Usage: scripts/build-rpm.sh [output-dir] [--no-build]
#   Result: OUTPUT/rpm/{sorot.spec, sorot-VERSION.tar.gz, sorot-VERSION-1.noarch.rpm}
# Overrides for non-Fedora hosts: RPM_PYTHON=/path/to/python (needs build + installer + setuptools + wheel)
# and RPM_NODEPS=1 (skips the Fedora BuildRequires check; only for trial builds, never for a release).
set -euo pipefail
# shellcheck source=lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

BUILD=1
ARGS=()
for arg in "$@"; do if [ "$arg" = "--no-build" ]; then BUILD=0; else ARGS+=("$arg"); fi; done
OUT="$(absdir "${ARGS[0]:-$ROOT/dist}")"
RPM_DIR="$(absdir "$OUT/rpm")"
URL="$(sed -n "s/^HOMEPAGE = \"\\(.*\\)\"$/\\1/p" "$ROOT/scripts/release.py")"
[ -n "$URL" ] || URL="$(python3 - "$ROOT" <<'PY'
import re, sys
text = open(sys.argv[1] + "/scripts/release.py", encoding="utf-8").read()
src = re.search(r'^SOURCE = "([^"]+)"', text, re.M).group(1)
print(src + "/tree/main/apps/sorot")
PY
)"

"$ROOT/scripts/build-source.sh" "$RPM_DIR" >/dev/null
rm -f "$RPM_DIR/sorot-$VERSION.zip"
CHANGELOG_DATE="$(date -u -d "$RELEASE_DATE" '+%a %b %d %Y')"
sed -e "s|@VERSION@|$VERSION|g" -e "s|@URL@|$URL|g" -e "s|@CHANGELOG_DATE@|$CHANGELOG_DATE|g" "$ROOT/packaging/rpm/sorot.spec.in" > "$RPM_DIR/sorot.spec"
if grep -q '@[A-Z0-9_]*@' "$RPM_DIR/sorot.spec"; then echo "Placeholder tersisa di sorot.spec" >&2; exit 1; fi
echo "$RPM_DIR/sorot.spec"
if [ "$BUILD" = 1 ] && command -v rpmbuild >/dev/null 2>&1; then
    TOP="$(mktemp -d)"
    trap 'rm -rf "$TOP"' EXIT
    mkdir -p "$TOP/SOURCES"
    cp "$RPM_DIR/sorot-$VERSION.tar.gz" "$TOP/SOURCES/"
    DEFS=(--define "_topdir $TOP" --define "_builddir $TOP/BUILD" --define "source_date_epoch_from_changelog 0"
          --define "use_source_date_epoch_as_buildtime 1" --define "clamp_mtime_to_source_date_epoch 1")
    [ -z "${RPM_PYTHON:-}" ] || DEFS+=(--define "python3 $RPM_PYTHON")
    NODEPS=(); [ -z "${RPM_NODEPS:-}" ] || NODEPS=(--nodeps)
    rpmbuild -bb "${NODEPS[@]}" "${DEFS[@]}" "$RPM_DIR/sorot.spec" >"$RPM_DIR/rpmbuild.log" 2>&1 || { tail -30 "$RPM_DIR/rpmbuild.log" >&2; exit 1; }
    cp "$TOP"/RPMS/noarch/*.rpm "$RPM_DIR/"
    ls "$RPM_DIR"/*.rpm
fi
