#!/bin/bash
# Sign dist/SHA256SUMS with your GPG key so downloads can be verified: `gpg --verify SHA256SUMS.asc SHA256SUMS`.
# Usage: scripts/sign-release.sh KEYID [dist-dir]        (GNUPGHOME is honoured; nothing is uploaded)
set -euo pipefail
KEY="${1:?Gunakan: sign-release.sh KEYID [dist]}"
DIR="${2:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/dist}"
[ -f "$DIR/SHA256SUMS" ] || { echo "tidak ada $DIR/SHA256SUMS (jalankan make dist)" >&2; exit 1; }
rm -f "$DIR/SHA256SUMS.asc"
gpg --batch --yes --local-user "$KEY" --armor --detach-sign -o "$DIR/SHA256SUMS.asc" "$DIR/SHA256SUMS"
gpg --batch --verify "$DIR/SHA256SUMS.asc" "$DIR/SHA256SUMS"
echo "Ditandatangani: $DIR/SHA256SUMS.asc"
