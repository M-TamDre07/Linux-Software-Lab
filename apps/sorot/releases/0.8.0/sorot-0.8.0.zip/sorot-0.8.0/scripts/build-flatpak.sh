#!/bin/bash
# Flatpak preparation: renders a flatpak-builder manifest for the current release.
# Usage: scripts/build-flatpak.sh [output-dir] [--base-url https://host/path/to/release/files] [--build]
#   Without --base-url the manifest points at the local tarball and wheel (for a trial build on this machine).
#   With --base-url the manifest points at BASE/sorot-VERSION.tar.gz and BASE/sorot-VERSION-py3-none-any.whl
#   with their SHA-256, which is the form Flathub requires. Nothing is uploaded.
#   --build  also runs flatpak-builder (needs flatpak, flatpak-builder and the org.kde.Platform 6.8 runtime
#            plus the io.qt.PySide.BaseApp 6.8 base app from Flathub; this was NOT possible in the build environment).
# The Flatpak application id is derived from the GitHub account; confirm it with the Flathub reviewers.
set -euo pipefail
# shellcheck source=lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

BASE="" BUILD=0 ARGS=()
while [ $# -gt 0 ]; do
    case "$1" in
        --base-url) BASE="${2:?--base-url butuh nilai}"; shift 2 ;;
        --build) BUILD=1; shift ;;
        *) ARGS+=("$1"); shift ;;
    esac
done
OUT="$(absdir "${ARGS[0]:-$ROOT/dist}")"
FP="$(absdir "$OUT/flatpak")"
APPID="${SOROT_FLATPAK_ID:-io.github.M_TamDre07.Sorot}"
"$ROOT/scripts/build-source.sh" "$FP" >/dev/null
rm -f "$FP/sorot-$VERSION.zip"
"$ROOT/scripts/build-wheel.sh" "$FP" >/dev/null
TARBALL="sorot-$VERSION.tar.gz"
WHEEL="sorot-$VERSION-py3-none-any.whl"

python3 - "$FP" "$APPID" "$VERSION" "$TARBALL" "$WHEEL" "$BASE" <<'PY'
import hashlib, json, pathlib, sys

fp, appid, version, tarball, wheel, base = sys.argv[1:7]
fp = pathlib.Path(fp)
sha = lambda name: hashlib.sha256((fp / name).read_bytes()).hexdigest()
if base:
    sources = [{"type": "file", "url": f"{base.rstrip('/')}/{name}", "sha256": sha(name)} for name in (tarball, wheel)]
else:
    sources = [{"type": "file", "path": name, "sha256": sha(name)} for name in (tarball, wheel)]
manifest = {
    "app-id": appid,
    "runtime": "org.kde.Platform",
    "runtime-version": "6.8",
    "sdk": "org.kde.Sdk",
    "base": "io.qt.PySide.BaseApp",
    "base-version": "6.8",
    "command": "sorot",
    "rename-desktop-file": "sorot.desktop",
    "rename-appdata-file": "sorot.metainfo.xml",
    "rename-icon": "sorot",
    "finish-args": [
        "--share=ipc",
        "--socket=x11",
        "--socket=wayland",
        "--device=dri",
        "--share=network",
        "--talk-name=org.freedesktop.secrets",
    ],
    "modules": [{
        "name": "sorot",
        "buildsystem": "simple",
        "build-commands": [
            f"pip3 install --verbose --exists-action=i --no-index --no-deps --prefix=${{FLATPAK_DEST}} --no-build-isolation {wheel}",
            f"mkdir -p src && tar -xzf {tarball} -C src --strip-components=1",
            "install -Dm644 src/packaging/sorot.desktop ${FLATPAK_DEST}/share/applications/sorot.desktop",
            f"sed -e 's|<id>sorot</id>|<id>{appid}</id>|' -e 's|sorot.desktop|{appid}.desktop|' src/packaging/sorot.metainfo.xml > sorot.metainfo.xml",
            "install -Dm644 sorot.metainfo.xml ${FLATPAK_DEST}/share/metainfo/sorot.metainfo.xml",
            "install -Dm644 src/packaging/sorot.svg ${FLATPAK_DEST}/share/icons/hicolor/scalable/apps/sorot.svg",
            "for s in 64 128 256; do install -Dm644 src/packaging/icons/sorot-$s.png ${FLATPAK_DEST}/share/icons/hicolor/${s}x${s}/apps/sorot.png; done",
            "install -Dm644 src/LICENSE ${FLATPAK_DEST}/share/licenses/" + appid + "/LICENSE",
        ],
        "sources": sources,
    }],
}
(fp / f"{appid}.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
PY
echo "$FP/$APPID.json"
if [ "$BUILD" = 1 ]; then
    command -v flatpak-builder >/dev/null 2>&1 || { echo "flatpak-builder tidak ditemukan." >&2; exit 1; }
    (cd "$FP" && flatpak-builder --user --force-clean --install-deps-from=flathub build-dir "$APPID.json")
fi
