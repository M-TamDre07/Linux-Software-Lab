#!/bin/bash
# Install everything that is not Python code: desktop entry, icon, man page, docs, examples,
# licence and the system extensions folder. Shared by the .deb, Arch and generic installs so the
# layout is defined in exactly one place.
#
# Usage: scripts/install-files.sh [--layout deb|arch|generic] DESTDIR PREFIX
#   deb      docs + Debian copyright file (the .deb build adds changelog.gz itself)
#   arch     docs + licence in PREFIX/share/licenses/sorot   (also the default for "generic")
set -euo pipefail
# shellcheck source=lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

LAYOUT=generic
if [ "${1:-}" = "--layout" ]; then LAYOUT="${2:?layout}"; shift 2; fi
DEST="${1:?Usage: install-files.sh [--layout deb|arch|generic] DESTDIR PREFIX}"
PREFIX="${2:?Usage: install-files.sh [--layout deb|arch|generic] DESTDIR PREFIX}"
case "$LAYOUT" in deb|arch|generic) ;; *) echo "layout tidak dikenal: $LAYOUT" >&2; exit 2 ;; esac
case "$PREFIX" in /*) ;; *) echo "PREFIX harus berupa jalur absolut" >&2; exit 2 ;; esac

D="${DEST%/}$PREFIX"
DOC="$D/share/doc/sorot"
install -d "$D/share/applications" "$D/share/icons/hicolor/scalable/apps" "$D/share/man/man1" \
    "$DOC/docs" "$D/share/sorot/extensions" "$D/share/metainfo"

install -m 0644 "$ROOT/packaging/sorot.desktop" "$D/share/applications/sorot.desktop"
install -m 0644 "$ROOT/packaging/sorot.svg" "$D/share/icons/hicolor/scalable/apps/sorot.svg"
install -m 0644 "$ROOT/packaging/sorot.metainfo.xml" "$D/share/metainfo/sorot.metainfo.xml"
for size in 64 128 256; do  # PNGs next to the SVG: AppStream catalogues and Discover prefer a raster icon
    install -D -m 0644 "$ROOT/packaging/icons/sorot-$size.png" "$D/share/icons/hicolor/${size}x${size}/apps/sorot.png"
done
install -m 0644 "$ROOT/packaging/extensions-README" "$D/share/sorot/extensions/README"

# Man page: the source holds @VERSION@/@DATE@ so the version lives in one place only.
sed -e "s/@VERSION@/$VERSION/g" -e "s/@DATE@/$RELEASE_DATE/g" "$ROOT/packaging/sorot.1" | gzip -9n > "$D/share/man/man1/sorot.1.gz"
chmod 0644 "$D/share/man/man1/sorot.1.gz"

install -m 0644 "$ROOT/README.md" "$DOC/README.md"
install -m 0644 "$ROOT"/docs/*.md "$DOC/docs/"
(cd "$ROOT" && find examples -type f -print0 | sort -z | xargs -0 -I{} install -D -m 0644 {} "$DOC/{}")

case "$LAYOUT" in
    deb)
        install -m 0644 "$ROOT/packaging/copyright" "$DOC/copyright"
        ;;
    arch|generic)
        install -m 0644 "$ROOT/CHANGELOG.md" "$DOC/CHANGELOG.md"
        install -D -m 0644 "$ROOT/LICENSE" "$D/share/licenses/sorot/LICENSE"
        ;;
esac
