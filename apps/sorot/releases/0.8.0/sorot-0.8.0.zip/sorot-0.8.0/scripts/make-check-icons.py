#!/usr/bin/env python3
"""Render packaging/check-icons/*.svg into the PNGs the theme uses (src/sorot/ui/assets/check-*.png, plus @2x).

Why PNG: Qt style sheets load ``image: url(...)`` through Qt's image plugins, and SVG support is a *plugin*
(libqsvg) that a distribution may not install; PNG is built into QtGui. Without the plugin the SVG tick simply
vanished. The PNGs are committed; rerun this only when the SVG sources change (needs PySide6 with QtSvg).
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from PySide6.QtCore import QRectF, Qt  # noqa: E402
from PySide6.QtGui import QGuiApplication, QImage, QPainter  # noqa: E402
from PySide6.QtSvg import QSvgRenderer  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SIZE = 14


def render(svg: Path, pixels: int) -> QImage:
    image = QImage(pixels, pixels, QImage.Format.Format_ARGB32)
    image.fill(Qt.GlobalColor.transparent)
    painter = QPainter(image)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    QSvgRenderer(str(svg)).render(painter, QRectF(0, 0, pixels, pixels))
    painter.end()
    return image


def main() -> int:
    QGuiApplication(sys.argv)
    out = ROOT / "src" / "sorot" / "ui" / "assets"
    for svg in sorted((ROOT / "packaging" / "check-icons").glob("*.svg")):
        for scale, suffix in ((1, ""), (2, "@2x")):
            target = out / f"{svg.stem}{suffix}.png"
            if not render(svg, SIZE * scale).save(str(target), "PNG"):
                print(f"gagal menulis {target}", file=sys.stderr)
                return 1
            print(target.relative_to(ROOT))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
