#!/bin/bash
# Build a signed apt repository from the .deb files in dist/, ready to upload to any static host
# (GitHub Pages, your own server). People add it once; after that Discover, `apt upgrade` and
# `apt install sorot` update Sorot in place, with no uninstalling and no downloading by hand.
#
# Usage: scripts/make-apt-repo.sh --key KEYID [--url https://host/path] [--debs DIR] [--out DIR]
#   --key   your GPG key (the private key stays on your machine; this script never creates one)
#   --url   where the repository will be served; only used to write the ready-to-copy sorot.sources
#   --debs  folder with sorot_*.deb (default: dist)      --out  output folder (default: dist/apt)
# Older versions already in --out/pool are kept, so people can still downgrade.
# GNUPGHOME is honoured. Nothing is uploaded or published by this script.
set -euo pipefail
# shellcheck source=lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

KEY="" URL="https://EXAMPLE.invalid/apt" DEBS="$ROOT/dist" OUT="$ROOT/dist/apt"
while [ $# -gt 0 ]; do
    case "$1" in
        --key) KEY="${2:?--key butuh nilai}"; shift 2 ;;
        --url) URL="${2:?--url butuh nilai}"; shift 2 ;;
        --debs) DEBS="${2:?--debs butuh nilai}"; shift 2 ;;
        --out) OUT="${2:?--out butuh nilai}"; shift 2 ;;
        *) echo "argumen tidak dikenal: $1" >&2; exit 2 ;;
    esac
done
[ -n "$KEY" ] || { echo "Gunakan: make-apt-repo.sh --key KEYID [--url URL]" >&2; exit 2; }
for tool in apt-ftparchive gpg gzip; do command -v "$tool" >/dev/null || { echo "perlu $tool (paket apt-utils/gnupg)" >&2; exit 1; }; done
gpg --batch --list-secret-keys "$KEY" >/dev/null 2>&1 || { echo "kunci rahasia $KEY tidak ditemukan di GNUPGHOME" >&2; exit 1; }
compgen -G "$DEBS/sorot_*_all.deb" >/dev/null || { echo "tidak ada sorot_*_all.deb di $DEBS (jalankan make deb)" >&2; exit 1; }

OUT="$(absdir "$OUT")"
POOL="$OUT/pool/main/s/sorot"
DIST="$OUT/dists/stable"
BIN="$DIST/main/binary-all"
mkdir -p "$POOL" "$BIN"
cp -f "$DEBS"/sorot_*_all.deb "$POOL/"

(cd "$OUT" && apt-ftparchive packages pool > "$BIN/Packages")
gzip -9n -c "$BIN/Packages" > "$BIN/Packages.gz"
(cd "$OUT" && apt-ftparchive \
    -o APT::FTPArchive::Release::Origin="Sorot" \
    -o APT::FTPArchive::Release::Label="Sorot" \
    -o APT::FTPArchive::Release::Suite="stable" \
    -o APT::FTPArchive::Release::Codename="stable" \
    -o APT::FTPArchive::Release::Architectures="all" \
    -o APT::FTPArchive::Release::Components="main" \
    -o APT::FTPArchive::Release::Description="Sorot teleprompter - repositori resmi Muhammad Andreatama" \
    release dists/stable > "$DIST/Release")

rm -f "$DIST/Release.gpg" "$DIST/InRelease"
gpg --batch --yes --local-user "$KEY" --armor --detach-sign -o "$DIST/Release.gpg" "$DIST/Release"
gpg --batch --yes --local-user "$KEY" --clearsign -o "$DIST/InRelease" "$DIST/Release"
gpg --batch --yes --armor --export "$KEY" > "$OUT/sorot-archive-keyring.asc"
FPR="$(gpg --batch --with-colons --fingerprint "$KEY" | awk -F: '/^fpr:/ {print $10; exit}')"

cat > "$OUT/sorot.sources" <<SOURCES
Types: deb
URIs: $URL
Suites: stable
Components: main
Signed-By: /etc/apt/keyrings/sorot-archive-keyring.asc
SOURCES
cat > "$OUT/PASANG.txt" <<TEXT
Pasang repositori Sorot sekali saja (setelah itu pembaruan muncul di Discover dan lewat apt):

  sudo install -d -m 0755 /etc/apt/keyrings
  sudo curl -fsSL $URL/sorot-archive-keyring.asc -o /etc/apt/keyrings/sorot-archive-keyring.asc
  sudo curl -fsSL $URL/sorot.sources -o /etc/apt/sources.list.d/sorot.sources
  sudo apt update && sudo apt install sorot

Periksa sidik jari kunci sebelum mempercayainya:
  gpg --show-keys --with-fingerprint /etc/apt/keyrings/sorot-archive-keyring.asc
  harus sama dengan: $FPR
TEXT
echo "Repositori: $OUT"
echo "Sidik jari kunci: $FPR"
