"""AI dialog and Drive flows driven through the real Qt widgets.

Providers and rclone are local test doubles (see fake_server.py and
fake_rclone.py): these tests prove the application logic, not compatibility
with any real provider or with the real rclone.
"""
from __future__ import annotations

import json

import pytest

pytest.importorskip("PySide6")
pytest.importorskip("pytestqt")

from fake_rclone import install_fake_rclone  # noqa: E402
from fake_server import FakeProvider, chat_reply  # noqa: E402
from PySide6.QtCore import QTimer  # noqa: E402
from PySide6.QtWidgets import QApplication, QCheckBox, QInputDialog, QMessageBox, QPushButton  # noqa: E402

from sorot.core.config import ConfigStore  # noqa: E402
from sorot.core.scripts import DraftStore, ScriptLibrary  # noqa: E402
from sorot.ui import drive_controller  # noqa: E402
from sorot.ui.ai_dialog import AIAssistantDialog, AIContext  # noqa: E402
from sorot.ui.main_window import MainWindow  # noqa: E402

pytestmark = pytest.mark.gui
CHAT, MODELS = "/v1/chat/completions", "/v1/models"


@pytest.fixture()
def provider():
    server = FakeProvider().start()
    yield server
    server.stop()


class Recorder:
    def __init__(self, provider, *, allow_send=True, keyring_available=True, save_key_ok=True):
        self.provider, self.sent_prompts, self.settings, self.session_keys, self.saved_keys = provider, [], [], [], []
        self.allow_send, self.save_key_ok = allow_send, save_key_ok
        self.context = AIContext(
            base_url=provider.base_url, model="model-uji", timeout=15, api_key="sk-uji-123456", wpm=130,
            keyring_available=keyring_available, keyring_saved=False,
            confirm_send=self._confirm, save_settings=lambda *a: self.settings.append(a),
            remember_session_key=self.session_keys.append, save_key=self._save_key, delete_key=lambda: True,
        )

    def _confirm(self, host, chars):
        self.sent_prompts.append((host, chars))
        return self.allow_send

    def _save_key(self, key):
        self.saved_keys.append(key)
        return (True, "") if self.save_key_ok else (False, "keyring gagal")


def make_dialog(qtbot, recorder, text="naskah saya"):
    dialog = AIAssistantDialog(text, recorder.context)
    qtbot.addWidget(dialog)
    dialog.show()
    return dialog


def capture_warnings(monkeypatch):
    messages = []
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: messages.append(a[2]))
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: messages.append(a[2]))
    return messages


# -------------------------------------------------------------------- AI dialog
def test_ai_happy_path_shows_preview_without_touching_the_script(qtbot, provider):
    provider.route("POST", CHAT, json=chat_reply("Versi baru"))
    rec = Recorder(provider)
    dialog = make_dialog(qtbot, rec)
    applied = []
    dialog.applyRequested.connect(lambda mode, text: applied.append((mode, text)))
    dialog.process_btn.click()
    qtbot.waitUntil(lambda: dialog.output_text.toPlainText() == "Versi baru", timeout=5000)
    assert applied == [], "hasil AI tidak boleh diterapkan otomatis"
    assert rec.sent_prompts == [("127.0.0.1", len("naskah saya"))]
    assert rec.settings == [(provider.base_url, "model-uji", 15)]
    assert rec.session_keys == ["sk-uji-123456"]
    assert dialog.process_btn.isEnabled() and not dialog.progress.isVisible()
    dialog.apply_btn.click()
    dialog.append_btn.click()
    assert applied == [("replace", "Versi baru"), ("append", "Versi baru")]


def test_declining_the_privacy_prompt_sends_nothing(qtbot, provider):
    rec = Recorder(provider, allow_send=False)
    dialog = make_dialog(qtbot, rec)
    dialog.process_btn.click()
    assert provider.requests == [] and rec.settings == [] and "Tidak ada data yang dikirim" in dialog.status.text()


def test_missing_key_or_model_is_reported_before_sending(qtbot, provider, monkeypatch):
    warnings = capture_warnings(monkeypatch)
    rec = Recorder(provider)
    dialog = make_dialog(qtbot, rec)
    dialog.api_key_input.setText("")
    dialog.process_btn.click()
    dialog.api_key_input.setText("k")
    dialog.model_input.setText("")
    dialog.process_btn.click()
    assert len(warnings) == 2 and "API key" in warnings[0] and "model" in warnings[1].lower()
    assert provider.requests == [] and rec.sent_prompts == []


def test_empty_script_and_missing_custom_instruction_are_caught(qtbot, provider, monkeypatch):
    warnings = capture_warnings(monkeypatch)
    dialog = make_dialog(qtbot, Recorder(provider), text="   ")
    dialog.process_btn.click()
    dialog.input_text.setPlainText("isi")
    dialog.task_combo.setCurrentIndex(dialog.task_combo.findData("custom"))
    dialog.process_btn.click()
    assert len(warnings) == 2 and "instruksi" in warnings[1].lower() and provider.requests == []


def test_task_specific_fields_are_shown_only_when_relevant(qtbot, provider):
    dialog = make_dialog(qtbot, Recorder(provider))
    assert dialog.custom_input.isHidden() and dialog.minutes_spin.isHidden()
    dialog.task_combo.setCurrentIndex(dialog.task_combo.findData("custom"))
    assert not dialog.custom_input.isHidden() and dialog.minutes_spin.isHidden()
    dialog.task_combo.setCurrentIndex(dialog.task_combo.findData("target_duration"))
    assert dialog.custom_input.isHidden() and not dialog.minutes_spin.isHidden()


def test_duration_task_sends_target_minutes_in_the_prompt(qtbot, provider):
    provider.route("POST", CHAT, json=chat_reply("ok"))
    dialog = make_dialog(qtbot, Recorder(provider))
    dialog.task_combo.setCurrentIndex(dialog.task_combo.findData("target_duration"))
    dialog.minutes_spin.setValue(5)
    dialog.process_btn.click()
    qtbot.waitUntil(lambda: dialog.output_text.toPlainText() == "ok", timeout=5000)
    prompt = json.loads(provider.requests[0]["body"])["messages"][1]["content"]
    assert "5 menit" in prompt and "650 kata" in prompt


def test_http_error_is_explained_and_dialog_recovers(qtbot, provider, monkeypatch):
    warnings = capture_warnings(monkeypatch)
    provider.route("POST", CHAT, status=429, headers={"Retry-After": "9"}, json={"error": {"message": "kuota"}})
    dialog = make_dialog(qtbot, Recorder(provider))
    dialog.process_btn.click()
    qtbot.waitUntil(lambda: bool(warnings), timeout=5000)
    assert "HTTP 429" in warnings[0] and "9 detik" in warnings[0]
    assert dialog.process_btn.isEnabled() and dialog.output_text.toPlainText() == ""


def test_cancel_discards_late_response(qtbot, provider):
    provider.route("POST", CHAT, delay=1.0, json=chat_reply("terlambat"))
    dialog = make_dialog(qtbot, Recorder(provider))
    dialog.process_btn.click()
    qtbot.waitUntil(dialog.cancel_btn.isVisible, timeout=2000)
    dialog.cancel_btn.click()
    qtbot.waitUntil(lambda: "Dibatalkan" in dialog.status.text(), timeout=5000)
    qtbot.wait(1300)
    assert dialog.output_text.toPlainText() == "" and dialog.process_btn.isEnabled()


def test_closing_while_running_does_not_block(qtbot, provider):
    provider.route("POST", CHAT, delay=1.0, json=chat_reply("x"))
    dialog = make_dialog(qtbot, Recorder(provider))
    dialog.process_btn.click()
    qtbot.waitUntil(dialog.cancel_btn.isVisible, timeout=2000)
    dialog.close()
    assert not dialog.isVisible()
    qtbot.wait(1300)  # the late reply must not crash anything


def test_connection_test_never_sends_the_script(qtbot, provider):
    provider.route("GET", MODELS, json={"data": [{"id": "model-uji"}]})
    rec = Recorder(provider)
    dialog = make_dialog(qtbot, rec, text="RAHASIA")
    dialog.test_btn.click()
    qtbot.waitUntil(lambda: "Koneksi berhasil" in dialog.status.text(), timeout=5000)
    assert [r["path"] for r in provider.requests] == [MODELS]
    assert b"RAHASIA" not in b"".join(r["body"] for r in provider.requests)
    assert rec.sent_prompts == [], "uji koneksi tidak boleh memicu konfirmasi pengiriman naskah"


def test_remember_key_uses_keyring_only_when_ticked(qtbot, provider):
    provider.route("POST", CHAT, json=chat_reply("ok"))
    rec = Recorder(provider)
    dialog = make_dialog(qtbot, rec)
    dialog.remember_check.setChecked(False)
    dialog.process_btn.click()
    qtbot.waitUntil(lambda: dialog.output_text.toPlainText() == "ok", timeout=5000)
    assert rec.saved_keys == []
    dialog.remember_check.setChecked(True)
    dialog.process_btn.click()
    qtbot.waitUntil(lambda: rec.saved_keys == ["sk-uji-123456"], timeout=5000)


def test_keyring_failure_is_reported_but_request_still_runs(qtbot, provider, monkeypatch):
    warnings = capture_warnings(monkeypatch)
    provider.route("POST", CHAT, json=chat_reply("ok"))
    dialog = make_dialog(qtbot, Recorder(provider, save_key_ok=False))
    dialog.remember_check.setChecked(True)
    dialog.process_btn.click()
    qtbot.waitUntil(lambda: dialog.output_text.toPlainText() == "ok", timeout=5000)
    assert warnings == ["keyring gagal"]


def test_keyring_checkbox_is_disabled_when_no_secure_backend(qtbot, provider):
    dialog = make_dialog(qtbot, Recorder(provider, keyring_available=False))
    assert not dialog.remember_check.isEnabled() and "Keyring" in dialog.remember_check.toolTip()


def test_api_key_field_is_masked_until_requested(qtbot, provider):
    from PySide6.QtWidgets import QLineEdit

    dialog = make_dialog(qtbot, Recorder(provider))
    assert dialog.api_key_input.echoMode() == QLineEdit.EchoMode.Password
    dialog.show_key.setChecked(True)
    assert dialog.api_key_input.echoMode() == QLineEdit.EchoMode.Normal


# ------------------------------------------------ main-window AI confirmations
def make_window(qtbot):
    window = MainWindow(ConfigStore(), DraftStore(), ScriptLibrary())
    qtbot.addWidget(window)
    window.show()
    return window


def click_in_modal(label: str, *, tick: bool = False) -> None:
    def press():
        modal = QApplication.activeModalWidget()
        assert modal is not None
        if tick:
            for box in modal.findChildren(QCheckBox):
                box.setChecked(True)
        for button in modal.findChildren(QPushButton):
            if button.text().replace("&", "") == label:
                button.click()
                return
        raise AssertionError("tombol tidak ditemukan")

    QTimer.singleShot(60, press)


def test_remote_host_requires_confirmation_and_can_be_remembered(qtbot):
    window = make_window(qtbot)
    click_in_modal("Batal")
    assert window._confirm_ai_send("api.example.com", 1234) is False
    assert window.config.ai_confirmed_hosts == []
    click_in_modal("Kirim", tick=True)
    assert window._confirm_ai_send("api.example.com", 1234) is True
    assert window.config.ai_confirmed_hosts == ["api.example.com"]
    assert window._confirm_ai_send("api.example.com", 1) is True  # no second prompt
    assert window._confirm_ai_send("localhost", 1) is True  # local servers never leave the machine
    window.close()


def test_api_key_is_never_written_to_config_or_draft(qtbot, provider):
    window = make_window(qtbot)
    window.session_api_key = "sk-sangat-rahasia-987654321"
    window._save_ai_settings(provider.base_url, "m", 30)
    window.close()
    from sorot.core import paths

    for file in (paths.config_file(), paths.draft_file()):
        if file.exists():
            assert "rahasia" not in file.read_text()


# ------------------------------------------------------------------------ Drive
@pytest.fixture()
def fake_rclone(tmp_path, monkeypatch):
    return install_fake_rclone(tmp_path, monkeypatch)


@pytest.fixture()
def auto_dialogs(monkeypatch):
    """Answer list/prompt dialogs programmatically. Returns the answer queue."""
    answers: dict[str, list] = {"choices": [], "text": []}
    monkeypatch.setattr(drive_controller._ListChoiceDialog, "exec", lambda self: 1)
    monkeypatch.setattr(drive_controller._ListChoiceDialog, "chosen", lambda self: answers["choices"].pop(0))
    monkeypatch.setattr(QInputDialog, "getText", staticmethod(lambda *a, **k: (answers["text"].pop(0), True)))
    return answers


def test_drive_open_flow_downloads_into_editor(qtbot, fake_rclone, auto_dialogs):
    root, log = fake_rclone
    (root / "Naskah").mkdir()
    (root / "Naskah" / "pidato.txt").write_text("Selamat pagi dari Drive", encoding="utf-8")
    auto_dialogs["choices"] += ["gdrive:", "pidato.txt"]
    auto_dialogs["text"] += ["Naskah"]
    window = make_window(qtbot)
    window.drive.open_text()
    qtbot.waitUntil(lambda: window.editor.toPlainText() == "Selamat pagi dari Drive", timeout=10000)
    assert "Naskah/pidato.txt" in window.status_label.text()
    assert not window.editor.document().isModified()
    window.close()


def test_drive_save_requires_confirmation_and_uploads(qtbot, fake_rclone, auto_dialogs, monkeypatch):
    root, _ = fake_rclone
    auto_dialogs["choices"] += ["gdrive:"]
    auto_dialogs["text"] += ["Folder/hasil.txt"]
    answers = [QMessageBox.StandardButton.No, QMessageBox.StandardButton.Yes]
    asked = []
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **k: (asked.append(a[2]), answers.pop(0))[1])
    window = make_window(qtbot)
    window._replace_editor_text("isi untuk Drive", modified=False)
    window.drive.save_text()
    qtbot.wait(800)
    assert not (root / "Folder" / "hasil.txt").exists(), "tanpa konfirmasi tidak boleh ada unggahan"
    assert "ditimpa" in asked[0]
    auto_dialogs["choices"] += ["gdrive:"]
    auto_dialogs["text"] += ["Folder/hasil.txt"]
    window.drive.save_text()
    qtbot.waitUntil(lambda: (root / "Folder" / "hasil.txt").exists(), timeout=10000)
    assert (root / "Folder" / "hasil.txt").read_text(encoding="utf-8") == "isi untuk Drive"
    window.close()


def test_drive_rejects_unsafe_path_before_any_upload(qtbot, fake_rclone, auto_dialogs, monkeypatch):
    root, log = fake_rclone
    warnings = capture_warnings(monkeypatch)
    auto_dialogs["choices"] += ["gdrive:"]
    auto_dialogs["text"] += ["../../etc/passwd"]
    window = make_window(qtbot)
    window._replace_editor_text("x", modified=False)
    window.drive.save_text()
    qtbot.waitUntil(lambda: bool(warnings), timeout=10000)
    assert "keluar" in warnings[0] or "tidak valid" in warnings[0]
    assert [json.loads(line)[0] for line in log.read_text().splitlines()] == ["listremotes"]
    window.close()


def test_drive_failure_is_reported_and_ui_stays_usable(qtbot, fake_rclone, auto_dialogs, monkeypatch):
    warnings = capture_warnings(monkeypatch)
    monkeypatch.setenv("FAKE_RCLONE_FAIL", "token expired")
    window = make_window(qtbot)
    window.drive.open_text()
    qtbot.waitUntil(lambda: bool(warnings), timeout=10000)
    assert "token expired" in warnings[0]
    assert window.drive._task is None
    window.close()


def test_drive_operation_can_be_cancelled(qtbot, fake_rclone, auto_dialogs, monkeypatch):
    monkeypatch.setenv("FAKE_RCLONE_SLEEP", "5")
    window = make_window(qtbot)
    window.drive.open_text()
    qtbot.waitUntil(lambda: window.drive._progress is not None, timeout=2000)
    window.drive.cancel()
    qtbot.waitUntil(lambda: "dibatalkan" in window.status_label.text(), timeout=5000)
    assert window.drive._task is None
    window.close()


def test_drive_without_rclone_explains_how_to_continue(qtbot, monkeypatch):
    infos = capture_warnings(monkeypatch)
    monkeypatch.setenv("PATH", "/nonexistent")
    window = make_window(qtbot)
    window.drive.open_text()
    window.drive.save_text()  # empty script is reported first
    window.drive.check_setup()
    assert any("rclone belum terpasang" in m for m in infos)
    window.close()


# --------------------------------------------------------------------- support
def test_support_dialog_copies_and_opens_only_on_click(qtbot, monkeypatch):
    from PySide6.QtGui import QDesktopServices, QGuiApplication

    from sorot.ui.dialogs import SupportDialog

    opened = []
    monkeypatch.setattr(QDesktopServices, "openUrl", staticmethod(lambda url: opened.append(url.toString()) or True))
    dialog = SupportDialog()
    qtbot.addWidget(dialog)
    dialog.show()
    assert opened == [], "tidak boleh membuka apa pun sebelum tombol ditekan"
    assert dialog.number_label.text() == "0812-7485-2534"
    dialog.copy_number_btn.click()
    assert QGuiApplication.clipboard().text() == "081274852534" and "disalin" in dialog.feedback.text()
    dialog.copy_link_btn.click()
    assert QGuiApplication.clipboard().text() == "https://saweria.co/tamaandrea"
    dialog.open_btn.click()
    assert opened == ["https://saweria.co/tamaandrea"]


def test_about_dialog_contact_is_copied_and_mailed_only_on_click(qtbot, monkeypatch):
    from PySide6.QtGui import QDesktopServices, QGuiApplication

    from sorot.ui.dialogs import AboutDialog

    opened = []
    monkeypatch.setattr(QDesktopServices, "openUrl", staticmethod(lambda url: opened.append(url.toString()) or True))
    dialog = AboutDialog("sesi uji")
    qtbot.addWidget(dialog)
    dialog.show()
    assert opened == [], "tidak boleh membuka aplikasi email sebelum tombol ditekan"
    assert dialog.email_label.text() == "muhammadandreatama@outlook.com"
    dialog.copy_email_btn.click()
    assert QGuiApplication.clipboard().text() == "muhammadandreatama@outlook.com" and "disalin" in dialog.contact_feedback.text()
    dialog.send_email_btn.click()
    assert opened == ["mailto:muhammadandreatama@outlook.com?subject=Sorot"]


def test_support_is_reachable_but_never_shown_unprompted(qtbot, monkeypatch):
    from sorot.ui import main_window as mw

    shown = []
    monkeypatch.setattr(mw.SupportDialog, "exec", lambda self: shown.append(True) or 0)
    window = make_window(qtbot)
    qtbot.wait(300)
    assert shown == [], "dialog dukungan tidak boleh muncul sendiri"
    window.support_btn.click()
    assert shown == [True]
    assert any(action.text().startswith("Dukung") for menu in window.menuBar().findChildren(type(window.extensions_menu)) for action in menu.actions())
    window.close()
