"""Upgrade path: version tracking, automatic backup, verified restore, install-method hints."""
from __future__ import annotations

import json
import os
import zipfile
from pathlib import Path

import pytest

import sorot
from sorot.app import main
from sorot.core import paths, upgrade
from sorot.core.config import MIGRATIONS, SCHEMA_VERSION, upgrade_schema

CURRENT = sorot.__version__


def seed_data() -> None:
    """A realistic user profile: settings, draft, history, a library script and an extension file."""
    paths.config_dir().mkdir(parents=True)
    (paths.config_dir() / "config.json").write_text(json.dumps({"schema_version": SCHEMA_VERSION, "font_size": 44}), encoding="utf-8")
    paths.data_dir().mkdir(parents=True)
    (paths.data_dir() / "draft.txt").write_text("Halo dunia\n[jeda 2]\nLanjut", encoding="utf-8")
    (paths.data_dir() / "draft-history").mkdir()
    (paths.data_dir() / "draft-history" / "a.txt").write_text("lama", encoding="utf-8")
    (paths.library_dir()).mkdir()
    (paths.library_dir() / "pidato.txt").write_text("pidato", encoding="utf-8")
    ext = paths.data_dir() / "extensions" / "uji.satu"
    ext.mkdir(parents=True)
    (ext / "sorot-extension.json").write_text("{}", encoding="utf-8")


def snapshot_tree() -> dict[str, str]:
    result = {}
    for root in (paths.config_dir(), paths.data_dir()):
        for path in sorted(root.rglob("*")):
            if path.is_file() and "backups" not in path.parts:
                result[str(path)] = path.read_text(encoding="utf-8")
    return result


# ------------------------------------------------------------------ versions
@pytest.mark.parametrize(("a", "b", "expected"), [
    ("0.5.0", "0.6.0", -1), ("0.6.0", "0.6.0", 0), ("0.10.0", "0.9.0", 1),
    ("1.0", "1.0.0", 0), ("0.6.0 Beta", "0.6.0", 0), ("v1.2.3", "1.2.4", -1),
])
def test_version_comparison(a, b, expected):
    assert upgrade.compare_versions(a, b) == expected


def test_unparseable_version_is_empty_tuple():
    assert upgrade.parse_version("beta") == ()


def test_detect_change_covers_every_state():
    assert upgrade.detect_change("0.6.0").kind == "fresh"
    upgrade.write_stamp("0.5.0", 3)
    assert upgrade.detect_change("0.6.0").kind == "upgrade"
    assert upgrade.detect_change("0.5.0").kind == "same"
    assert upgrade.detect_change("0.4.0").kind == "downgrade"
    upgrade.version_stamp_file().write_text("{not json", encoding="utf-8")
    assert upgrade.detect_change("0.6.0").kind == "fresh"  # unreadable == no record
    upgrade.version_stamp_file().write_text(json.dumps({"version": "abc"}), encoding="utf-8")
    assert upgrade.detect_change("0.6.0").kind == "unknown"


# ------------------------------------------------------------------ backup / restore
def test_backup_round_trip_restores_deleted_and_changed_files():
    seed_data()
    before = snapshot_tree()
    backup = upgrade.create_backup(app_version=CURRENT, schema_version=SCHEMA_VERSION)
    assert backup.parent == upgrade.backups_dir() and oct(backup.stat().st_mode & 0o777) == "0o600"
    info = upgrade.inspect_backup(backup)
    assert info.app_version == CURRENT and "data/draft.txt" in info.files and "config/config.json" in info.files
    assert not any(name.startswith("data/backups") for name in info.files), "a backup must never contain backups"

    (paths.data_dir() / "draft.txt").write_text("RUSAK", encoding="utf-8")
    (paths.library_dir() / "pidato.txt").unlink()
    restored, safety = upgrade.restore_backup(backup, app_version=CURRENT, schema_version=SCHEMA_VERSION)
    assert len(restored.files) == len(info.files)
    assert snapshot_tree() == before
    assert safety is not None and "pre-restore" in safety.name, "the state before restoring is saved first"
    assert upgrade.inspect_backup(safety).files["data/draft.txt"]


def test_restore_is_additive_and_keeps_files_not_in_backup():
    seed_data()
    backup = upgrade.create_backup(app_version=CURRENT, schema_version=SCHEMA_VERSION)
    (paths.library_dir() / "baru.txt").write_text("dibuat setelah cadangan", encoding="utf-8")
    upgrade.restore_backup(backup, app_version=CURRENT, schema_version=SCHEMA_VERSION)
    assert (paths.library_dir() / "baru.txt").read_text(encoding="utf-8") == "dibuat setelah cadangan"


def test_backup_with_no_data_is_refused_politely():
    with pytest.raises(upgrade.BackupError, match="Belum ada data"):
        upgrade.create_backup(app_version=CURRENT, schema_version=SCHEMA_VERSION)


def test_backup_never_overwrites_an_existing_file(tmp_path):
    seed_data()
    target = tmp_path / "saya.zip"
    target.write_text("penting", encoding="utf-8")
    with pytest.raises(upgrade.BackupError, match="tidak ditimpa"):
        upgrade.create_backup(target, app_version=CURRENT, schema_version=SCHEMA_VERSION)
    assert target.read_text(encoding="utf-8") == "penting"


def test_backup_to_directory_and_size_limit(tmp_path):
    seed_data()
    folder = tmp_path / "out"
    folder.mkdir()
    made = upgrade.create_backup(folder, app_version=CURRENT, schema_version=SCHEMA_VERSION)
    assert made.parent == folder
    with pytest.raises(upgrade.BackupError, match="terlalu besar"):
        upgrade.create_backup(tmp_path / "x.zip", app_version=CURRENT, schema_version=SCHEMA_VERSION, max_bytes=5)


def rewrite_zip(source: Path, target: Path, *, replace=None, add=None, manifest_edit=None) -> Path:
    """Copy a backup while tampering with it (test helper)."""
    with zipfile.ZipFile(source) as zin, zipfile.ZipFile(target, "w") as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == upgrade.MANIFEST_NAME and manifest_edit:
                manifest = json.loads(data)
                manifest_edit(manifest)
                data = json.dumps(manifest).encode()
            if replace and item.filename in replace:
                data = replace[item.filename]
            zout.writestr(item.filename, data)
        for name, data in (add or {}).items():
            zout.writestr(name, data)
    return target


def test_tampered_file_is_detected_before_anything_is_written(tmp_path):
    seed_data()
    backup = upgrade.create_backup(app_version=CURRENT, schema_version=SCHEMA_VERSION)
    bad = rewrite_zip(backup, tmp_path / "bad.zip", replace={"data/draft.txt": b"disusupi"})
    before = snapshot_tree()
    with pytest.raises(upgrade.BackupError, match="hash tidak cocok"):
        upgrade.restore_backup(bad, app_version=CURRENT, schema_version=SCHEMA_VERSION)
    assert snapshot_tree() == before


@pytest.mark.parametrize("name", ["../evil.txt", "/etc/passwd", "data/../../evil", "data\\x", "other/file.txt", "data/backups/x.zip", "data", "config/./x", "data//x", "data/x/"])
def test_unsafe_member_names_are_rejected(tmp_path, name):
    seed_data()
    backup = upgrade.create_backup(app_version=CURRENT, schema_version=SCHEMA_VERSION)

    import hashlib

    def edit(manifest):  # a CORRECT hash, so only name validation can reject this entry
        manifest["files"][name] = {"sha256": hashlib.sha256(b"x").hexdigest(), "size": 1}

    bad = rewrite_zip(backup, tmp_path / "bad.zip", add={name: b"x"}, manifest_edit=edit)
    with pytest.raises(upgrade.BackupError, match="(?i)tidak aman|tidak dikenal|tidak diizinkan"):
        upgrade.inspect_backup(bad)
    assert not (tmp_path / "evil.txt").exists()


@pytest.mark.parametrize("parts", [("data", "..", "..", "evil"), ("config", "..", "x"), ("data", "scripts", "..", "..", "..", "y")])
def test_destination_is_confined_even_if_name_validation_were_bypassed(parts):
    from pathlib import PurePosixPath

    with pytest.raises(upgrade.BackupError, match="keluar dari folder"):
        upgrade._destination(PurePosixPath(*parts))


def test_destination_rejects_a_symlinked_directory_escape(tmp_path):
    outside = tmp_path / "luar"
    outside.mkdir()
    paths.data_dir().mkdir(parents=True)
    (paths.data_dir() / "scripts").symlink_to(outside)
    from pathlib import PurePosixPath

    with pytest.raises(upgrade.BackupError, match="keluar dari folder"):
        upgrade._destination(PurePosixPath("data/scripts/jahat.txt"))


def test_files_not_listed_in_manifest_are_rejected(tmp_path):
    seed_data()
    backup = upgrade.create_backup(app_version=CURRENT, schema_version=SCHEMA_VERSION)
    bad = rewrite_zip(backup, tmp_path / "bad.zip", add={"data/selundupan.txt": b"x"})
    with pytest.raises(upgrade.BackupError, match="tidak tercantum"):
        upgrade.inspect_backup(bad)


@pytest.mark.parametrize("edit", [lambda m: m.update(app="lain"), lambda m: m.update(format=99), lambda m: m.update(files=[])])
def test_foreign_or_future_manifests_are_rejected(tmp_path, edit):
    seed_data()
    backup = upgrade.create_backup(app_version=CURRENT, schema_version=SCHEMA_VERSION)
    with pytest.raises(upgrade.BackupError):
        upgrade.inspect_backup(rewrite_zip(backup, tmp_path / "bad.zip", manifest_edit=edit))


def test_non_zip_and_missing_files_are_reported(tmp_path):
    junk = tmp_path / "junk.zip"
    junk.write_bytes(b"bukan zip")
    with pytest.raises(upgrade.BackupError, match="bukan cadangan"):
        upgrade.inspect_backup(junk)
    with pytest.raises(upgrade.BackupError, match="tidak ditemukan"):
        upgrade.inspect_backup(tmp_path / "tidak-ada.zip")


def test_symlinks_are_not_followed_into_the_backup(tmp_path):
    seed_data()
    secret = tmp_path / "rahasia.txt"
    secret.write_text("JANGAN DICADANGKAN", encoding="utf-8")
    (paths.library_dir() / "tautan.txt").symlink_to(secret)
    info = upgrade.inspect_backup(upgrade.create_backup(app_version=CURRENT, schema_version=SCHEMA_VERSION))
    assert "data/scripts/tautan.txt" not in info.files


def test_restore_refuses_while_the_app_runs():
    seed_data()
    backup = upgrade.create_backup(app_version=CURRENT, schema_version=SCHEMA_VERSION)
    lock = paths.state_dir() / "sorot.lock"
    lock.parent.mkdir(parents=True)
    lock.write_text(f"{os.getpid()}\nSorot\nhost\n", encoding="utf-8")
    assert upgrade.running_instance_pid() == os.getpid()
    with pytest.raises(upgrade.BackupError, match="sedang berjalan"):
        upgrade.restore_backup(backup, app_version=CURRENT, schema_version=SCHEMA_VERSION)


def test_stale_or_garbage_lock_does_not_block_restore():
    lock = paths.state_dir() / "sorot.lock"
    lock.parent.mkdir(parents=True)
    lock.write_text("999999999\nSorot\nhost\n", encoding="utf-8")
    assert upgrade.running_instance_pid() is None
    lock.write_text("bukan angka", encoding="utf-8")
    assert upgrade.running_instance_pid() is None


def test_auto_backups_are_pruned_but_manual_ones_never(tmp_path):
    seed_data()
    folder = upgrade.backups_dir()
    folder.mkdir(parents=True)
    for index in range(8):
        auto = folder / f"sorot-backup-auto-0.{index}.0-20260101-00000{index}.zip"
        auto.write_bytes(b"x")
        os.utime(auto, (1_000_000 + index, 1_000_000 + index))
    manual = folder / "sorot-backup-manual-0.1.0-20250101-000000.zip"
    manual.write_bytes(b"x")
    os.utime(manual, (1, 1))
    removed = upgrade.prune_auto_backups(keep=5)
    assert len(removed) == 3 and manual.exists()
    assert sorted(p.name for p in folder.glob("sorot-backup-auto-*"))[0].startswith("sorot-backup-auto-0.3.0")


# ------------------------------------------------------------------ startup hook
def test_fresh_install_makes_no_backup_and_records_the_version():
    assert upgrade.on_startup(CURRENT, SCHEMA_VERSION) == []
    assert not upgrade.backups_dir().exists()
    assert upgrade.read_stamp()["version"] == CURRENT


def test_first_run_after_an_untracked_release_backs_up_existing_data():
    """Upgrading from <= 0.5.x: data exists but no version was ever recorded."""
    seed_data()
    before = snapshot_tree()
    notices = upgrade.on_startup(CURRENT, SCHEMA_VERSION)
    assert len(notices) == 1 and "Cadangan otomatis" in notices[0]
    assert len(upgrade.list_backups()) == 1
    assert snapshot_tree() == before, "the hook itself must not alter user data"
    assert upgrade.on_startup(CURRENT, SCHEMA_VERSION) == [], "same version -> silent"


def test_upgrade_and_downgrade_notices():
    seed_data()
    upgrade.write_stamp("0.5.0", 3)
    up = upgrade.on_startup("0.6.0", SCHEMA_VERSION)
    assert "diperbarui dari versi 0.5.0 ke 0.6.0" in up[0]
    down = upgrade.on_startup("0.4.0", SCHEMA_VERSION)
    assert "diturunkan dari versi 0.6.0 ke 0.4.0" in down[0] and "mungkin diabaikan" in down[0]
    assert upgrade.read_stamp()["version"] == "0.4.0"


def test_startup_hook_never_raises_even_if_backup_fails(monkeypatch):
    seed_data()
    upgrade.write_stamp("0.1.0", 1)

    def boom(*args, **kwargs):
        raise OSError("disk penuh")

    monkeypatch.setattr(upgrade, "create_backup", boom)
    notices = upgrade.on_startup(CURRENT, SCHEMA_VERSION)
    assert len(notices) == 1 and "tidak dapat dibuat" in notices[0]
    assert upgrade.read_stamp()["version"] == CURRENT


# ------------------------------------------------------------------ install method
def make_root(tmp_path, *, dpkg=False, pacman=False):
    root = tmp_path / "root"
    if dpkg:
        (root / "var/lib/dpkg/info").mkdir(parents=True)
        (root / "var/lib/dpkg/info/sorot.list").write_text("x", encoding="utf-8")
    if pacman:
        (root / "var/lib/pacman/local/sorot-0.6.0-1").mkdir(parents=True)
    return root


def test_install_method_detection(tmp_path):
    same = {"prefix": "/usr", "base_prefix": "/usr"}
    assert upgrade.detect_install_method("/usr/lib/sorot/sorot/core/upgrade.py", root=make_root(tmp_path, dpkg=True), **same).key == "deb"
    assert upgrade.detect_install_method("/usr/lib/python3.13/site-packages/sorot/core/upgrade.py", root=make_root(tmp_path, pacman=True), **same).key == "pacman"
    assert upgrade.detect_install_method("/home/u/.local/share/sorot/venv/lib/python3.12/site-packages/sorot/core/upgrade.py", root=tmp_path, **same).key == "user-script"
    assert upgrade.detect_install_method("/home/u/.local/pipx/venvs/sorot/lib/python3.12/site-packages/sorot/core/upgrade.py", root=tmp_path, **same).key == "pipx"
    assert upgrade.detect_install_method("/opt/venv/lib/python3.12/site-packages/sorot/core/upgrade.py", root=tmp_path, prefix="/opt/venv", base_prefix="/usr").key == "pip-venv"
    assert upgrade.detect_install_method("/opt/x/site-packages/sorot/core/upgrade.py", root=tmp_path, **same).key == "unknown"
    # a /usr/lib/sorot path WITHOUT a dpkg record is not claimed to be a .deb install
    assert upgrade.detect_install_method("/usr/lib/sorot/sorot/core/upgrade.py", root=tmp_path, **same).key == "unknown"


def test_source_checkout_is_recognised():
    assert upgrade.detect_install_method(Path(upgrade.__file__), prefix="/usr", base_prefix="/usr").key == "source"


# ------------------------------------------------------------------ config migrations
def test_every_schema_step_has_a_migration():
    assert set(MIGRATIONS) == set(range(1, SCHEMA_VERSION)), "raising SCHEMA_VERSION requires adding its migration step"


@pytest.mark.parametrize("start", range(1, SCHEMA_VERSION + 1))
def test_migration_chain_from_any_version_reaches_current_and_is_pure(start):
    original = {"schema_version": start, "font_size": 40}
    snapshot = dict(original)
    result = upgrade_schema(original)
    assert original == snapshot, "input must not be mutated"
    assert result["font_size"] == 40
    if start < 3:
        assert result["speed_mode"] == "pps"


def test_newer_schema_passes_through_untouched():
    assert upgrade_schema({"schema_version": SCHEMA_VERSION + 5, "mystery": 1}) == {"schema_version": SCHEMA_VERSION + 5, "mystery": 1}


# ------------------------------------------------------------------ CLI
def test_upgrade_info_cli(capsys):
    seed_data()
    assert main(["--upgrade-info"]) == 0
    out = capsys.readouterr().out
    assert f"Sorot {CURRENT}" in out and "Cara memperbarui" in out and "docs/UPGRADING.md" in out


def test_backup_and_restore_cli_round_trip(capsys, tmp_path):
    seed_data()
    before = snapshot_tree()
    target = tmp_path / "cadangan.zip"
    assert main(["--backup", str(target)]) == 0
    assert "diverifikasi" in capsys.readouterr().out and target.exists()
    (paths.data_dir() / "draft.txt").write_text("hilang", encoding="utf-8")
    assert main(["--restore", str(target)]) == 0
    assert snapshot_tree() == before
    assert "Dipulihkan" in capsys.readouterr().out


def test_cli_error_paths(capsys, tmp_path):
    assert main(["--backup"]) == 1 and "Belum ada data" in capsys.readouterr().err
    assert main(["--restore"]) == 2
    assert main(["--restore", str(tmp_path / "tidak-ada.zip")]) == 1
    assert "tidak ditemukan" in capsys.readouterr().err


def test_help_mentions_new_commands_and_contact(capsys):
    assert main(["--help"]) == 0
    out = capsys.readouterr().out
    assert "--upgrade-info" in out and "--backup" in out and "--restore" in out and sorot.CONTACT_EMAIL in out


def test_upgrade_info_flags_data_from_an_untracked_release(capsys):
    seed_data()
    assert main(["--upgrade-info"]) == 0
    out = capsys.readouterr().out
    assert "cadangan otomatis dibuat saat Sorot dijalankan" in out and "instalasi baru" not in out.split("Status")[1].split("\n")[0]
    upgrade.write_stamp(CURRENT, SCHEMA_VERSION)
    main(["--upgrade-info"])
    assert "versi sama" in capsys.readouterr().out
