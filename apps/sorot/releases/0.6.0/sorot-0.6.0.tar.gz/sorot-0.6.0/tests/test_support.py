import pytest

import sorot
from sorot import support
from sorot.support import (
    SupportInfo,
    contact_mailto,
    format_id_phone,
    international_id_phone,
    normalize_id_phone,
    support_info,
    validate_email,
)


@pytest.mark.parametrize("raw", ["081274852534", "81274852534", "+62 812-7485-2534", "6281274852534", "0812 7485 2534", "0812-7485-2534"])
def test_phone_variants_normalise_to_national_form(raw):
    assert normalize_id_phone(raw) == "081274852534"


@pytest.mark.parametrize("raw", ["", "abc", "0212345678", "0812", "08127485253400000", "+1 202 555 0100"])
def test_non_mobile_numbers_are_rejected(raw):
    with pytest.raises(ValueError):
        normalize_id_phone(raw)


def test_display_formats():
    assert format_id_phone("81274852534") == "0812-7485-2534"
    assert international_id_phone("081274852534") == "+62 812-7485-2534"


def test_configured_support_info_is_valid_and_https_only():
    info = support_info()
    assert info.saweria_url == "https://saweria.co/tamaandrea" and info.gopay_display == "0812-7485-2534"
    assert info.author == "Muhammad Andreatama"
    with pytest.raises(ValueError):
        SupportInfo("x", "http://saweria.co/x", "081274852534").validate()
    with pytest.raises(ValueError):
        SupportInfo("x", "javascript:alert(1)", "081274852534").validate()
    with pytest.raises(ValueError):
        SupportInfo("x", "https://saweria.co/x", "123").validate()


def test_promise_text_states_there_is_no_nagging_or_tracking():
    assert "sukarela" in support.PROMISE and "tidak ada pelacakan" in support.PROMISE


def test_professional_contact_is_the_real_address_and_not_a_placeholder():
    assert sorot.CONTACT_EMAIL == "muhammadandreatama@outlook.com"
    assert support_info().contact_email == sorot.CONTACT_EMAIL
    assert ".invalid" not in sorot.CONTACT_EMAIL


def test_contact_mailto_is_well_formed():
    assert contact_mailto() == "mailto:muhammadandreatama@outlook.com"
    assert contact_mailto(subject="Kerja sama & tawaran") == "mailto:muhammadandreatama@outlook.com?subject=Kerja%20sama%20%26%20tawaran"


@pytest.mark.parametrize("bad", ["", "tanpa-at", "a@b", "a b@c.com", "a@b.com,c@d.com", "a@b.com?cc=x@y.com", "a@b.com\nBcc: x@y.com", "javascript:alert(1)"])
def test_malformed_or_injected_addresses_are_rejected(bad):
    with pytest.raises(ValueError):
        validate_email(bad)
    with pytest.raises(ValueError):
        contact_mailto(bad)
    with pytest.raises(ValueError):
        SupportInfo("x", "https://saweria.co/x", "081274852534", bad).validate()
