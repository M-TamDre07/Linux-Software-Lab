# Pengujian manual (GNOME Wayland dan KDE Plasma)

Semua butir berstatus **BELUM DIUJI** pada rilis 0.4.0 karena tidak ada sesi desktop nyata di lingkungan pembangunan. Catat hasilnya di tabel akhir dan jalankan `sorot --diagnostics` sebelum mulai.

## Persiapan
1. Pasang paket, buka aplikasi, isi naskah ±30 baris.
2. Catat: desktop, jenis sesi (`echo $XDG_SESSION_TYPE`), backend Qt (tab Sistem).
3. Siapkan aplikasi biasa (editor teks atau browser) sebagai latar.

## Matriks yang diuji
Ulangi bagian “Pemeriksaan” untuk setiap baris:

| # | Desktop | Sesi | Backend Qt |
|---|---|---|---|
| 1 | GNOME | Wayland | otomatis (XWayland/xcb) |
| 2 | GNOME | Wayland | `SOROT_QT_PLATFORM=wayland` |
| 3 | KDE Plasma | Wayland | otomatis |
| 4 | KDE Plasma | Wayland | `SOROT_QT_PLATFORM=wayland` |
| 5 | KDE Plasma | X11 | otomatis |
| 6 | Xfce / Cinnamon (jika ada) | X11 | otomatis |
| 7 | Arch Linux (paket dari `PKGBUILD`), KDE atau GNOME | Wayland atau X11 | otomatis |

## Pemeriksaan
1. **Mulai dan tutup.** Aplikasi terbuka tanpa error; menutup jendela utama menutup overlay; tidak ada proses `python3 -m sorot` tersisa (`pgrep -f sorot`).
2. **Overlay di atas aplikasi biasa.** Tekan “Tampilkan overlay”. Klik aplikasi latar. Apakah overlay tetap di atas? (Wayland asli: mungkin tidak, lihat catatan kompatibilitas.)
3. **Transparansi & ukuran.** Geser slider transparansi dan ubah lebar/tinggi; overlay mengikuti.
4. **Geser & ubah ukuran.** Arahkan kursor ke overlay → seret “⠿ Geser”; seret pegangan sudut kanan bawah; Ctrl+seret.
5. **Gulir.** Mulai/Jeda/Awal dari bar overlay dan dari jendela utama; roda mouse; tombol − dan +; berhenti di akhir naskah.
6. **Fokus.** Ketik di aplikasi latar saat overlay tampil — fokus tidak boleh berpindah ke overlay.
7. **Klik-tembus.** Aktifkan; klik pada area overlay — apakah klik sampai ke aplikasi latar? Matikan lagi.
8. **Tanpa bingkai / selalu-di-atas.** Matikan masing-masing; catat efeknya.
9. **Multi-monitor** (jika ada). Pilih layar lain; cabut layar saat overlay tampil.
10. **Layar penuh.** Jadikan aplikasi latar layar penuh; catat apakah overlay tampak.
11. **Persistensi.** Ubah ukuran huruf, warna, posisi manual; tutup; buka lagi — pengaturan dan posisi kembali.
12. **Pemulihan crash.** Ketik teks, tunggu 2 detik, `pkill -9 -f sorot`, buka lagi — teks kembali.
13. **Pintasan.** Ctrl+Enter, Ctrl+Space, Esc, Ctrl+R, Alt+↑/↓ dengan editor terfokus.
14. **Fitur tak didukung.** Pastikan pesan di tab Tampilan/Sistem sesuai kenyataan yang kamu lihat (jangan percaya tabel kemampuan secara membabi buta; laporkan jika salah).
15. **Screen sharing.** Bagikan seluruh layar pada aplikasi rapat target; catat apakah overlay ikut tampak.

## Tabel hasil

| # | Hasil (LULUS / GAGAL / SEBAGIAN) | Catatan |
|---|---|---|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| 6 | | |
