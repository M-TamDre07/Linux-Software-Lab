# shellcheck shell=bash
# Shared by the build scripts. Source it; do not run it.
# Provides: ROOT, VERSION, RELEASE_DATE and a reproducible environment (SOURCE_DATE_EPOCH, LC_ALL, TZ).
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VERSION="$(python3 "$ROOT/scripts/release.py" version)"
RELEASE_DATE="$(tr -d '[:space:]' < "$ROOT/packaging/RELEASE_DATE")"
export SOURCE_DATE_EPOCH="${SOURCE_DATE_EPOCH:-$(date -u -d "$RELEASE_DATE 00:00:00" +%s)}"
export LC_ALL=C TZ=UTC

# absdir DIR -> creates DIR if needed and prints its absolute path
absdir() { mkdir -p "$1" && (cd "$1" && pwd); }
