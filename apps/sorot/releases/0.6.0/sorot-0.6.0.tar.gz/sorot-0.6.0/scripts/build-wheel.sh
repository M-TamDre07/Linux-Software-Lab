#!/bin/bash
# Reproducible pure-Python wheel (for pip, pipx, and as the payload of the Arch package).
# Needs setuptools and wheel; uses `python -m build` when present, otherwise `pip wheel`.
# Builds in a scratch copy so the source tree never gains build/ or *.egg-info.
# Usage: scripts/build-wheel.sh [output-dir]
set -euo pipefail
# shellcheck source=lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
OUT="$(absdir "${1:-$ROOT/dist}")"
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
mkdir -p "$STAGE/src"
cp -r "$ROOT/src/sorot" "$STAGE/src/sorot"
cp "$ROOT/pyproject.toml" "$ROOT/README.md" "$ROOT/LICENSE" "$STAGE/"
find "$STAGE" -name '__pycache__' -type d -prune -exec rm -rf {} +
find "$STAGE" -exec touch -h -d "@$SOURCE_DATE_EPOCH" {} +
if python3 -c 'import build' 2>/dev/null; then
    (cd "$STAGE" && python3 -m build --wheel --no-isolation --outdir "$OUT" >/dev/null)
else
    (cd "$STAGE" && python3 -m pip wheel . --no-build-isolation --no-deps -q -w "$OUT")
fi
echo "$OUT/sorot-$VERSION-py3-none-any.whl"
