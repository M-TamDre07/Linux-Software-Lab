#!/bin/bash
# Reproducible Debian package (Architecture: all).
# Usage: scripts/build-deb.sh [output-dir]
set -euo pipefail
# shellcheck source=lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
OUT="$(absdir "${1:-$ROOT/dist}")"
PKG="sorot_${VERSION}_all"
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT

# ---- code and launcher ----------------------------------------------------------
install -d "$STAGE/usr/lib/sorot" "$STAGE/usr/bin"
(cd "$ROOT/src" && find sorot \( -name '*.py' -o -name '*.svg' \) -print0 | sort -z | xargs -0 -I{} install -D -m 0644 {} "$STAGE/usr/lib/sorot/{}")
install -m 0755 "$ROOT/packaging/sorot.sh" "$STAGE/usr/bin/sorot"
# ---- everything else: one shared definition of the file layout ---------------------
"$ROOT/scripts/install-files.sh" --layout deb "$STAGE" /usr
gzip -9n -c "$ROOT/packaging/debian-changelog" > "$STAGE/usr/share/doc/sorot/changelog.gz"
chmod 0644 "$STAGE/usr/share/doc/sorot/changelog.gz"

# ---- control data -------------------------------------------------------------------
install -d "$STAGE/DEBIAN"
SIZE="$(du -sk --apparent-size "$STAGE" | cut -f1)"
sed -e "s/@VERSION@/$VERSION/" -e "s/@SIZE@/$SIZE/" "$ROOT/packaging/control.in" > "$STAGE/DEBIAN/control"
for script in postinst prerm postrm; do install -m 0755 "$ROOT/packaging/$script" "$STAGE/DEBIAN/$script"; done
(cd "$STAGE" && find usr -type f -print0 | sort -z | xargs -0 md5sum > DEBIAN/md5sums)
chmod 0644 "$STAGE/DEBIAN/md5sums"

# ---- normalise and build ---------------------------------------------------------------
find "$STAGE" -exec touch -h -d "@$SOURCE_DATE_EPOCH" {} +
dpkg-deb --root-owner-group -Zxz -b "$STAGE" "$OUT/$PKG.deb" >/dev/null
echo "$OUT/$PKG.deb"
