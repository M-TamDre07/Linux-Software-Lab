#!/bin/bash
# Arch Linux packaging: renders PKGBUILD and .SRCINFO next to the source tarball.
# Usage: scripts/build-arch.sh [output-dir] [--makepkg]
#   Result: OUTPUT/arch/{PKGBUILD,.SRCINFO,sorot-VERSION.tar.gz}
#   --makepkg  also run `makepkg -f` there (needs an Arch system and a non-root user)
set -euo pipefail
# shellcheck source=lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

RUN_MAKEPKG=0
ARGS=()
for arg in "$@"; do if [ "$arg" = "--makepkg" ]; then RUN_MAKEPKG=1; else ARGS+=("$arg"); fi; done
OUT="$(absdir "${ARGS[0]:-$ROOT/dist}")"
ARCH_DIR="$(absdir "$OUT/arch")"
TARBALL="sorot-$VERSION.tar.gz"

# The PKGBUILD's source is exactly the tarball we publish, so build it first (reproducibly).
"$ROOT/scripts/build-source.sh" "$ARCH_DIR" >/dev/null
rm -f "$ARCH_DIR/sorot-$VERSION.zip"
SHA256="$(sha256sum "$ARCH_DIR/$TARBALL" | cut -d' ' -f1)"
sed -e "s/@VERSION@/$VERSION/g" -e "s/@SHA256@/$SHA256/g" "$ROOT/packaging/arch/PKGBUILD.in" > "$ARCH_DIR/PKGBUILD"
if grep -q '@[A-Z0-9_]*@' "$ARCH_DIR/PKGBUILD"; then echo "Placeholder tersisa di PKGBUILD" >&2; exit 1; fi
bash -n "$ARCH_DIR/PKGBUILD"
# makepkg's own output is authoritative when available; otherwise render the same fields ourselves.
if command -v makepkg >/dev/null 2>&1 && [ "$(id -u)" != 0 ]; then
    (cd "$ARCH_DIR" && makepkg --printsrcinfo > .SRCINFO)
else
    python3 "$ROOT/scripts/release.py" srcinfo "$ARCH_DIR/PKGBUILD" > "$ARCH_DIR/.SRCINFO"
fi
echo "$ARCH_DIR/PKGBUILD"
echo "$ARCH_DIR/.SRCINFO"
echo "$ARCH_DIR/$TARBALL"
if [ "$RUN_MAKEPKG" = 1 ]; then
    command -v makepkg >/dev/null 2>&1 || { echo "makepkg tidak ditemukan: jalankan ini di Arch Linux." >&2; exit 1; }
    [ "$(id -u)" != 0 ] || { echo "makepkg tidak boleh dijalankan sebagai root." >&2; exit 1; }
    (cd "$ARCH_DIR" && makepkg -f)
fi
