#!/bin/bash
# Build every release artifact and one combined SHA256SUMS.
# Usage: scripts/build-all.sh [output-dir]
set -euo pipefail
# shellcheck source=lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
python3 "$ROOT/scripts/release.py" check
OUT="$(absdir "${1:-$ROOT/dist}")"
"$ROOT/scripts/build-deb.sh" "$OUT" >/dev/null
"$ROOT/scripts/build-source.sh" "$OUT" >/dev/null
"$ROOT/scripts/build-wheel.sh" "$OUT" >/dev/null
"$ROOT/scripts/build-arch.sh" "$OUT" >/dev/null
(cd "$OUT" && sha256sum "sorot_${VERSION}_all.deb" "sorot-$VERSION.tar.gz" "sorot-$VERSION.zip" "sorot-$VERSION-py3-none-any.whl" \
    "arch/PKGBUILD" "arch/.SRCINFO" > SHA256SUMS && cat SHA256SUMS)
