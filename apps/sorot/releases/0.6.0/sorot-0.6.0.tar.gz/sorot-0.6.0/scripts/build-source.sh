#!/bin/bash
# Reproducible source archives: sorot-VERSION.tar.gz and sorot-VERSION.zip.
# Usage: scripts/build-source.sh [output-dir]
set -euo pipefail
# shellcheck source=lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
OUT="$(absdir "${1:-$ROOT/dist}")"

if git -C "$ROOT" rev-parse --git-dir >/dev/null 2>&1 && [ -n "$(git -C "$ROOT" ls-files | head -1)" ]; then
    FILES="$(git -C "$ROOT" ls-files)"
else
    FILES="$(cd "$ROOT" && find . -type f -not -path './.git/*' -not -path './dist/*' -not -path './build/*' -not -path '*/__pycache__/*' \
        -not -path './.venv/*' -not -path './.pytest_cache/*' -not -path './.mypy_cache/*' -not -path './.ruff_cache/*' \
        -not -path '*.egg-info/*' -not -name '*.pyc' | sed 's|^\./||' | sort)"
fi
SRC="sorot-$VERSION"
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
mkdir -p "$STAGE/$SRC"
(cd "$ROOT" && echo "$FILES" | tar -cf - -T -) | tar -xf - -C "$STAGE/$SRC"
find "$STAGE" -exec touch -h -d "@$SOURCE_DATE_EPOCH" {} +
(cd "$STAGE" && tar --sort=name --owner=0 --group=0 --numeric-owner --mtime="@$SOURCE_DATE_EPOCH" -cf - "$SRC" | gzip -9n > "$OUT/$SRC.tar.gz")
rm -f "$OUT/$SRC.zip"
(cd "$STAGE" && find "$SRC" -type f | sort | TZ=UTC zip -X -q -9 "$OUT/$SRC.zip" -@)
echo "$OUT/$SRC.tar.gz"
echo "$OUT/$SRC.zip"
