"""Extension support: manifests, discovery, safe installation, and out-of-process runners.

Two kinds of extension share one manifest format (``sorot-extension.json``):

* **Declarative** — data only (themes, overlay colour presets, AI task prompts, script
  templates). Nothing is executed.
* **Code** — a Python ``entry`` file that runs in a separate process and talks to the
  application over a JSON-lines protocol. It is not sandboxed; the user must approve it
  explicitly and any change to its files revokes that approval.
"""

API_VERSION = 1
MANIFEST_NAME = "sorot-extension.json"
