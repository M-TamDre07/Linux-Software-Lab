"""Install and remove user extensions safely (folders and ``.zip`` archives)."""
from __future__ import annotations

import shutil
import stat
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

from sorot.extensions import MANIFEST_NAME
from sorot.extensions.discovery import MAX_TREE_BYTES, MAX_TREE_FILES, hash_tree, user_extensions_dir
from sorot.extensions.manifest import ExtensionError, load_manifest


def _copy_tree_checked(source: Path, target: Path) -> None:
    files = total = 0
    for item in source.rglob("*"):
        if item.is_symlink():
            raise ExtensionError(f"Tautan simbolik tidak diizinkan di dalam ekstensi: {item.relative_to(source)}")
        if item.is_file():
            files += 1
            total += item.stat().st_size
            if files > MAX_TREE_FILES or total > MAX_TREE_BYTES:
                raise ExtensionError("Ekstensi terlalu besar (maksimal 2000 berkas / 50 MB).")
    shutil.copytree(source, target, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".git"))


def _finalise(staged: Path, *, replace: bool, user_dir: Path) -> str:
    manifest = load_manifest(staged)
    user_dir.mkdir(parents=True, exist_ok=True)
    destination = user_dir / manifest.ext_id
    if destination.exists():
        if not replace:
            raise ExtensionError(f"Ekstensi “{manifest.ext_id}” sudah terpasang.")
        backup = destination.with_name(destination.name + ".old")
        if backup.exists():
            shutil.rmtree(backup)
        destination.rename(backup)
        try:
            shutil.move(str(staged), str(destination))
        except Exception:
            backup.rename(destination)
            raise
        shutil.rmtree(backup, ignore_errors=True)
    else:
        shutil.move(str(staged), str(destination))
    if manifest.has_code:
        hash_tree(destination)  # fail early on oversized trees
    return manifest.ext_id


def install_from_dir(source: Path, *, replace: bool = False, user_dir: Path | None = None) -> str:
    source = Path(source)
    if not (source / MANIFEST_NAME).is_file():
        raise ExtensionError(f"Folder yang dipilih tidak berisi {MANIFEST_NAME}.")
    load_manifest(source)  # validate before copying anything
    root = user_dir or user_extensions_dir()
    root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=root, prefix=".install-") as scratch:
        staged = Path(scratch) / "ext"
        _copy_tree_checked(source, staged)
        return _finalise(staged, replace=replace, user_dir=root)


def install_from_zip(archive: Path, *, replace: bool = False, user_dir: Path | None = None) -> str:
    root = user_dir or user_extensions_dir()
    root.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(archive) as zf, tempfile.TemporaryDirectory(dir=root, prefix=".install-") as scratch:
            infos = zf.infolist()
            if len(infos) > MAX_TREE_FILES:
                raise ExtensionError("Arsip berisi terlalu banyak berkas.")
            if sum(i.file_size for i in infos) > MAX_TREE_BYTES:
                raise ExtensionError("Isi arsip melebihi batas 50 MB setelah diekstrak.")
            names = [PurePosixPath(i.filename) for i in infos if not i.is_dir()]
            prefix = ""
            if names and not any(n.as_posix() == MANIFEST_NAME for n in names):
                tops = {n.parts[0] for n in names}
                if len(tops) == 1 and any(n.as_posix() == f"{next(iter(tops))}/{MANIFEST_NAME}" for n in names):
                    prefix = next(iter(tops)) + "/"
            staged = Path(scratch) / "ext"
            staged.mkdir()
            for info in infos:
                mode = info.external_attr >> 16
                if stat.S_ISLNK(mode):
                    raise ExtensionError(f"Tautan simbolik tidak diizinkan di arsip: {info.filename}")
                name = PurePosixPath(info.filename)
                if name.is_absolute() or ".." in name.parts or "\\" in info.filename or "\x00" in info.filename:
                    raise ExtensionError(f"Jalur berbahaya di arsip: {info.filename}")
                relative = info.filename[len(prefix):] if prefix and info.filename.startswith(prefix) else info.filename
                if prefix and not info.filename.startswith(prefix):
                    continue
                if not relative or info.is_dir():
                    continue
                target = (staged / relative).resolve()
                if staged.resolve() not in target.parents:
                    raise ExtensionError(f"Jalur berbahaya di arsip: {info.filename}")
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as src, target.open("wb") as out:
                    shutil.copyfileobj(src, out, length=1 << 20)
            if not (staged / MANIFEST_NAME).is_file():
                raise ExtensionError(f"Arsip tidak berisi {MANIFEST_NAME} di tingkat teratas.")
            return _finalise(staged, replace=replace, user_dir=root)
    except zipfile.BadZipFile as exc:
        raise ExtensionError("Berkas bukan arsip ZIP yang valid.") from exc
    except OSError as exc:
        raise ExtensionError(f"Pemasangan gagal: {exc.strerror or exc}") from exc


def uninstall(ext_id: str, *, user_dir: Path | None = None) -> None:
    """Remove a user-installed extension. Only the user directory is ever touched."""
    root = (user_dir or user_extensions_dir()).resolve()
    target = (root / ext_id).resolve()
    if target.parent != root or not target.is_dir():
        raise ExtensionError("Ekstensi tidak ditemukan di folder pengguna (ekstensi sistem atau pip tidak dapat dihapus dari sini).")
    shutil.rmtree(target)
