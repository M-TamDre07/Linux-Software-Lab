"""Enable/approval rules (pure functions over the ``extensions`` section of the config).

* Declarative extensions are enabled by default; nothing in them is executed.
* Code extensions are never enabled implicitly. Approval records the SHA-256 of the
  extension's files; if any file changes, the approval no longer matches and the
  extension stays off until the user approves the new code.
"""
from __future__ import annotations

from typing import Any

from sorot.extensions.discovery import ExtensionInfo

States = dict[str, dict[str, Any]]


def approval_status(info: ExtensionInfo, states: States) -> str:
    """One of: ``invalid``, ``active``, ``disabled``, ``needs_approval``, ``changed``."""
    if not info.usable or info.manifest is None:
        return "invalid"
    state = states.get(info.ext_id)
    if not info.manifest.has_code:
        return "disabled" if state is not None and state.get("enabled") is False else "active"
    if not state or not state.get("enabled"):
        return "needs_approval" if not state or not state.get("approved_hash") else "disabled"
    return "active" if state.get("approved_hash") == info.code_hash else "changed"


def is_active(info: ExtensionInfo, states: States) -> bool:
    return approval_status(info, states) == "active"


def approve(states: States, info: ExtensionInfo) -> None:
    states[info.ext_id] = {"enabled": True, "approved_hash": info.code_hash}


def enable_declarative(states: States, ext_id: str) -> None:
    states[ext_id] = {"enabled": True, "approved_hash": ""}


def disable(states: States, ext_id: str) -> None:
    previous = states.get(ext_id, {})
    states[ext_id] = {"enabled": False, "approved_hash": previous.get("approved_hash", "")}


def forget(states: States, ext_id: str) -> None:
    states.pop(ext_id, None)


STATUS_LABELS = {
    "invalid": "tidak valid",
    "active": "aktif",
    "disabled": "nonaktif",
    "needs_approval": "menunggu persetujuan",
    "changed": "kode berubah — perlu disetujui ulang",
}
