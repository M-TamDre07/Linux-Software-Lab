"""JSON-lines protocol between the application (host) and an extension process (runner).

Host -> runner: ``{"id": 1, "method": "transform", "params": {...}}`` or, for events,
``{"event": "playback.started", "data": {...}}`` (no reply expected).
Runner -> host: ``{"id": 1, "result": ...}``, ``{"id": 1, "error": "..."}``, ``{"notify": "..."}``
or ``{"log": "..."}``. One message per line, UTF-8, at most ``MAX_LINE_BYTES``.
"""
from __future__ import annotations

import json
from typing import Any

MAX_LINE_BYTES = 12_000_000
EVENT_NAMES = (
    "app.started", "app.closing", "script.opened", "script.saved", "script.changed",
    "overlay.shown", "overlay.hidden", "playback.started", "playback.paused", "playback.finished", "playback.progress",
)
METHODS = ("hello", "transform", "import", "export", "action", "shutdown")
TIMEOUTS = {"hello": 15.0, "transform": 30.0, "import": 60.0, "export": 60.0, "action": 30.0}


def encode(message: dict[str, Any]) -> bytes:
    data = json.dumps(message, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if len(data) > MAX_LINE_BYTES:
        raise ValueError("pesan terlalu besar")
    return data + b"\n"


def decode(line: bytes) -> dict[str, Any]:
    message = json.loads(line.decode("utf-8"))
    if not isinstance(message, dict):
        raise ValueError("pesan harus berupa objek JSON")
    return message
