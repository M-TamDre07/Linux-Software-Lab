"""Find extensions on disk and fingerprint their code."""
from __future__ import annotations

import hashlib
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

from sorot.core import paths
from sorot.extensions import MANIFEST_NAME
from sorot.extensions.manifest import ExtensionError, Manifest, load_manifest

LOGGER = logging.getLogger(__name__)
MAX_TREE_BYTES = 50_000_000
MAX_TREE_FILES = 2000
SYSTEM_DIRS = (Path("/usr/share/sorot/extensions"), Path("/usr/local/share/sorot/extensions"))
ENTRY_POINT_GROUP = "sorot.extensions"


def user_extensions_dir() -> Path:
    return paths.data_dir() / "extensions"


def extension_data_dir(ext_id: str) -> Path:
    """Private, writable scratch space the extension may use (created on demand)."""
    return paths.data_dir() / "extension-data" / ext_id


@dataclass
class ExtensionInfo:
    manifest: Manifest | None
    path: Path
    origin: str  # "user" | "system" | "pip"
    error: str = ""
    code_hash: str = ""
    problems: list[str] = field(default_factory=list)

    @property
    def ext_id(self) -> str:
        return self.manifest.ext_id if self.manifest else f"?{self.path.name}"

    @property
    def usable(self) -> bool:
        return self.manifest is not None and not self.error


def hash_tree(root: Path) -> str:
    """SHA-256 over relative paths and contents of every regular file (stable ordering)."""
    digest = hashlib.sha256()
    total = files = 0
    root = Path(root)
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames[:] = sorted(d for d in dirnames if d not in {"__pycache__", ".git"})
        for name in sorted(filenames):
            file = Path(dirpath) / name
            if file.is_symlink() or name.endswith((".pyc", ".pyo")):
                continue
            files += 1
            if files > MAX_TREE_FILES:
                raise ExtensionError("Terlalu banyak berkas dalam ekstensi.")
            size = file.stat().st_size
            total += size
            if total > MAX_TREE_BYTES:
                raise ExtensionError("Ukuran total ekstensi melebihi batas 50 MB.")
            digest.update(file.relative_to(root).as_posix().encode("utf-8") + b"\0")
            with file.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1 << 20), b""):
                    digest.update(chunk)
            digest.update(b"\0")
    return digest.hexdigest()


def _inspect(path: Path, origin: str) -> ExtensionInfo:
    try:
        manifest = load_manifest(path)
        code_hash = hash_tree(path) if manifest.has_code else ""
        return ExtensionInfo(manifest, path, origin, code_hash=code_hash, problems=list(manifest.problems))
    except ExtensionError as exc:
        return ExtensionInfo(None, path, origin, error=str(exc))


def _scan_dir(directory: Path, origin: str) -> list[ExtensionInfo]:
    if not directory.is_dir():
        return []
    found = []
    for child in sorted(directory.iterdir()):
        if child.is_dir() and not child.is_symlink() and (child / MANIFEST_NAME).exists():
            found.append(_inspect(child, origin))
    return found


def _entry_point_dirs() -> list[Path]:
    """Directories of pip-installed packages that advertise the ``sorot.extensions`` entry-point group."""
    import importlib.util
    from importlib.metadata import entry_points

    result: list[Path] = []
    try:
        points = entry_points(group=ENTRY_POINT_GROUP)
    except Exception as exc:  # noqa: BLE001 - a broken distribution must not stop startup
        LOGGER.warning("Entry point ekstensi tidak dapat dibaca: %s", type(exc).__name__)
        return result
    for point in points:
        module_name = point.value.split(":")[0].strip()
        try:
            spec = importlib.util.find_spec(module_name)
        except Exception:  # noqa: BLE001
            continue
        locations = list(spec.submodule_search_locations or []) if spec else []
        if locations:
            result.append(Path(locations[0]))
    return result


def discover(*, user_dir: Path | None = None, system_dirs: tuple[Path, ...] | None = None, include_pip: bool = True) -> list[ExtensionInfo]:
    """All extensions visible to the application. User installs shadow same-id system/pip ones."""
    infos: list[ExtensionInfo] = []
    infos += _scan_dir(user_dir or user_extensions_dir(), "user")
    for directory in system_dirs if system_dirs is not None else SYSTEM_DIRS:
        infos += _scan_dir(directory, "system")
    if include_pip:
        for directory in _entry_point_dirs():
            if (directory / MANIFEST_NAME).exists():
                infos.append(_inspect(directory, "pip"))
    seen: dict[str, ExtensionInfo] = {}
    unique: list[ExtensionInfo] = []
    for info in infos:
        if info.usable and info.ext_id in seen:
            seen[info.ext_id].problems.append(f"salinan di {info.path} diabaikan (id ganda).")
            continue
        if info.usable:
            seen[info.ext_id] = info
        unique.append(info)
    return unique
