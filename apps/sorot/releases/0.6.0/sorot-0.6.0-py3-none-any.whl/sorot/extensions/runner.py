"""Child process that hosts one code extension. Run as ``python -m sorot.extensions.runner <dir> <entry>``.

``stdout`` is reserved for the protocol; anything the extension prints is redirected to
``stderr`` (which the host logs). The extension talks to the application only through
the ``api`` object passed to its ``activate(api)`` function.
"""
from __future__ import annotations

import importlib.util
import os
import sys
import threading
import traceback
from collections.abc import Callable
from pathlib import Path
from typing import Any

from sorot.extensions import API_VERSION, protocol

_PROTO_OUT = sys.stdout  # keep the real stdout for the protocol before redirecting
sys.stdout = sys.stderr


class ExtensionAPI:
    """What an extension can do. All registration happens inside ``activate``."""

    api_version = API_VERSION

    def __init__(self, app_version: str, data_dir: str) -> None:
        self.app_version = app_version
        self.data_dir = Path(data_dir)
        self._transforms: dict[str, tuple[str, Callable[[str], str]]] = {}
        self._importers: dict[str, tuple[str, list[str], Callable[[str], str]]] = {}
        self._exporters: dict[str, tuple[str, str, Callable[[str, str], None]]] = {}
        self._actions: dict[str, tuple[str, Callable[[str], Any]]] = {}
        self._handlers: dict[str, list[Callable[[dict], None]]] = {}
        self._lock = threading.Lock()
        self._sent_notifications = 0

    # -- registration -------------------------------------------------------
    def register_transform(self, transform_id: str, label: str, function: Callable[[str], str]) -> None:
        """``function(text) -> text``; shown under Ekstensi and applied (undoably) to the script or selection."""
        self._transforms[str(transform_id)] = (str(label), function)

    def register_importer(self, importer_id: str, label: str, extensions: list[str], function: Callable[[str], str]) -> None:
        """``function(path) -> text`` for files with one of ``extensions`` (e.g. ``[".md"]``)."""
        self._importers[str(importer_id)] = (str(label), [str(e) for e in extensions], function)

    def register_exporter(self, exporter_id: str, label: str, extension: str, function: Callable[[str, str], None]) -> None:
        """``function(text, path)`` writes the script to ``path``."""
        self._exporters[str(exporter_id)] = (str(label), str(extension), function)

    def register_action(self, action_id: str, label: str, function: Callable[[str], Any]) -> None:
        """``function(text) -> None | str | {"notify": str, "set_text": str}``."""
        self._actions[str(action_id)] = (str(label), function)

    def on(self, event: str, function: Callable[[dict], None]) -> None:
        """Subscribe to an application event (see ``protocol.EVENT_NAMES``)."""
        self._handlers.setdefault(str(event), []).append(function)

    # -- talking back ---------------------------------------------------------------
    def notify(self, message: str) -> None:
        """Show a short message in the application's status bar (rate limited)."""
        with self._lock:
            self._sent_notifications += 1
            if self._sent_notifications > 50:
                return
        _send({"notify": str(message)[:300]})

    def log(self, message: str) -> None:
        _send({"log": str(message)[:500]})

    def describe(self) -> dict[str, Any]:
        return {
            "transforms": [{"id": k, "label": v[0]} for k, v in self._transforms.items()],
            "importers": [{"id": k, "label": v[0], "extensions": v[1]} for k, v in self._importers.items()],
            "exporters": [{"id": k, "label": v[0], "extension": v[1]} for k, v in self._exporters.items()],
            "actions": [{"id": k, "label": v[0]} for k, v in self._actions.items()],
            "events": [e for e in self._handlers if e in protocol.EVENT_NAMES],
        }


_write_lock = threading.Lock()


def _send(message: dict[str, Any]) -> None:
    data = protocol.encode(message)
    with _write_lock:
        _PROTO_OUT.buffer.write(data)
        _PROTO_OUT.buffer.flush()


def _load_entry(directory: Path, entry: str) -> Any:
    sys.path.insert(0, str(directory))
    spec = importlib.util.spec_from_file_location("sorot_extension_entry", directory / entry)
    if spec is None or spec.loader is None:
        raise ImportError(f"tidak dapat memuat {entry}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _handle(api: ExtensionAPI, module: Any, method: str, params: dict[str, Any]) -> Any:
    if method == "transform":
        _label, function = api._transforms[params["id"]]
        result = function(params["text"])
        if not isinstance(result, str):
            raise TypeError("transform harus mengembalikan teks (str)")
        return {"text": result}
    if method == "import":
        _label, _exts, reader = api._importers[params["id"]]
        result = reader(params["path"])
        if not isinstance(result, str):
            raise TypeError("importer harus mengembalikan teks (str)")
        return {"text": result}
    if method == "export":
        _label, _ext, writer = api._exporters[params["id"]]
        writer(params["text"], params["path"])
        return {}
    if method == "action":
        _label, act = api._actions[params["id"]]
        outcome = act(params.get("text", ""))
        if outcome is None:
            return {}
        if isinstance(outcome, str):
            return {"notify": outcome[:300]}
        if isinstance(outcome, dict):
            return {k: outcome[k] for k in ("notify", "set_text") if isinstance(outcome.get(k), str)}
        raise TypeError("action harus mengembalikan None, str, atau dict")
    raise ValueError(f"metode tidak dikenal: {method}")


def main(argv: list[str]) -> int:
    directory, entry = Path(argv[1]).resolve(), argv[2]
    api: ExtensionAPI | None = None
    module: Any = None
    for raw in sys.stdin.buffer:
        try:
            message = protocol.decode(raw)
        except (ValueError, UnicodeDecodeError):
            continue
        if "event" in message:
            if api is not None:
                for handler in api._handlers.get(str(message["event"]), []):
                    try:
                        handler(message.get("data") or {})
                    except Exception:  # noqa: BLE001 - one bad handler must not kill the runner
                        traceback.print_exc()
            continue
        request_id, method, params = message.get("id"), message.get("method"), message.get("params") or {}
        try:
            if method == "hello":
                api = ExtensionAPI(str(params.get("app_version", "")), str(params.get("data_dir", "")))
                api.data_dir.mkdir(parents=True, exist_ok=True)
                os.chdir(directory)
                module = _load_entry(directory, entry)
                activate = getattr(module, "activate", None)
                if not callable(activate):
                    raise AttributeError("ekstensi harus mendefinisikan fungsi activate(api)")
                activate(api)
                result: Any = api.describe()
            elif method == "shutdown":
                deactivate = getattr(module, "deactivate", None)
                if callable(deactivate):
                    deactivate()
                _send({"id": request_id, "result": {}})
                return 0
            elif api is None:
                raise RuntimeError("belum diaktifkan")
            else:
                result = _handle(api, module, str(method), params)
            _send({"id": request_id, "result": result})
        except KeyError as exc:
            _send({"id": request_id, "error": f"perintah tidak terdaftar: {exc}"})
        except Exception as exc:  # noqa: BLE001 - report every failure to the host
            traceback.print_exc()
            _send({"id": request_id, "error": f"{type(exc).__name__}: {exc}"[:500]})
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
