"""Application bootstrap: argument handling, logging, Qt backend, and startup."""
from __future__ import annotations

import logging
import os
import sys

from sorot import APP_NAME, ORG_NAME, VERSION_LABEL, __version__

HELP = (
    f"Sorot {VERSION_LABEL} — teleprompter desktop\n\n"
    "Penggunaan: sorot [opsi]\n\n"
    "Opsi:\n"
    "  -h, --help      tampilkan bantuan ini\n"
    "  --version       tampilkan versi aplikasi\n"
    "  --diagnostics   cetak ringkasan lingkungan sistem tanpa membuka jendela\n"
    "  --extensions    daftar ekstensi yang ditemukan beserta statusnya\n"
    "  --validate-extension FOLDER [--run]\n"
    "                  periksa manifest ekstensi; dengan --run juga memuatnya (menjalankan kodenya)\n"
    "  --upgrade-info  tampilkan versi, cara pemasangan, cara memperbarui, dan daftar cadangan\n"
    "  --backup [BERKAS|FOLDER]\n"
    "                  buat cadangan data (pengaturan, naskah, ekstensi) sebagai ZIP terverifikasi\n"
    "  --restore BERKAS  pulihkan cadangan (aplikasi harus tertutup; kondisi saat ini dicadangkan dulu)\n"
    "  --verbose       tulis log juga ke terminal\n"
    "  --allow-multiple  izinkan lebih dari satu salinan berjalan (tidak disarankan)\n\n"
    "Backend Qt: ubah di tab Sistem, atau override sementara dengan SOROT_QT_PLATFORM=auto|xcb|wayland\n"
    "Log: ~/.local/state/sorot/sorot.log\n"
    "Kontak profesional: muhammadandreatama@outlook.com"
)


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if "--help" in args or "-h" in args:
        print(HELP)
        return 0
    if "--version" in args:
        print(f"Sorot {__version__}")
        return 0

    from sorot.core.config import ConfigStore
    from sorot.logging_setup import setup_logging
    from sorot.services.platform_info import available_qt_platforms, format_platform_report, select_qt_platform

    verbose = "--verbose" in args
    setup_logging(level=logging.DEBUG if verbose else logging.INFO, console=verbose)
    log = logging.getLogger(__name__)
    from sorot.crash import install_crash_handlers

    install_crash_handlers()

    store = ConfigStore()
    loaded = store.load()
    choice = select_qt_platform(preference=loaded.config.qt_platform, available=available_qt_platforms())

    if "--upgrade-info" in args:
        return _upgrade_info()
    if "--backup" in args:
        return _backup(args)
    if "--restore" in args:
        return _restore(args)
    if "--extensions" in args:
        return _list_extensions(loaded.config)
    if "--validate-extension" in args:
        index = args.index("--validate-extension")
        if index + 1 >= len(args):
            print("Gunakan: sorot --validate-extension FOLDER [--run]", file=sys.stderr)
            return 2
        return _validate_extension(args[index + 1], run="--run" in args)

    if "--diagnostics" in args:
        print(format_platform_report(choice.platform or "otomatis oleh Qt"))
        print(f"\nPilihan backend: {choice.description}")
        return 0

    # Back up *before* anything is saved in the new format; never blocks startup.
    from sorot.core import upgrade
    from sorot.core.config import SCHEMA_VERSION

    upgrade_notices = upgrade.on_startup(__version__, SCHEMA_VERSION)

    if choice.platform:
        os.environ["QT_QPA_PLATFORM"] = choice.platform
    log.info("Memulai Sorot %s; backend: %s", __version__, choice.description)

    try:
        from PySide6.QtWidgets import QApplication, QMessageBox
    except ImportError as exc:
        print(
            "Sorot membutuhkan PySide6 (Qt 6). Pada Debian 13: `sudo apt install python3-pyside6.qtwidgets`.\n"
            f"Detail: {exc}",
            file=sys.stderr,
        )
        return 2

    app = QApplication([sys.argv[0]])
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    app.setApplicationVersion(__version__)
    app.setDesktopFileName("sorot")

    from sorot.single_instance import InstanceLock

    lock = InstanceLock()
    if "--allow-multiple" not in args and not lock.acquire():
        pid = lock.owner_pid()
        QMessageBox.information(
            None, APP_NAME,
            f"{APP_NAME} sudah berjalan{f' (PID {pid})' if pid else ''}. Gunakan jendela yang sudah ada.\n\n"
            "Dua salinan sekaligus dapat saling menimpa draf dan pengaturan.",
        )
        return 0
    from sorot.core.scripts import DraftStore, ScriptLibrary
    from sorot.legacy_import import import_legacy, import_previous_install
    from sorot.ui.main_window import MainWindow

    draft = DraftStore()
    library = ScriptLibrary()
    notices = list(loaded.notices) + upgrade_notices
    if loaded.is_new and not loaded.notices and not draft.path.exists():
        if import_previous_install(store, draft, library):
            notices.append("Data dari versi 0.4.x (Tama Prompter) diimpor; berkas lama tidak diubah.")
        elif import_legacy(store, draft) is not None:
            notices.append("Pengaturan dan naskah dari versi 0.3.x diimpor; berkas lama tidak diubah.")
    try:
        window = MainWindow(store, draft, library, startup_notices=notices)
    except Exception as exc:  # noqa: BLE001 - show the user something instead of dying silently
        log.exception("Antarmuka gagal dimulai")
        QMessageBox.critical(None, APP_NAME, f"Aplikasi gagal memulai antarmuka.\n\n{type(exc).__name__}: {exc}\n\nBackend: {choice.description}")
        return 1
    window.show()
    try:
        return app.exec()
    finally:
        lock.release()


def _upgrade_info() -> int:
    from sorot.core import upgrade
    from sorot.core.config import SCHEMA_VERSION

    print(upgrade.describe(__version__, SCHEMA_VERSION))
    return 0


def _option_value(args: list[str], flag: str) -> str | None:
    """The argument after ``flag`` unless it is missing or looks like another option."""
    index = args.index(flag)
    if index + 1 < len(args) and not args[index + 1].startswith("--"):
        return args[index + 1]
    return None


def _backup(args: list[str]) -> int:
    from pathlib import Path

    from sorot.core import upgrade
    from sorot.core.config import SCHEMA_VERSION

    target = _option_value(args, "--backup")
    try:
        path = upgrade.create_backup(Path(target) if target else None, app_version=__version__, schema_version=SCHEMA_VERSION)
        info = upgrade.inspect_backup(path)  # read it back and verify every hash
    except (upgrade.BackupError, OSError) as exc:
        print(f"Cadangan gagal: {exc}", file=sys.stderr)
        return 1
    print(f"Cadangan dibuat dan diverifikasi: {path}  ({len(info.files)} berkas)")
    print("Isinya mencakup naskah dan pengaturan tanpa enkripsi; simpan di tempat yang aman.")
    return 0


def _restore(args: list[str]) -> int:
    from pathlib import Path

    from sorot.core import upgrade
    from sorot.core.config import SCHEMA_VERSION

    source = _option_value(args, "--restore")
    if source is None:
        print("Gunakan: sorot --restore BERKAS.zip", file=sys.stderr)
        return 2
    try:
        info, safety = upgrade.restore_backup(Path(source), app_version=__version__, schema_version=SCHEMA_VERSION)
    except (upgrade.BackupError, OSError) as exc:
        print(f"Pemulihan gagal: {exc}", file=sys.stderr)
        return 1
    print(f"Dipulihkan: {len(info.files)} berkas dari cadangan Sorot {info.app_version or '?'} ({info.created or 'tanggal tidak tercatat'}).")
    if safety is not None:
        print(f"Kondisi sebelum pemulihan disimpan di: {safety}")
    if upgrade.compare_versions(info.app_version, __version__) > 0:
        print("Peringatan: cadangan berasal dari versi yang lebih baru; sebagian pengaturan mungkin diabaikan.")
    return 0


def _list_extensions(config) -> int:  # noqa: ANN001
    from sorot.extensions import discovery, state

    infos = discovery.discover()
    if not infos:
        print(f"Tidak ada ekstensi. Folder pengguna: {discovery.user_extensions_dir()}")
        return 0
    for info in infos:
        if not info.usable or info.manifest is None:
            print(f"- {info.path.name}: TIDAK VALID — {info.error}")
            continue
        m = info.manifest
        status = state.STATUS_LABELS[state.approval_status(info, config.extensions)]
        print(f"- {m.ext_id}  v{m.version}  [{m.kind}, {info.origin}]  {status}\n    {m.name} — {info.path}")
        for problem in info.problems:
            print(f"    ! {problem}")
    return 0


def _validate_extension(folder: str, *, run: bool) -> int:
    from pathlib import Path

    from sorot import __version__
    from sorot.extensions import discovery
    from sorot.extensions.host import ExtensionProcess
    from sorot.extensions.manifest import ExtensionError, load_manifest

    path = Path(folder)
    try:
        manifest = load_manifest(path)
        digest = discovery.hash_tree(path) if manifest.has_code else ""
    except ExtensionError as exc:
        print(f"TIDAK VALID: {exc}")
        return 1
    print(f"Manifest valid: {manifest.ext_id} v{manifest.version} ({manifest.kind})")
    for problem in manifest.problems:
        print(f"  peringatan: {problem}")
    print(f"  tema={len(manifest.themes)} preset={len(manifest.presets)} tugas_ai={len(manifest.ai_tasks)} templat={len(manifest.templates)}")
    if manifest.has_code:
        print(f"  sidik jari kode: {digest}")
        if not run:
            print("  (gunakan --run untuk memuat ekstensi dan mencetak perintah yang didaftarkannya; ini menjalankan kodenya)")
            return 0
        info = discovery.ExtensionInfo(manifest, path, "user", code_hash=digest)
        process = ExtensionProcess(info, __version__)
        try:
            caps = process.start()
        except ExtensionError as exc:
            print(f"GAGAL DIMUAT: {exc}")
            return 1
        finally:
            process.stop()
        print(f"  transformasi={[c['id'] for c in caps.transforms]} aksi={[c['id'] for c in caps.actions]}")
        print(f"  impor={[c['id'] for c in caps.importers]} ekspor={[c['id'] for c in caps.exporters]} event={caps.events}")
    return 0
