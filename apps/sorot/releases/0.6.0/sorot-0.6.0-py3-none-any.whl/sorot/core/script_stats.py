"""Script statistics and the speaking-time model (pure functions).

Model: a block takes ``words / wpm`` minutes, plus small pauses for
punctuation (the speaker breathes at commas and sentence ends), plus any
explicit pause. It is an *estimate*; real delivery varies by speaker.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from sorot.core.script_markup import Block, ParsedScript, parse_script

DEFAULT_WPM = 130
MIN_WPM = 60
MAX_WPM = 260
COMMA_PAUSE = 0.25
SENTENCE_PAUSE = 0.5

_SENTENCE_END = re.compile(r"[.!?…]+(?=\s|$)")
_CLAUSE_END = re.compile(r"[,;:](?=\s|$)")


@dataclass(frozen=True)
class ScriptStats:
    characters: int
    words: int
    seconds: int


def clamp_wpm(wpm: float) -> int:
    return max(MIN_WPM, min(MAX_WPM, int(round(wpm))))


def count_words(text: str) -> int:
    return len(text.split())


def speech_seconds(block: Block, wpm: float) -> float:
    """Time spent *speaking* a block (excludes its explicit pause)."""
    if block.kind != "text" or block.words == 0:
        return 0.0
    wpm = clamp_wpm(wpm)
    spoken = block.words * 60.0 / wpm
    spoken += len(_CLAUSE_END.findall(block.text)) * COMMA_PAUSE
    spoken += len(_SENTENCE_END.findall(block.text)) * SENTENCE_PAUSE
    return spoken


def block_seconds(block: Block, wpm: float) -> float:
    return speech_seconds(block, wpm) + block.pause


def parsed_seconds(parsed: ParsedScript, wpm: float) -> float:
    return sum(block_seconds(block, wpm) for block in parsed.blocks)


def estimate_seconds(text: str, wpm: int = DEFAULT_WPM) -> int:
    """Estimated delivery time in whole seconds (0 for an empty script)."""
    parsed = parse_script(text)
    if parsed.words == 0 and parsed.cue_seconds == 0:
        return 0
    return max(1, round(parsed_seconds(parsed, wpm)))


def compute_stats(text: str, wpm: int = DEFAULT_WPM) -> ScriptStats:
    parsed = parse_script(text)
    visible = len("\n".join(b.text for b in parsed.blocks if b.kind == "text"))
    seconds = 0 if parsed.words == 0 and parsed.cue_seconds == 0 else max(1, round(parsed_seconds(parsed, wpm)))
    return ScriptStats(visible, parsed.words, seconds)


def format_clock(seconds: float) -> str:
    """``m:ss`` (or ``h:mm:ss``) for readouts."""
    total = max(0, int(round(seconds)))
    minutes, secs = divmod(total, 60)
    if minutes >= 60:
        hours, minutes = divmod(minutes, 60)
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def format_duration(seconds: int) -> str:
    if seconds <= 0:
        return "0 detik"
    minutes, secs = divmod(seconds, 60)
    if minutes == 0:
        return f"{secs} detik"
    if minutes >= 60:
        hours, minutes = divmod(minutes, 60)
        return f"{hours} jam {minutes:02d} menit"
    return f"{minutes} menit {secs:02d} detik"


def format_stats(stats: ScriptStats) -> str:
    def thousands(value: int) -> str:
        return f"{value:,}".replace(",", ".")

    return f"{thousands(stats.characters)} karakter · {thousands(stats.words)} kata · ±{format_duration(stats.seconds)}"
