"""Reading timeline: maps elapsed time to a scroll position (and back).

The scroller does not move at a constant pixel speed. It follows the speaker:
each line is given the time it takes to say it (plus punctuation and cue
pauses), so a short line passes quickly and a dense paragraph slowly, and a
``[jeda 3]`` cue really holds the screen for three seconds.

Pure Python: the Qt layer only supplies line geometry.
"""
from __future__ import annotations

import bisect
from collections.abc import Sequence
from dataclasses import dataclass
from enum import StrEnum

from sorot.core.script_markup import Block
from sorot.core.script_stats import clamp_wpm, speech_seconds

PASS_THROUGH_PPS = 160.0  # speed past lines that carry no speech (blank lines, cues)
MAX_PPS = 2400.0
MIN_SCALE = 0.1


class SpeedMode(StrEnum):
    PPS = "pps"  # constant pixels per second (legacy behaviour)
    WPM = "wpm"  # follow speaking speed in words per minute
    DURATION = "duration"  # finish the script in a target time


@dataclass(frozen=True)
class LineBox:
    """Vertical extent of one displayed line, already in scroll-value units."""

    top: float
    bottom: float


@dataclass(frozen=True)
class Segment:
    t0: float
    t1: float
    y0: float
    y1: float


@dataclass(frozen=True)
class Timeline:
    segments: tuple[Segment, ...]
    duration: float
    speech_seconds: float  # time actually spent moving through spoken lines
    words: int

    @property
    def end_position(self) -> float:
        return self.segments[-1].y1 if self.segments else 0.0

    @property
    def start_position(self) -> float:
        return self.segments[0].y0 if self.segments else 0.0

    @property
    def effective_wpm(self) -> float:
        return self.words * 60.0 / self.speech_seconds if self.speech_seconds > 0 and self.words else 0.0

    def position_at(self, t: float) -> float:
        if not self.segments:
            return 0.0
        if t <= 0:
            return self.segments[0].y0
        if t >= self.duration:
            return self.segments[-1].y1
        index = bisect.bisect_right([s.t0 for s in self.segments], t) - 1
        seg = self.segments[max(0, index)]
        if seg.t1 <= seg.t0:
            return seg.y1
        return seg.y0 + (seg.y1 - seg.y0) * (t - seg.t0) / (seg.t1 - seg.t0)

    def time_at(self, y: float) -> float:
        """Earliest time at which the reading position reaches ``y``."""
        if not self.segments or y <= self.segments[0].y0:
            return 0.0
        if y >= self.segments[-1].y1:
            return self.duration
        for seg in self.segments:
            if seg.y0 <= y <= seg.y1:
                if seg.y1 == seg.y0:
                    return seg.t0
                return seg.t0 + (seg.t1 - seg.t0) * (y - seg.y0) / (seg.y1 - seg.y0)
        return self.duration


def build_timeline(
    blocks: Sequence[Block],
    lines: Sequence[LineBox],
    *,
    mode: SpeedMode,
    wpm: float = 130,
    pps: float = 28,
    target_seconds: float = 180,
) -> Timeline:
    """Build the timeline for ``blocks`` laid out as ``lines`` (same length)."""
    count = min(len(blocks), len(lines))
    if count == 0:
        return Timeline((), 0.0, 0.0, 0)
    blocks, lines = blocks[:count], lines[:count]
    wpm = clamp_wpm(wpm)
    pps = max(1.0, float(pps))

    # (height, motion seconds, hold seconds) per line, before any scaling.
    plan: list[tuple[float, float, float]] = []
    for block, box in zip(blocks, lines, strict=True):
        height = max(0.0, box.bottom - box.top)
        if mode is SpeedMode.PPS:
            motion = height / pps
            hold = block.pause if block.kind == "cue" else 0.0
        else:
            spoken = speech_seconds(block, wpm)
            motion = spoken if spoken > 0 else height / PASS_THROUGH_PPS
            hold = block.pause
        plan.append((height, motion, hold))

    scale = 1.0
    if mode is SpeedMode.DURATION:
        motion_total = sum(m for _h, m, _p in plan)
        hold_total = sum(p for _h, _m, p in plan)
        free = max(1.0, float(target_seconds) - hold_total)
        if motion_total > 0:
            scale = max(MIN_SCALE, free / motion_total)

    segments: list[Segment] = []
    t = 0.0
    y = lines[0].top
    speech = 0.0
    for block, box, (height, motion, hold) in zip(blocks, lines, plan, strict=True):
        motion *= scale
        if height > 0 and motion > 0:
            motion = max(motion, height / MAX_PPS)  # never faster than MAX_PPS
        target_y = max(y, box.bottom)
        if motion > 0 or target_y > y:
            span = motion if motion > 0 else (target_y - y) / MAX_PPS
            segments.append(Segment(t, t + span, y, target_y))
            t += span
            y = target_y
            if block.kind == "text":
                speech += span
        if hold > 0:
            segments.append(Segment(t, t + hold, y, y))
            t += hold
    words = sum(b.words for b in blocks)
    return Timeline(tuple(segments), t, speech, words)
