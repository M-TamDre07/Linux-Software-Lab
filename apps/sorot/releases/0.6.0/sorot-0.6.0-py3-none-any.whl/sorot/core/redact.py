"""Best-effort removal of secrets from text that may be logged or displayed."""
from __future__ import annotations

import re

_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"(?i)(bearer\s+)[A-Za-z0-9._~+/=\-]{6,}"), r"\1[DISAMARKAN]"),
    (re.compile(r"(?i)\b(api[_\-]?key|authorization|token|secret|password|passwd)(\"?\s*[:=]\s*\"?)[^\s\"',;}]+"), r"\1\2[DISAMARKAN]"),
    (re.compile(r"\b(?:sk|pk|rk|gsk|xai|key)[_\-][A-Za-z0-9_\-]{8,}"), "[KUNCI-DISAMARKAN]"),
    (re.compile(r"\b[A-Za-z0-9_\-]{40,}\b"), "[TOKEN-PANJANG-DISAMARKAN]"),
)


def redact(text: str) -> str:
    for pattern, replacement in _PATTERNS:
        text = pattern.sub(replacement, text)
    return text
