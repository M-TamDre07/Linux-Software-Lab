"""Script markup: hidden notes, pause cues, and a per-line reading model.

Syntax (whole lines only)::

    // catatan untuk diri sendiri      -> never shown, never counted
    [jeda]  or  [jeda 3]  or  [pause 2.5]  -> the prompt holds for N seconds

Everything else is spoken text. Each displayed line maps to exactly one
``Block`` so the overlay can align its layout with the reading model.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

DEFAULT_CUE_SECONDS = 2.0
MIN_CUE_SECONDS = 0.5
MAX_CUE_SECONDS = 120.0
BLANK_LINE_PAUSE = 0.5

_NOTE = re.compile(r"^\s*//")
_CUE = re.compile(r"^\s*\[\s*(?:jeda|pause)(?:\s+(\d+(?:[.,]\d+)?))?\s*(?:detik|dtk|s|d)?\s*\]\s*$", re.IGNORECASE)


@dataclass(frozen=True)
class Block:
    """One displayed line."""

    text: str
    words: int
    kind: str  # "text" | "blank" | "cue"
    pause: float  # seconds the prompt holds after this line


@dataclass(frozen=True)
class ParsedScript:
    display_text: str
    blocks: tuple[Block, ...]
    words: int
    notes_hidden: int
    cue_seconds: float


def _cue_label(seconds: float) -> str:
    shown = f"{seconds:g}"
    return f"— JEDA {shown} DTK —"


def parse_script(raw: str) -> ParsedScript:
    """Split ``raw`` into displayable blocks (``\\n`` separated, one block per line)."""
    # U+2028/2029 would make Qt split a line into extra blocks and break the 1:1 line mapping.
    raw = raw.replace("\u2028", " ").replace("\u2029", " ").replace("\x0b", " ").replace("\x0c", " ")
    lines = raw.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    blocks: list[Block] = []
    words = notes = 0
    cue_total = 0.0
    for line in lines:
        if _NOTE.match(line):
            notes += 1
            continue
        cue = _CUE.match(line)
        if cue:
            seconds = float(cue.group(1).replace(",", ".")) if cue.group(1) else DEFAULT_CUE_SECONDS
            seconds = max(MIN_CUE_SECONDS, min(MAX_CUE_SECONDS, seconds))
            blocks.append(Block(_cue_label(seconds), 0, "cue", seconds))
            cue_total += seconds
        elif not line.strip():
            blocks.append(Block("", 0, "blank", BLANK_LINE_PAUSE))
        else:
            count = len(line.split())
            words += count
            blocks.append(Block(line, count, "text", 0.0))
    return ParsedScript("\n".join(b.text for b in blocks), tuple(blocks), words, notes, cue_total)
