"""Cooperative cancellation shared by background network/subprocess work."""
from __future__ import annotations

import threading


class OperationCancelled(Exception):
    """Raised inside a background task when the user cancelled it."""


class CancelToken:
    def __init__(self) -> None:
        self._event = threading.Event()

    def cancel(self) -> None:
        self._event.set()

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()

    def raise_if_cancelled(self) -> None:
        if self._event.is_set():
            raise OperationCancelled()
