"""Qt-free application logic: configuration, scripts, storage, and statistics."""
