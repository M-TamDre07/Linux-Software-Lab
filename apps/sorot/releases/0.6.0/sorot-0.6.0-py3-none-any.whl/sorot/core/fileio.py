"""Small, dependency-free file helpers: atomic writes and bounded reads."""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

MAX_SCRIPT_BYTES = 5_000_000


class ScriptFileError(Exception):
    """A user-facing problem while reading or writing a script file."""


def atomic_write_text(path: Path, text: str, *, mode: int = 0o600) -> None:  # private by default
    """Write ``text`` to ``path`` so readers never observe a partial file.

    The data is written to a temporary file in the same directory, flushed to
    disk, and then moved over the destination with ``os.replace``.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp_path, mode)
        os.replace(tmp_path, path)
    except BaseException:
        try:
            tmp_path.unlink()
        except OSError:
            pass
        raise
    try:  # Persist the rename itself; best effort on filesystems that allow it.
        dir_fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    except OSError:
        pass


def read_script(path: Path, *, max_bytes: int = MAX_SCRIPT_BYTES) -> str:
    """Read a UTF-8 script, with clear errors for the usual failure modes."""
    path = Path(path)
    try:
        size = path.stat().st_size
    except OSError as exc:
        raise ScriptFileError(f"Berkas tidak dapat diakses: {exc.strerror or exc}") from exc
    if not path.is_file():
        raise ScriptFileError("Jalur yang dipilih bukan berkas biasa.")
    if size > max_bytes:
        raise ScriptFileError(
            f"Berkas terlalu besar ({size / 1_000_000:.1f} MB). Batas untuk naskah adalah {max_bytes / 1_000_000:.0f} MB."
        )
    try:
        data = path.read_bytes()
    except OSError as exc:
        raise ScriptFileError(f"Berkas tidak dapat dibaca: {exc.strerror or exc}") from exc
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ScriptFileError(
            "Berkas bukan teks UTF-8 yang valid. Simpan ulang berkas dengan encoding UTF-8 lalu coba lagi."
        ) from exc
