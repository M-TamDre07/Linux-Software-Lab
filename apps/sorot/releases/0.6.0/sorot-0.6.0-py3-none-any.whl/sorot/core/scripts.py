"""Local script storage: crash-safe draft and a small named-script library."""
from __future__ import annotations

import logging
import os
import re
import time
from dataclasses import dataclass
from pathlib import Path

from sorot.core import paths
from sorot.core.fileio import ScriptFileError, atomic_write_text, read_script

LOGGER = logging.getLogger(__name__)

_INVALID_NAME_CHARS = re.compile(r'[\x00-\x1f/\\:*?"<>|]')


SNAPSHOT_KEEP = 20
SNAPSHOT_MIN_INTERVAL = 60.0


@dataclass(frozen=True)
class Snapshot:
    name: str
    path: Path
    modified: float
    size: int


class DraftStore:
    """Holds the working script so it survives a crash or forced shutdown.

    Besides the live draft there is a short rolling history of snapshots, so an
    accidental delete or replacement can be undone even after the app restarts.
    """

    def __init__(self, path: Path | None = None) -> None:
        self.path = Path(path) if path is not None else paths.draft_file()

    @property
    def snapshot_dir(self) -> Path:
        return self.path.parent / "draft-history"

    def snapshot(self, text: str, *, force: bool = False, now: float | None = None) -> Path | None:
        """Record ``text`` in the history. Returns the new file, or ``None`` if skipped.

        Skipped when empty, identical to the newest snapshot, or (unless ``force``)
        when the newest snapshot is younger than ``SNAPSHOT_MIN_INTERVAL``.
        """
        if not text.strip():
            return None
        moment = time.time() if now is None else now
        existing = self.snapshots()
        if existing:
            newest = existing[0]
            try:
                if read_script(newest.path) == text:
                    return None
            except ScriptFileError:
                pass
            if not force and moment - newest.modified < SNAPSHOT_MIN_INTERVAL:
                return None
        stamp = time.strftime("%Y%m%d-%H%M%S", time.localtime(moment))
        target = self.snapshot_dir / f"{stamp}.txt"
        counter = 1
        while target.exists():
            target = self.snapshot_dir / f"{stamp}-{counter}.txt"
            counter += 1
        atomic_write_text(target, text)
        os.utime(target, (moment, moment))
        for old in self.snapshots()[SNAPSHOT_KEEP:]:
            try:
                old.path.unlink()
            except OSError:
                pass
        return target

    def snapshots(self) -> list[Snapshot]:
        if not self.snapshot_dir.is_dir():
            return []
        items: list[Snapshot] = []
        for file in self.snapshot_dir.glob("*.txt"):
            try:
                info = file.stat()
            except OSError:
                continue
            items.append(Snapshot(file.stem, file, info.st_mtime, info.st_size))
        return sorted(items, key=lambda item: (item.modified, item.name), reverse=True)

    def load_snapshot(self, name: str) -> str:
        path = (self.snapshot_dir / f"{Path(name).name}.txt")
        if path.resolve().parent != self.snapshot_dir.resolve():
            raise ScriptFileError("Jalur riwayat tidak valid.")
        return read_script(path)

    def load(self) -> str:
        try:
            return read_script(self.path)
        except ScriptFileError:
            if self.path.exists():
                LOGGER.warning("Draf naskah tidak dapat dibaca; memulai dengan naskah kosong.")
            return ""

    def save(self, text: str) -> None:
        try:
            atomic_write_text(self.path, text)
        except OSError as exc:
            LOGGER.error("Draf naskah gagal disimpan: %s", exc.strerror or exc)
            raise

    def clear(self) -> None:
        try:
            self.path.unlink()
        except FileNotFoundError:
            pass


@dataclass(frozen=True)
class LibraryEntry:
    name: str
    path: Path
    modified: float
    size: int


def safe_script_name(raw: str) -> str:
    """Turn user input into a safe file name inside the library (never a path)."""
    name = raw.strip()
    if name.lower().endswith(".txt"):
        name = name[:-4]
    name = _INVALID_NAME_CHARS.sub("_", name)
    name = name.strip(" .")[:80].rstrip(" .")  # no hidden files, no trailing dots/spaces
    if not name:
        raise ScriptFileError("Nama naskah tidak boleh kosong.")
    return name + ".txt"


class ScriptLibrary:
    def __init__(self, directory: Path | None = None) -> None:
        self.directory = Path(directory) if directory is not None else paths.library_dir()

    def list(self) -> list[LibraryEntry]:
        if not self.directory.is_dir():
            return []
        entries: list[LibraryEntry] = []
        for item in self.directory.iterdir():
            if item.is_file() and item.suffix == ".txt" and not item.name.startswith("."):
                try:
                    info = item.stat()
                except OSError:
                    continue
                entries.append(LibraryEntry(item.stem, item, info.st_mtime, info.st_size))
        return sorted(entries, key=lambda entry: entry.modified, reverse=True)

    def path_for(self, name: str) -> Path:
        return self.directory / safe_script_name(name)

    def exists(self, name: str) -> bool:
        return self.path_for(name).exists()

    def save(self, name: str, text: str) -> Path:
        path = self.path_for(name)
        try:
            atomic_write_text(path, text)
        except OSError as exc:
            raise ScriptFileError(f"Naskah tidak dapat disimpan: {exc.strerror or exc}") from exc
        return path

    def load(self, name: str) -> str:
        return read_script(self.path_for(name))

    def delete(self, name: str) -> None:
        path = self.path_for(name)
        # Defence in depth: the resolved target must live inside the library.
        if path.resolve().parent != self.directory.resolve():
            raise ScriptFileError("Jalur naskah tidak valid.")
        try:
            path.unlink()
        except FileNotFoundError:
            return
        except OSError as exc:
            raise ScriptFileError(f"Naskah tidak dapat dihapus: {exc.strerror or exc}") from exc


def format_modified(timestamp: float) -> str:
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(timestamp))
