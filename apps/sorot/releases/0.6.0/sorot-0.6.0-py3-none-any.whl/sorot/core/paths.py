"""XDG-compliant locations for configuration, user data, and logs.

Paths are resolved at call time (not import time) so tests and users can
override ``XDG_*`` variables.
"""
from __future__ import annotations

import os
from pathlib import Path

APP_DIR_NAME = "sorot"


def _xdg(variable: str, fallback: Path) -> Path:
    value = os.environ.get(variable, "").strip()
    # The XDG spec says relative paths must be ignored.
    if value and os.path.isabs(value):
        return Path(value)
    return fallback


def config_dir() -> Path:
    return _xdg("XDG_CONFIG_HOME", Path.home() / ".config") / APP_DIR_NAME


def data_dir() -> Path:
    return _xdg("XDG_DATA_HOME", Path.home() / ".local" / "share") / APP_DIR_NAME


def state_dir() -> Path:
    return _xdg("XDG_STATE_HOME", Path.home() / ".local" / "state") / APP_DIR_NAME


def config_file() -> Path:
    return config_dir() / "config.json"


def draft_file() -> Path:
    return data_dir() / "draft.txt"


def library_dir() -> Path:
    return data_dir() / "scripts"


def log_file() -> Path:
    return state_dir() / "sorot.log"


def legacy_qsettings_file() -> Path:
    """Where Sorot 0.3.x kept preferences and the last script."""
    return _xdg("XDG_CONFIG_HOME", Path.home() / ".config") / "TamaAndrea" / "TamaPrompter.conf"


# Locations used by 0.4.x, when the application was still called "Tama Prompter".
_PREVIOUS_DIR = "tama-prompter"


def previous_config_file() -> Path:
    return _xdg("XDG_CONFIG_HOME", Path.home() / ".config") / _PREVIOUS_DIR / "config.json"


def previous_data_dir() -> Path:
    return _xdg("XDG_DATA_HOME", Path.home() / ".local" / "share") / _PREVIOUS_DIR
