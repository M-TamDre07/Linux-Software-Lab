"""Google Drive (rclone) user flows: choose remote, browse, open, save, check setup."""
from __future__ import annotations

from collections.abc import Callable

from PySide6.QtCore import QObject, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QProgressDialog,
    QVBoxLayout,
    QWidget,
)

from sorot.services import drive_service
from sorot.services.drive_service import DriveIntegrationError, RemoteInfo
from sorot.ui.task_worker import BackgroundTask


class _ListChoiceDialog(QDialog):
    """A filterable list, used for remotes and for files."""

    def __init__(self, title: str, prompt: str, items: list[tuple[str, str]], parent: QWidget) -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(520, 420)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(prompt))
        self.filter = QLineEdit()
        self.filter.setPlaceholderText("Ketik untuk menyaring…")
        self.filter.setClearButtonEnabled(True)
        self.filter.setAccessibleName("Saring daftar")
        layout.addWidget(self.filter)
        self.list = QListWidget()
        self.list.setAccessibleName(title)
        for label, value in items:
            item = QListWidgetItem(label)
            item.setData(256, value)
            self.list.addItem(item)
        if self.list.count():
            self.list.setCurrentRow(0)
        layout.addWidget(self.list, 1)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.filter.textChanged.connect(self._apply_filter)
        self.list.itemDoubleClicked.connect(lambda _item: self.accept())

    def _apply_filter(self, text: str) -> None:
        needle = text.strip().lower()
        first_visible = None
        for index in range(self.list.count()):
            item = self.list.item(index)
            hidden = bool(needle) and needle not in item.text().lower()
            item.setHidden(hidden)
            if not hidden and first_visible is None:
                first_visible = item
        if first_visible is not None:
            self.list.setCurrentItem(first_visible)

    def chosen(self) -> str | None:
        item = self.list.currentItem()
        return item.data(256) if item is not None and not item.isHidden() else None


class DriveController(QObject):
    """Orchestrates Drive flows. All rclone work runs in background tasks."""

    def __init__(
        self,
        window: QWidget,
        *,
        get_text: Callable[[], str],
        set_text: Callable[[str], None],
        confirm_replace: Callable[[], bool],
        status: Callable[[str], None],
    ) -> None:
        super().__init__(window)
        self.window = window
        self.get_text = get_text
        self.set_text = set_text
        self.confirm_replace = confirm_replace
        self.status = status
        self._task: BackgroundTask | None = None
        self._progress: QProgressDialog | None = None

    # ----------------------------------------------------------- shared plumbing
    def _run(self, label: str, function, on_success) -> None:
        if self._task is not None and self._task.running:
            QMessageBox.information(self.window, "Google Drive", "Masih ada operasi Drive yang berjalan. Tunggu atau batalkan dulu.")
            return
        progress = QProgressDialog(label, "Batalkan", 0, 0, self.window)
        progress.setWindowTitle("Integrasi Google Drive")
        progress.setMinimumDuration(250)
        progress.setAutoClose(False)
        progress.setAutoReset(False)
        task = BackgroundTask(function, self)
        self._task, self._progress = task, progress
        task.succeeded.connect(lambda result: self._done(on_success, result))
        task.failed.connect(self._failed)
        task.cancelled.connect(self._cancelled)
        progress.canceled.connect(task.cancel)
        progress.show()
        task.start()

    def _close_progress(self) -> None:
        if self._progress is not None:
            try:
                self._progress.canceled.disconnect()
            except (RuntimeError, TypeError):
                pass
            self._progress.close()
            self._progress.deleteLater()
        self._task = self._progress = None

    def _done(self, on_success, result) -> None:
        self._close_progress()
        on_success(result)

    def _failed(self, message: str) -> None:
        self._close_progress()
        self.status("Operasi Drive gagal.")
        QMessageBox.warning(self.window, "Google Drive", message)

    def _cancelled(self) -> None:
        self._close_progress()
        self.status("Operasi Drive dibatalkan.")

    def cancel(self) -> None:
        if self._task is not None:
            self._task.cancel()

    # --------------------------------------------------------------------- flows
    def _require_rclone(self) -> bool:
        if drive_service.rclone_available():
            return True
        QMessageBox.information(
            self.window, "Google Drive",
            "rclone belum terpasang. Integrasi Drive bersifat opsional.\n\nPada Debian: `sudo apt install rclone`, lalu `rclone config` "
            "untuk membuat remote Google Drive.\n\nTanpa rclone, kamu tetap bisa membuka Drive di browser atau memakai folder Drive yang "
            "disinkronkan aplikasi lain lalu membukanya lewat Berkas → Buka naskah.",
        )
        return False

    def _choose_remote(self, then: Callable[[str], None]) -> None:
        if not self._require_rclone():
            return
        self.status("Membaca daftar remote rclone…")

        def picked(remotes: list[RemoteInfo]) -> None:
            if not remotes:
                QMessageBox.information(self.window, "Belum ada remote", "rclone tersedia tetapi belum ada remote. Jalankan `rclone config` dan buat remote Google Drive.")
                return
            ordered = sorted(remotes, key=lambda r: (not r.is_google_drive, r.name))
            items = [(r.label + ("" if r.is_google_drive else "   — bukan Google Drive"), r.name) for r in ordered]
            dialog = _ListChoiceDialog("Pilih remote", "Remote rclone yang akan dipakai:", items, self.window)
            if dialog.exec() == QDialog.DialogCode.Accepted:
                remote = dialog.chosen()
                if remote:
                    then(remote)

        self._run("Membaca daftar remote…", lambda token: drive_service.list_remotes(token), picked)

    def open_text(self) -> None:
        self._choose_remote(self._after_remote_for_open)

    def _after_remote_for_open(self, remote: str) -> None:
        folder, ok = QInputDialog.getText(
            self.window, "Folder di Drive", "Cari naskah .txt di folder (kosongkan untuk seluruh remote, kedalaman maksimal 5):",
        )
        if not ok:
            return
        folder = folder.strip()
        self.status(f"Mencari naskah di {remote}{folder}…")
        self._run(
            f"Mencari berkas .txt di {remote}{folder}…",
            lambda token: drive_service.list_text_files(remote, folder, cancel=token),
            lambda files: self._choose_file(remote, folder, files),
        )

    def _choose_file(self, remote: str, folder: str, files: list[str]) -> None:
        if not files:
            QMessageBox.information(self.window, "Tidak ada naskah", f"Tidak ditemukan berkas .txt pada {remote}{folder}.")
            return
        dialog = _ListChoiceDialog("Buka naskah dari Drive", "Pilih berkas .txt:", [(name, name) for name in files], self.window)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        relative = dialog.chosen()
        if not relative:
            return
        path = f"{folder.rstrip('/')}/{relative}" if folder else relative
        if not self.confirm_replace():
            return
        self.status(f"Mengunduh {path}…")
        self._run(
            f"Mengunduh {path}…",
            lambda token: drive_service.read_text_file(remote, path, token),
            lambda text: (self.set_text(text), self.status(f"Naskah dibuka dari {remote}{path}")),
        )

    def save_text(self) -> None:
        text = self.get_text()
        if not text.strip():
            QMessageBox.information(self.window, "Naskah kosong", "Isi naskah sebelum menyimpan ke Drive.")
            return
        self._choose_remote(lambda remote: self._ask_path_and_save(remote, text))

    def _ask_path_and_save(self, remote: str, text: str) -> None:
        path, ok = QInputDialog.getText(
            self.window, "Simpan naskah ke Drive", "Lokasi berkas relatif terhadap remote (contoh: Naskah/video.txt):",
            QLineEdit.EchoMode.Normal, "naskah.txt",
        )
        if not ok or not path.strip():
            return
        path = path.strip()
        try:
            drive_service.remote_target(remote, path)
        except DriveIntegrationError as exc:
            QMessageBox.warning(self.window, "Google Drive", str(exc))
            return
        if QMessageBox.question(
            self.window, "Konfirmasi penyimpanan",
            f"Kirim naskah ke {remote}{path}?\n\nJika berkas dengan jalur itu sudah ada, isinya akan ditimpa. Sorot tidak menghapus berkas apa pun.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No,
        ) != QMessageBox.StandardButton.Yes:
            return
        self.status(f"Mengirim naskah ke {remote}{path}…")
        self._run(
            f"Mengirim naskah ke {remote}{path}…",
            lambda token: drive_service.write_text_file(remote, path, text, token),
            lambda _result: self.status(f"Naskah berhasil dikirim ke {remote}{path}"),
        )

    def check_setup(self) -> None:
        if not self._require_rclone():
            return

        def show(info: tuple[str, list[RemoteInfo]]) -> None:
            version, remotes = info
            lines = [f"Versi: {version}", f"Lokasi: {drive_service.rclone_path()}", ""]
            if remotes:
                lines.append("Remote terkonfigurasi:")
                lines += [f"  • {r.label}" + ("" if r.is_google_drive else "  (bukan Google Drive)") for r in remotes]
                if not any(r.is_google_drive for r in remotes):
                    lines.append("\nBelum ada remote bertipe “drive”. Jalankan `rclone config` untuk menambahkannya.")
            else:
                lines.append("Belum ada remote. Jalankan `rclone config`.")
            lines += [
                "",
                "Autentikasi: dikelola rclone lewat browser. Sorot tidak pernah meminta atau menyimpan kata sandi Google.",
                "Mencabut akses: hapus remote dengan `rclone config` (opsi d) dan cabut aplikasi “rclone” di https://myaccount.google.com/permissions.",
            ]
            QMessageBox.information(self.window, "Konfigurasi rclone", "\n".join(lines))

        self._run(
            "Memeriksa rclone…",
            lambda token: (drive_service.rclone_version(token), drive_service.list_remotes(token)),
            show,
        )

    @staticmethod
    def open_web() -> None:
        QDesktopServices.openUrl(QUrl("https://drive.google.com/drive/my-drive"))
