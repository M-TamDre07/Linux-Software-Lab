"""The "Ekstensi" page and the approval dialog for code extensions."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QCheckBox,
    QDialog,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from sorot.extensions import discovery
from sorot.extensions.discovery import ExtensionInfo
from sorot.extensions.manifest import ExtensionError
from sorot.ui.extension_manager import ExtensionManager
from sorot.ui.widgets import caps, role

PERMISSION_TEXT = {
    "network": "mengakses jaringan/internet",
    "filesystem": "membaca atau menulis berkas",
    "subprocess": "menjalankan program lain",
    "clipboard": "mengakses clipboard",
    "other": "izin lain",
}


class ApprovalDialog(QDialog):
    """Explicit consent before any third-party code runs."""

    def __init__(self, info: ExtensionInfo, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        manifest = info.manifest
        assert manifest is not None
        self.setWindowTitle("Setujui ekstensi berkode")
        self.setMinimumWidth(520)
        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        title = QLabel(manifest.name)
        role(title, "title")
        layout.addWidget(title)
        meta = QLabel(f"versi {manifest.version} · oleh {manifest.author or 'tanpa nama'} · id {manifest.ext_id}")
        role(meta, "muted")
        layout.addWidget(meta)
        if manifest.description:
            description = QLabel(manifest.description)
            description.setWordWrap(True)
            layout.addWidget(description)
        permissions = ", ".join(PERMISSION_TEXT[p] for p in manifest.permissions) or "tidak menyatakan izin khusus"
        facts = QLabel(
            f"Izin yang dinyatakan ekstensi (informasi saja, tidak ditegakkan): {permissions}.\n"
            f"Lokasi: {info.path}\nSidik jari kode (SHA-256): {info.code_hash[:16]}…"
        )
        facts.setWordWrap(True)
        role(facts, "mono")
        layout.addWidget(facts)
        warning = QLabel(
            "Ekstensi ini menjalankan kode Python di komputermu dengan izin akun yang sama denganmu. Sorot menjalankannya di proses "
            "terpisah dan membatasi waktunya, tetapi itu BUKAN sandbox: ekstensi tetap bisa membaca berkas, memakai jaringan, atau "
            "menjalankan program. Setujui hanya jika kamu mempercayai pembuatnya. Jika kodenya berubah, persetujuan dicabut otomatis."
        )
        warning.setWordWrap(True)
        role(warning, "warn")
        layout.addWidget(warning)
        self.understand = QCheckBox("Saya memahami risikonya dan mempercayai ekstensi ini")
        layout.addWidget(self.understand)
        row = QHBoxLayout()
        self.ok_btn = QPushButton("Setujui dan aktifkan")
        role(self.ok_btn, "primary")
        self.ok_btn.setEnabled(False)
        cancel = QPushButton("Batal")
        row.addStretch(1)
        row.addWidget(cancel)
        row.addWidget(self.ok_btn)
        layout.addLayout(row)
        self.understand.toggled.connect(self.ok_btn.setEnabled)
        self.ok_btn.clicked.connect(self.accept)
        cancel.clicked.connect(self.reject)


class ExtensionsPage(QWidget):
    def __init__(self, manager: ExtensionManager, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("page")
        self.manager = manager
        layout = QVBoxLayout(self)
        layout.setContentsMargins(26, 18, 26, 12)
        layout.setSpacing(10)
        title = QLabel("Ekstensi")
        role(title, "title")
        layout.addWidget(title)
        intro = QLabel(
            "Tambahkan tema, preset warna, tugas AI, templat naskah, dan perintah buatan komunitas. Ekstensi deklaratif hanya berisi data. "
            "Ekstensi berkode berjalan dengan izin akunmu: pasang hanya dari sumber yang kamu percaya."
        )
        intro.setWordWrap(True)
        role(intro, "muted")
        layout.addWidget(intro)
        buttons = QGridLayout()
        buttons.setHorizontalSpacing(8)
        self.install_dir_btn = QPushButton("Pasang dari folder…")
        self.install_zip_btn = QPushButton("Pasang dari ZIP…")
        self.reload_btn = QPushButton("Muat ulang")
        self.open_dir_btn = QPushButton("Buka folder ekstensi")
        for index, button in enumerate((self.install_dir_btn, self.install_zip_btn, self.reload_btn, self.open_dir_btn)):
            role(button, "ghost")
            buttons.addWidget(button, 0, index)
        buttons.setColumnStretch(4, 1)
        layout.addLayout(buttons)

        body = QHBoxLayout()
        body.setSpacing(14)
        self.list = QListWidget()
        self.list.setAccessibleName("Daftar ekstensi")
        self.list.setMinimumWidth(240)
        body.addWidget(self.list, 2)
        detail = QFrame()
        role(detail, "panel")
        dl = QVBoxLayout(detail)
        dl.setContentsMargins(16, 12, 16, 14)
        dl.setSpacing(6)
        dl.addWidget(caps("Rincian"))
        self.name_label = QLabel("Pilih ekstensi")
        role(self.name_label, "stat")
        self.name_label.setWordWrap(True)
        self.meta_label = QLabel("")
        role(self.meta_label, "muted")
        self.meta_label.setWordWrap(True)
        self.description_label = QLabel("")
        self.description_label.setWordWrap(True)
        self.contrib_label = QLabel("")
        role(self.contrib_label, "mono")
        self.contrib_label.setWordWrap(True)
        self.status_label = QLabel("")
        role(self.status_label, "note")
        self.status_label.setWordWrap(True)
        self.problems_label = QLabel("")
        role(self.problems_label, "faint")
        self.problems_label.setWordWrap(True)
        for widget in (self.name_label, self.meta_label, self.description_label, self.contrib_label, self.status_label, self.problems_label):
            dl.addWidget(widget)
        actions = QHBoxLayout()
        self.toggle_btn = QPushButton("Aktifkan")
        role(self.toggle_btn, "primary")
        self.remove_btn = QPushButton("Hapus")
        role(self.remove_btn, "danger")
        actions.addWidget(self.toggle_btn)
        actions.addWidget(self.remove_btn)
        actions.addStretch(1)
        dl.addStretch(1)
        dl.addLayout(actions)
        body.addWidget(detail, 3)
        layout.addLayout(body, 1)

        self.install_dir_btn.clicked.connect(self.install_from_folder)
        self.install_zip_btn.clicked.connect(self.install_from_zip)
        self.reload_btn.clicked.connect(self.manager.refresh)
        self.open_dir_btn.clicked.connect(self._open_dir)
        self.list.currentItemChanged.connect(lambda *_: self._show_selected())
        self.toggle_btn.clicked.connect(self._toggle)
        self.remove_btn.clicked.connect(self._remove)
        self.manager.changed.connect(self.refresh_view)
        self.refresh_view()

    # ------------------------------------------------------------------ view
    def _selected(self) -> ExtensionInfo | None:
        item = self.list.currentItem()
        if item is None:
            return None
        index = item.data(256)
        return self.manager.infos[index] if isinstance(index, int) and 0 <= index < len(self.manager.infos) else None

    def refresh_view(self) -> None:
        current = self._selected()
        current_key = (current.ext_id, str(current.path)) if current else None
        self.list.blockSignals(True)
        self.list.clear()
        for index, info in enumerate(self.manager.infos):
            if info.usable and info.manifest:
                text = f"{info.manifest.name}   v{info.manifest.version}\n{info.manifest.kind} · {self.manager.status_text(info)}"
            else:
                text = f"{info.path.name}\ntidak valid"
            item = QListWidgetItem(text)
            item.setData(256, index)
            self.list.addItem(item)
            if current_key == (info.ext_id, str(info.path)):
                self.list.setCurrentItem(item)
        if self.list.currentItem() is None and self.list.count():
            self.list.setCurrentRow(0)
        self.list.blockSignals(False)
        self._show_selected()

    def _show_selected(self) -> None:
        info = self._selected()
        busy = self.manager.refreshing
        if info is None:
            self.name_label.setText("Belum ada ekstensi" if not self.manager.infos else "Pilih ekstensi")
            self.meta_label.setText(f"Folder pengguna: {discovery.user_extensions_dir()}")
            for label in (self.description_label, self.contrib_label, self.status_label, self.problems_label):
                label.setText("")
            self.toggle_btn.setEnabled(False)
            self.remove_btn.setEnabled(False)
            return
        if not info.usable or info.manifest is None:
            self.name_label.setText(info.path.name)
            self.meta_label.setText(str(info.path))
            self.description_label.setText("")
            self.contrib_label.setText("")
            self.status_label.setText(f"Tidak valid: {info.error}")
            self.problems_label.setText("")
            self.toggle_btn.setEnabled(False)
            self.remove_btn.setEnabled(info.origin == "user")
            self.remove_btn.setProperty("broken", True)
            return
        m = info.manifest
        self.name_label.setText(m.name)
        origin = {"user": "pasang pengguna", "system": "ekstensi sistem", "pip": "paket pip"}[info.origin]
        self.meta_label.setText(f"v{m.version} · oleh {m.author or 'tanpa nama'} · {m.kind} · {origin}\nid {m.ext_id}")
        self.description_label.setText(m.description)
        parts = []
        if m.themes:
            parts.append(f"{len(m.themes)} tema")
        if m.presets:
            parts.append(f"{len(m.presets)} preset warna")
        if m.ai_tasks:
            parts.append(f"{len(m.ai_tasks)} tugas AI")
        if m.templates:
            parts.append(f"{len(m.templates)} templat")
        if m.has_code:
            caps_ = self.manager.host.capabilities().get(m.ext_id)
            if caps_:
                parts.append(f"{len(caps_.transforms)} transformasi, {len(caps_.actions)} aksi, {len(caps_.importers)} impor, {len(caps_.exporters)} ekspor")
            else:
                parts.append("perintah kode (muncul setelah aktif)")
        self.contrib_label.setText("Menyumbang: " + (", ".join(parts) or "—"))
        status = self.manager.approval(info)
        note = self.manager.status_text(info).capitalize()
        if m.has_code and m.permissions:
            note += "\nIzin dinyatakan: " + ", ".join(PERMISSION_TEXT[p] for p in m.permissions) + " (informasi saja)."
        self.status_label.setText(note)
        self.problems_label.setText("\n".join(f"• {p}" for p in info.problems))
        if status == "active":
            self.toggle_btn.setText("Nonaktifkan")
            role(self.toggle_btn, "ghost")
        else:
            self.toggle_btn.setText("Setujui dan aktifkan…" if m.has_code else "Aktifkan")
            role(self.toggle_btn, "primary")
        self.toggle_btn.setEnabled(not busy)
        self.remove_btn.setEnabled(info.origin == "user" and not busy)
        self.remove_btn.setToolTip("" if info.origin == "user" else "Hanya ekstensi yang dipasang pengguna yang dapat dihapus dari sini.")

    # --------------------------------------------------------------- actions
    def _toggle(self) -> None:
        info = self._selected()
        if info is None or not info.usable or info.manifest is None:
            return
        if self.manager.approval(info) == "active":
            self.manager.disable(info.ext_id)
        elif info.manifest.has_code:
            dialog = ApprovalDialog(info, self)
            if dialog.exec() == QDialog.DialogCode.Accepted:
                self.manager.approve(info)
        else:
            self.manager.enable(info.ext_id)

    def _remove(self) -> None:
        info = self._selected()
        if info is None or info.origin != "user":
            return
        name = info.manifest.name if info.manifest else info.path.name
        answer = QMessageBox.warning(
            self, "Hapus ekstensi?", f"Hapus ekstensi “{name}” dari komputer ini? Data yang dibuatnya di folder data ekstensi tidak ikut dihapus.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            if info.usable:
                self.manager.uninstall(info.ext_id)
            else:
                import shutil

                shutil.rmtree(info.path)
                self.manager.refresh()
        except (ExtensionError, OSError) as exc:
            QMessageBox.warning(self, "Ekstensi", str(exc))

    def _install(self, installer, path: Path) -> None:  # noqa: ANN001
        try:
            ext_id = installer(path)
        except ExtensionError as exc:
            if "sudah terpasang" in str(exc):
                answer = QMessageBox.question(
                    self, "Ganti ekstensi?", f"{exc}\n\nGanti dengan versi ini? Jika kodenya berbeda, persetujuan lama dicabut.",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No,
                )
                if answer == QMessageBox.StandardButton.Yes:
                    try:
                        ext_id = installer(path, replace=True)
                    except ExtensionError as inner:
                        QMessageBox.warning(self, "Ekstensi", str(inner))
                        return
                else:
                    return
            else:
                QMessageBox.warning(self, "Ekstensi", str(exc))
                return
        QMessageBox.information(self, "Ekstensi terpasang", f"“{ext_id}” terpasang. Ekstensi berkode belum berjalan sampai kamu menyetujuinya.")

    def install_from_folder(self) -> None:
        chosen = QFileDialog.getExistingDirectory(self, "Pilih folder ekstensi", str(Path.home()))
        if chosen:
            self._install(self.manager.install_dir, Path(chosen))

    def install_from_zip(self) -> None:
        chosen, _ = QFileDialog.getOpenFileName(self, "Pilih arsip ekstensi", str(Path.home()), "Arsip ZIP (*.zip)")
        if chosen:
            self._install(self.manager.install_zip, Path(chosen))

    def _open_dir(self) -> None:
        directory = discovery.user_extensions_dir()
        directory.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(directory)))
