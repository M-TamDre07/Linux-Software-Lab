"""Syntax colouring for the script markup (notes and pause cues)."""
from __future__ import annotations

import re

from PySide6.QtGui import QColor, QFont, QSyntaxHighlighter, QTextCharFormat, QTextDocument

from sorot.ui import theme

_NOTE = re.compile(r"^\s*//.*$")
_CUE = re.compile(r"^\s*\[\s*(?:jeda|pause)(?:\s+\d+(?:[.,]\d+)?)?\s*(?:detik|dtk|s|d)?\s*\]\s*$", re.IGNORECASE)


class ScriptHighlighter(QSyntaxHighlighter):
    def __init__(self, document: QTextDocument) -> None:
        super().__init__(document)
        self._note = QTextCharFormat()
        self._cue = QTextCharFormat()
        self.refresh_colors()

    def refresh_colors(self) -> None:
        p = theme.palette()
        self._note = QTextCharFormat()
        self._note.setForeground(QColor(p.faint))
        self._note.setFontItalic(True)
        self._cue = QTextCharFormat()
        self._cue.setForeground(QColor(p.accent))
        self._cue.setFontWeight(QFont.Weight.Bold)
        # Re-colouring must not make an untouched script look "unsaved".
        document = self.document()
        was_modified = document.isModified()
        self.rehighlight()
        document.setModified(was_modified)

    def highlightBlock(self, text: str) -> None:  # noqa: N802
        if _NOTE.match(text):
            self.setFormat(0, len(text), self._note)
        elif _CUE.match(text):
            self.setFormat(0, len(text), self._cue)
