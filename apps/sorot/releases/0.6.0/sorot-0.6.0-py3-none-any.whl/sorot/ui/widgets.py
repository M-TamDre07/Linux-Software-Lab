"""Custom controls: stepper, segmented choice, position map, tally light, caps labels."""
from __future__ import annotations

from collections.abc import Callable

from PySide6.QtCore import QEvent, QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QIcon, QKeyEvent, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QButtonGroup,
    QColorDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from sorot.ui import appearance, theme


def role(widget: QWidget, value: str) -> None:
    """Set a stylesheet role (``QLabel[role="caps"]``) and refresh the style."""
    widget.setProperty("role", value)
    widget.style().unpolish(widget)
    widget.style().polish(widget)


def caps(text: str, *, tone: str = "caps") -> QLabel:
    label = QLabel(text.upper())
    role(label, tone)
    font = label.font()
    font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 1.3)
    label.setFont(font)
    return label


def hrule() -> QFrame:
    line = QFrame()
    role(line, "rule")
    line.setFrameShape(QFrame.Shape.NoFrame)
    return line


# --------------------------------------------------------------------------
class Stepper(QFrame):
    """[ − ] value [ + ]: large, tactile targets that work well with a touchpad.

    Mirrors the parts of the ``QSpinBox`` API the application uses. The value is
    shown in a plain ``QLineEdit`` (a styled ``QSpinBox`` collapses its text
    field), parsed on Enter/blur, and steppable with the arrow keys or wheel.
    """

    valueChanged = Signal(int)

    def __init__(self, low: int = 0, high: int = 100, *, step: int = 1, suffix: str = "",
                 formatter: Callable[[int], str] | None = None, parser: Callable[[str], int | None] | None = None,
                 parent: QWidget | None = None) -> None:
        super().__init__(parent)
        role(self, "stepper")
        self._low, self._high, self._step = low, high, step
        self._suffix, self._special = suffix, ""
        self._formatter, self._parser = formatter, parser
        self._value = low
        self.edit = QLineEdit()
        role(self.edit, "stepvalue")
        self.edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.edit.setFrame(False)
        self.edit.setMinimumWidth(64)
        self.edit.editingFinished.connect(self._commit)
        self.edit.installEventFilter(self)
        self.minus = QPushButton("−")
        self.plus = QPushButton("+")
        for button in (self.minus, self.plus):
            role(button, "step")
            button.setAutoRepeat(True)
            button.setAutoRepeatDelay(350)
            button.setAutoRepeatInterval(70)
            button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.minus.setAccessibleName("Kurangi")
        self.plus.setAccessibleName("Tambah")
        row = QHBoxLayout(self)
        row.setContentsMargins(1, 1, 1, 1)
        row.setSpacing(0)
        row.addWidget(self.minus)
        row.addWidget(self.edit, 1)
        row.addWidget(self.plus)
        self.minus.clicked.connect(lambda: self.stepBy(-1))
        self.plus.clicked.connect(lambda: self.stepBy(1))
        self.setFocusProxy(self.edit)
        self._refresh_text()

    # -- text <-> value ----------------------------------------------------
    def _format(self, value: int) -> str:
        if self._special and value == self._low:
            return self._special
        return self._formatter(value) if self._formatter else f"{value}{self._suffix}"

    def _refresh_text(self) -> None:
        self.edit.setText(self._format(self._value))

    def _commit(self) -> None:
        text = self.edit.text().strip()
        if self._special and text == self._special:
            self.setValue(self._low)
            return
        raw = text.replace(self._suffix, "").strip() if self._suffix else text
        parsed = self._parser(raw) if self._parser else None
        if parsed is None and not self._parser:
            digits = "".join(ch for ch in raw if ch.isdigit() or ch == "-")
            parsed = int(digits) if digits not in {"", "-"} else None
        if parsed is None:
            self._refresh_text()  # unparseable input: show the current value again
        else:
            self.setValue(parsed)
            self._refresh_text()

    # -- QSpinBox-compatible surface ---------------------------------------
    def value(self) -> int:
        return self._value

    def setValue(self, value: int) -> None:  # noqa: N802
        value = max(self._low, min(self._high, int(value)))
        changed = value != self._value
        self._value = value
        self._refresh_text()
        if changed:
            self.valueChanged.emit(value)

    def stepBy(self, steps: int) -> None:  # noqa: N802
        self.setValue(self._value + steps * self._step)

    def minimum(self) -> int:
        return self._low

    def maximum(self) -> int:
        return self._high

    def setRange(self, low: int, high: int) -> None:  # noqa: N802
        self._low, self._high = low, high
        self.setValue(self._value)

    def setSpecialValueText(self, text: str) -> None:  # noqa: N802
        self._special = text
        self._refresh_text()

    def setAccessibleName(self, name: str) -> None:  # noqa: N802
        super().setAccessibleName(name)
        self.edit.setAccessibleName(name)

    # -- keyboard / wheel / focus ring ----------------------------------------
    def eventFilter(self, watched, event) -> bool:  # noqa: N802
        if watched is self.edit:
            kind = event.type()
            if kind == QEvent.Type.KeyPress:
                key = event.key()
                if key in (Qt.Key.Key_Up, Qt.Key.Key_Down):
                    self._commit()
                    self.stepBy(1 if key == Qt.Key.Key_Up else -1)
                    return True
                if key in (Qt.Key.Key_PageUp, Qt.Key.Key_PageDown):
                    self._commit()
                    self.stepBy(10 if key == Qt.Key.Key_PageUp else -10)
                    return True
            elif kind == QEvent.Type.Wheel and self.edit.hasFocus():
                self.stepBy(1 if event.angleDelta().y() > 0 else -1)
                return True
            elif kind in (QEvent.Type.FocusIn, QEvent.Type.FocusOut):
                self.setProperty("focused", kind == QEvent.Type.FocusIn)
                self.style().unpolish(self)
                self.style().polish(self)
                if kind == QEvent.Type.FocusIn:
                    QTimer.singleShot(0, self.edit.selectAll)
        return super().eventFilter(watched, event)


class Segmented(QFrame):
    """A joined row of exclusive choices."""

    valueChanged = Signal(str)

    def __init__(self, options: list[tuple[str, str]], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._group = QButtonGroup(self)
        self._group.setExclusive(True)
        self._buttons: dict[str, QPushButton] = {}
        row = QHBoxLayout(self)
        row.setContentsMargins(1, 0, 0, 0)
        row.setSpacing(0)
        for label, value in options:
            button = QPushButton(label)
            role(button, "seg")
            button.setCheckable(True)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setAccessibleName(label)
            self._group.addButton(button)
            self._buttons[value] = button
            row.addWidget(button, 1)
        self._group.buttonToggled.connect(self._toggled)
        first = next(iter(self._buttons.values()))
        first.setChecked(True)

    def _toggled(self, button: QPushButton, checked: bool) -> None:
        if checked:
            self.valueChanged.emit(self.value())

    def value(self) -> str:
        return next((key for key, button in self._buttons.items() if button.isChecked()), "")

    def setValue(self, value: str) -> None:
        button = self._buttons.get(value)
        if button is not None:
            button.setChecked(True)

    def blockSignals(self, block: bool) -> bool:  # noqa: N802
        self._group.blockSignals(block)
        return super().blockSignals(block)


class PositionPicker(QWidget):
    """A miniature screen: click where the overlay should sit."""

    valueChanged = Signal(str)
    _SPOTS = {
        "top-left": (0, 0), "top-center": (1, 0), "top-right": (2, 0), "center": (1, 1),
        "bottom-left": (0, 2), "bottom-center": (1, 2), "bottom-right": (2, 2),
    }

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._value = "top-center"
        self._hover: str | None = None
        self.setFixedSize(188, 112)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setAccessibleName("Posisi overlay di layar")
        self.setToolTip("Klik untuk memilih posisi. Menyeret overlay sendiri memindahkannya ke posisi manual.")

    def value(self) -> str:
        return self._value

    def setValue(self, value: str) -> None:
        if value != self._value:
            self._value = value
            self.update()

    def blockSignals(self, block: bool) -> bool:  # noqa: N802
        return super().blockSignals(block)

    def _screen_rect(self) -> QRectF:
        return QRectF(6, 6, self.width() - 12, self.height() - 12)

    def _spot_center(self, key: str) -> QPointF:
        col, row = self._SPOTS[key]
        r = self._screen_rect().adjusted(18, 16, -18, -16)
        return QPointF(r.left() + r.width() * col / 2, r.top() + r.height() * row / 2)

    def _spot_at(self, pos: QPointF) -> str | None:
        for key in self._SPOTS:
            c = self._spot_center(key)
            if abs(pos.x() - c.x()) <= 16 and abs(pos.y() - c.y()) <= 13:
                return key
        return None

    def paintEvent(self, _event) -> None:  # noqa: N802
        p = theme.palette()
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        screen = self._screen_rect()
        painter.setPen(QPen(QColor(p.line_strong), 1.2))
        painter.setBrush(QColor(p.inset))
        painter.drawRoundedRect(screen, 3, 3)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(p.line))
        painter.drawRect(QRectF(self.width() / 2 - 14, screen.bottom() - 0.5, 28, 3))
        for key in self._SPOTS:
            c = self._spot_center(key)
            box = QRectF(c.x() - 14, c.y() - 5, 28, 10)
            selected = key == self._value
            painter.setPen(QPen(QColor(p.accent if selected else p.line_strong), 1.2))
            painter.setBrush(QColor(p.accent) if selected else (QColor(p.raised) if key == self._hover else Qt.BrushStyle.NoBrush))
            painter.drawRoundedRect(box, 1.5, 1.5)
        if self._value == "manual":
            painter.setPen(QColor(p.accent))
            font = painter.font()
            font.setPointSize(7)
            font.setBold(True)
            painter.setFont(font)
            painter.drawText(screen.adjusted(0, 0, -6, -5), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignBottom, "MANUAL")
        if self.hasFocus():
            painter.setPen(QPen(QColor(p.accent), 1, Qt.PenStyle.DotLine))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawRect(self.rect().adjusted(0, 0, -1, -1))

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        spot = self._spot_at(event.position())
        if spot != self._hover:
            self._hover = spot
            self.setCursor(Qt.CursorShape.PointingHandCursor if spot else Qt.CursorShape.ArrowCursor)
            self.update()

    def leaveEvent(self, _event) -> None:  # noqa: N802
        self._hover = None
        self.update()

    def mousePressEvent(self, event) -> None:  # noqa: N802
        spot = self._spot_at(event.position())
        if spot:
            self._choose(spot)

    def keyPressEvent(self, event: QKeyEvent) -> None:  # noqa: N802
        moves = {Qt.Key.Key_Left: (-1, 0), Qt.Key.Key_Right: (1, 0), Qt.Key.Key_Up: (0, -1), Qt.Key.Key_Down: (0, 1)}
        delta = moves.get(Qt.Key(event.key()))
        if delta is None:
            super().keyPressEvent(event)
            return
        col, row = self._SPOTS.get(self._value, (1, 0))
        target = (col + delta[0], row + delta[1])
        for key, spot in self._SPOTS.items():
            if spot == target:
                self._choose(key)
                return

    def _choose(self, key: str) -> None:
        if key != self._value:
            self._value = key
            self.update()
            self.valueChanged.emit(key)


class TallyLight(QWidget):
    """off / standby (overlay shown, paused) / live (scrolling)."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._state = "off"
        self.setFixedSize(14, 14)

    def setState(self, state: str) -> None:  # noqa: N802
        if state != self._state:
            self._state = state
            self.update()

    def state(self) -> str:
        return self._state

    def paintEvent(self, _event) -> None:  # noqa: N802
        p = theme.palette()
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(1.5, 1.5, 11, 11)
        if self._state == "live":
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(p.live))
        elif self._state == "standby":
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(p.accent))
        else:
            painter.setPen(QPen(QColor(p.faint), 1.4))
            painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawEllipse(rect)


class ColorButton(QPushButton):
    """A button showing a colour swatch; opens the standard colour dialog."""

    colorChanged = Signal(str)

    def __init__(self, title: str, color: str = "#FFFFFF", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._title = title
        self._color = color
        self.setAccessibleName(title)
        self.clicked.connect(self._choose)
        self._refresh()

    @property
    def color(self) -> str:
        return self._color

    def set_color(self, color: str, *, emit: bool = False) -> None:
        if color.upper() == self._color.upper():
            return
        self._color = color.upper()
        self._refresh()
        if emit:
            self.colorChanged.emit(self._color)

    def _refresh(self) -> None:
        swatch = QPixmap(18, 18)
        swatch.fill(QColor(self._color))
        self.setIcon(QIcon(swatch))
        self.setText(self._color.upper())
        self.setToolTip(f"{self._title}: klik untuk memilih warna")

    def _choose(self) -> None:
        chosen = QColorDialog.getColor(QColor(self._color), self, self._title)
        if chosen.isValid():
            self.set_color(chosen.name(), emit=True)


class OverlayPreview(QFrame):
    """A read-only miniature of the overlay for the settings page."""

    SAMPLE = "Contoh tampilan naskah.\nGaris baca ada di baris ini.\nBaris ketiga untuk perataan."

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("previewHost")
        self.setStyleSheet("QFrame#previewHost { background: #5B6475; border: 1px solid #00000040; border-radius: 3px; }")
        self.setFixedHeight(112)
        self.panel = QFrame(self)
        self.panel.setObjectName("panel")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.addWidget(self.panel)
        self._inner = QVBoxLayout(self.panel)
        self.view = QTextEdit(self.panel)
        self.view.setReadOnly(True)
        self.view.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.view.setFrameShape(QFrame.Shape.NoFrame)
        self.view.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.view.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.view.setAccessibleName("Pratinjau tampilan overlay")
        self.view.setPlainText(self.SAMPLE)
        self._inner.addWidget(self.view)

    def apply(self, *, font_family: str, font_size: int, text_color: str, background_color: str,
              background_opacity: int, text_align: str, margin: int, rounded: bool) -> None:
        self.panel.setStyleSheet(appearance.panel_stylesheet(background_color, background_opacity, rounded=rounded))
        self.view.setStyleSheet(appearance.text_stylesheet(text_color))
        self.view.setFont(appearance.make_font(font_family, min(font_size, 20)))
        self.view.document().setDefaultTextOption(appearance.text_option(text_align))
        margin = min(margin, 18)
        self._inner.setContentsMargins(margin, margin // 2, margin, margin // 2)
