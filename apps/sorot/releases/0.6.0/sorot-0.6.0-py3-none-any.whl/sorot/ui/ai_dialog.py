"""Optional AI assistant dialog.

Nothing is sent anywhere until the user presses "Proses naskah" and confirms the
destination. "Uji koneksi" never sends script text.
"""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

from PySide6.QtCore import Signal
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
)

from sorot.services import ai_service as ai
from sorot.services.ai_service import AIConfig, AIError
from sorot.ui.task_worker import BackgroundTask


@dataclass
class AIContext:
    """Everything the dialog needs from the main window, without importing it."""

    base_url: str
    model: str
    timeout: int
    api_key: str
    wpm: int
    keyring_available: bool
    keyring_saved: bool
    confirm_send: Callable[[str, int], bool]  # (host, characters) -> proceed?
    save_settings: Callable[[str, str, int], None]
    remember_session_key: Callable[[str], None]
    save_key: Callable[[str], tuple[bool, str]]
    delete_key: Callable[[], bool]
    extra_tasks: dict[str, ai.AITask] = field(default_factory=dict)  # contributed by extensions


class AIAssistantDialog(QDialog):
    applyRequested = Signal(str, str)  # mode ("replace" | "append"), text

    def __init__(self, current_text: str, context: AIContext, parent=None) -> None:
        super().__init__(parent)
        self.ctx = context
        self.task: BackgroundTask | None = None
        self.setWindowTitle("Sorot — Asisten AI")
        self.resize(780, 700)
        self.setMinimumSize(640, 560)
        layout = QVBoxLayout(self)

        privacy = QLabel(
            "AI bersifat opsional. Saat diproses, teks naskah dikirim lewat internet ke penyedia API yang kamu pilih. "
            "Biaya penggunaan API bergantung pada penyedia dan pemakaianmu. Jangan kirim kata sandi atau data pribadi sensitif."
        )
        privacy.setWordWrap(True)
        privacy.setObjectName("hint")
        layout.addWidget(privacy)

        form = QFormLayout()
        self.endpoint_input = QLineEdit(context.base_url)
        self.endpoint_input.setPlaceholderText("https://api.openai.com/v1")
        self.endpoint_input.setAccessibleName("API base URL")
        self.model_input = QLineEdit(context.model)
        self.model_input.setAccessibleName("Nama model")
        self.api_key_input = QLineEdit(context.api_key)
        self.api_key_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.api_key_input.setPlaceholderText("API key (tidak pernah ditulis ke berkas pengaturan)")
        self.api_key_input.setAccessibleName("API key")
        self.show_key = QCheckBox("Tampilkan")
        key_row = QHBoxLayout()
        key_row.addWidget(self.api_key_input, 1)
        key_row.addWidget(self.show_key)
        self.timeout_spin = QSpinBox()
        self.timeout_spin.setRange(ai.MIN_TIMEOUT, ai.MAX_TIMEOUT)
        self.timeout_spin.setSuffix(" detik")
        self.timeout_spin.setValue(context.timeout)
        form.addRow("API base URL", self.endpoint_input)
        form.addRow("Model", self.model_input)
        form.addRow("API key", key_row)
        form.addRow("Batas waktu", self.timeout_spin)
        layout.addLayout(form)

        key_options = QHBoxLayout()
        self.remember_check = QCheckBox("Simpan API key di keyring sistem")
        self.remember_check.setEnabled(context.keyring_available)
        if not context.keyring_available:
            self.remember_check.setToolTip(
                "Keyring desktop yang aman tidak ditemukan (pasang python3-keyring dan layanan seperti GNOME Keyring/KWallet). "
                "API key hanya berlaku sampai aplikasi ditutup."
            )
        self.remember_check.setChecked(context.keyring_available and context.keyring_saved)
        self.forget_btn = QPushButton("Hapus key tersimpan")
        self.forget_btn.setEnabled(context.keyring_available and context.keyring_saved)
        self.test_btn = QPushButton("Uji koneksi")
        self.test_btn.setToolTip("Memeriksa URL, API key, dan model. Tidak mengirim naskah.")
        key_options.addWidget(self.remember_check, 1)
        key_options.addWidget(self.forget_btn)
        key_options.addWidget(self.test_btn)
        layout.addLayout(key_options)

        task_form = QFormLayout()
        self.task_combo = QComboBox()
        for task in ai.TASKS:
            self.task_combo.addItem(task.label, task.task_id)
        for task in context.extra_tasks.values():
            self.task_combo.addItem(task.label, task.task_id)
        self.custom_input = QLineEdit()
        self.custom_input.setPlaceholderText("Tulis instruksi, mis. “Ubah menjadi pembukaan video yang singkat”")
        self.minutes_spin = QSpinBox()
        self.minutes_spin.setRange(1, 120)
        self.minutes_spin.setValue(3)
        self.minutes_spin.setSuffix(" menit")
        task_form.addRow("Tugas AI", self.task_combo)
        task_form.addRow("Instruksi", self.custom_input)
        task_form.addRow("Durasi target", self.minutes_spin)
        layout.addLayout(task_form)
        self._task_form = task_form

        layout.addWidget(QLabel("Naskah yang akan dikirim ke AI"))
        self.input_text = QPlainTextEdit()
        self.input_text.setPlainText(current_text)
        self.input_text.setPlaceholderText("Masukkan naskah terlebih dahulu di jendela utama…")
        layout.addWidget(self.input_text, 2)
        layout.addWidget(QLabel("Hasil AI — periksa dan edit dulu sebelum dipakai"))
        self.output_text = QPlainTextEdit()
        self.output_text.setPlaceholderText("Hasil AI akan muncul di sini. Naskah utama tidak berubah sampai kamu memilih “Ganti naskah” atau “Tambahkan”.")
        layout.addWidget(self.output_text, 2)

        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setTextVisible(False)
        self.progress.hide()
        layout.addWidget(self.progress)

        buttons = QHBoxLayout()
        self.process_btn = QPushButton("Proses naskah")
        self.process_btn.setObjectName("primary")
        self.cancel_btn = QPushButton("Batalkan")
        self.cancel_btn.hide()
        self.apply_btn = QPushButton("Ganti naskah")
        self.apply_btn.setToolTip("Mengganti seluruh isi editor utama dengan hasil ini. Dapat dibatalkan dengan Ctrl+Z di editor.")
        self.append_btn = QPushButton("Tambahkan")
        self.copy_btn = QPushButton("Salin hasil")
        self.close_btn = QPushButton("Tutup")
        for button in (self.process_btn, self.cancel_btn, self.apply_btn, self.append_btn, self.copy_btn):
            buttons.addWidget(button)
        buttons.addStretch(1)
        buttons.addWidget(self.close_btn)
        layout.addLayout(buttons)
        self.status = QLabel("Tidak ada data yang dikirim sampai kamu menekan Proses naskah.")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)

        self.show_key.toggled.connect(lambda on: self.api_key_input.setEchoMode(QLineEdit.EchoMode.Normal if on else QLineEdit.EchoMode.Password))
        self.task_combo.currentIndexChanged.connect(self._update_task_fields)
        self.process_btn.clicked.connect(self.process_text)
        self.cancel_btn.clicked.connect(self.cancel_running)
        self.test_btn.clicked.connect(self.test_connection)
        self.forget_btn.clicked.connect(self._forget_key)
        self.apply_btn.clicked.connect(lambda: self._emit_apply("replace"))
        self.append_btn.clicked.connect(lambda: self._emit_apply("append"))
        self.copy_btn.clicked.connect(self._copy)
        self.close_btn.clicked.connect(self.close)
        self._update_task_fields()

    # ------------------------------------------------------------------ helpers
    def _current_task(self) -> ai.AITask:
        key = self.task_combo.currentData()
        return ai.TASKS_BY_ID.get(key) or self.ctx.extra_tasks[key]

    def _update_task_fields(self) -> None:
        task = self._current_task()
        for widget, visible in ((self.custom_input, task.needs_custom), (self.minutes_spin, task.needs_minutes)):
            widget.setVisible(visible)
            label = self._task_form.labelForField(widget)
            if label is not None:
                label.setVisible(visible)

    def _config(self) -> AIConfig:
        return AIConfig(
            base_url=self.endpoint_input.text().strip(), model=self.model_input.text().strip(),
            api_key=self.api_key_input.text().strip(), timeout_seconds=self.timeout_spin.value(),
        )

    def _set_busy(self, busy: bool, message: str = "") -> None:
        for widget in (self.process_btn, self.test_btn, self.endpoint_input, self.model_input, self.api_key_input,
                       self.timeout_spin, self.task_combo, self.custom_input, self.minutes_spin, self.input_text):
            widget.setEnabled(not busy)
        self.cancel_btn.setVisible(busy)
        self.progress.setVisible(busy)
        if message:
            self.status.setText(message)

    def _persist_settings(self, config: AIConfig) -> None:
        self.ctx.save_settings(config.base_url, config.model, config.timeout_seconds)
        self.ctx.remember_session_key(config.api_key)
        if self.remember_check.isChecked() and config.api_key:
            saved, message = self.ctx.save_key(config.api_key)
            if not saved:
                QMessageBox.warning(self, "Penyimpanan API key", message)
            else:
                self.forget_btn.setEnabled(True)

    # ------------------------------------------------------------------- actions
    def process_text(self) -> None:
        text = self.input_text.toPlainText().strip()
        if not text:
            QMessageBox.information(self, "Naskah kosong", "Masukkan naskah sebelum menjalankan AI.")
            return
        config = self._config()
        task = self._current_task()
        minutes = self.minutes_spin.value() if task.needs_minutes else None
        try:
            ai.validate_config(config)
            ai.build_messages(
                task.task_id, text, custom_instruction=self.custom_input.text(), target_minutes=minutes, wpm=self.ctx.wpm,
                extra_tasks=self.ctx.extra_tasks,
            )
            host = ai.api_host(config.base_url)
        except AIError as exc:
            QMessageBox.warning(self, "Konfigurasi AI", str(exc))
            return
        if not self.ctx.confirm_send(host, len(text)):
            self.status.setText("Dibatalkan. Tidak ada data yang dikirim.")
            return
        self._persist_settings(config)
        custom, wpm = self.custom_input.text(), self.ctx.wpm
        self._start(
            lambda token: ai.complete(
                config, task.task_id, text, custom_instruction=custom, target_minutes=minutes, wpm=wpm, cancel=token,
                extra_tasks=self.ctx.extra_tasks,
            ),
            "Memproses naskah… Kamu dapat membatalkan kapan saja.", self._on_result,
        )

    def test_connection(self) -> None:
        config = self._config()
        try:
            ai.validate_config(config)
        except AIError as exc:
            QMessageBox.warning(self, "Konfigurasi AI", str(exc))
            return
        self._start(lambda token: ai.test_connection(config, cancel=token), "Menguji koneksi… (naskah tidak dikirim)", self._on_test_ok)

    def _start(self, function, message: str, on_success) -> None:
        self.task = BackgroundTask(function, self)
        self.task.succeeded.connect(on_success)
        self.task.failed.connect(self._on_failed)
        self.task.cancelled.connect(self._on_cancelled)
        self._set_busy(True, message)
        self.task.start()

    def cancel_running(self) -> None:
        if self.task is not None and self.task.running:
            self.task.cancel()
            self.cancel_btn.setEnabled(False)
            self.status.setText("Membatalkan… Hasil yang datang terlambat akan diabaikan. Provider mungkin tetap menagih permintaan yang sudah terkirim.")

    def _finish(self) -> None:
        self.task = None
        self.cancel_btn.setEnabled(True)
        self._set_busy(False)

    def _on_result(self, result) -> None:
        self._finish()
        self.output_text.setPlainText(str(result))
        self.status.setText("Selesai. Periksa dan edit hasilnya, lalu pilih Ganti naskah atau Tambahkan.")

    def _on_test_ok(self, message) -> None:
        self._finish()
        self.status.setText(str(message))

    def _on_failed(self, message: str) -> None:
        self._finish()
        self.status.setText("Permintaan gagal.")
        QMessageBox.warning(self, "Permintaan AI gagal", message)

    def _on_cancelled(self) -> None:
        self._finish()
        self.status.setText("Dibatalkan. Naskah tidak berubah.")

    def _emit_apply(self, mode: str) -> None:
        result = self.output_text.toPlainText().strip()
        if not result:
            QMessageBox.information(self, "Hasil kosong", "Belum ada hasil untuk digunakan.")
            return
        self.applyRequested.emit(mode, result)
        self.status.setText("Naskah utama diperbarui. Gunakan Ctrl+Z di editor untuk membatalkan." if mode == "replace" else "Hasil ditambahkan ke naskah utama.")

    def _copy(self) -> None:
        text = self.output_text.toPlainText()
        if text:
            QGuiApplication.clipboard().setText(text)
            self.status.setText("Hasil disalin ke clipboard.")

    def _forget_key(self) -> None:
        if self.ctx.delete_key():
            self.forget_btn.setEnabled(False)
            self.remember_check.setChecked(False)
            self.status.setText("API key tersimpan dihapus dari keyring.")
        else:
            self.status.setText("Tidak ada API key tersimpan yang dapat dihapus.")

    def closeEvent(self, event) -> None:  # noqa: N802
        if self.task is not None and self.task.running:
            self.task.cancel()  # never block closing; a late result is discarded
        super().closeEvent(event)
