"""Qt-side owner of the extension subsystem: discovery, approval, processes, contributions."""
from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from PySide6.QtCore import QObject, Signal

from sorot.core.config import AppConfig
from sorot.extensions import discovery, installer, state
from sorot.extensions.discovery import ExtensionInfo
from sorot.extensions.host import ExtensionHost
from sorot.extensions.manifest import PresetDef, TemplateDef, ThemeDef
from sorot.services.ai_service import AITask
from sorot.ui.task_worker import BackgroundTask

LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class Command:
    ext_id: str
    ext_name: str
    kind: str  # transform | action | importer | exporter
    command_id: str
    label: str
    extension: str = ""  # file suffix for importers/exporters
    extensions: tuple[str, ...] = ()


class ExtensionManager(QObject):
    changed = Signal()
    notify = Signal(str)

    def __init__(self, config: AppConfig, save_config: Callable[[], None], app_version: str, parent: QObject | None = None, *,
                 user_dir: Path | None = None, system_dirs: tuple[Path, ...] | None = None, include_pip: bool = True,
                 python: str | None = None) -> None:
        super().__init__(parent)
        self.config = config
        self._save_config = save_config
        self.user_dir, self.system_dirs, self.include_pip = user_dir, system_dirs, include_pip
        self.infos: list[ExtensionInfo] = []
        self.host = ExtensionHost(app_version, on_notify=self._on_notify, python=python)
        self._refreshing = False
        self._again = False
        self._tasks: set[BackgroundTask] = set()
        self._call_task: BackgroundTask | None = None

    # ---------------------------------------------------------------- refresh
    def _discover(self) -> list[ExtensionInfo]:
        return discovery.discover(user_dir=self.user_dir, system_dirs=self.system_dirs, include_pip=self.include_pip)

    def _active_code(self, infos: list[ExtensionInfo]) -> list[ExtensionInfo]:
        return [i for i in infos if i.usable and i.manifest and i.manifest.has_code and state.is_active(i, self.config.extensions)]

    def _work(self, _token) -> list[ExtensionInfo]:  # runs off the GUI thread: starting processes can take seconds
        infos = self._discover()
        self.host.sync(self._active_code(infos))
        return infos

    def refresh(self) -> None:
        if self._refreshing:
            self._again = True
            return
        self._refreshing = True
        task = BackgroundTask(self._work, self)
        self._tasks.add(task)
        task.succeeded.connect(lambda infos, t=task: self._refreshed(infos, t))
        task.failed.connect(lambda message, t=task: self._refresh_failed(message, t))
        task.start()

    def refresh_blocking(self) -> None:
        self.infos = self._work(None)
        self.changed.emit()

    @property
    def refreshing(self) -> bool:
        return self._refreshing

    def _refreshed(self, infos: list[ExtensionInfo], task: BackgroundTask) -> None:
        self._tasks.discard(task)
        self.infos = infos
        self._refreshing = False
        self.changed.emit()
        if self._again:
            self._again = False
            self.refresh()

    def _refresh_failed(self, message: str, task: BackgroundTask) -> None:
        self._tasks.discard(task)
        self._refreshing = False
        LOGGER.warning("Pemuatan ekstensi gagal: %s", message)
        self.notify.emit(f"Ekstensi gagal dimuat: {message}")

    # ----------------------------------------------------------------- queries
    def info(self, ext_id: str) -> ExtensionInfo | None:
        return next((i for i in self.infos if i.usable and i.ext_id == ext_id), None)

    def approval(self, info: ExtensionInfo) -> str:
        return state.approval_status(info, self.config.extensions)

    def status_text(self, info: ExtensionInfo) -> str:
        status = self.approval(info)
        label = state.STATUS_LABELS[status]
        if status == "active" and info.manifest and info.manifest.has_code:
            host_status = self.host.status(info.ext_id)
            if host_status != "berjalan":
                label = f"aktif, tetapi {host_status}"
        return label

    def active(self) -> list[ExtensionInfo]:
        return [i for i in self.infos if state.is_active(i, self.config.extensions)]

    def themes(self) -> list[tuple[str, str, ThemeDef]]:
        return [(f"{i.ext_id}/{t.theme_id}", f"{t.name} · {i.manifest.name}", t) for i in self.active() if i.manifest for t in i.manifest.themes]

    def presets(self) -> dict[str, PresetDef]:
        return {f"{p.name} · {i.manifest.name}": p for i in self.active() if i.manifest for p in i.manifest.presets}

    def templates(self) -> list[tuple[str, TemplateDef]]:
        return [(i.manifest.name, t) for i in self.active() if i.manifest for t in i.manifest.templates]

    def ai_tasks(self) -> dict[str, AITask]:
        tasks: dict[str, AITask] = {}
        for info in self.active():
            if info.manifest:
                for t in info.manifest.ai_tasks:
                    key = f"ext:{info.ext_id}/{t.task_id}"
                    tasks[key] = AITask(key, f"{t.label} · {info.manifest.name}", t.instruction)
        return tasks

    def commands(self) -> list[Command]:
        commands: list[Command] = []
        for ext_id, caps in self.host.capabilities().items():
            info = self.info(ext_id)
            name = info.manifest.name if info and info.manifest else ext_id
            commands += [Command(ext_id, name, "transform", c["id"], c["label"]) for c in caps.transforms]
            commands += [Command(ext_id, name, "action", c["id"], c["label"]) for c in caps.actions]
            commands += [Command(ext_id, name, "importer", c["id"], c["label"], extensions=tuple(str(e) for e in c.get("extensions", []))) for c in caps.importers]
            commands += [Command(ext_id, name, "exporter", c["id"], c["label"], extension=str(c.get("extension", ""))) for c in caps.exporters]
        return commands

    # --------------------------------------------------------------- user actions
    def approve(self, info: ExtensionInfo) -> None:
        state.approve(self.config.extensions, info)
        self._save_config()
        self.refresh()

    def enable(self, ext_id: str) -> None:
        state.enable_declarative(self.config.extensions, ext_id)
        self._save_config()
        self.refresh()

    def disable(self, ext_id: str) -> None:
        state.disable(self.config.extensions, ext_id)
        if self.config.theme_ext.startswith(f"{ext_id}/"):
            self.config.theme_ext = ""
        self._save_config()
        self.refresh()

    def install_dir(self, path: Path, *, replace: bool = False) -> str:
        ext_id = installer.install_from_dir(path, replace=replace, user_dir=self.user_dir)
        self.refresh()
        return ext_id

    def install_zip(self, path: Path, *, replace: bool = False) -> str:
        ext_id = installer.install_from_zip(path, replace=replace, user_dir=self.user_dir)
        self.refresh()
        return ext_id

    def uninstall(self, ext_id: str) -> None:
        self.host.sync([i for i in self._active_code(self.infos) if i.ext_id != ext_id])
        installer.uninstall(ext_id, user_dir=self.user_dir)
        state.forget(self.config.extensions, ext_id)
        if self.config.theme_ext.startswith(f"{ext_id}/"):
            self.config.theme_ext = ""
        self._save_config()
        self.refresh()

    # -------------------------------------------------------------------- calls
    def busy(self) -> bool:
        return self._call_task is not None  # cleared by the result handler, so never True->False before the result is applied

    def call_async(self, ext_id: str, method: str, params: dict[str, Any], on_ok: Callable[[Any], None],
                   on_fail: Callable[[str], None], *, on_cancel: Callable[[], None] | None = None) -> bool:
        if self.busy():
            return False
        task = BackgroundTask(lambda token: self.host.call(ext_id, method, params, cancel=token), self)
        self._call_task = task

        def succeeded(result: Any) -> None:
            self._clear(task)
            on_ok(result)

        def failed(message: str) -> None:
            self._clear(task)
            on_fail(message)

        def cancelled() -> None:
            self._clear(task)
            if on_cancel:
                on_cancel()

        task.succeeded.connect(succeeded)
        task.failed.connect(failed)
        task.cancelled.connect(cancelled)
        task.start()
        return True

    def cancel_call(self) -> None:
        if self._call_task is not None:
            self._call_task.cancel()

    def _clear(self, task: BackgroundTask) -> None:
        if self._call_task is task:
            self._call_task = None
        self.changed.emit()

    def broadcast(self, event: str, data: dict[str, Any]) -> None:
        self.host.broadcast(event, data)

    def _on_notify(self, ext_id: str, message: str) -> None:
        info = self.info(ext_id)
        self.notify.emit(f"[{info.manifest.name if info and info.manifest else ext_id}] {message}")

    def shutdown(self) -> None:
        self.host.shutdown()
