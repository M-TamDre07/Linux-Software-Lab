"""Design tokens and the application stylesheet.

Direction: a broadcast-desk look. Warm graphite (or paper) surfaces, one amber
accent that doubles as a "tally light", hairline borders, small corners, and
monospaced numerals for anything that counts time. No gradients, no glow.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path

FONT_UI = '"Inter", "Noto Sans", "Cantarell", "DejaVu Sans", sans-serif'
FONT_SERIF = '"Noto Serif", "Source Serif 4", "DejaVu Serif", serif'
FONT_MONO = '"JetBrains Mono", "Noto Sans Mono", "DejaVu Sans Mono", monospace'


@dataclass(frozen=True)
class Palette:
    name: str
    bg: str
    surface: str
    raised: str
    inset: str
    line: str
    line_strong: str
    text: str
    muted: str
    faint: str
    accent: str
    accent_ink: str
    live: str
    ok: str
    selection: str


DARK = Palette(
    name="dark", bg="#131210", surface="#1A1916", raised="#24221E", inset="#0F0E0C", line="#2E2B25", line_strong="#4B473E",
    text="#EBE5D6", muted="#A19A89", faint="#6F6959", accent="#FFB000", accent_ink="#1B1300", live="#EF5B48", ok="#7CC38F",
    selection="#5A4310",
)
LIGHT = Palette(
    name="light", bg="#ECE6D9", surface="#F5F1E7", raised="#FFFFFF", inset="#FBF9F3", line="#D2CAB7", line_strong="#A59D88",
    text="#1F1C16", muted="#5F5849", faint="#8C8470", accent="#B35900", accent_ink="#FFFFFF", live="#B3321F", ok="#2E7D4F",
    selection="#F2D9A8",
)
PALETTES = {"dark": DARK, "light": LIGHT}

_current = DARK


def palette() -> Palette:
    return _current


def use_palette(name: str | Palette) -> Palette:
    global _current
    _current = name if isinstance(name, Palette) else PALETTES.get(name, DARK)
    return _current


def palette_from_extension(base: str, colors: dict[str, str]) -> Palette:
    """A palette derived from ``dark`` or ``light`` with some colours overridden by an extension."""
    origin = PALETTES.get(base, DARK)
    allowed = {key: value for key, value in colors.items() if key in origin.__dataclass_fields__ and key != "name"}
    return replace(origin, name=origin.name, **allowed)


def _check_icon(p: Palette) -> str:
    name = "check-light.svg" if p.name == "light" else "check-dark.svg"
    return (Path(__file__).parent / "assets" / name).as_posix()


def build_stylesheet(p: Palette) -> str:
    check = _check_icon(p)
    return f"""
* {{ font-family: {FONT_UI}; font-size: 10pt; outline: none; }}
QMainWindow, QDialog {{ background: {p.bg}; color: {p.text}; }}
QWidget#root, QWidget#page, QWidget#transport, QWidget#statusbar {{ background: {p.bg}; }}
QLabel {{ background: transparent; color: {p.text}; }}
QLabel[role="muted"] {{ color: {p.muted}; }}
QLabel[role="faint"] {{ color: {p.faint}; }}
QLabel[role="caps"] {{ color: {p.muted}; font-size: 8pt; font-weight: 700; }}
QLabel[role="title"] {{ font-family: {FONT_SERIF}; font-size: 20pt; font-weight: 700; color: {p.text}; }}
QLabel[role="mono"] {{ font-family: {FONT_MONO}; color: {p.text}; }}
QLabel[role="readout"] {{ font-family: {FONT_MONO}; font-size: 26pt; font-weight: 700; color: {p.text}; }}
QLabel[role="stat"] {{ font-family: {FONT_MONO}; font-size: 15pt; font-weight: 700; color: {p.text}; }}
QLabel[role="note"] {{ color: {p.muted}; border-left: 2px solid {p.line_strong}; padding-left: 8px; }}
QLabel[role="warn"] {{ color: {p.text}; background: {p.raised}; border: 1px solid {p.accent}; border-radius: 3px; padding: 6px 8px; }}
QLabel#status {{ font-family: {FONT_MONO}; font-size: 9pt; color: {p.muted}; padding: 0 2px; }}

QFrame[role="panel"] {{ background: {p.surface}; border: 1px solid {p.line}; border-radius: 3px; }}
QFrame[role="rail"] {{ background: {p.surface}; border: none; border-right: 1px solid {p.line}; }}
QFrame[role="rule"] {{ background: {p.line}; border: none; max-height: 1px; min-height: 1px; }}
QFrame[role="vrule"] {{ background: {p.line}; border: none; max-width: 1px; min-width: 1px; }}

QPlainTextEdit, QTextEdit, QLineEdit, QListWidget, QKeySequenceEdit {{
    background: {p.inset}; color: {p.text}; border: 1px solid {p.line}; border-radius: 3px; padding: 6px 8px;
    selection-background-color: {p.selection}; selection-color: {p.text};
}}
QPlainTextEdit#script {{ font-family: {FONT_SERIF}; font-size: 14pt; padding: 16px 20px; }}
QPlainTextEdit#mono {{ font-family: {FONT_MONO}; font-size: 9pt; }}
QPlainTextEdit:focus, QTextEdit:focus, QLineEdit:focus, QListWidget:focus, QKeySequenceEdit:focus {{ border: 1px solid {p.accent}; }}
QListWidget::item {{ padding: 6px 8px; border-radius: 2px; }}
QListWidget::item:selected {{ background: {p.selection}; color: {p.text}; }}

QComboBox {{ background: {p.inset}; color: {p.text}; border: 1px solid {p.line}; border-radius: 3px; padding: 5px 8px; min-height: 20px; }}
QComboBox:focus, QComboBox:on {{ border: 1px solid {p.accent}; }}
QComboBox QAbstractItemView {{ background: {p.raised}; color: {p.text}; border: 1px solid {p.line_strong}; selection-background-color: {p.selection}; selection-color: {p.text}; outline: none; }}

QPushButton {{ background: {p.raised}; color: {p.text}; border: 1px solid {p.line_strong}; border-radius: 3px; padding: 7px 12px; font-weight: 600; }}
QPushButton:hover {{ border-color: {p.muted}; }}
QPushButton:pressed {{ background: {p.inset}; }}
QPushButton:focus {{ border: 1px solid {p.accent}; }}
QPushButton:disabled {{ color: {p.faint}; border-color: {p.line}; background: {p.surface}; }}
QPushButton[role="primary"] {{ background: {p.accent}; color: {p.accent_ink}; border: 1px solid {p.accent}; font-weight: 800; }}
QPushButton[role="primary"]:hover {{ background: {p.accent}; border-color: {p.text}; }}
QPushButton[role="primary"]:disabled {{ background: {p.line}; color: {p.faint}; border-color: {p.line}; }}
QPushButton[role="ghost"] {{ background: transparent; border: 1px solid {p.line}; color: {p.muted}; font-weight: 600; }}
QPushButton[role="ghost"]:hover {{ color: {p.text}; border-color: {p.line_strong}; }}
QPushButton[role="danger"] {{ background: transparent; color: {p.live}; border: 1px solid {p.live}; }}
QPushButton[role="danger"]:hover {{ background: {p.live}; color: {p.bg}; }}
QPushButton[role="nav"] {{ background: transparent; border: none; border-left: 3px solid transparent; border-radius: 0; text-align: left;
    padding: 11px 14px; color: {p.muted}; font-weight: 600; }}
QPushButton[role="nav"]:hover {{ color: {p.text}; background: {p.raised}; }}
QPushButton[role="nav"]:checked {{ color: {p.text}; background: {p.raised}; border-left: 3px solid {p.accent}; }}
QPushButton[role="seg"] {{ background: {p.inset}; border: 1px solid {p.line_strong}; border-radius: 0; padding: 5px 10px; margin-left: -1px; color: {p.muted}; font-weight: 600; }}
QPushButton[role="seg"]:checked {{ background: {p.accent}; color: {p.accent_ink}; border-color: {p.accent}; font-weight: 800; }}
QPushButton[role="seg"]:hover:!checked {{ color: {p.text}; }}
QPushButton[role="step"] {{ background: {p.raised}; border: none; border-radius: 0; padding: 0; min-width: 30px; font-family: {FONT_MONO}; font-size: 12pt; font-weight: 700; color: {p.text}; }}
QPushButton[role="step"]:hover {{ background: {p.selection}; }}
QPushButton[role="step"]:pressed {{ background: {p.accent}; color: {p.accent_ink}; }}

QFrame[role="stepper"] {{ background: {p.inset}; border: 1px solid {p.line_strong}; border-radius: 3px; }}
QFrame[role="stepper"][focused="true"] {{ border: 1px solid {p.accent}; }}
QLineEdit[role="stepvalue"], QLineEdit[role="stepvalue"]:focus {{ background: transparent; border: none; border-radius: 0; font-family: {FONT_MONO}; font-weight: 700; padding: 4px 2px; selection-background-color: {p.selection}; color: {p.text}; }}

QCheckBox {{ spacing: 9px; color: {p.text}; padding: 3px 0; }}
QCheckBox::indicator {{ width: 14px; height: 14px; border: 1px solid {p.line_strong}; border-radius: 2px; background: {p.inset}; }}
QCheckBox::indicator:checked {{ background: {p.accent}; border-color: {p.accent}; image: url({check}); }}
QCheckBox::indicator:hover {{ border-color: {p.muted}; }}
QCheckBox:focus {{ color: {p.accent}; }}

QSlider::groove:horizontal {{ height: 3px; background: {p.line_strong}; }}
QSlider::sub-page:horizontal {{ background: {p.accent}; }}
QSlider::handle:horizontal {{ background: {p.text}; width: 10px; height: 18px; margin: -8px 0; border-radius: 1px; }}

QScrollArea {{ border: none; background: transparent; }}
QScrollBar:vertical {{ background: transparent; width: 9px; margin: 0; }}
QScrollBar::handle:vertical {{ background: {p.line_strong}; min-height: 28px; border-radius: 1px; }}
QScrollBar::handle:vertical:hover {{ background: {p.muted}; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar:horizontal {{ height: 9px; background: transparent; }}
QScrollBar::handle:horizontal {{ background: {p.line_strong}; border-radius: 1px; min-width: 28px; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}

QMenuBar {{ background: {p.bg}; color: {p.muted}; padding: 2px 6px; }}
QMenuBar::item {{ padding: 4px 9px; background: transparent; }}
QMenuBar::item:selected {{ background: {p.raised}; color: {p.text}; }}
QMenu {{ background: {p.raised}; color: {p.text}; border: 1px solid {p.line_strong}; padding: 4px; }}
QMenu::item {{ padding: 6px 22px 6px 14px; }}
QMenu::item:selected {{ background: {p.selection}; }}
QMenu::item:disabled {{ color: {p.faint}; }}
QMenu::separator {{ height: 1px; background: {p.line}; margin: 4px 8px; }}
QToolTip {{ background: {p.raised}; color: {p.text}; border: 1px solid {p.line_strong}; padding: 4px 6px; }}
QProgressBar {{ background: {p.inset}; border: 1px solid {p.line}; height: 6px; text-align: center; }}
QProgressBar::chunk {{ background: {p.accent}; }}
QMessageBox, QProgressDialog {{ background: {p.bg}; }}
"""
