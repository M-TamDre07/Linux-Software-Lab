"""Shared rendering helpers so the overlay and the settings preview always match."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont, QTextOption

_ALIGNMENTS = {
    "left": Qt.AlignmentFlag.AlignLeft,
    "center": Qt.AlignmentFlag.AlignHCenter,
    "right": Qt.AlignmentFlag.AlignRight,
    "justify": Qt.AlignmentFlag.AlignJustify,
}


def panel_stylesheet(background: str, opacity_percent: int, *, rounded: bool) -> str:
    color = QColor(background)
    alpha = max(0, min(100, opacity_percent)) * 255 // 100
    radius = 14 if rounded else 0
    border = "1px solid rgba(180, 202, 238, 95)" if rounded else "none"
    return (
        "QFrame#panel {"
        f"background-color: rgba({color.red()}, {color.green()}, {color.blue()}, {alpha});"
        f"border: {border}; border-radius: {radius}px; }}"
    )


def text_stylesheet(text_color: str) -> str:
    return (
        "QTextEdit { background: transparent; border: none;"
        f"color: {text_color}; selection-background-color: rgba(71,124,250,120); }}"
    )


def make_font(family: str, size: int) -> QFont:
    font = QFont(family or "Noto Sans")
    font.setPointSize(max(6, size))
    font.setWeight(QFont.Weight.DemiBold)
    return font


def text_option(alignment: str) -> QTextOption:
    option = QTextOption()
    option.setAlignment(_ALIGNMENTS.get(alignment, Qt.AlignmentFlag.AlignLeft))
    option.setWrapMode(QTextOption.WrapMode.WordWrap)
    return option
