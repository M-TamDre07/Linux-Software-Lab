from sorot.app import main

raise SystemExit(main())
