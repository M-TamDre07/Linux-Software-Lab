"""Last-resort diagnostics: log uncaught exceptions (redacted) and dump native crashes."""
from __future__ import annotations

import faulthandler
import logging
import sys
import threading
from pathlib import Path
from types import TracebackType
from typing import IO

from sorot.core import paths

LOGGER = logging.getLogger("sorot.crash")
_fault_file: IO[str] | None = None


def _log_exception(kind: str, exc_type: type[BaseException], exc: BaseException, tb: TracebackType | None) -> None:
    # The logging filter redacts secrets from the message; the traceback text is not logged verbatim.
    LOGGER.error("%s tak tertangani: %s: %s", kind, exc_type.__name__, exc)
    frames: list[str] = []
    while tb is not None and len(frames) < 12:
        frames.append(f"{Path(tb.tb_frame.f_code.co_filename).name}:{tb.tb_lineno} {tb.tb_frame.f_code.co_name}")
        tb = tb.tb_next
    LOGGER.error("lokasi: %s", " <- ".join(reversed(frames)))


def install_crash_handlers(fault_log: Path | None = None) -> None:
    global _fault_file
    previous = sys.excepthook

    def hook(exc_type: type[BaseException], exc: BaseException, tb: TracebackType | None) -> None:
        _log_exception("Pengecualian", exc_type, exc, tb)
        previous(exc_type, exc, tb)

    sys.excepthook = hook

    def thread_hook(args: threading.ExceptHookArgs) -> None:
        if args.exc_value is not None:
            _log_exception("Pengecualian thread", args.exc_type, args.exc_value, args.exc_traceback)

    threading.excepthook = thread_hook
    target = fault_log or paths.state_dir() / "crash.log"
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        _fault_file = target.open("a", encoding="utf-8")
        faulthandler.enable(_fault_file)
    except OSError:
        pass
