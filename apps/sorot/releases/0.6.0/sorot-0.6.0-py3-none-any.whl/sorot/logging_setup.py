"""Application logging with automatic redaction of secrets.

Script text and API keys are never passed to the logger by the application;
the redaction filter is a second line of defence for exception messages that
come from third-party code.
"""
from __future__ import annotations

import logging
import os
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

from sorot.core import paths
from sorot.core.redact import redact

ROOT_NAME = "sorot"


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            message = record.getMessage()
        except Exception:  # malformed format string; keep the raw text
            message = str(record.msg)
        record.msg = redact(message)
        record.args = ()
        if record.exc_info and record.exc_info[1] is not None:
            # Keep the exception type visible but drop its message, which may
            # contain URLs with credentials or response bodies.
            record.exc_text = f"{record.exc_info[0].__name__}: {redact(str(record.exc_info[1]))}"
            record.exc_info = None
        return True


def setup_logging(*, level: int = logging.INFO, path: Path | None = None, console: bool = False) -> Path | None:
    """Configure the ``sorot`` logger. Returns the log file path, if any."""
    logger = logging.getLogger(ROOT_NAME)
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    logger.setLevel(level)
    logger.propagate = False
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    redactor = RedactingFilter()
    log_path: Path | None = Path(path) if path is not None else paths.log_file()
    try:
        assert log_path is not None
        log_path.parent.mkdir(parents=True, exist_ok=True)
        file_handler = RotatingFileHandler(log_path, maxBytes=512_000, backupCount=3, encoding="utf-8")
        try:
            os.chmod(log_path, 0o600)
        except OSError:
            pass
        file_handler.setFormatter(formatter)
        file_handler.addFilter(redactor)
        logger.addHandler(file_handler)
    except OSError:
        log_path = None
    if console or log_path is None:
        stream = logging.StreamHandler(sys.stderr)
        stream.setFormatter(formatter)
        stream.addFilter(redactor)
        logger.addHandler(stream)
    return log_path
