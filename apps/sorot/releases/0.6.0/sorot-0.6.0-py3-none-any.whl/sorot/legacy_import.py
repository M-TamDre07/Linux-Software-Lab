"""One-time, non-destructive imports of earlier installs.

* 0.4.x (named "Tama Prompter"): ``~/.config/tama-prompter`` and ``~/.local/share/tama-prompter``
* 0.3.x: a single QSettings file under ``~/.config/TamaAndrea``

Old files are only ever read or copied, never modified or deleted.
"""
from __future__ import annotations

import logging
import shutil

from sorot.core import paths
from sorot.core.config import AppConfig, ConfigStore, migrate_legacy_values
from sorot.core.scripts import DraftStore, ScriptLibrary

LOGGER = logging.getLogger(__name__)


def read_legacy_values() -> dict | None:
    """Read the old QSettings file read-only. Returns ``None`` when absent."""
    path = paths.legacy_qsettings_file()
    if not path.is_file():
        return None
    from PySide6.QtCore import QSettings

    settings = QSettings(str(path), QSettings.Format.IniFormat)
    return {key: settings.value(key) for key in settings.allKeys()}


def import_legacy(store: ConfigStore, draft: DraftStore) -> tuple[AppConfig, str] | None:
    """Import old values once. The legacy file is never modified or deleted."""
    try:
        values = read_legacy_values()
    except Exception as exc:  # noqa: BLE001 - never let a bad old file block startup
        LOGGER.warning("Pengaturan lama tidak dapat dibaca: %s", type(exc).__name__)
        return None
    if values is None:
        return None
    config, text = migrate_legacy_values(values)
    store.save(config)
    if text.strip() and not draft.path.exists():
        draft.save(text)
    LOGGER.info("Pengaturan versi 0.3.x diimpor; berkas lama dibiarkan apa adanya.")
    return config, text


def import_previous_install(store: ConfigStore, draft: DraftStore, library: ScriptLibrary) -> bool:
    """Copy settings, draft, history, and the script library from a 0.4.x install.

    Returns ``True`` if anything was imported. Existing new-install files are never overwritten.
    """
    old_config = paths.previous_config_file()
    old_data = paths.previous_data_dir()
    if not old_config.is_file() and not old_data.is_dir():
        return False
    imported = False
    try:
        if old_config.is_file() and not store.path.exists():
            store.path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(old_config, store.path)
            store.path.chmod(0o600)
            # Run it through the validator so the file on disk is in the current schema.
            store.save(store.load().config)
            imported = True
        old_draft = old_data / "draft.txt"
        if old_draft.is_file() and not draft.path.exists():
            draft.path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(old_draft, draft.path)
            draft.path.chmod(0o600)
            imported = True
        for source_dir, target_dir in ((old_data / "scripts", library.directory), (old_data / "draft-history", draft.snapshot_dir)):
            if source_dir.is_dir():
                target_dir.mkdir(parents=True, exist_ok=True)
                for item in source_dir.glob("*.txt"):
                    target = target_dir / item.name
                    if not target.exists():
                        shutil.copy2(item, target)
                        target.chmod(0o600)
                        imported = True
    except OSError as exc:
        LOGGER.warning("Impor dari instalasi sebelumnya sebagian gagal: %s", exc.strerror or exc)
    if imported:
        LOGGER.info("Data dari instalasi 0.4.x diimpor; berkas lama dibiarkan apa adanya.")
    return imported
