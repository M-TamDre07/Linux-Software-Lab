"""One running copy per user: two windows would overwrite each other's draft and settings."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QLockFile

from sorot.core import paths


class InstanceLock:
    def __init__(self, path: Path | None = None) -> None:
        self.path = Path(path) if path is not None else paths.state_dir() / "sorot.lock"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = QLockFile(str(self.path))
        self._lock.setStaleLockTime(30_000)  # a lock left by a dead process is taken over

    def acquire(self) -> bool:
        return bool(self._lock.tryLock(0))

    def owner_pid(self) -> int | None:
        info = self._lock.getLockInfo()  # PySide6 returns (pid, host, app) or (ok, pid, host, app) depending on version
        values = tuple(info)
        if len(values) == 4:
            ok, *values = values  # type: ignore[assignment]
            if not ok:
                return None
        try:
            return int(str(values[0]))
        except (TypeError, ValueError, IndexError):
            return None

    def release(self) -> None:
        self._lock.unlock()
