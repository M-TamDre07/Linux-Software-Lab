"""Conservative wrapper around python-keyring.

The application never falls back to plain-text key storage. Known
insecure/fail backends are not offered as a persistence option.
"""
from __future__ import annotations

import logging
from typing import Any

LOGGER = logging.getLogger(__name__)

SERVICE_NAME = "sorot"
LEGACY_SERVICE_NAME = "tama-prompter"  # 0.4.x; read-only fallback
API_KEY_USERNAME = "api-key"
_INSECURE_MARKERS = ("fail", "plaintext", "nullkeyring", "keyrings.alt.file", "plainkeyring")


def _secure_backend() -> tuple[Any, Any] | None:
    try:
        import keyring

        backend = keyring.get_keyring()
        identity = f"{type(backend).__module__}.{type(backend).__name__}".lower()
        if any(marker in identity for marker in _INSECURE_MARKERS):
            return None
        priority = getattr(backend, "priority", None)
        if priority is not None and float(priority) <= 0:
            return None
        return keyring, backend
    except Exception as exc:  # keyring missing or backend broken
        LOGGER.info("Keyring tidak tersedia: %s", type(exc).__name__)
        return None


def is_available() -> bool:
    """Whether a non-obviously-insecure desktop keyring backend is available."""
    return _secure_backend() is not None


def backend_name() -> str:
    pair = _secure_backend()
    if pair is None:
        return "tidak tersedia"
    return f"{type(pair[1]).__module__}.{type(pair[1]).__name__}"


def get_api_key() -> str:
    pair = _secure_backend()
    if pair is None:
        return ""
    keyring, _backend = pair
    try:
        return keyring.get_password(SERVICE_NAME, API_KEY_USERNAME) or keyring.get_password(LEGACY_SERVICE_NAME, API_KEY_USERNAME) or ""
    except Exception as exc:
        LOGGER.warning("Gagal membaca API key dari keyring: %s", type(exc).__name__)
        return ""


def has_saved_key() -> bool:
    return bool(get_api_key())


def save_api_key(value: str) -> None:
    pair = _secure_backend()
    if pair is None:
        raise RuntimeError("Backend keyring desktop yang aman tidak tersedia.")
    keyring, _backend = pair
    keyring.set_password(SERVICE_NAME, API_KEY_USERNAME, value)


def delete_api_key() -> bool:
    """Delete the stored key. Returns True if a key was removed."""
    pair = _secure_backend()
    if pair is None:
        return False
    keyring, _backend = pair
    removed = False
    for service in (SERVICE_NAME, LEGACY_SERVICE_NAME):
        try:
            keyring.delete_password(service, API_KEY_USERNAME)
            removed = True
        except Exception as exc:  # normal when no key exists under that name
            LOGGER.info("Tidak ada API key yang dihapus (%s): %s", service, type(exc).__name__)
    return removed
