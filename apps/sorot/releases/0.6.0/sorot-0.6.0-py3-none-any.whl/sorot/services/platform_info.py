"""Desktop-session detection, Qt backend selection, and overlay capability report.

This module never installs or modifies anything on the system. The capability
table describes what each Qt backend is *documented or generally known* to
allow; it is guidance, not proof that a feature works on a given compositor.
"""
from __future__ import annotations

import os
import platform
import shutil
from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path


class Support(StrEnum):
    SUPPORTED = "umumnya didukung"
    LIMITED = "terbatas"
    UNSUPPORTED = "tidak tersedia"
    UNKNOWN = "tidak diketahui"


@dataclass(frozen=True)
class CapabilityItem:
    key: str
    label: str
    support: Support
    note: str


# --------------------------------------------------------------------------
# Session and plugin detection
# --------------------------------------------------------------------------
def classify_session(env: Mapping[str, str] | None = None) -> str:
    """Detect session type from environment variables without importing Qt."""
    values = os.environ if env is None else env
    explicit = values.get("XDG_SESSION_TYPE", "").strip().lower()
    if explicit in {"wayland", "x11", "tty"}:
        return explicit
    if values.get("WAYLAND_DISPLAY"):
        return "wayland"
    if values.get("DISPLAY"):
        return "x11"
    return "tidak diketahui"


def _plugin_loadable(path: Path) -> bool:
    """Whether the plugin library and the system libraries it needs can be loaded.

    A plugin file can exist while a dependency (e.g. ``libxcb-cursor0``) is
    missing; Qt then aborts at startup. Loading it first lets us pick another
    backend instead.
    """
    try:
        from PySide6.QtCore import QLibrary

        library = QLibrary(str(path))
        ok = library.load()
        if ok:
            library.unload()
        return bool(ok)
    except Exception:
        return True  # cannot probe: do not block the choice


def available_qt_platforms(plugin_dir: Path | None = None) -> set[str] | None:
    """Names of *loadable* Qt platform plugins, or ``None`` if undeterminable."""
    try:
        if plugin_dir is None:
            from PySide6.QtCore import QLibraryInfo

            plugin_dir = Path(QLibraryInfo.path(QLibraryInfo.LibraryPath.PluginsPath)) / "platforms"
    except Exception:  # PySide6 missing or broken
        return None
    if not plugin_dir.is_dir():
        return None
    names: set[str] = set()
    for item in plugin_dir.glob("libq*.so*"):
        stem = item.name[len("libq"):].split(".so")[0]
        name = "wayland" if stem.startswith("wayland") else stem
        if name in names:
            continue
        # Only the two backends we may choose between are probed; others are listed as found.
        if name in {"xcb", "wayland"} and not _plugin_loadable(item):
            continue
        names.add(name)
    return names


@dataclass(frozen=True)
class BackendChoice:
    platform: str | None  # value for QT_QPA_PLATFORM, or None to leave Qt's default
    description: str


def select_qt_platform(
    env: Mapping[str, str] | None = None,
    *,
    preference: str = "auto",
    available: set[str] | None = None,
) -> BackendChoice:
    """Decide which Qt platform plugin to request.

    Precedence: ``SOROT_QT_PLATFORM`` > configured preference > automatic policy.
    An explicit ``QT_QPA_PLATFORM`` from the user's environment is respected
    when the preference is ``auto``.
    """
    values = os.environ if env is None else env
    forced = values.get("SOROT_QT_PLATFORM", "").strip().lower()
    choice = forced if forced in {"auto", "xcb", "wayland"} else preference if preference in {"auto", "xcb", "wayland"} else "auto"
    source = "variabel SOROT_QT_PLATFORM" if forced in {"xcb", "wayland"} else "pengaturan"
    session = classify_session(values)

    def has(name: str) -> bool:
        return available is None or name in available

    if choice in {"xcb", "wayland"}:
        if has(choice):
            return BackendChoice(choice, f"{choice} (dipilih lewat {source})")
        fallback = BackendChoice(None, f"plugin Qt “{choice}” tidak ditemukan; Qt memilih backend sendiri")
        return fallback
    if values.get("QT_QPA_PLATFORM"):
        return BackendChoice(None, f"{values['QT_QPA_PLATFORM']} (dari lingkungan pengguna)")
    if session == "wayland":
        if values.get("DISPLAY") and has("xcb"):
            return BackendChoice("xcb", "xcb melalui XWayland (otomatis; posisi overlay lebih terkontrol)")
        if values.get("WAYLAND_DISPLAY") and has("wayland"):
            return BackendChoice("wayland", "wayland asli (otomatis; XWayland tidak tersedia)")
    return BackendChoice(None, "otomatis oleh Qt")


# --------------------------------------------------------------------------
# Capability table
# --------------------------------------------------------------------------
def _backend_family(backend: str) -> str:
    name = (backend or "").lower()
    if name.startswith("wayland"):
        return "wayland"
    if name in {"xcb", "offscreen", "minimal", "eglfs", "linuxfb", "vnc"}:
        return name
    return "other"


def detect_capabilities(backend: str, session: str = "", desktop: str = "") -> list[CapabilityItem]:
    """What the overlay can reasonably expect from ``backend``.

    Every entry is an expectation derived from Qt's documentation and general
    desktop behaviour. None of it replaces testing on the real session.
    """
    family = _backend_family(backend)
    s = Support
    if family == "xcb":
        return [
            CapabilityItem("transparency", "Transparansi latar", s.SUPPORTED, "Butuh compositing aktif; hampir semua desktop modern menyalakannya."),
            CapabilityItem("position", "Posisi jendela diatur aplikasi", s.SUPPORTED, "X11/XWayland mengizinkan posisi absolut."),
            CapabilityItem("always_on_top", "Selalu di atas", s.SUPPORTED, "Bergantung pada window manager; layar penuh eksklusif dapat menutupi overlay."),
            CapabilityItem("click_through", "Klik-tembus", s.SUPPORTED, "Memakai input shape X11."),
            CapabilityItem("drag_resize", "Geser dan ubah ukuran", s.SUPPORTED, "Memakai fitur geser/ubah ukuran sistem jika ada, atau cadangan manual."),
            CapabilityItem("multi_monitor", "Pilih monitor", s.SUPPORTED, "Posisi ditentukan relatif terhadap monitor terpilih."),
        ]
    if family == "wayland":
        return [
            CapabilityItem("transparency", "Transparansi latar", s.SUPPORTED, "Umumnya tersedia."),
            CapabilityItem("position", "Posisi jendela diatur aplikasi", s.UNSUPPORTED, "Protokol Wayland melarang aplikasi menentukan posisi absolut; compositor yang memutuskan. Preset posisi dan monitor mungkin diabaikan."),
            CapabilityItem("always_on_top", "Selalu di atas", s.LIMITED, "Tidak ada mekanisme standar; sebagian compositor (mis. GNOME) mengabaikan permintaan ini. Coba mode xcb jika perlu."),
            CapabilityItem("click_through", "Klik-tembus", s.UNKNOWN, "Umumnya memakai input region kosong, tetapi perilaku antar-compositor belum diverifikasi."),
            CapabilityItem("drag_resize", "Geser dan ubah ukuran", s.SUPPORTED, "Memakai permintaan geser/ubah ukuran dari compositor (Ctrl + seret, pegangan sudut)."),
            CapabilityItem("multi_monitor", "Pilih monitor", s.LIMITED, "Compositor yang menentukan di monitor mana jendela muncul."),
        ]
    note = "Backend ini bukan target utama aplikasi; perilaku overlay tidak diketahui."
    return [
        CapabilityItem(key, label, s.UNKNOWN, note)
        for key, label in (
            ("transparency", "Transparansi latar"), ("position", "Posisi jendela diatur aplikasi"),
            ("always_on_top", "Selalu di atas"), ("click_through", "Klik-tembus"),
            ("drag_resize", "Geser dan ubah ukuran"), ("multi_monitor", "Pilih monitor"),
        )
    ]


def capability(items: list[CapabilityItem], key: str) -> CapabilityItem:
    return next(item for item in items if item.key == key)


# --------------------------------------------------------------------------
# Diagnostics report
# --------------------------------------------------------------------------
def _read_os_release() -> dict[str, str]:
    values: dict[str, str] = {}
    try:
        with open("/etc/os-release", encoding="utf-8") as handle:
            for line in handle:
                if "=" in line:
                    key, value = line.rstrip().split("=", 1)
                    values[key] = value.strip().strip('"')
    except OSError:
        pass
    return values


@dataclass(frozen=True)
class PlatformInfo:
    os_name: str
    os_id: str
    os_version: str
    python_version: str
    qt_version: str
    kernel: str
    architecture: str
    desktop: str
    session_type: str
    display: str
    wayland_display: str
    qt_plugins: str
    rclone: str
    keyring: str
    backend: str


def collect_platform_info(qt_platform: str = "belum dimulai", env: Mapping[str, str] | None = None) -> PlatformInfo:
    values = os.environ if env is None else env
    release = _read_os_release()
    try:
        import PySide6

        qt_version = getattr(PySide6, "__version__", "terpasang")
    except Exception:
        qt_version = "tidak terdeteksi di interpreter ini"
    plugins = available_qt_platforms()
    try:
        from sorot.services import keyring_service

        keyring_text = keyring_service.backend_name() if keyring_service.is_available() else "tidak tersedia (API key tidak akan disimpan permanen)"
    except Exception:
        keyring_text = "tidak tersedia"
    rclone = shutil.which("rclone")
    return PlatformInfo(
        os_name=release.get("PRETTY_NAME", platform.platform()),
        os_id=release.get("ID", "tidak diketahui"),
        os_version=release.get("VERSION_ID", "tidak diketahui"),
        python_version=platform.python_version(),
        qt_version=qt_version,
        kernel=platform.release(),
        architecture=platform.machine(),
        desktop=values.get("XDG_CURRENT_DESKTOP") or values.get("DESKTOP_SESSION", "tidak diketahui"),
        session_type=classify_session(values),
        display=values.get("DISPLAY", "") or "tidak tersedia",
        wayland_display=values.get("WAYLAND_DISPLAY", "") or "tidak tersedia",
        qt_plugins=", ".join(sorted(plugins)) if plugins is not None else "tidak dapat ditentukan",
        rclone=rclone if rclone else "belum terpasang",
        keyring=keyring_text,
        backend=qt_platform,
    )


def format_platform_report(qt_platform: str = "belum dimulai", env: Mapping[str, str] | None = None) -> str:
    from sorot import VERSION_LABEL

    info = collect_platform_info(qt_platform, env)
    lines = [
        f"Sorot {VERSION_LABEL} — Diagnostik Sistem",
        "",
        f"Sistem operasi  : {info.os_name}",
        f"ID / versi      : {info.os_id} / {info.os_version}",
        f"Python          : {info.python_version}",
        f"PySide6         : {info.qt_version}",
        f"Kernel          : {info.kernel}",
        f"Arsitektur      : {info.architecture}",
        f"Desktop         : {info.desktop}",
        f"Sesi grafis     : {info.session_type}",
        f"Backend Qt      : {info.backend}",
        f"Plugin Qt       : {info.qt_plugins}",
        f"DISPLAY         : {info.display}",
        f"WAYLAND_DISPLAY : {info.wayland_display}",
        f"rclone          : {info.rclone}",
        f"Keyring         : {info.keyring}",
        "",
        "Kemampuan overlay yang diharapkan pada backend ini (panduan, BUKAN hasil uji pada perangkatmu):",
    ]
    for item in detect_capabilities(info.backend, info.session_type, info.desktop):
        lines.append(f"  - {item.label}: {item.support.value}. {item.note}")
    lines += [
        "",
        "Catatan: Sorot memakai driver input, layar, dan grafik yang dikelola sistem operasi. "
        "Aplikasi ini tidak memasang, menghapus, atau mengubah driver maupun ekstensi desktop.",
    ]
    return "\n".join(lines)
