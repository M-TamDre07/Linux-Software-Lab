"""Optional Google Drive bridge through a user-configured rclone remote.

Safety properties
-----------------
* ``rclone`` is always started with an argument list, never through a shell.
* Remote names and paths are validated; paths cannot escape the remote.
* Every call has a timeout and can be cancelled; output is size-bounded.
* Nothing is deleted. Writing a file replaces an existing file with the same
  path, which is why the UI asks for explicit confirmation first.
"""
from __future__ import annotations

import logging
import re
import shutil
import subprocess
import time
from dataclasses import dataclass

from sorot.core.cancel import CancelToken, OperationCancelled

LOGGER = logging.getLogger(__name__)

MAX_TEXT_BYTES = 5_000_000
_POLL_SECONDS = 0.2
# Bound rclone's own waiting so one stuck connection cannot hang a request.
_RCLONE_LIMITS = ["--contimeout", "15s", "--timeout", "30s", "--retries", "1", "--low-level-retries", "2"]
_REMOTE_PATTERN = re.compile(r"[A-Za-z0-9_][A-Za-z0-9_. -]*:")


class DriveIntegrationError(RuntimeError):
    """A Drive/rclone problem whose message is safe to show to the user."""


@dataclass(frozen=True)
class RemoteInfo:
    name: str  # includes the trailing colon, e.g. "gdrive:"
    kind: str  # rclone backend type, e.g. "drive"; may be empty

    @property
    def is_google_drive(self) -> bool:
        return self.kind == "drive"

    @property
    def label(self) -> str:
        return f"{self.name}  ({self.kind})" if self.kind else self.name


def rclone_path() -> str | None:
    return shutil.which("rclone")


def rclone_available() -> bool:
    return rclone_path() is not None


def _require_rclone() -> str:
    path = rclone_path()
    if path is None:
        raise DriveIntegrationError(
            "rclone belum terpasang. Integrasi Drive bersifat opsional dan memakai rclone; aplikasi tetap dapat dipakai tanpa fitur ini."
        )
    return path


def _run(args: list[str], *, timeout: float, cancel: CancelToken | None, binary: bool = False) -> bytes:
    """Run rclone without a shell; honour the timeout and cancellation."""
    executable = _require_rclone()
    command = [executable, *args]
    LOGGER.info("Menjalankan rclone: subperintah=%s", args[0] if args else "")
    try:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL)
    except OSError as exc:
        raise DriveIntegrationError(f"rclone tidak dapat dijalankan: {exc.strerror or exc}") from exc
    deadline = time.monotonic() + timeout
    out = err = b""
    while True:
        if cancel is not None and cancel.cancelled:
            _terminate(process)
            raise OperationCancelled()
        if time.monotonic() > deadline:
            _terminate(process)
            raise DriveIntegrationError("Operasi Drive melewati batas waktu. Periksa koneksi internet dan konfigurasi rclone.")
        try:
            out, err = process.communicate(timeout=_POLL_SECONDS)
            break
        except subprocess.TimeoutExpired:
            continue
    if process.returncode != 0:
        message = err.decode("utf-8", errors="replace").strip().splitlines()
        detail = message[-1] if message else f"kode keluar {process.returncode}"
        raise DriveIntegrationError(f"rclone gagal: {detail}")
    return out


def _terminate(process: subprocess.Popen) -> None:
    try:
        process.kill()
    except OSError:
        pass
    try:
        process.communicate(timeout=5)
    except Exception:  # noqa: BLE001 - best-effort cleanup
        pass


def validate_remote(remote: str) -> str:
    if not _REMOTE_PATTERN.fullmatch(remote or ""):
        raise DriveIntegrationError("Nama remote tidak valid. Pilih remote dari hasil `rclone listremotes`.")
    return remote


def clean_relative_path(relative_path: str, *, allow_empty: bool = False) -> str:
    cleaned = (relative_path or "").strip().lstrip("/")
    if not cleaned:
        if allow_empty:
            return ""
        raise DriveIntegrationError("Jalur berkas tidak valid.")
    if "\x00" in cleaned or cleaned.startswith("~") or "\\" in cleaned:
        raise DriveIntegrationError("Jalur berkas tidak valid.")
    parts = cleaned.rstrip("/").split("/")
    if any(part in {".", ".."} for part in parts):
        raise DriveIntegrationError("Jalur berkas tidak boleh keluar dari direktori remote.")
    if any(not part.strip() for part in parts):
        raise DriveIntegrationError("Jalur berkas tidak boleh memiliki segmen kosong.")
    return cleaned


def remote_target(remote: str, relative_path: str) -> str:
    # The result always begins with a validated "name:" so it can never be read as an option.
    return validate_remote(remote) + clean_relative_path(relative_path)


def parse_remotes(output: str) -> list[RemoteInfo]:
    remotes: list[RemoteInfo] = []
    for line in output.splitlines():
        line = line.strip()
        if not line:
            continue
        name, _, kind = line.partition(" ")
        if name.endswith(":") and _REMOTE_PATTERN.fullmatch(name):
            remotes.append(RemoteInfo(name, kind.strip()))
    return remotes


def list_remotes(cancel: CancelToken | None = None) -> list[RemoteInfo]:
    out = _run(["listremotes", "--long"], timeout=15, cancel=cancel)
    return parse_remotes(out.decode("utf-8", errors="replace"))


def rclone_version(cancel: CancelToken | None = None) -> str:
    out = _run(["version"], timeout=10, cancel=cancel).decode("utf-8", errors="replace")
    return out.splitlines()[0].strip() if out.strip() else "versi tidak diketahui"


def list_text_files(
    remote: str, folder: str = "", *, max_depth: int = 5, limit: int = 1000, cancel: CancelToken | None = None
) -> list[str]:
    """List ``.txt`` files below ``remote``/``folder`` (relative to ``folder``)."""
    base = validate_remote(remote) + clean_relative_path(folder, allow_empty=True)
    depth = max(1, min(int(max_depth), 20))
    out = _run(
        ["lsf", base, "--recursive", "--files-only", "--include", "*.txt", "--ignore-case",
         "--max-depth", str(depth), *_RCLONE_LIMITS],
        timeout=60,
        cancel=cancel,
    )
    files = [line.strip() for line in out.decode("utf-8", errors="replace").splitlines() if line.strip()]
    return files[:limit]


def read_text_file(remote: str, relative_path: str, cancel: CancelToken | None = None) -> str:
    target = remote_target(remote, relative_path)
    # --count bounds how much rclone will print, so a huge file is never fully downloaded.
    out = _run(["cat", target, "--count", str(MAX_TEXT_BYTES + 1), *_RCLONE_LIMITS], timeout=60, cancel=cancel)
    if len(out) > MAX_TEXT_BYTES:
        raise DriveIntegrationError("Berkas terlalu besar (maksimal 5 MB untuk naskah teks).")
    try:
        return out.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise DriveIntegrationError("Berkas bukan teks UTF-8 yang valid.") from exc


def write_text_file(remote: str, relative_path: str, text: str, cancel: CancelToken | None = None) -> None:
    """Upload ``text``. The caller must have asked the user to confirm overwriting."""
    import tempfile
    from pathlib import Path

    target = remote_target(remote, relative_path)
    with tempfile.TemporaryDirectory(prefix="sorot-") as temporary:
        local_path = Path(temporary) / "naskah.txt"
        local_path.write_text(text, encoding="utf-8")
        _run(["copyto", str(local_path), target, *_RCLONE_LIMITS], timeout=90, cancel=cancel)
