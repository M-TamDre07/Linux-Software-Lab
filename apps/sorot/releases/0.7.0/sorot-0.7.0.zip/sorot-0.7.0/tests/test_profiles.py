"""Display profiles: validation, partial apply, files, user store, extension contributions, CLI."""
from __future__ import annotations

import json

import pytest

from sorot.app import main
from sorot.core import paths, profiles
from sorot.core.config import MIGRATIONS, SCHEMA_VERSION, AppConfig, upgrade_schema
from sorot.core.profiles import ProfileError, make_profile
from sorot.extensions.manifest import parse_manifest


# ------------------------------------------------------------------ new config keys
def test_new_appearance_keys_have_defaults_that_keep_the_old_look():
    c = AppConfig()
    assert (c.font_weight, c.line_spacing, c.letter_spacing, c.mirror, c.show_countdown, c.profile) == ("demibold", 100, 0, False, True, "")


@pytest.mark.parametrize(("key", "bad", "expected"), [
    ("line_spacing", 5, 100), ("line_spacing", 9999, 250), ("line_spacing", "x", 100),
    ("letter_spacing", -3, 0), ("letter_spacing", 500, 30),
    ("font_weight", "heavy", "demibold"), ("font_weight", 7, "demibold"),
    ("mirror", "mungkin", False), ("mirror", 1, False),
])
def test_new_keys_are_clamped_or_defaulted(key, bad, expected):
    assert getattr(AppConfig.from_dict({key: bad}), key) == expected


def test_config_from_older_schema_gets_defaults_and_round_trips():
    c = AppConfig.from_dict(upgrade_schema({"schema_version": 3, "font_size": 50}))
    assert c.font_size == 50 and c.line_spacing == 100 and not c.mirror
    again = AppConfig.from_dict(c.to_dict())
    assert again.to_dict() == c.to_dict() and c.to_dict()["schema_version"] == SCHEMA_VERSION == 4
    assert 3 in MIGRATIONS


# ------------------------------------------------------------------ profile object
def test_make_profile_validates_through_the_config_rules():
    p = make_profile("  Uji   satu ", {"font_size": 9999, "text_color": "bukan-warna", "mirror": True, "rahasia": "x", "window_width": 5}, "  catatan\n panjang ")
    assert p.name == "Uji satu" and p.description == "catatan panjang"
    assert p.values["font_size"] == 120 and p.values["mirror"] is True
    assert p.values["text_color"] == AppConfig().text_color, "invalid color falls back to the default"
    assert set(p.values) == {"font_size", "text_color", "mirror"}
    assert p.ignored == ("rahasia", "window_width"), "only appearance keys are ever carried"


@pytest.mark.parametrize(("name", "values"), [
    ("", {"font_size": 30}), ("x" * 61, {"font_size": 30}), ("a\x00b", {"font_size": 30}), (None, {"font_size": 30}),
    ("ok", {}), ("ok", []), ("ok", "teks"), ("ok", {"hanya_tak_dikenal": 1}),
])
def test_invalid_profiles_are_rejected(name, values):
    with pytest.raises(ProfileError):
        make_profile(name, values)


def test_apply_changes_only_listed_keys_and_reports_them():
    c = AppConfig()
    c.font_size, c.text_color = 44, "#123456"
    changed = profiles.apply_profile(make_profile("Warna", {"background_color": "#000000", "font_size": 44}), c)
    assert changed == ["background_color"], "font_size was already 44 -> not reported"
    assert c.text_color == "#123456", "keys the profile does not list stay untouched"
    assert c.profile == "Warna"


def test_apply_never_touches_unrelated_settings():
    c = AppConfig()
    c.overlay_width, c.wpm, c.always_on_top, c.click_through = 999, 111, False, True
    profiles.apply_profile(profiles.BUILTIN["Rig cermin"], c)
    assert (c.overlay_width, c.wpm, c.always_on_top, c.click_through) == (999, 111, False, True)
    assert c.mirror is True and c.start_delay == 3 and c.text_align == "center"


def test_from_config_captures_the_whole_look_and_round_trips_through_apply():
    c = AppConfig.from_dict({"font_size": 61, "line_spacing": 140, "mirror": True, "text_color": "#AABBCC", "margin": 33})
    p = profiles.from_config(c, "Saya")
    assert set(p.values) == set(profiles.PROFILE_KEYS)
    fresh = AppConfig()
    profiles.apply_profile(p, fresh)
    assert all(getattr(fresh, k) == getattr(c, k) for k in profiles.PROFILE_KEYS)


def test_builtin_profiles_are_valid_distinct_and_complete_enough():
    assert len(profiles.BUILTIN) >= 6
    for name, p in profiles.BUILTIN.items():
        assert p.name == name and p.description and not p.ignored and p.values
        assert make_profile(p.name, p.values).values == p.values, "built-ins are fixed points of validation"
    assert profiles.BUILTIN["Studio gelap"].values["font_size"] == AppConfig().font_size, "default profile matches the default config"
    assert sum(1 for p in profiles.BUILTIN.values() if p.values.get("mirror")) == 1


# ------------------------------------------------------------------ JSON files
def test_json_round_trip():
    p = profiles.BUILTIN["Kontras tinggi"]
    assert profiles.loads(profiles.dumps(p)) == p


@pytest.mark.parametrize("text", ["", "{", "[]", "123", '{"name": "x"}', '{"sorot_profile": 2, "name": "x", "values": {"font_size": 30}}',
                                  '{"sorot_profile": true, "name": "x", "values": {"font_size": 30}}', '{"sorot_profile": 1, "name": "x"}'])
def test_malformed_profile_files_are_rejected(text):
    with pytest.raises(ProfileError):
        profiles.loads(text)


def test_oversized_profile_is_rejected_before_parsing(tmp_path):
    big = tmp_path / "besar.json"
    big.write_text('{"sorot_profile": 1, "name": "x", "values": {"font_size": 30}, "x": "' + "a" * profiles.MAX_PROFILE_BYTES + '"}', encoding="utf-8")
    with pytest.raises(ProfileError, match="terlalu besar"):
        profiles.read_file(big)


def test_future_keys_in_a_profile_are_ignored_not_fatal():
    p = profiles.loads(json.dumps({"sorot_profile": 1, "name": "Baru", "values": {"font_size": 40, "efek_neon": True}}))
    assert p.values == {"font_size": 40} and p.ignored == ("efek_neon",)


# ------------------------------------------------------------------ user store
def test_user_profiles_save_list_delete():
    p = make_profile("Milik saya", {"font_size": 47, "text_align": "center"}, "uji")
    path = profiles.save_user_profile(p)
    assert path.parent == profiles.profiles_dir() and oct(path.stat().st_mode & 0o777) == "0o600"
    users, problems = profiles.load_user_profiles()
    assert users == {"Milik saya": p} and problems == []
    merged = profiles.all_profiles()
    assert merged["Milik saya"][0] == "pengguna" and merged["Studio gelap"][0] == "bawaan"
    assert profiles.delete_user_profile("Milik saya") is True and profiles.delete_user_profile("Milik saya") is False
    assert profiles.load_user_profiles() == ({}, [])


def test_saving_over_the_same_name_replaces_and_builtin_names_are_protected():
    profiles.save_user_profile(make_profile("A", {"font_size": 20}))
    profiles.save_user_profile(make_profile("A", {"font_size": 21}))
    users, _ = profiles.load_user_profiles()
    assert len(users) == 1 and users["A"].values["font_size"] == 21
    with pytest.raises(ProfileError, match="bawaan"):
        profiles.save_user_profile(make_profile("Studio gelap", {"font_size": 20}))


def test_names_that_slug_alike_do_not_collide():
    profiles.save_user_profile(make_profile("Tes A!", {"font_size": 20}))
    profiles.save_user_profile(make_profile("Tes A?", {"font_size": 22}))
    users, _ = profiles.load_user_profiles()
    assert set(users) == {"Tes A!", "Tes A?"}


def test_a_broken_file_is_reported_and_skipped_never_fatal():
    profiles.save_user_profile(make_profile("Baik", {"font_size": 20}))
    (profiles.profiles_dir() / "rusak.json").write_text("{bukan json", encoding="utf-8")
    (profiles.profiles_dir() / "bawaan.json").write_text(profiles.dumps(profiles.BUILTIN["Rig cermin"]), encoding="utf-8")
    users, problems = profiles.load_user_profiles()
    assert set(users) == {"Baik"} and len(problems) == 2


def test_symlinked_profile_files_are_not_followed(tmp_path):
    outside = tmp_path / "luar.json"
    outside.write_text(profiles.dumps(make_profile("Tautan", {"font_size": 20})), encoding="utf-8")
    profiles.profiles_dir().mkdir(parents=True)
    (profiles.profiles_dir() / "tautan.json").symlink_to(outside)
    assert profiles.load_user_profiles() == ({}, [])


def test_user_profiles_are_included_in_backups():
    from sorot.core import upgrade

    profiles.save_user_profile(make_profile("Ikut cadangan", {"font_size": 33}))
    names = [name for name, _ in upgrade.collect_files()]
    assert any(n.startswith("data/profiles/") for n in names)


# ------------------------------------------------------------------ extension contributions
def manifest_with(profiles_list):
    return parse_manifest(json.dumps({"id": "uji.profil", "name": "Uji", "version": "1.0.0", "api": 1, "contributes": {"display_profiles": profiles_list}}))


def test_extension_can_contribute_display_profiles():
    m = manifest_with([{"name": "Senja", "description": "hangat", "values": {"text_color": "#FFD9B8", "background_color": "#1A0F14", "mirror": False}}])
    assert [p.name for p in m.profiles] == ["Senja"] and m.problems == []
    assert m.profiles[0].values["text_color"] == "#FFD9B8"


def test_bad_extension_profiles_are_dropped_and_reported():
    m = manifest_with([
        {"name": "Baik", "values": {"font_size": 40, "efek": 1}},
        {"name": "Kosong", "values": {}},
        {"name": "Baik", "values": {"font_size": 41}},
        {"values": {"font_size": 40}},
        "bukan-objek",
    ])
    assert [p.name for p in m.profiles] == ["Baik"]
    text = " ".join(m.problems)
    assert "Kosong" in text and "ganda" in text and "efek" in text


def test_an_extension_with_only_profiles_is_valid():
    m = manifest_with([{"name": "Satu", "values": {"font_size": 40}}])
    assert not any("tidak menyumbangkan" in problem for problem in m.problems)


def test_extension_profiles_cannot_smuggle_non_appearance_settings():
    m = manifest_with([{"name": "Nakal", "values": {"font_size": 40, "ai_base_url": "https://jahat.example", "shortcuts": {"play": "x"}, "click_through": True}}])
    assert set(m.profiles[0].values) == {"font_size"}
    c = AppConfig()
    profiles.apply_profile(m.profiles[0], c)
    assert c.ai_base_url == AppConfig().ai_base_url and c.click_through is False


# ------------------------------------------------------------------ CLI
def test_cli_lists_profiles(capsys):
    assert main(["--profiles"]) == 0
    out = capsys.readouterr().out
    assert "Rig cermin  [bawaan]" in out and "0 profil milikmu" in out


def test_cli_export_then_import_round_trip(capsys, tmp_path):
    target = tmp_path / "rig.json"
    assert main(["--export-profile", "Rig cermin", str(target)]) == 0
    assert json.loads(target.read_text(encoding="utf-8"))["values"]["mirror"] is True
    # a profile exported from the built-in name cannot be re-imported under the same name
    assert main(["--import-profile", str(target)]) == 1
    assert "bawaan" in capsys.readouterr().err
    data = json.loads(target.read_text(encoding="utf-8"))
    data["name"] = "Rig kustom"
    renamed = tmp_path / "kustom.json"
    renamed.write_text(json.dumps(data), encoding="utf-8")
    assert main(["--import-profile", str(renamed)]) == 0
    assert "Rig kustom" in profiles.load_user_profiles()[0]


def test_cli_export_current_and_error_paths(capsys, tmp_path):
    target = tmp_path / "saya.json"
    assert main(["--export-profile", "sekarang", str(target)]) == 0
    assert profiles.read_file(target).values["font_size"] == AppConfig().font_size
    assert main(["--export-profile", "sekarang", str(target)]) == 1 and "tidak ditimpa" in capsys.readouterr().err
    assert main(["--export-profile", "Tidak ada", str(tmp_path / "x.json")]) == 1
    assert main(["--export-profile", "Rig cermin"]) == 2
    assert main(["--import-profile"]) == 2
    bad = tmp_path / "bad.json"
    bad.write_text("{}", encoding="utf-8")
    assert main(["--import-profile", str(bad)]) == 1


def test_help_lists_profile_commands(capsys):
    main(["--help"])
    out = capsys.readouterr().out
    assert "--profiles" in out and "--export-profile" in out and "--import-profile" in out


def test_profiles_live_under_the_data_dir():
    assert profiles.profiles_dir() == paths.data_dir() / "profiles"


def test_loads_enforces_the_size_limit_on_its_own():
    huge = '{"sorot_profile": 1, "name": "x", "values": {"font_size": 30}, "x": "' + "a" * profiles.MAX_PROFILE_BYTES + '"}'
    with pytest.raises(ProfileError, match="terlalu besar"):
        profiles.loads(huge)
