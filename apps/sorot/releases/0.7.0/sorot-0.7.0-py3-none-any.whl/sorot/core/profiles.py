"""Display profiles: a shareable bundle of everything that controls how the prompt *looks*.

A profile is a small JSON file::

    {"sorot_profile": 1, "name": "Studio gelap", "description": "...", "values": {"font_size": 44, ...}}

Design rules
------------
* A profile only holds appearance keys (``PROFILE_KEYS``). It never carries window position,
  API settings, shortcuts or anything else, so importing one cannot change unrelated behaviour.
* ``values`` may be partial: applying a profile changes only the keys it lists.
* Every value is validated and clamped by ``AppConfig.from_dict`` (the same code that reads
  ``config.json``), so there is one definition of what is valid.
* Unknown keys are ignored and reported, so a profile written by a newer version still loads.
* Qt-free: usable from the CLI, from extensions' manifests and from tests.
"""
from __future__ import annotations

import hashlib
import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from sorot.core import paths
from sorot.core.config import AppConfig
from sorot.core.fileio import atomic_write_text

LOGGER = logging.getLogger(__name__)

PROFILE_FORMAT = 1
MAX_PROFILE_BYTES = 64 * 1024
MAX_NAME = 60
MAX_DESCRIPTION = 200
MAX_USER_PROFILES = 200

#: The only keys a profile may carry, in the order they are written.
PROFILE_KEYS: tuple[str, ...] = (
    "font_family", "font_size", "font_weight", "line_spacing", "letter_spacing",
    "text_color", "background_color", "background_opacity", "text_align", "margin",
    "guide_enabled", "guide_position", "show_progress",
    "mirror", "start_delay", "show_countdown",
)


class ProfileError(Exception):
    """A user-facing problem with a profile file or name."""


@dataclass(frozen=True)
class DisplayProfile:
    name: str
    description: str = ""
    values: dict[str, Any] = field(default_factory=dict)
    ignored: tuple[str, ...] = ()  # keys that were dropped (unknown or not allowed)

    def to_dict(self) -> dict[str, Any]:
        return {"sorot_profile": PROFILE_FORMAT, "name": self.name, "description": self.description, "values": dict(self.values)}


def clean_name(name: object) -> str:
    text = " ".join(str(name or "").split())
    if not text or len(text) > MAX_NAME or any(ord(ch) < 32 for ch in text):
        raise ProfileError(f"Nama profil harus 1–{MAX_NAME} karakter tanpa karakter kontrol.")
    return text


def make_profile(name: object, values: object, description: object = "") -> DisplayProfile:
    """Validate ``values`` through ``AppConfig`` and keep only the keys that were actually given."""
    cleaned_name = clean_name(name)
    if not isinstance(values, dict) or not values:
        raise ProfileError("Profil harus memuat minimal satu nilai.")
    given = [key for key in values if key in PROFILE_KEYS]
    ignored = tuple(sorted(str(key) for key in values if key not in PROFILE_KEYS))
    if not given:
        raise ProfileError("Profil tidak memuat satu pun pengaturan tampilan yang dikenal.")
    checked = AppConfig.from_dict({key: values[key] for key in given})
    note = " ".join(str(description or "").split())[:MAX_DESCRIPTION]
    return DisplayProfile(cleaned_name, note, {key: getattr(checked, key) for key in PROFILE_KEYS if key in given}, ignored)


def from_config(config: AppConfig, name: object, description: object = "") -> DisplayProfile:
    """Capture the whole current look."""
    return make_profile(name, {key: getattr(config, key) for key in PROFILE_KEYS}, description)


def apply_profile(profile: DisplayProfile, config: AppConfig) -> list[str]:
    """Copy the profile's values onto ``config``. Returns the keys whose value actually changed."""
    merged = AppConfig.from_dict({**{key: getattr(config, key) for key in PROFILE_KEYS}, **profile.values})
    changed = []
    for key in profile.values:
        new = getattr(merged, key)
        if getattr(config, key) != new:
            setattr(config, key, new)
            changed.append(key)
    config.profile = profile.name
    return changed


# --------------------------------------------------------------------------- JSON
def dumps(profile: DisplayProfile) -> str:
    return json.dumps(profile.to_dict(), indent=2, ensure_ascii=False) + "\n"


def loads(text: str) -> DisplayProfile:
    if len(text.encode("utf-8", errors="replace")) > MAX_PROFILE_BYTES:
        raise ProfileError("Berkas profil terlalu besar.")
    try:
        data = json.loads(text)
    except ValueError as exc:
        raise ProfileError("Berkas bukan JSON yang valid.") from exc
    if not isinstance(data, dict) or "sorot_profile" not in data:
        raise ProfileError("Ini bukan berkas profil Sorot (kunci 'sorot_profile' tidak ada).")
    version = data.get("sorot_profile")
    if not isinstance(version, int) or isinstance(version, bool) or version != PROFILE_FORMAT:
        raise ProfileError(f"Format profil {version!r} tidak didukung versi ini.")
    return make_profile(data.get("name"), data.get("values"), data.get("description", ""))


def read_file(path: Path) -> DisplayProfile:
    path = Path(path)
    try:
        if path.stat().st_size > MAX_PROFILE_BYTES:
            raise ProfileError("Berkas profil terlalu besar.")
        return loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError) as exc:
        raise ProfileError(f"Berkas tidak dapat dibaca: {exc}") from exc


def write_file(profile: DisplayProfile, path: Path) -> None:
    atomic_write_text(Path(path), dumps(profile), mode=0o600)


# --------------------------------------------------------------------------- built in
def _builtin(name: str, description: str, **values: Any) -> DisplayProfile:
    return make_profile(name, values, description)


BUILTIN: dict[str, DisplayProfile] = {
    p.name: p
    for p in (
        _builtin("Studio gelap", "Putih di biru tua; bawaan Sorot.", font_size=30, font_weight="demibold", line_spacing=100,
                 letter_spacing=0, text_color="#F7F9FC", background_color="#0C121F", background_opacity=58, text_align="left",
                 margin=16, mirror=False),
        _builtin("Kertas terang", "Hitam di putih, nyaman di ruangan terang.", font_size=32, font_weight="demibold",
                 line_spacing=115, text_color="#111827", background_color="#FFFFFF", background_opacity=88, text_align="left",
                 mirror=False),
        _builtin("Kontras tinggi", "Kuning di hitam, sangat mudah dibaca dari jauh.", font_size=44, font_weight="bold",
                 line_spacing=125, letter_spacing=3, text_color="#FFE94A", background_color="#000000", background_opacity=90,
                 text_align="center", margin=24, mirror=False),
        _builtin("Bacaan lega", "Huruf besar dan spasi baris lapang untuk naskah panjang.", font_size=40, font_weight="normal",
                 line_spacing=150, letter_spacing=2, text_color="#FFE7A3", background_color="#1B1F27", background_opacity=75,
                 text_align="left", margin=28, mirror=False),
        _builtin("Rig cermin", "Teks dibalik untuk beam-splitter, hitam pekat, rata tengah, hitung mundur 3 detik.", font_size=48,
                 font_weight="bold", line_spacing=130, text_color="#FFFFFF", background_color="#000000", background_opacity=95,
                 text_align="center", margin=24, mirror=True, start_delay=3, show_countdown=True),
        _builtin("Presentasi ringan", "Kecil dan transparan agar slide tetap terlihat.", font_size=24, font_weight="demibold",
                 line_spacing=110, text_color="#F7F9FC", background_color="#0C121F", background_opacity=35, text_align="left",
                 margin=12, mirror=False),
    )
}


# --------------------------------------------------------------------------- user store
def profiles_dir() -> Path:
    return paths.data_dir() / "profiles"


def _slug(name: str) -> str:
    base = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:30] or "profil"
    return f"{base}-{hashlib.sha1(name.encode('utf-8')).hexdigest()[:6]}"


def user_profile_path(name: str) -> Path:
    return profiles_dir() / f"{_slug(clean_name(name))}.json"


def save_user_profile(profile: DisplayProfile) -> Path:
    if profile.name in BUILTIN:
        raise ProfileError(f"“{profile.name}” adalah nama profil bawaan; pakai nama lain.")
    existing = list(profiles_dir().glob("*.json")) if profiles_dir().is_dir() else []
    target = user_profile_path(profile.name)
    if target not in existing and len(existing) >= MAX_USER_PROFILES:
        raise ProfileError(f"Maksimal {MAX_USER_PROFILES} profil pengguna.")
    write_file(profile, target)
    return target


def load_user_profiles() -> tuple[dict[str, DisplayProfile], list[str]]:
    """All readable user profiles plus a list of problems (unreadable files are skipped, never fatal)."""
    found: dict[str, DisplayProfile] = {}
    problems: list[str] = []
    folder = profiles_dir()
    if not folder.is_dir():
        return found, problems
    for path in sorted(folder.glob("*.json"))[:MAX_USER_PROFILES]:
        if path.is_symlink():
            continue
        try:
            profile = read_file(path)
        except ProfileError as exc:
            problems.append(f"{path.name}: {exc}")
            continue
        if profile.name in BUILTIN:
            problems.append(f"{path.name}: memakai nama profil bawaan, diabaikan")
            continue
        found[profile.name] = profile
    return found, problems


def delete_user_profile(name: str) -> bool:
    path = user_profile_path(name)
    try:
        path.unlink()
        return True
    except FileNotFoundError:
        return False


def all_profiles(extension_profiles: dict[str, DisplayProfile] | None = None) -> dict[str, tuple[str, DisplayProfile]]:
    """``{name: (source, profile)}``; later sources win: built-in < extension < user."""
    merged: dict[str, tuple[str, DisplayProfile]] = {n: ("bawaan", p) for n, p in BUILTIN.items()}
    for name, profile in (extension_profiles or {}).items():
        merged.setdefault(name, ("ekstensi", profile))
    users, _problems = load_user_profiles()
    for name, profile in users.items():
        merged[name] = ("pengguna", profile)
    return merged
