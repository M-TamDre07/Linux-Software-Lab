"""Primary window: script desk, overlay settings, integrations, system."""
from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Any

from PySide6.QtCore import QRect, Qt, QTimer, QUrl
from PySide6.QtGui import QAction, QDesktopServices, QFont, QGuiApplication, QKeySequence, QTextCursor
from PySide6.QtWidgets import (
    QApplication,
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFontComboBox,
    QFormLayout,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSlider,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from sorot import APP_NAME, AUTHOR, VERSION_LABEL, __version__
from sorot.core import paths
from sorot.core import profiles
from sorot.core.config import (
    ALIGNMENT_LABELS,
    COLOR_PRESETS,
    SHORTCUT_LABELS,
    SPEED_MODE_LABELS,
    THEME_LABELS,
    ConfigStore,
)
from sorot.core.fileio import ScriptFileError, atomic_write_text, read_script
from sorot.core.script_markup import parse_script
from sorot.core.script_stats import MAX_WPM, MIN_WPM, format_clock, parsed_seconds
from sorot.core.scripts import DraftStore, ScriptLibrary
from sorot.services import keyring_service
from sorot.services.platform_info import (
    Support,
    capability,
    classify_session,
    detect_capabilities,
    format_platform_report,
)
from sorot.ui import theme
from sorot.ui.ai_dialog import AIAssistantDialog, AIContext
from sorot.ui.dialogs import AboutDialog, ScriptLibraryDialog, ShortcutsDialog, SnapshotDialog, SupportDialog
from sorot.ui.drive_controller import DriveController
from sorot.ui.extension_manager import Command, ExtensionManager
from sorot.ui.extensions_page import ExtensionsPage
from sorot.ui.highlighter import ScriptHighlighter
from sorot.ui.overlay import PromptOverlay
from sorot.ui.widgets import (
    ColorButton,
    OverlayPreview,
    PositionPicker,
    Segmented,
    Stepper,
    TallyLight,
    caps,
    hrule,
    role,
)

LOGGER = logging.getLogger(__name__)
_LOOPBACK = {"localhost", "127.0.0.1", "::1"}
_CUSTOM_PRESET = "Kustom"
_CUSTOM_PROFILE = "Kustom (belum disimpan)"
_WEIGHT_LABELS = (("Normal", "normal"), ("Sedang", "demibold"), ("Tebal", "bold"))
SPEED_STEPS = {"wpm": 5, "duration": 15, "pps": 8}
MODE_PAGE = {"wpm": 0, "duration": 1, "pps": 2}
NAV_ITEMS = (("01", "Naskah"), ("02", "Tampilan"), ("03", "Integrasi"), ("04", "Sistem"), ("05", "Ekstensi"))
EXTENSIONS_PAGE = 4
PROGRESS_EVENT_SECONDS = 1.0


def _clock_to_seconds(text: str) -> int | None:
    """Parse ``m:ss``, ``mm:ss`` or plain seconds for the duration stepper."""
    text = text.strip()
    try:
        if ":" in text:
            minutes, seconds = text.split(":", 1)
            return int(minutes) * 60 + int(seconds)
        return int(text)
    except ValueError:
        return None


class MainWindow(QMainWindow):
    stat_words: QLabel
    stat_chars: QLabel
    stat_time: QLabel

    def __init__(
        self,
        config_store: ConfigStore | None = None,
        draft_store: DraftStore | None = None,
        library: ScriptLibrary | None = None,
        startup_notices: list[str] | None = None,
    ) -> None:
        super().__init__()
        self.store = config_store or ConfigStore()
        self.draft = draft_store or DraftStore()
        self.library = library or ScriptLibrary()
        self.config = self.store.load().config
        self.session_api_key = ""
        self.current_file: Path | None = None
        self._loading = True
        self._font_touched = False
        self._run_token = 0
        self._save_error_shown = False
        self._notices = list(startup_notices or [])
        self.backend = QGuiApplication.platformName()
        self.capabilities = detect_capabilities(self.backend, classify_session())

        self.overlay = PromptOverlay()
        self.extensions = ExtensionManager(self.config, self._schedule_config_save, __version__, self)
        self._extensions_started = False
        self._last_progress_event = 0.0
        self._last_stats = (0, 0)
        self._palette_key: tuple | None = None
        self._extension_notice_shown = False
        self.sync_timer = self._timer(150, self._sync_from_editor)
        self.draft_timer = self._timer(800, self._save_draft)
        self.config_timer = self._timer(500, self._save_config)
        self.snapshot_timer = self._timer(20_000, self._snapshot_now)
        self.changed_event_timer = self._timer(1500, self._emit_script_changed)
        self.stop_timer = self._timer(0, self._auto_stop)
        self.delay_timer = self._timer(0, self._delayed_start)
        self.countdown_timer = QTimer(self)
        self.countdown_timer.setInterval(1000)
        self.countdown_timer.timeout.connect(self._countdown_tick)
        self._countdown_left = 0
        self._profiles: dict[str, tuple[str, profiles.DisplayProfile]] = {}

        self.setWindowTitle(APP_NAME)
        self.resize(self.config.window_width, self.config.window_height)
        self.setMinimumSize(860, 560)
        self._build_menus()
        self._build_ui()
        self.highlighter = ScriptHighlighter(self.editor.document())
        self.drive = DriveController(
            self, get_text=self.editor.toPlainText, set_text=lambda text: self._replace_editor_text(text, modified=False),
            confirm_replace=lambda: self._confirm_discard("Membuka naskah dari Drive"), status=self._set_status,
        )
        self._connect()
        self.extensions.changed.connect(self._on_extensions_changed)
        self.extensions.notify.connect(self._set_status)
        self._load_initial_state()
        self._loading = False
        self._apply_theme()
        self._apply_config_to_widgets()
        self._refresh_screens()
        self._apply_shortcuts()
        self._apply_overlay_config()
        self._sync_from_editor()
        self._update_title()
        self._update_tally()
        self._set_status(self._startup_status())
        app = QApplication.instance()
        if isinstance(app, QApplication):
            app.screenAdded.connect(self._on_screens_changed)
            app.screenRemoved.connect(self._on_screens_changed)
        QGuiApplication.styleHints().colorSchemeChanged.connect(self._on_color_scheme_changed)
        self.extensions.refresh()

    # =================================================================== setup
    def _build_menus(self) -> None:
        bar = self.menuBar()
        file_menu = bar.addMenu("&Berkas")
        for action in (
            self._action("Naskah baru", self.new_script, "Ctrl+N"),
            self._action("Buka naskah…", self.open_file, "Ctrl+O"),
            self._action("Naskah lokal…", self.open_library, "Ctrl+L"),
            self._action("Riwayat draf…", self.open_history),
            self._action("Simpan", self.save_file, "Ctrl+S"),
            self._action("Simpan sebagai / ekspor…", self.save_file_as, "Ctrl+Shift+S"),
        ):
            file_menu.addAction(action)
        self.templates_menu = file_menu.addMenu("Naskah dari templat")
        self.templates_menu.setEnabled(False)
        file_menu.addSeparator()
        file_menu.addAction(self._action("Pulihkan pengaturan dari cadangan…", self.restore_settings_backup))
        file_menu.addAction(self._action("Keluar", self.close, "Ctrl+Q"))

        overlay_menu = bar.addMenu("&Overlay")
        self.overlay_actions: dict[str, QAction] = {}
        for key, slot in (
            ("show_overlay", self.show_overlay), ("toggle_scroll", self.toggle_scroll), ("reset_scroll", self.reset_scroll),
            ("hide_overlay", self.hide_overlay), ("speed_up", lambda: self.adjust_speed(+1)), ("speed_down", lambda: self.adjust_speed(-1)),
        ):
            action = self._action(SHORTCUT_LABELS[key], slot)
            self.overlay_actions[key] = action
            overlay_menu.addAction(action)
        overlay_menu.addSeparator()
        overlay_menu.addAction(self._action("Panduan overlay dan kompatibilitas…", self.show_compatibility_help))

        integration_menu = bar.addMenu("&Integrasi")
        integration_menu.addAction(self._action("Asisten AI / pengaturan API…", self.open_ai_assistant))
        drive_menu = integration_menu.addMenu("Google Drive melalui rclone")
        drive_menu.addAction(self._action("Buka naskah .txt dari Drive…", lambda: self.drive.open_text()))
        drive_menu.addAction(self._action("Simpan naskah ke Drive…", lambda: self.drive.save_text()))
        drive_menu.addAction(self._action("Periksa konfigurasi rclone…", lambda: self.drive.check_setup()))
        drive_menu.addAction(self._action("Buka Google Drive di browser", DriveController.open_web))

        self.extensions_menu = bar.addMenu("E&kstensi")

        help_menu = bar.addMenu("Ban&tuan")
        help_menu.addAction(self._action("Diagnostik sistem…", self.show_diagnostics))
        help_menu.addAction(self._action("Dukung pengembangan…", self.show_support))
        help_menu.addAction(self._action(f"Tentang {APP_NAME}", self.show_about))

    def _build_ui(self) -> None:
        root = QWidget()
        root.setObjectName("root")
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        body = QHBoxLayout()
        body.setSpacing(0)
        body.addWidget(self._build_rail())
        content = QWidget()
        content.setObjectName("page")
        column = QVBoxLayout(content)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        self.pages = QStackedWidget()
        column.addWidget(self.pages, 1)
        column.addWidget(hrule())
        column.addWidget(self._build_transport())
        body.addWidget(content, 1)
        outer.addLayout(body, 1)
        outer.addWidget(hrule())
        outer.addWidget(self._build_statusbar())
        self._add_pages()

    def _add_pages(self) -> None:
        for builder in (self._page_script, self._page_look, self._page_integrations, self._page_system):
            self.pages.addWidget(builder())
        self.extensions_page = ExtensionsPage(self.extensions)
        self.pages.addWidget(self.extensions_page)

    def _build_rail(self) -> QFrame:
        rail = QFrame()
        role(rail, "rail")
        rail.setFixedWidth(176)
        layout = QVBoxLayout(rail)
        layout.setContentsMargins(0, 18, 0, 14)
        layout.setSpacing(0)
        mark = QLabel(APP_NAME)
        role(mark, "title")
        mark.setContentsMargins(16, 0, 0, 0)
        layout.addWidget(mark)
        tag = caps("Teleprompter", tone="faint")
        tag.setContentsMargins(16, 2, 0, 18)
        layout.addWidget(tag)
        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        self.nav_buttons: list[QPushButton] = []
        self.nav_layout = layout
        for index, (number, label) in enumerate(NAV_ITEMS):
            self._add_nav_button(index, number, label)
        layout.addStretch(1)
        state_row = QHBoxLayout()
        state_row.setContentsMargins(16, 0, 12, 0)
        self.tally = TallyLight()
        self.tally_label = caps("Overlay mati")
        state_row.addWidget(self.tally)
        state_row.addWidget(self.tally_label, 1)
        layout.addLayout(state_row)
        self.support_btn = QPushButton("Dukung Sorot")
        role(self.support_btn, "ghost")
        self.support_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.support_btn.setToolTip("Dukungan sukarela untuk pengembangan Sorot")
        self.support_btn.setContentsMargins(0, 0, 0, 0)
        support_row = QHBoxLayout()
        support_row.setContentsMargins(14, 10, 14, 0)
        support_row.addWidget(self.support_btn)
        layout.addLayout(support_row)
        credit = QLabel(f"{VERSION_LABEL.upper()}\noleh {AUTHOR}")
        role(credit, "faint")
        credit.setContentsMargins(16, 10, 8, 0)
        credit.setWordWrap(True)
        credit.setStyleSheet("font-size: 8pt;")
        layout.addWidget(credit)
        return rail

    def _add_nav_button(self, index: int, number: str, label: str) -> QPushButton:
        button = QPushButton(f"{number}   {label}")
        role(button, "nav")
        button.setCheckable(True)
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.setAccessibleName(f"Halaman {label}")
        button.clicked.connect(lambda _checked=False, i=index: self._go_page(i))
        self.nav_group.addButton(button)
        self.nav_buttons.append(button)
        self.nav_layout.insertWidget(2 + len(self.nav_buttons) - 1, button)
        if index == 0:
            button.setChecked(True)
        return button

    def _go_page(self, index: int) -> None:
        if 0 <= index < self.pages.count():
            self.pages.setCurrentIndex(index)
            if index < len(self.nav_buttons):
                self.nav_buttons[index].setChecked(True)

    def _build_transport(self) -> QWidget:
        bar = QWidget()
        bar.setObjectName("transport")
        row = QHBoxLayout(bar)
        row.setContentsMargins(24, 12, 24, 12)
        row.setSpacing(16)
        readout = QVBoxLayout()
        readout.setSpacing(0)
        self.readout = QLabel("00:00")
        role(self.readout, "readout")
        self.readout.setAccessibleName("Waktu tersisa")
        self.readout_sub = caps("Tersisa · total 00:00")
        readout.addWidget(self.readout)
        readout.addWidget(self.readout_sub)
        row.addLayout(readout)
        row.addStretch(1)
        self.show_btn, self.show_hint = self._transport_button(row, "TAMPILKAN", primary=True)
        self.play_btn, self.play_hint = self._transport_button(row, "MULAI")
        self.reset_btn, self.reset_hint = self._transport_button(row, "AWAL")
        self.hide_btn, self.hide_hint = self._transport_button(row, "SEMBUNYIKAN", danger=True)
        return bar

    @staticmethod
    def _transport_button(row: QHBoxLayout, text: str, *, primary: bool = False, danger: bool = False) -> tuple[QPushButton, QLabel]:
        column = QVBoxLayout()
        column.setSpacing(3)
        button = QPushButton(text)
        button.setMinimumSize(100, 40)
        if primary:
            role(button, "primary")
        elif danger:
            role(button, "danger")
        hint = QLabel("")
        role(hint, "faint")
        hint.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        hint.setStyleSheet("font-family: monospace; font-size: 8pt;")
        column.addWidget(button)
        column.addWidget(hint)
        row.addLayout(column)
        return button, hint

    def _build_statusbar(self) -> QWidget:
        bar = QWidget()
        bar.setObjectName("statusbar")
        row = QHBoxLayout(bar)
        row.setContentsMargins(16, 5, 16, 5)
        self.status_label = QLabel("Siap.")
        self.status_label.setObjectName("status")
        self.status_label.setWordWrap(True)
        self.status_label.setAccessibleName("Status aplikasi")
        self.session_label = QLabel("")
        self.session_label.setObjectName("status")
        row.addWidget(self.status_label, 1)
        row.addWidget(self.session_label)
        return bar

    # ---------------------------------------------------------------- pages
    @staticmethod
    def _page(title: str, subtitle: str = "", *, header: bool = True) -> tuple[QWidget, QVBoxLayout]:
        page = QWidget()
        page.setObjectName("page")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(26, 18, 26, 12)
        layout.setSpacing(10)
        if header:
            head = QLabel(title)
            role(head, "title")
            layout.addWidget(head)
        if header and subtitle:
            sub = QLabel(subtitle)
            role(sub, "muted")
            layout.addWidget(sub)
        return page, layout

    @staticmethod
    def _panel(title: str) -> tuple[QFrame, QVBoxLayout]:
        frame = QFrame()
        role(frame, "panel")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(16, 12, 16, 14)
        layout.setSpacing(8)
        layout.addWidget(caps(title))
        return frame, layout

    @staticmethod
    def _scrolling(page: QWidget) -> QScrollArea:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(page)
        return scroll

    def _stat(self, label: str) -> tuple[QWidget, QLabel]:
        box = QWidget()
        column = QVBoxLayout(box)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        value = QLabel("0")
        role(value, "stat")
        column.addWidget(caps(label, tone="faint"))
        column.addWidget(value)
        return box, value

    def _page_script(self) -> QWidget:
        page, layout = self._page("Naskah", header=False)
        head = QLabel("Naskah")
        role(head, "title")
        top = QHBoxLayout()
        self.file_label = QLabel("")
        role(self.file_label, "faint")
        self.open_btn = QPushButton("Buka…")
        self.save_btn = QPushButton("Simpan")
        self.library_btn = QPushButton("Naskah lokal…")
        self.history_btn = QPushButton("Riwayat")
        for button in (self.open_btn, self.save_btn, self.library_btn, self.history_btn):
            role(button, "ghost")
        top.addWidget(head)
        top.addStretch(1)
        top.addWidget(self.file_label)
        top.addSpacing(10)
        for button in (self.open_btn, self.save_btn, self.library_btn, self.history_btn):
            top.addWidget(button)
        layout.addLayout(top)

        body = QHBoxLayout()
        body.setSpacing(14)
        left = QVBoxLayout()
        left.setSpacing(10)
        self.editor = QPlainTextEdit()
        self.editor.setObjectName("script")
        self.editor.setPlaceholderText("Tempel atau ketik naskah di sini…\n\n// baris ini catatan pribadi, tidak tampil di overlay\n[jeda 3]")
        self.editor.setAccessibleName("Editor naskah")
        self.editor.setMinimumHeight(180)
        left.addWidget(self.editor, 1)
        stats = QHBoxLayout()
        stats.setSpacing(28)
        for attribute, label in (("stat_words", "Kata"), ("stat_chars", "Karakter"), ("stat_time", "Durasi estimasi")):
            box, value = self._stat(label)
            setattr(self, attribute, value)
            stats.addWidget(box)
        self.stat_extra = QLabel("")
        role(self.stat_extra, "faint")
        stats.addStretch(1)
        stats.addWidget(self.stat_extra)
        left.addLayout(stats)
        body.addLayout(left, 1)

        inspector, ilayout = self._panel("Kecepatan")
        inspector.setFixedWidth(278)
        self.speed_mode_seg = Segmented([(SPEED_MODE_LABELS["wpm"], "wpm"), ("Durasi", "duration"), ("Px/dtk", "pps")])
        ilayout.addWidget(self.speed_mode_seg)
        self.speed_stack = QStackedWidget()
        self.wpm_spin = Stepper(MIN_WPM, MAX_WPM, step=5, suffix=" kata/mnt")
        self.target_spin = Stepper(10, 14400, step=5, formatter=lambda v: f"{v // 60}:{v % 60:02d}", parser=_clock_to_seconds)
        self.speed_spin = Stepper(0, 400, step=4, suffix=" px/dtk")
        for caption, widget in (("Kecepatan bicara", self.wpm_spin), ("Selesai dalam (m:ss)", self.target_spin), ("Kecepatan gulir", self.speed_spin)):
            holder = QWidget()
            column = QVBoxLayout(holder)
            column.setContentsMargins(0, 4, 0, 0)
            column.setSpacing(4)
            caption_label = QLabel(caption)
            role(caption_label, "muted")
            column.addWidget(caption_label)
            column.addWidget(widget)
            self.speed_stack.addWidget(holder)
            widget.setAccessibleName(caption)
        ilayout.addWidget(self.speed_stack)
        self.speed_note = QLabel("")
        role(self.speed_note, "note")
        self.speed_note.setWordWrap(True)
        ilayout.addWidget(self.speed_note)
        ilayout.addWidget(hrule())
        ilayout.addWidget(caps("Waktu"))
        self.delay_spin = Stepper(0, 120, suffix=" dtk")
        self.duration_spin = Stepper(0, 240, suffix=" mnt")
        self.duration_spin.setSpecialValueText("Tak dibatasi")
        for caption, widget in (("Jeda sebelum mulai", self.delay_spin), ("Berhenti otomatis", self.duration_spin)):
            caption_label = QLabel(caption)
            role(caption_label, "muted")
            ilayout.addWidget(caption_label)
            ilayout.addWidget(widget)
            widget.setAccessibleName(caption)
        ilayout.addWidget(hrule())
        ilayout.addWidget(caps("Isyarat naskah"))
        cheat = QLabel("// catatan pribadi\n[jeda]  tahan 2 detik\n[jeda 5]  tahan 5 detik")
        role(cheat, "mono")
        ilayout.addWidget(cheat)
        self.hint_label = QLabel("")
        role(self.hint_label, "faint")
        self.hint_label.setWordWrap(True)
        self.hint_label.hide()  # the shortcuts are printed under the transport buttons instead
        ilayout.addStretch(1)
        body.addWidget(inspector)
        layout.addLayout(body, 1)
        return page

    def _page_look(self) -> QWidget:
        page, layout = self._page("Tampilan", "Yang kamu atur di sini langsung tampak di pratinjau dan overlay.")
        self.preview = OverlayPreview()
        layout.addWidget(self.preview)
        columns = QHBoxLayout()
        columns.setSpacing(14)
        left, right = QVBoxLayout(), QVBoxLayout()
        left.setSpacing(12)
        right.setSpacing(12)

        profile_panel, pl = self._panel("Profil tampilan")
        self.profile_combo = QComboBox()
        self.profile_combo.setAccessibleName("Profil tampilan")
        self.profile_note = QLabel("")
        role(self.profile_note, "note")
        self.profile_note.setWordWrap(True)
        self.profile_save_btn = QPushButton("Simpan tampilan ini…")
        self.profile_import_btn = QPushButton("Impor…")
        self.profile_export_btn = QPushButton("Ekspor…")
        self.profile_delete_btn = QPushButton("Hapus")
        profile_row = QHBoxLayout()
        for button in (self.profile_save_btn, self.profile_import_btn, self.profile_export_btn, self.profile_delete_btn):
            profile_row.addWidget(button)
        profile_row.addStretch(1)
        pl.addWidget(self.profile_combo)
        pl.addWidget(self.profile_note)
        pl.addLayout(profile_row)
        left.addWidget(profile_panel)

        text_panel, tl = self._panel("Teks dan latar")
        form = QFormLayout()
        form.setHorizontalSpacing(14)
        form.setVerticalSpacing(8)
        self.preset_combo = QComboBox()
        self.preset_combo.addItems([_CUSTOM_PRESET, *COLOR_PRESETS])  # extension presets are appended later
        self.font_combo = QFontComboBox()
        self.font_combo.setEditable(False)
        self.font_spin = Stepper(12, 120, step=2, suffix=" pt")
        self.text_color_btn = ColorButton("Warna teks")
        self.bg_color_btn = ColorButton("Warna latar")
        colors = QHBoxLayout()
        colors.addWidget(self.text_color_btn)
        colors.addWidget(self.bg_color_btn)
        self.opacity_slider = QSlider(Qt.Orientation.Horizontal)
        self.opacity_slider.setRange(0, 95)
        self.opacity_slider.setAccessibleName("Transparansi latar")
        self.opacity_value = QLabel("58%")
        role(self.opacity_value, "mono")
        opacity = QHBoxLayout()
        opacity.addWidget(self.opacity_slider, 1)
        opacity.addWidget(self.opacity_value)
        self.align_seg = Segmented([(ALIGNMENT_LABELS["left"], "left"), ("Tengah", "center"), ("Kanan", "right"), ("Rata", "justify")])
        self.margin_spin = Stepper(0, 120, step=2, suffix=" px")
        self.weight_combo = QComboBox()
        for label, value in _WEIGHT_LABELS:
            self.weight_combo.addItem(label, value)
        self.line_spacing_spin = Stepper(100, 250, step=5, suffix=" %")
        self.letter_spacing_spin = Stepper(0, 30, step=1, suffix=" %")
        for label, widget in (
            ("Tema warna", self.preset_combo), ("Jenis huruf", self.font_combo), ("Ukuran huruf", self.font_spin),
            ("Warna teks · latar", colors), ("Transparansi", opacity), ("Perataan", self.align_seg), ("Margin", self.margin_spin),
            ("Ketebalan huruf", self.weight_combo), ("Spasi baris", self.line_spacing_spin), ("Spasi huruf", self.letter_spacing_spin),
        ):
            form.addRow(label, widget)
        tl.addLayout(form)
        left.addWidget(text_panel)

        guide_panel, gl = self._panel("Garis baca dan progres")
        gform = QFormLayout()
        gform.setHorizontalSpacing(14)
        self.guide_check = QCheckBox("Tampilkan garis baca (baris yang sedang dibaca)")
        self.guide_spin = Stepper(10, 70, step=5, suffix=" %")
        self.progress_check = QCheckBox("Tampilkan garis progres dan sisa waktu")
        gl.addWidget(self.guide_check)
        gform.addRow("Letak dari atas", self.guide_spin)
        gl.addLayout(gform)
        gl.addWidget(self.progress_check)
        left.addWidget(guide_panel)

        mode_panel, ml = self._panel("Cermin dan hitung mundur")
        self.mirror_check = QCheckBox("Balik teks horizontal (mode cermin untuk beam-splitter)")
        self.mirror_check.setToolTip("Hanya tampilan: tombol dan jendela tidak ikut dibalik. Pratinjau memperlihatkan hasilnya.")
        self.countdown_check = QCheckBox("Tampilkan hitung mundur besar saat jeda mulai (lihat “Jeda sebelum mulai”)")
        ml.addWidget(self.mirror_check)
        ml.addWidget(self.countdown_check)
        left.addWidget(mode_panel)
        left.addStretch(1)

        window_panel, wl = self._panel("Jendela overlay")
        top = QHBoxLayout()
        self.position_picker = PositionPicker()
        top.addWidget(self.position_picker)
        side = QFormLayout()
        side.setHorizontalSpacing(12)
        self.width_spin = Stepper(300, 4000, step=20, suffix=" px")
        self.height_spin = Stepper(100, 2400, step=10, suffix=" px")
        side.addRow("Lebar", self.width_spin)
        side.addRow("Tinggi", self.height_spin)
        top.addLayout(side, 1)
        wl.addLayout(top)
        self.screen_combo = QComboBox()
        screen_form = QFormLayout()
        screen_form.addRow("Layar", self.screen_combo)
        wl.addLayout(screen_form)
        self.aot_check = QCheckBox("Selalu di atas jendela lain")
        self.frameless_check = QCheckBox("Tanpa bingkai (mode overlay)")
        self.clickthrough_check = QCheckBox("Teruskan klik ke aplikasi di belakang")
        self.clickthrough_check.setToolTip("Jika aktif, overlay tidak bisa digeser atau diklik. Gunakan jendela utama untuk menyembunyikannya.")
        for check in (self.aot_check, self.frameless_check, self.clickthrough_check):
            wl.addWidget(check)
        self.capability_note = QLabel("")
        role(self.capability_note, "note")
        self.capability_note.setWordWrap(True)
        wl.addWidget(self.capability_note)
        right.addWidget(window_panel)
        right.addStretch(1)
        columns.addLayout(left, 1)
        columns.addLayout(right, 1)
        layout.addLayout(columns)
        layout.addStretch(1)
        return self._scrolling(page)

    def _page_integrations(self) -> QWidget:
        page, layout = self._page("Integrasi", "Semuanya opsional dan hanya berjalan atas tindakanmu.")
        row = QHBoxLayout()
        row.setSpacing(14)
        ai_panel, al = self._panel("Asisten AI")
        desc = QLabel("Perbaiki bahasa, ringkas, terjemahkan, atau sesuaikan durasi naskah dengan API penyedia pilihanmu. Tidak ada yang dikirim sampai kamu menekan Proses dan menyetujui tujuannya.")
        desc.setWordWrap(True)
        role(desc, "muted")
        al.addWidget(desc)
        self.ai_btn = QPushButton("Buka Asisten AI…")
        role(self.ai_btn, "primary")
        al.addWidget(self.ai_btn, 0, Qt.AlignmentFlag.AlignLeft)
        al.addStretch(1)
        drive_panel, dl = self._panel("Google Drive")
        ddesc = QLabel("Memakai rclone yang kamu konfigurasi sendiri. Tanpa rclone, aplikasi tetap berjalan; kamu bisa membuka Drive di browser atau memakai folder Drive yang disinkronkan aplikasi lain.")
        ddesc.setWordWrap(True)
        role(ddesc, "muted")
        dl.addWidget(ddesc)
        buttons = QGridLayout()
        buttons.setHorizontalSpacing(8)
        buttons.setVerticalSpacing(8)
        self.drive_open_btn = QPushButton("Buka dari Drive…")
        self.drive_save_btn = QPushButton("Simpan ke Drive…")
        self.drive_check_btn = QPushButton("Periksa rclone…")
        self.drive_web_btn = QPushButton("Drive di browser")
        for index, button in enumerate((self.drive_open_btn, self.drive_save_btn, self.drive_check_btn, self.drive_web_btn)):
            role(button, "ghost")
            buttons.addWidget(button, index // 2, index % 2)
        dl.addLayout(buttons)
        dl.addStretch(1)
        row.addWidget(ai_panel, 1)
        row.addWidget(drive_panel, 1)
        layout.addLayout(row)
        layout.addStretch(1)
        return page

    def _page_system(self) -> QWidget:
        page, layout = self._page("Sistem", "Tema, backend jendela, pintasan, dan diagnostik.")
        panel, pl = self._panel("Aplikasi")
        form = QFormLayout()
        form.setHorizontalSpacing(14)
        self.theme_seg = Segmented([(THEME_LABELS["dark"], "dark"), (THEME_LABELS["light"], "light"), ("Ikuti sistem", "system")])
        self.qt_platform_combo = QComboBox()
        for key, label in (("auto", "Otomatis (disarankan)"), ("xcb", "X11 / XWayland (xcb)"), ("wayland", "Wayland asli")):
            self.qt_platform_combo.addItem(label, key)
        self.qt_platform_combo.setToolTip("Perubahan berlaku setelah aplikasi dijalankan ulang.")
        self.ext_theme_combo = QComboBox()
        self.ext_theme_combo.addItem("Tidak dipakai", "")
        self.ext_theme_combo.setToolTip("Tema tambahan dari ekstensi yang aktif")
        form.addRow("Tema", self.theme_seg)
        form.addRow("Tema dari ekstensi", self.ext_theme_combo)
        form.addRow("Backend Qt (perlu restart)", self.qt_platform_combo)
        pl.addLayout(form)
        layout.addWidget(panel)
        buttons = QGridLayout()
        buttons.setHorizontalSpacing(8)
        buttons.setVerticalSpacing(8)
        self.shortcuts_btn = QPushButton("Pintasan keyboard…")
        self.copy_report_btn = QPushButton("Salin laporan diagnostik")
        self.guide_btn = QPushButton("Panduan overlay")
        self.log_btn = QPushButton("Buka folder log")
        for index, button in enumerate((self.shortcuts_btn, self.copy_report_btn, self.guide_btn, self.log_btn)):
            role(button, "ghost")
            buttons.addWidget(button, index // 2, index % 2)
        layout.addLayout(buttons)
        self.report_view = QPlainTextEdit()
        self.report_view.setObjectName("mono")
        self.report_view.setReadOnly(True)
        self.report_view.setAccessibleName("Laporan diagnostik sistem")
        layout.addWidget(self.report_view, 1)
        return page

    def _connect(self) -> None:
        o = self.overlay
        self.editor.textChanged.connect(self._on_text_changed)
        self.editor.document().modificationChanged.connect(lambda _m: self._update_title())
        self.open_btn.clicked.connect(self.open_file)
        self.save_btn.clicked.connect(self.save_file)
        self.library_btn.clicked.connect(self.open_library)
        self.history_btn.clicked.connect(self.open_history)
        self.support_btn.clicked.connect(self.show_support)
        self.show_btn.clicked.connect(self.show_overlay)
        self.play_btn.clicked.connect(self.toggle_scroll)
        self.reset_btn.clicked.connect(self.reset_scroll)
        self.hide_btn.clicked.connect(self.hide_overlay)
        self.ai_btn.clicked.connect(self.open_ai_assistant)
        self.drive_open_btn.clicked.connect(lambda: self.drive.open_text())
        self.drive_save_btn.clicked.connect(lambda: self.drive.save_text())
        self.drive_check_btn.clicked.connect(lambda: self.drive.check_setup())
        self.drive_web_btn.clicked.connect(DriveController.open_web)
        self.shortcuts_btn.clicked.connect(self.edit_shortcuts)
        self.copy_report_btn.clicked.connect(self.copy_report)
        self.guide_btn.clicked.connect(self.show_compatibility_help)
        self.log_btn.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(paths.state_dir()))))
        o.playPauseRequested.connect(self.toggle_scroll)
        o.resetRequested.connect(self.reset_scroll)
        o.hideRequested.connect(self.hide_overlay)
        o.speedAdjustRequested.connect(self.adjust_speed)
        o.scrollingChanged.connect(self._on_scrolling_changed)
        o.progressChanged.connect(self._on_progress)
        o.geometryChangedByUser.connect(self._on_overlay_geometry_changed)
        self.preset_combo.activated.connect(self._on_preset_chosen)
        self.profile_combo.activated.connect(self._on_profile_chosen)
        self.profile_save_btn.clicked.connect(self._save_profile)
        self.profile_import_btn.clicked.connect(self._import_profile)
        self.profile_export_btn.clicked.connect(self._export_profile)
        self.profile_delete_btn.clicked.connect(self._delete_profile)
        self.font_combo.activated.connect(lambda _i: setattr(self, "_font_touched", True))
        for color_button in (self.text_color_btn, self.bg_color_btn):
            color_button.colorChanged.connect(self._on_setting_changed)
        self.ext_theme_combo.activated.connect(self._on_ext_theme_chosen)
        for combo in (self.font_combo, self.screen_combo, self.qt_platform_combo, self.weight_combo):
            combo.currentIndexChanged.connect(self._on_setting_changed)
        for seg in (self.speed_mode_seg, self.align_seg, self.theme_seg):
            seg.valueChanged.connect(self._on_setting_changed)
        self.position_picker.valueChanged.connect(self._on_setting_changed)
        for numeric in (self.font_spin, self.margin_spin, self.width_spin, self.height_spin, self.speed_spin, self.wpm_spin, self.target_spin,
                        self.delay_spin, self.duration_spin, self.guide_spin, self.opacity_slider,
                        self.line_spacing_spin, self.letter_spacing_spin):
            numeric.valueChanged.connect(self._on_setting_changed)
        for check in (self.aot_check, self.frameless_check, self.clickthrough_check, self.guide_check, self.progress_check,
                      self.mirror_check, self.countdown_check):
            check.toggled.connect(self._on_setting_changed)

    # ============================================================ state <-> UI
    def _load_initial_state(self) -> None:
        self._replace_editor_text(self.draft.load(), modified=False, snapshot=False)
        self.editor.document().clearUndoRedoStacks()

    def _bound_widgets(self) -> tuple:
        return (
            self.font_combo, self.font_spin, self.text_color_btn, self.bg_color_btn, self.opacity_slider, self.align_seg,
            self.margin_spin, self.position_picker, self.width_spin, self.height_spin, self.aot_check, self.frameless_check,
            self.clickthrough_check, self.speed_mode_seg, self.speed_spin, self.wpm_spin, self.target_spin, self.delay_spin,
            self.duration_spin, self.guide_check, self.guide_spin, self.progress_check, self.theme_seg, self.qt_platform_combo,
            self.preset_combo, self.weight_combo, self.line_spacing_spin, self.letter_spacing_spin, self.mirror_check, self.countdown_check,
        )

    def _apply_config_to_widgets(self) -> None:
        c = self.config
        widgets = self._bound_widgets()
        for widget in widgets:
            widget.blockSignals(True)
        if c.font_family:
            self.font_combo.setCurrentFont(QFont(c.font_family))
        self.font_spin.setValue(c.font_size)
        self.text_color_btn.set_color(c.text_color)
        self.bg_color_btn.set_color(c.background_color)
        self.opacity_slider.setValue(c.background_opacity)
        self.opacity_value.setText(f"{c.background_opacity}%")
        self.align_seg.setValue(c.text_align)
        self.margin_spin.setValue(c.margin)
        self.weight_combo.setCurrentIndex(max(0, self.weight_combo.findData(c.font_weight)))
        self.line_spacing_spin.setValue(c.line_spacing)
        self.letter_spacing_spin.setValue(c.letter_spacing)
        self.mirror_check.setChecked(c.mirror)
        self.countdown_check.setChecked(c.show_countdown)
        self.position_picker.setValue(c.position)
        self.width_spin.setValue(c.overlay_width)
        self.height_spin.setValue(c.overlay_height)
        self.aot_check.setChecked(c.always_on_top)
        self.frameless_check.setChecked(c.frameless)
        self.clickthrough_check.setChecked(c.click_through)
        self.speed_mode_seg.setValue(c.speed_mode)
        self.speed_stack.setCurrentIndex(MODE_PAGE[c.speed_mode])
        self.speed_spin.setValue(c.scroll_speed)
        self.wpm_spin.setValue(c.wpm)
        self.target_spin.setValue(c.target_seconds)
        self.delay_spin.setValue(c.start_delay)
        self.duration_spin.setValue(c.auto_stop_minutes)
        self.guide_check.setChecked(c.guide_enabled)
        self.guide_spin.setValue(c.guide_position)
        self.progress_check.setChecked(c.show_progress)
        self.theme_seg.setValue(c.theme)
        self.qt_platform_combo.setCurrentIndex(max(0, self.qt_platform_combo.findData(c.qt_platform)))
        self._sync_preset_combo()
        for widget in widgets:
            widget.blockSignals(False)
        self._refresh_profiles()

    def _read_widgets_into_config(self) -> None:
        c = self.config
        if self._font_touched or c.font_family:  # keep the built-in default until the user picks a font
            c.font_family = self.font_combo.currentFont().family()
        c.font_size = self.font_spin.value()
        c.text_color = self.text_color_btn.color
        c.background_color = self.bg_color_btn.color
        c.background_opacity = self.opacity_slider.value()
        c.text_align = self.align_seg.value()
        c.margin = self.margin_spin.value()
        c.font_weight = self.weight_combo.currentData() or c.font_weight
        c.line_spacing = self.line_spacing_spin.value()
        c.letter_spacing = self.letter_spacing_spin.value()
        c.mirror = self.mirror_check.isChecked()
        c.show_countdown = self.countdown_check.isChecked()
        c.position = self.position_picker.value()
        screen = self.screen_combo.currentData()
        c.screen_name = screen if isinstance(screen, str) else c.screen_name
        c.overlay_width = self.width_spin.value()
        c.overlay_height = self.height_spin.value()
        c.always_on_top = self.aot_check.isChecked()
        c.frameless = self.frameless_check.isChecked()
        c.click_through = self.clickthrough_check.isChecked()
        c.speed_mode = self.speed_mode_seg.value() or c.speed_mode
        c.scroll_speed = self.speed_spin.value()
        c.wpm = self.wpm_spin.value()
        c.target_seconds = self.target_spin.value()
        c.start_delay = self.delay_spin.value()
        c.auto_stop_minutes = self.duration_spin.value()
        c.guide_enabled = self.guide_check.isChecked()
        c.guide_position = self.guide_spin.value()
        c.show_progress = self.progress_check.isChecked()
        c.theme = self.theme_seg.value() or c.theme
        c.qt_platform = self.qt_platform_combo.currentData()

    def _on_setting_changed(self, *_args) -> None:
        if self._loading:
            return
        previous_theme = self.config.theme
        self._read_widgets_into_config()
        self.opacity_value.setText(f"{self.config.background_opacity}%")
        self.speed_stack.setCurrentIndex(MODE_PAGE[self.config.speed_mode])
        self._sync_preset_combo()
        self._sync_profile_combo()
        if self.config.theme != previous_theme:
            self._apply_theme()
        self._apply_overlay_config()
        if self.overlay.isVisible() or self.config.position != "manual":
            self._place_overlay()
        self._schedule_config_save()

    # =============================================================== overlay
    def _apply_overlay_config(self) -> None:
        c = self.config
        self.overlay.set_appearance(
            font_family=c.font_family, font_size=c.font_size, text_color=c.text_color, background_color=c.background_color,
            background_opacity=c.background_opacity, text_align=c.text_align, margin=c.margin,
            font_weight=c.font_weight, line_spacing=c.line_spacing, letter_spacing=c.letter_spacing, mirror=c.mirror,
        )
        self.overlay.configure_window(always_on_top=c.always_on_top, frameless=c.frameless, click_through=c.click_through)
        self.overlay.set_speed(c.speed_mode, pps=c.scroll_speed, wpm=c.wpm, target_seconds=c.target_seconds)
        self.overlay.set_guide(enabled=c.guide_enabled, position_percent=c.guide_position, show_progress=c.show_progress)
        self.preview.apply(
            font_family=c.font_family, font_size=c.font_size, text_color=c.text_color, background_color=c.background_color,
            background_opacity=c.background_opacity, text_align=c.text_align, margin=c.margin, rounded=c.frameless,
            font_weight=c.font_weight, line_spacing=c.line_spacing, letter_spacing=c.letter_spacing, mirror=c.mirror,
        )
        self._update_capability_note()
        self._update_hint()
        self._update_report()
        self._update_speed_note()
        self._sync_stats()

    def _update_speed_note(self) -> None:
        c = self.config
        if c.speed_mode == "wpm":
            text = f"Gulir mengikuti {c.wpm} kata/menit, termasuk jeda napas pada tanda baca dan isyarat [jeda]."
        elif c.speed_mode == "duration":
            effective = self.overlay.effective_wpm()
            text = f"Selesai dalam {format_clock(c.target_seconds)}."
            if effective:
                text += f" Setara ±{effective:.0f} kata/menit."
                if effective > 200:
                    text += " Itu cepat untuk dibacakan dengan jelas."
                elif effective < 70:
                    text += " Itu sangat lambat; naskah mungkin terlalu pendek."
        else:
            text = f"Gulir tetap {c.scroll_speed} px/detik dan tidak mengikuti jumlah kata."
        self.speed_note.setText(text)

    def show_overlay(self) -> None:
        self._run_token += 1
        self._cancel_start_delay()
        self._sync_from_editor()
        self._apply_overlay_config()
        self._place_overlay()
        self.overlay.show()
        self.overlay.raise_()
        self._update_tally()
        self.extensions.broadcast("overlay.shown", {})
        delay = self.config.start_delay
        if delay > 0:
            self.delay_timer.start(delay * 1000)
            if self.config.show_countdown:
                self._countdown_left = delay
                self.overlay.show_countdown(delay)
                self.countdown_timer.start()
            self._set_status(f"Overlay tampil. Gulir otomatis dimulai dalam {delay} detik.")
        else:
            self.overlay.start_scrolling()
            self._set_status("Overlay aktif. Arahkan kursor ke overlay untuk tombol kontrol, atau pakai pintasan di jendela utama.")
        self._restart_auto_stop()

    def toggle_scroll(self) -> None:
        if not self.overlay.isVisible():
            self.show_overlay()
            return
        if self.overlay.is_scrolling():
            self.overlay.pause_scrolling()
            self._set_status("Gulir dijeda.")
        elif not self.overlay.can_scroll():
            if self.config.speed_mode == "pps" and self.config.scroll_speed <= 0:
                self._set_status("Kecepatan gulir 0. Naikkan kecepatannya untuk memulai gulir otomatis.")
            else:
                self._set_status("Naskah masih kosong; tidak ada yang bisa digulir.")
        else:
            self.overlay.start_scrolling()
            self._set_status("Gulir otomatis berjalan.")

    def reset_scroll(self) -> None:
        self.overlay.reset_scroll()
        self._set_status("Naskah dikembalikan ke bagian paling atas.")

    def hide_overlay(self) -> None:
        self._run_token += 1
        self._cancel_start_delay()
        self.stop_timer.stop()
        self.overlay.pause_scrolling()
        self.overlay.hide()
        self._update_tally()
        self.extensions.broadcast("overlay.hidden", {})
        self._set_status("Overlay disembunyikan.")

    def adjust_speed(self, steps: int) -> None:
        mode = self.config.speed_mode
        if mode == "wpm":
            self.wpm_spin.setValue(self.wpm_spin.value() + SPEED_STEPS["wpm"] * steps)
            self._set_status(f"Kecepatan bicara: {self.wpm_spin.value()} kata/menit.")
        elif mode == "duration":
            self.target_spin.setValue(self.target_spin.value() - SPEED_STEPS["duration"] * steps)  # faster = shorter
            self._set_status(f"Selesai dalam {format_clock(self.target_spin.value())}.")
        else:
            self.speed_spin.setValue(self.speed_spin.value() + SPEED_STEPS["pps"] * steps)
            self._set_status(f"Kecepatan gulir: {self.speed_spin.value()} px/detik.")

    def _on_scrolling_changed(self, scrolling: bool) -> None:
        self.play_btn.setText("JEDA" if scrolling else "MULAI")
        self._update_tally()
        if scrolling:
            self.extensions.broadcast("playback.started", {"total": round(self.overlay.duration(), 1)})
        elif self.overlay.at_end():
            self.extensions.broadcast("playback.finished", {"total": round(self.overlay.duration(), 1)})
        else:
            self.extensions.broadcast("playback.paused", {"elapsed": round(self.overlay.elapsed(), 1)})
        if not scrolling and self.overlay.at_end():
            self._set_status("Naskah sudah sampai akhir. Tekan AWAL untuk mengulang.")

    def _on_progress(self, elapsed: float, total: float) -> None:
        self.readout.setText(format_clock(max(0.0, total - elapsed)))
        self.readout_sub.setText(f"TERSISA · TOTAL {format_clock(total)}")
        now = time.monotonic()
        if self.overlay.is_scrolling() and now - self._last_progress_event >= PROGRESS_EVENT_SECONDS:
            self._last_progress_event = now
            self.extensions.broadcast("playback.progress", {"elapsed": round(elapsed, 1), "total": round(total, 1)})
        if self.config.speed_mode == "duration":
            self._update_speed_note()

    def _update_tally(self) -> None:
        if not self.overlay.isVisible():
            state, label = "off", "Overlay mati"
        elif self.overlay.is_scrolling():
            state, label = "live", "Menggulir"
        else:
            state, label = "standby", "Siap"
        self.tally.setState(state)
        self.tally_label.setText(label.upper())

    def _go_diag(self) -> None:
        self._go_page(3)

    # ============================================================== the editor
    def _snapshot_now(self, *, force: bool = False) -> None:
        try:
            self.draft.snapshot(self.editor.toPlainText(), force=force)
        except OSError as exc:
            LOGGER.warning("Snapshot draf gagal: %s", exc.strerror or exc)

    def _sync_from_editor(self) -> None:
        parsed = parse_script(self.editor.toPlainText())
        self.overlay.set_script(parsed)
        self._sync_stats(parsed)

    def _sync_stats(self, parsed=None) -> None:  # noqa: ANN001
        if parsed is None:
            parsed = parse_script(self.editor.toPlainText())
        seconds = 0 if parsed.words == 0 and parsed.cue_seconds == 0 else max(1, round(parsed_seconds(parsed, self.config.wpm)))
        characters = sum(len(b.text) for b in parsed.blocks if b.kind == "text")
        self.stat_words.setText(f"{parsed.words:,}".replace(",", "."))
        self.stat_chars.setText(f"{characters:,}".replace(",", "."))
        self.stat_time.setText(format_clock(seconds))
        self._last_stats = (parsed.words, characters)
        extras = []
        if parsed.notes_hidden:
            extras.append(f"{parsed.notes_hidden} catatan tersembunyi")
        cues = sum(1 for b in parsed.blocks if b.kind == "cue")
        if cues:
            extras.append(f"{cues} jeda ({parsed.cue_seconds:g} dtk)")
        self.stat_extra.setText(" · ".join(extras))

    def _replace_editor_text(self, text: str, *, modified: bool | None = None, snapshot: bool = True) -> None:
        """Replace everything while keeping undo history (unlike ``setPlainText``)."""
        if snapshot:
            self._snapshot_now(force=True)  # a rollback point that survives restarts
        cursor = self.editor.textCursor()
        cursor.beginEditBlock()
        cursor.select(QTextCursor.SelectionType.Document)
        cursor.insertText(text)
        cursor.endEditBlock()
        self.editor.setTextCursor(cursor)
        self.editor.moveCursor(QTextCursor.MoveOperation.Start)
        if modified is not None:
            self.editor.document().setModified(modified)
        self._sync_from_editor()
        self._save_draft()

    def open_history(self) -> None:
        self._snapshot_now(force=False)
        dialog = SnapshotDialog(self.draft, self)
        dialog.restoreRequested.connect(self._restore_snapshot)
        dialog.exec()

    def _restore_snapshot(self, name: str) -> None:
        try:
            text = self.draft.load_snapshot(name)
        except ScriptFileError as exc:
            QMessageBox.warning(self, APP_NAME, str(exc))
            return
        self._replace_editor_text(text)
        self.editor.document().setModified(True)
        self._set_status("Naskah dipulihkan dari riwayat draf. Ctrl+Z mengembalikan isi sebelumnya.")

    # ================================================================ theme/help
    def _resolve_palette(self) -> str:
        choice = self.config.theme
        if choice == "system":
            scheme = QGuiApplication.styleHints().colorScheme()
            return "light" if scheme == Qt.ColorScheme.Light else "dark"
        return choice if choice in theme.PALETTES else "dark"

    def _extension_palette(self) -> theme.Palette | None:
        key = self.config.theme_ext
        if not key:
            return None
        for ext_key, _label, definition in self.extensions.themes():
            if ext_key == key:
                return theme.palette_from_extension(definition.base, definition.colors)
        return None

    def _apply_theme(self) -> None:
        self._palette_key = (self.config.theme, self.config.theme_ext, self._resolve_palette())
        palette = theme.use_palette(self._extension_palette() or self._resolve_palette())
        app = QApplication.instance()
        if isinstance(app, QApplication):
            app.setStyle("Fusion")
        self.setStyleSheet(theme.build_stylesheet(palette))
        self.highlighter.refresh_colors()
        for widget in (self.position_picker, self.tally):
            widget.update()

    def _on_color_scheme_changed(self, *_args) -> None:
        if self.config.theme == "system":
            self._apply_theme()

    def _update_hint(self) -> None:
        s = self.config.shortcuts
        self.hint_label.setText(
            f"Pintasan (saat jendela ini terfokus): {s['toggle_scroll']} mulai/jeda · {s['speed_up']}/{s['speed_down']} kecepatan · "
            f"{s['reset_scroll']} awal · {s['hide_overlay']} sembunyikan. Di atas aplikasi lain, pakai tombol di overlay."
        )
        self.show_hint.setText(s["show_overlay"])
        self.play_hint.setText(s["toggle_scroll"])
        self.reset_hint.setText(s["reset_scroll"])
        self.hide_hint.setText(s["hide_overlay"])

    def show_diagnostics(self) -> None:
        self._go_page(3)
        self._update_report()

    def show_about(self) -> None:
        dialog = AboutDialog(f"sesi {classify_session()} · backend Qt {self.backend}", self)

        def open_support() -> None:
            dialog.accept()
            self.show_support()

        dialog.supportRequested.connect(open_support)
        dialog.exec()

    def show_support(self) -> None:
        SupportDialog(self).exec()

    # =============================================================== extensions
    def _presets_map(self) -> dict[str, tuple[str, str, int]]:
        merged = dict(COLOR_PRESETS)
        for name, preset in self.extensions.presets().items():
            merged.setdefault(name, (preset.text_color, preset.background_color, preset.background_opacity))
        return merged

    def _refresh_presets(self) -> None:
        self.preset_combo.blockSignals(True)
        self.preset_combo.clear()
        self.preset_combo.addItems([_CUSTOM_PRESET, *self._presets_map()])
        self.preset_combo.blockSignals(False)
        self._sync_preset_combo()

    def _refresh_ext_themes(self) -> None:
        self.ext_theme_combo.blockSignals(True)
        self.ext_theme_combo.clear()
        self.ext_theme_combo.addItem("Tidak dipakai", "")
        for key, label, _definition in self.extensions.themes():
            self.ext_theme_combo.addItem(label, key)
        index = self.ext_theme_combo.findData(self.config.theme_ext)
        self.ext_theme_combo.setCurrentIndex(max(0, index))
        self.ext_theme_combo.blockSignals(False)

    def _on_ext_theme_chosen(self, _index: int) -> None:
        self.config.theme_ext = self.ext_theme_combo.currentData() or ""
        self._apply_theme()
        self._schedule_config_save()

    def _on_extensions_changed(self) -> None:
        if self.config.theme_ext and not any(key == self.config.theme_ext for key, _label, _d in self.extensions.themes()):
            if not self.extensions.refreshing:
                self.config.theme_ext = ""  # the extension was disabled or removed: fall back to the built-in theme
                self._schedule_config_save()
        self._refresh_presets()
        self._refresh_profiles()
        self._refresh_ext_themes()
        self._rebuild_extensions_menu()
        self._rebuild_templates_menu()
        if (self.config.theme, self.config.theme_ext, self._resolve_palette()) != self._palette_key:
            self._apply_theme()
        if not self._extensions_started and not self.extensions.refreshing:
            self._extensions_started = True
            self.extensions.broadcast("app.started", {"version": __version__})

    def _rebuild_templates_menu(self) -> None:
        menu = self.templates_menu
        menu.clear()
        templates = self.extensions.templates()
        menu.setEnabled(bool(templates))
        for ext_name, template in templates:
            action = menu.addAction(f"{template.name} · {ext_name}")
            action.triggered.connect(lambda _checked=False, text=template.text: self._apply_template(text))

    def _apply_template(self, text: str) -> None:
        if not self._confirm_discard("Naskah dari templat"):
            return
        self.current_file = None
        self._replace_editor_text(text, modified=False)
        self._update_title()
        self._set_status("Templat dimuat. Ctrl+Z mengembalikan isi sebelumnya.")

    def _rebuild_extensions_menu(self) -> None:
        menu = self.extensions_menu
        menu.clear()
        commands = self.extensions.commands()
        grouped: dict[str, list[Command]] = {}
        for command in commands:
            grouped.setdefault(command.ext_name, []).append(command)
        if not grouped:
            placeholder = menu.addAction("Belum ada perintah dari ekstensi aktif")
            placeholder.setEnabled(False)
        for ext_name, items in grouped.items():
            header = menu.addAction(ext_name.upper())
            header.setEnabled(False)
            for command in items:
                if command.kind in {"transform", "action"}:
                    action = menu.addAction(f"    {command.label}")
                    action.triggered.connect(lambda _checked=False, c=command: self._run_ext_command(c))
        for kind, title in (("importer", "Impor naskah dari…"), ("exporter", "Ekspor naskah ke…")):
            entries = [c for c in commands if c.kind == kind]
            if entries:
                menu.addSeparator()
                submenu = menu.addMenu(title)
                for command in entries:
                    action = submenu.addAction(f"{command.label} ({command.ext_name})")
                    action.triggered.connect(lambda _checked=False, c=command: self._run_ext_command(c))
        menu.addSeparator()
        cancel = menu.addAction("Batalkan perintah ekstensi yang berjalan")
        cancel.setEnabled(self.extensions.busy())
        cancel.triggered.connect(self.extensions.cancel_call)
        menu.addAction("Kelola ekstensi…").triggered.connect(lambda: self._go_page(EXTENSIONS_PAGE))
        menu.addAction("Muat ulang ekstensi").triggered.connect(self.extensions.refresh)

    def _emit_script_changed(self) -> None:
        words, characters = self._last_stats
        self.extensions.broadcast("script.changed", {"words": words, "characters": characters})

    def _run_ext_command(self, command: Command) -> None:
        if self.extensions.busy():
            self._set_status("Masih ada perintah ekstensi yang berjalan. Tunggu atau batalkan lewat menu Ekstensi.")
            return
        if command.kind == "transform":
            self._run_text_command(command, "transform")
        elif command.kind == "action":
            self._run_text_command(command, "action")
        elif command.kind == "importer":
            self._run_importer(command)
        elif command.kind == "exporter":
            self._run_exporter(command)

    def _run_text_command(self, command: Command, method: str) -> None:
        cursor = self.editor.textCursor()
        full = self.editor.toPlainText()
        if cursor.hasSelection() and method == "transform":
            start, end = cursor.selectionStart(), cursor.selectionEnd()
            original = full[start:end]
        else:
            start, end, original = 0, len(full), full
        if len(original.encode("utf-8")) > 5_000_000:
            self._set_status("Naskah terlalu besar untuk dikirim ke ekstensi (maksimal 5 MB).")
            return

        def done(result: Any) -> None:
            result = result if isinstance(result, dict) else {}
            if method == "transform":
                text = result.get("text")
                if isinstance(text, str):
                    self._apply_extension_text(command, full, start, end, text)
                return
            if isinstance(result.get("notify"), str):
                self._set_status(f"[{command.ext_name}] {result['notify']}")
            if isinstance(result.get("set_text"), str):
                self._apply_extension_text(command, full, 0, len(full), result["set_text"])

        self._set_status(f"Menjalankan “{command.label}” ({command.ext_name})…")
        self.extensions.call_async(command.ext_id, method, {"id": command.command_id, "text": original}, done, self._extension_failed,
                                   on_cancel=lambda: self._set_status("Perintah ekstensi dibatalkan. Naskah tidak berubah."))

    def _apply_extension_text(self, command: Command, before: str, start: int, end: int, new_text: str) -> None:
        if self.editor.toPlainText() != before:
            self._set_status("Naskah berubah saat ekstensi bekerja, jadi hasilnya tidak diterapkan. Jalankan lagi.")
            return
        if len(new_text.encode("utf-8")) > 5_000_000:
            self._set_status("Hasil ekstensi terlalu besar (maksimal 5 MB) dan tidak diterapkan.")
            return
        self._snapshot_now(force=True)
        cursor = QTextCursor(self.editor.document())
        cursor.setPosition(start)
        cursor.setPosition(end, QTextCursor.MoveMode.KeepAnchor)
        cursor.beginEditBlock()
        cursor.insertText(new_text)
        cursor.endEditBlock()
        self.editor.document().setModified(True)
        self._set_status(f"“{command.label}” diterapkan. Ctrl+Z membatalkan.")

    def _extension_failed(self, message: str) -> None:
        self._set_status("Perintah ekstensi gagal.")
        QMessageBox.warning(self, "Ekstensi", message)

    def _run_importer(self, command: Command) -> None:
        patterns = " ".join(f"*{ext}" for ext in command.extensions) or "*"
        start = self.config.last_directory if self.config.last_directory and Path(self.config.last_directory).is_dir() else str(Path.home())
        filename, _ = QFileDialog.getOpenFileName(self, f"Impor — {command.label}", start, f"{command.label} ({patterns});;Semua berkas (*)")
        if not filename or not self._confirm_discard("Impor naskah"):
            return

        def done(result: Any) -> None:
            text = result.get("text") if isinstance(result, dict) else None
            if not isinstance(text, str) or len(text.encode("utf-8")) > 5_000_000:
                self._set_status("Ekstensi tidak mengembalikan teks yang valid (atau terlalu besar).")
                return
            self.current_file = None
            self._replace_editor_text(text, modified=False)
            self._update_title()
            self._set_status(f"Naskah diimpor lewat “{command.label}”. Ctrl+Z mengembalikan isi sebelumnya.")

        self._set_status(f"Mengimpor lewat “{command.label}”…")
        self.extensions.call_async(command.ext_id, "import", {"id": command.command_id, "path": filename}, done, self._extension_failed)

    def _run_exporter(self, command: Command) -> None:
        suffix = command.extension if command.extension.startswith(".") else ""
        start = Path(self.config.last_directory or Path.home()) / f"naskah{suffix}"
        filename, _ = QFileDialog.getSaveFileName(self, f"Ekspor — {command.label}", str(start))
        if not filename:
            return
        text = self.editor.toPlainText()
        self._set_status(f"Mengekspor lewat “{command.label}”…")
        self.extensions.call_async(
            command.ext_id, "export", {"id": command.command_id, "text": text, "path": filename},
            lambda _r: self._set_status(f"Naskah diekspor ke {Path(filename).name}. Berkas ditulis oleh ekstensi."), self._extension_failed,
        )

    # ================================================================ closing
    def closeEvent(self, event) -> None:  # noqa: N802
        if not self._confirm_discard(f"Keluar dari {APP_NAME}"):
            event.ignore()
            return
        for timer in (self.sync_timer, self.draft_timer, self.config_timer, self.snapshot_timer, self.changed_event_timer, self.stop_timer, self.delay_timer, self.countdown_timer):
            timer.stop()
        self._read_widgets_into_config()
        if not (self.isMaximized() or self.isFullScreen()):
            self.config.window_width, self.config.window_height = self.width(), self.height()
        self._save_draft()
        self._snapshot_now(force=True)
        self._save_config()
        self.drive.cancel()
        self.extensions.broadcast("app.closing", {})
        self.extensions.cancel_call()
        self.extensions.shutdown()
        self.overlay.pause_scrolling()
        self.overlay.close()
        super().closeEvent(event)

    def _timer(self, interval: int, slot) -> QTimer:
        timer = QTimer(self)
        timer.setSingleShot(True)
        if interval:
            timer.setInterval(interval)
        timer.timeout.connect(slot)
        return timer

    def _action(self, text: str, slot, shortcut: str | QKeySequence.StandardKey | None = None) -> QAction:
        action = QAction(text, self)
        action.triggered.connect(slot)
        if shortcut:
            action.setShortcut(QKeySequence(shortcut))
        return action

    def new_script(self) -> None:
        if not self._confirm_discard("Naskah baru"):
            return
        self.current_file = None
        self._replace_editor_text("", modified=False)
        self._update_title()
        self._set_status("Naskah baru dimulai. Naskah sebelumnya masih bisa dikembalikan dengan Ctrl+Z.")

    def open_file(self) -> None:
        if not self._confirm_discard("Buka naskah"):
            return
        start = self.config.last_directory if self.config.last_directory and Path(self.config.last_directory).is_dir() else str(Path.home())
        filename, _ = QFileDialog.getOpenFileName(self, "Buka naskah", start, "Berkas teks (*.txt *.md);;Semua berkas (*)")
        if not filename:
            return
        try:
            text = read_script(Path(filename))
        except ScriptFileError as exc:
            QMessageBox.warning(self, APP_NAME, str(exc))
            return
        self.current_file = Path(filename)
        self.config.last_directory = str(self.current_file.parent)
        self._replace_editor_text(text, modified=False)
        self._update_title()
        self._schedule_config_save()
        self._set_status(f"Naskah dibuka: {self.current_file.name}")
        self.extensions.broadcast("script.opened", {"name": self.current_file.name})

    def save_file(self) -> bool:
        if self.current_file is None:
            return self.save_file_as()
        return self._write_file(self.current_file)

    def save_file_as(self) -> bool:
        start = self.current_file or Path(self.config.last_directory or Path.home()) / "naskah.txt"
        filename, selected = QFileDialog.getSaveFileName(self, "Simpan naskah", str(start), "Berkas teks (*.txt);;Markdown (*.md)")
        if not filename:
            return False
        path = Path(filename)
        if not path.suffix:
            path = path.with_suffix(".md" if "md" in selected else ".txt")
        if self._write_file(path):
            self.current_file = path
            self.config.last_directory = str(path.parent)
            self._update_title()
            self._schedule_config_save()
            return True
        return False

    def _write_file(self, path: Path) -> bool:
        try:
            atomic_write_text(path, self.editor.toPlainText(), mode=0o644)
        except OSError as exc:
            QMessageBox.warning(self, APP_NAME, f"Tidak dapat menyimpan berkas.\n\n{exc.strerror or exc}")
            return False
        self.editor.document().setModified(False)
        self._set_status(f"Naskah disimpan: {path.name}")
        self.extensions.broadcast("script.saved", {"name": path.name})
        return True

    def open_library(self) -> None:
        dialog = ScriptLibraryDialog(self.library, self.editor.toPlainText(), self)
        dialog.openRequested.connect(self._open_from_library)
        dialog.exec()

    def _open_from_library(self, name: str) -> None:
        if not self._confirm_discard("Buka naskah lokal"):
            return
        try:
            text = self.library.load(name)
        except ScriptFileError as exc:
            QMessageBox.warning(self, APP_NAME, str(exc))
            return
        self.current_file = None
        self._replace_editor_text(text, modified=False)
        self._update_title()
        self._set_status(f"Naskah lokal dibuka: {name}")

    def _update_title(self) -> None:
        modified = self.editor.document().isModified()
        name = self.current_file.name if self.current_file else "tanpa berkas"
        self.file_label.setText(f"{name}{' • belum disimpan' if modified else ''}")
        self.setWindowTitle(f"{APP_NAME} {VERSION_LABEL} — {name}{'*' if modified else ''}")

    def open_ai_assistant(self) -> None:
        c = self.config
        key = os.environ.get("SOROT_API_KEY", "").strip() or self.session_api_key or keyring_service.get_api_key()
        context = AIContext(
            base_url=c.ai_base_url, model=c.ai_model, timeout=c.ai_timeout, api_key=key, wpm=c.wpm,
            keyring_available=keyring_service.is_available(), keyring_saved=keyring_service.has_saved_key(),
            confirm_send=self._confirm_ai_send, save_settings=self._save_ai_settings,
            remember_session_key=lambda value: setattr(self, "session_api_key", value),
            save_key=self._save_ai_key, delete_key=self._delete_ai_key, extra_tasks=self.extensions.ai_tasks(),
        )
        dialog = AIAssistantDialog(self.editor.toPlainText(), context, self)
        dialog.applyRequested.connect(self._apply_ai_result)
        dialog.exec()

    def _confirm_ai_send(self, host: str, characters: int) -> bool:
        if host in _LOOPBACK or host in self.config.ai_confirmed_hosts:
            return True
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Icon.Warning)
        box.setWindowTitle("Kirim naskah ke layanan AI?")
        box.setText(f"Naskah ({characters:,} karakter) akan dikirim melalui internet ke:\n\n{host}".replace(",", "."))
        box.setInformativeText(
            "Penyedia dapat memproses data sesuai kebijakannya dan pemakaian API dapat berbayar. Jangan kirim informasi rahasia atau data pribadi sensitif."
        )
        remember = QCheckBox("Jangan tanya lagi untuk layanan ini")
        box.setCheckBox(remember)
        send = box.addButton("Kirim", QMessageBox.ButtonRole.AcceptRole)
        cancel = box.addButton("Batal", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(cancel)
        box.setEscapeButton(cancel)
        box.exec()
        if box.clickedButton() is not send:
            return False
        if remember.isChecked():
            self.config.ai_confirmed_hosts = sorted({*self.config.ai_confirmed_hosts, host})
            self._schedule_config_save()
        return True

    def _save_ai_settings(self, base_url: str, model: str, timeout: int) -> None:
        self.config.ai_base_url, self.config.ai_model, self.config.ai_timeout = base_url, model, timeout
        self._schedule_config_save()

    def _save_ai_key(self, key: str) -> tuple[bool, str]:
        try:
            keyring_service.save_api_key(key)
            return True, ""
        except Exception as exc:  # noqa: BLE001
            LOGGER.warning("Penyimpanan API key ke keyring gagal: %s", type(exc).__name__)
            return False, "API key tidak dapat disimpan di keyring yang aman. Key hanya berlaku sampai aplikasi ditutup dan tidak ditulis ke berkas."

    def _delete_ai_key(self) -> bool:
        self.session_api_key = ""
        return keyring_service.delete_api_key()

    def _apply_ai_result(self, mode: str, text: str) -> None:
        if mode == "replace":
            self._replace_editor_text(text)
        else:
            current = self.editor.toPlainText().rstrip()
            self._replace_editor_text((current + "\n\n" + text).strip() if current else text)
        self.editor.document().setModified(True)

    def _schedule_config_save(self) -> None:
        if not self._loading:
            self.config_timer.start()

    def _save_config(self) -> None:
        self.config_timer.stop()
        try:
            self.store.save(self.config)
        except OSError as exc:
            if not self._save_error_shown:
                self._save_error_shown = True
                self._set_status(f"Peringatan: pengaturan tidak dapat disimpan ({exc.strerror or exc}).")

    def restore_settings_backup(self) -> None:
        if QMessageBox.question(
            self, "Pulihkan pengaturan", "Ganti pengaturan sekarang dengan cadangan terakhir? Pengaturan saat ini akan hilang.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No,
        ) != QMessageBox.StandardButton.Yes:
            return
        if not self.store.restore_backup():
            QMessageBox.information(self, APP_NAME, "Belum ada cadangan pengaturan yang valid.")
            return
        self.config = self.store.load().config
        self._loading = True
        self._apply_config_to_widgets()
        self._loading = False
        self._apply_theme()
        self._apply_shortcuts()
        self._apply_overlay_config()
        self._place_overlay()
        self._set_status("Pengaturan dipulihkan dari cadangan.")

    def edit_shortcuts(self) -> None:
        dialog = ShortcutsDialog(self.config.shortcuts, self)
        if dialog.exec():
            self.config.shortcuts = dialog.values()
            self._apply_shortcuts()
            self._update_hint()
            self._schedule_config_save()

    def _apply_shortcuts(self) -> None:
        for key, action in self.overlay_actions.items():
            action.setShortcut(QKeySequence(self.config.shortcuts.get(key, "")))
        self._update_hint()

    def _refresh_screens(self) -> None:
        self.screen_combo.blockSignals(True)
        self.screen_combo.clear()
        for index, screen in enumerate(QApplication.screens()):
            area = screen.availableGeometry()
            self.screen_combo.addItem(f"Layar {index + 1} — {screen.name()} ({area.width()}×{area.height()})", screen.name())
        wanted = self.screen_combo.findData(self.config.screen_name)
        self.screen_combo.setCurrentIndex(wanted if wanted >= 0 else 0)
        self.screen_combo.blockSignals(False)

    def _on_screens_changed(self, *_args) -> None:
        self._refresh_screens()
        self._place_overlay()
        self._set_status("Konfigurasi layar berubah; posisi overlay disesuaikan.")

    def _update_capability_note(self) -> None:
        lines = []
        for key in ("position", "always_on_top", "click_through"):
            item = capability(self.capabilities, key)
            if item.support in (Support.UNSUPPORTED, Support.LIMITED, Support.UNKNOWN):
                lines.append(f"• {item.label}: {item.support.value}. {item.note}")
        self.capability_note.setText(
            "\n".join(lines) if lines else f"Backend {self.backend}: semua kontrol jendela umumnya didukung. Hasil tetap bergantung pada desktop-mu."
        )

    def _update_report(self) -> None:
        self.report_view.setPlainText(format_platform_report(self.backend))

    def copy_report(self) -> None:
        QApplication.clipboard().setText(format_platform_report(self.backend))
        self._set_status("Laporan diagnostik disalin. Periksa isinya sebelum membagikannya.")

    def show_compatibility_help(self) -> None:
        text = (
            f"Sesi: {classify_session()}\nBackend Qt: {self.backend}\n\n"
            "• X11/XWayland: posisi, selalu-di-atas, dan klik-tembus umumnya bisa dikontrol.\n"
            "• Wayland asli: compositor menentukan posisi jendela; selalu-di-atas tidak dijamin; geser dan ubah ukuran memakai fitur compositor.\n\n"
            "Uji dengan menampilkan overlay di atas aplikasi biasa. Jika perilakunya tidak sesuai, ubah “Backend Qt” di tab Sistem, atau jalankan dari terminal:\n\n"
            "  SOROT_QT_PLATFORM=xcb sorot\n  SOROT_QT_PLATFORM=wayland sorot\n\n"
            "Tutup semua proses aplikasi sebelum mencoba mode lain. Overlay bisa ikut tertangkap saat layar dibagikan atau direkam."
        )
        QMessageBox.information(self, "Panduan overlay dan kompatibilitas", text)

    def _selected_screen(self):
        screens = QApplication.screens()
        name = self.screen_combo.currentData()
        for screen in screens:
            if screen.name() == name:
                return screen
        return QApplication.primaryScreen()

    def _place_overlay(self) -> None:
        screen = self._selected_screen()
        if screen is None:
            return
        area = screen.availableGeometry()
        width = min(self.config.overlay_width, max(300, area.width() - 24))
        height = min(self.config.overlay_height, max(100, area.height() - 24))
        margin = 24
        position = self.config.position
        x = area.x() + (area.width() - width) // 2
        y = area.y() + margin
        if position == "manual":
            saved = (self.config.overlay_x, self.config.overlay_y)
            if saved[0] is not None and saved[1] is not None and self._is_visible_on_some_screen(QRect(saved[0], saved[1], width, height)):
                x, y = saved
        elif position in {"top-left", "bottom-left"}:
            x = area.x() + margin
        elif position in {"top-right", "bottom-right"}:
            x = area.x() + area.width() - width - margin
        if position.startswith("bottom"):
            y = area.y() + area.height() - height - margin
        elif position == "center":
            y = area.y() + (area.height() - height) // 2
        self.overlay.apply_geometry(QRect(x, y, width, height))

    @staticmethod
    def _is_visible_on_some_screen(rect: QRect) -> bool:
        return any(screen.availableGeometry().intersected(rect).width() >= 80 and screen.availableGeometry().intersected(rect).height() >= 40
                   for screen in QApplication.screens())

    def _on_overlay_geometry_changed(self) -> None:
        rect = self.overlay.geometry()
        for spin, value in ((self.width_spin, rect.width()), (self.height_spin, rect.height())):
            spin.blockSignals(True)
            spin.setValue(max(spin.minimum(), min(spin.maximum(), value)))
            spin.blockSignals(False)
        self.config.overlay_width, self.config.overlay_height = self.width_spin.value(), self.height_spin.value()
        if capability(self.capabilities, "position").support is not Support.UNSUPPORTED:
            self.config.position = "manual"
            self.config.overlay_x, self.config.overlay_y = rect.x(), rect.y()
            self.position_picker.blockSignals(True)
            self.position_picker.setValue("manual")
            self.position_picker.blockSignals(False)
        self._schedule_config_save()

    def _confirm_discard(self, action: str) -> bool:
        """Ask before an action that would replace unsaved work. True = go on."""
        if not (self.editor.document().isModified() and self.editor.toPlainText().strip()):
            return True
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Icon.Warning)
        box.setWindowTitle(action)
        box.setText("Naskah punya perubahan yang belum disimpan ke berkas.")
        box.setInformativeText("Simpan dulu sebelum melanjutkan?")
        save = box.addButton("Simpan", QMessageBox.ButtonRole.AcceptRole)
        discard = box.addButton("Lanjutkan tanpa menyimpan", QMessageBox.ButtonRole.DestructiveRole)
        cancel = box.addButton("Batal", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(save)
        box.setEscapeButton(cancel)
        box.exec()
        clicked = box.clickedButton()
        if clicked is save:
            return self.save_file()
        return clicked is discard

    def _save_draft(self) -> None:
        self.draft_timer.stop()
        try:
            self.draft.save(self.editor.toPlainText())
        except OSError as exc:
            if not self._save_error_shown:
                self._save_error_shown = True
                self._set_status(f"Peringatan: draf otomatis tidak dapat disimpan ({exc.strerror or exc}). Simpan naskah ke berkas secara manual.")

    def _startup_status(self) -> str:
        parts = [f"Siap · sesi {classify_session()} · backend Qt {self.backend}. AI dan Drive bersifat opsional."]
        if self.backend.startswith("wayland"):
            parts.append("Pada Wayland asli posisi overlay ditentukan compositor dan selalu-di-atas tidak dijamin.")
        elif self.backend == "xcb" and classify_session() == "wayland":
            parts.append("Overlay berjalan lewat XWayland agar posisi dapat dikontrol.")
        parts.extend(self._notices)
        return " ".join(parts)

    def _set_status(self, message: str) -> None:
        self.status_label.setText(message)

    def _restart_auto_stop(self) -> None:
        self.stop_timer.stop()
        if self.config.auto_stop_minutes > 0:
            self.stop_timer.start(self.config.auto_stop_minutes * 60_000)

    def _auto_stop(self) -> None:
        self.overlay.pause_scrolling()
        self._set_status("Waktu selesai. Overlay tetap tampil; gulir dihentikan.")

    def _cancel_start_delay(self) -> None:
        """Stop the start delay and take the countdown off the overlay."""
        self.delay_timer.stop()
        self.countdown_timer.stop()
        self._countdown_left = 0
        self.overlay.hide_countdown()

    def _countdown_tick(self) -> None:
        self._countdown_left -= 1
        if self._countdown_left > 0 and self.overlay.isVisible():
            self.overlay.show_countdown(self._countdown_left)
        else:
            self.countdown_timer.stop()
            self.overlay.hide_countdown()

    def _delayed_start(self) -> None:
        self.countdown_timer.stop()
        self.overlay.hide_countdown()
        if self.overlay.isVisible():
            self.overlay.start_scrolling()
            self._set_status("Gulir otomatis berjalan.")

    # =============================================================== display profiles
    def _refresh_profiles(self) -> None:
        """Rebuild the profile list (built-in + extensions + the user's files) and select the matching entry."""
        self._profiles = profiles.all_profiles(self.extensions.display_profiles())
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        self.profile_combo.addItem(_CUSTOM_PROFILE, "")
        for name, (source, _profile) in self._profiles.items():
            self.profile_combo.addItem(f"{name} (milikmu)" if source == "pengguna" else name, name)
        self.profile_combo.blockSignals(False)
        self._sync_profile_combo()

    def _matching_profile(self) -> str:
        """Name of the profile whose values equal the current settings ('' if none). Prefers the last applied one."""
        c = self.config
        names = list(self._profiles)
        if c.profile in self._profiles:
            names.insert(0, c.profile)
        for name in names:
            if all(getattr(c, key) == value for key, value in self._profiles[name][1].values.items()):
                return name
        return ""

    def _sync_profile_combo(self) -> None:
        name = self._matching_profile()
        self.profile_combo.blockSignals(True)
        self.profile_combo.setCurrentIndex(max(0, self.profile_combo.findData(name)) if name else 0)
        self.profile_combo.blockSignals(False)
        entry = self._profiles.get(name)
        if entry is None:
            self.profile_note.setText("Pengaturan sekarang tidak sama dengan profil mana pun. Simpan agar bisa dipakai lagi atau dibagikan.")
        else:
            source, profile = entry
            self.profile_note.setText(f"{profile.description or 'Tanpa keterangan.'}  [{source}]")
        self.profile_delete_btn.setEnabled(entry is not None and entry[0] == "pengguna")

    def _on_profile_chosen(self, _index: int) -> None:
        name = self.profile_combo.currentData()
        entry = self._profiles.get(name) if name else None
        if entry is None:
            return
        changed = profiles.apply_profile(entry[1], self.config)
        self._apply_config_to_widgets()
        self._apply_overlay_config()
        if self.overlay.isVisible() or self.config.position != "manual":
            self._place_overlay()
        self._schedule_config_save()
        self._set_status(f"Profil “{name}” diterapkan ({len(changed)} pengaturan berubah).")

    def _save_profile(self) -> None:
        self._read_widgets_into_config()
        suggestion = self.config.profile if self._profiles.get(self.config.profile, ("", None))[0] == "pengguna" else ""
        name, accepted = QInputDialog.getText(self, "Simpan profil tampilan", "Nama profil:", text=suggestion)
        if not accepted:
            return
        try:
            profile = profiles.from_config(self.config, name)
            existing = self._profiles.get(profile.name)
            if existing is not None and existing[0] == "pengguna" and QMessageBox.question(
                self, "Ganti profil?", f"Profil “{profile.name}” sudah ada. Ganti dengan tampilan sekarang?",
            ) != QMessageBox.StandardButton.Yes:
                return
            profiles.save_user_profile(profile)
        except (profiles.ProfileError, OSError) as exc:
            QMessageBox.warning(self, "Profil tampilan", str(exc))
            return
        self.config.profile = profile.name
        self._refresh_profiles()
        self._schedule_config_save()
        self._set_status(f"Profil “{profile.name}” disimpan.")

    def _import_profile(self) -> None:
        path, _filter = QFileDialog.getOpenFileName(self, "Impor profil tampilan", self.config.last_directory, "Profil Sorot (*.json);;Semua berkas (*)")
        if not path:
            return
        try:
            profile = profiles.read_file(Path(path))
            profiles.save_user_profile(profile)
        except (profiles.ProfileError, OSError) as exc:
            QMessageBox.warning(self, "Profil tampilan", str(exc))
            return
        self._refresh_profiles()
        note = f" Kunci tak dikenal diabaikan: {', '.join(profile.ignored)}." if profile.ignored else ""
        self._set_status(f"Profil “{profile.name}” ditambahkan. Pilih dari daftar untuk memakainya.{note}")

    def _export_profile(self) -> None:
        self._read_widgets_into_config()
        name = self._matching_profile()
        profile = self._profiles[name][1] if name else profiles.from_config(self.config, "Profil saya", "Diekspor dari tampilan saat ini.")
        path, _filter = QFileDialog.getSaveFileName(self, "Ekspor profil tampilan", f"{profile.name}.json", "Profil Sorot (*.json)")
        if not path:
            return
        target = Path(path if path.lower().endswith(".json") else path + ".json")
        try:
            profiles.write_file(profile, target)
        except OSError as exc:
            QMessageBox.warning(self, "Profil tampilan", f"Tidak dapat menulis berkas: {exc}")
            return
        self._set_status(f"Profil “{profile.name}” diekspor ke {target.name}.")

    def _delete_profile(self) -> None:
        name = self._matching_profile()
        entry = self._profiles.get(name)
        if entry is None or entry[0] != "pengguna":
            return
        if QMessageBox.question(self, "Hapus profil?", f"Hapus profil “{name}”? Pengaturan yang sedang dipakai tidak berubah.") != QMessageBox.StandardButton.Yes:
            return
        profiles.delete_user_profile(name)
        if self.config.profile == name:
            self.config.profile = ""
        self._refresh_profiles()
        self._schedule_config_save()
        self._set_status(f"Profil “{name}” dihapus.")

    def _on_preset_chosen(self, _index: int) -> None:
        preset = self._presets_map().get(self.preset_combo.currentText())
        if preset is None:
            return
        text, background, opacity = preset
        for widget in (self.text_color_btn, self.bg_color_btn, self.opacity_slider):
            widget.blockSignals(True)
        self.text_color_btn.set_color(text)
        self.bg_color_btn.set_color(background)
        self.opacity_slider.setValue(opacity)
        for widget in (self.text_color_btn, self.bg_color_btn, self.opacity_slider):
            widget.blockSignals(False)
        self._on_setting_changed()

    def _sync_preset_combo(self) -> None:
        current = (self.text_color_btn.color.upper(), self.bg_color_btn.color.upper(), self.opacity_slider.value())
        name = next((n for n, (t, b, o) in self._presets_map().items() if (t.upper(), b.upper(), o) == current), _CUSTOM_PRESET)
        self.preset_combo.setCurrentText(name)

    def _on_text_changed(self) -> None:
        self.sync_timer.start()
        self.draft_timer.start()
        self.snapshot_timer.start()
        self.changed_event_timer.start()
