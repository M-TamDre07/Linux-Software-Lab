"""Manifest parsing and validation. Invalid *entries* are dropped and reported; an invalid
*manifest* (bad id, unsupported API, unsafe entry path) makes the extension unusable."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from sorot import __version__
from sorot.core.profiles import DisplayProfile, ProfileError, make_profile
from sorot.extensions import API_VERSION, MANIFEST_NAME

MAX_MANIFEST_BYTES = 256_000
ID_PATTERN = re.compile(r"[a-z0-9][a-z0-9._-]{2,63}")
ITEM_ID_PATTERN = re.compile(r"[a-z0-9][a-z0-9._-]{0,47}")
HEX_COLOR = re.compile(r"#[0-9A-Fa-f]{6}")
KNOWN_PERMISSIONS = ("network", "filesystem", "subprocess", "clipboard", "other")
PALETTE_KEYS = (
    "bg", "surface", "raised", "inset", "line", "line_strong", "text", "muted", "faint", "accent", "accent_ink", "live", "ok", "selection",
)
MAX_ITEMS = 50
MAX_TEMPLATE_CHARS = 100_000


class ExtensionError(Exception):
    """A problem with an extension; the message is safe to show to the user."""


@dataclass(frozen=True)
class ThemeDef:
    theme_id: str
    name: str
    base: str
    colors: dict[str, str]


@dataclass(frozen=True)
class PresetDef:
    name: str
    text_color: str
    background_color: str
    background_opacity: int


@dataclass(frozen=True)
class AITaskDef:
    task_id: str
    label: str
    instruction: str


@dataclass(frozen=True)
class TemplateDef:
    name: str
    text: str


@dataclass
class Manifest:
    ext_id: str
    name: str
    version: str
    author: str = ""
    description: str = ""
    homepage: str = ""
    license: str = ""
    entry: str = ""
    permissions: tuple[str, ...] = ()
    themes: list[ThemeDef] = field(default_factory=list)
    presets: list[PresetDef] = field(default_factory=list)
    ai_tasks: list[AITaskDef] = field(default_factory=list)
    templates: list[TemplateDef] = field(default_factory=list)
    profiles: list[DisplayProfile] = field(default_factory=list)
    problems: list[str] = field(default_factory=list)

    @property
    def has_code(self) -> bool:
        return bool(self.entry)

    @property
    def kind(self) -> str:
        return "kode" if self.has_code else "deklaratif"


def _text(value: Any, limit: int) -> str:
    return value.strip()[:limit] if isinstance(value, str) else ""


def _version_tuple(text: str) -> tuple[int, ...]:
    parts = re.findall(r"\d+", text)[:3]
    return tuple(int(p) for p in parts) or (0,)


def parse_manifest(raw: bytes | str, root: Path | None = None) -> Manifest:
    size = len(raw) if isinstance(raw, bytes) else len(raw.encode("utf-8"))
    if size > MAX_MANIFEST_BYTES:
        raise ExtensionError("Manifest terlalu besar.")
    try:
        data = json.loads(raw)
    except (ValueError, UnicodeDecodeError) as exc:
        raise ExtensionError(f"Manifest bukan JSON yang valid: {exc}") from exc
    if not isinstance(data, dict):
        raise ExtensionError("Manifest harus berupa objek JSON.")

    ext_id = data.get("id")
    if not isinstance(ext_id, str) or not ID_PATTERN.fullmatch(ext_id):
        raise ExtensionError("Field “id” wajib: huruf kecil, angka, titik, minus, atau garis bawah (3–64 karakter).")
    name = _text(data.get("name"), 80)
    if not name:
        raise ExtensionError("Field “name” wajib diisi.")
    api = data.get("api")
    if api != API_VERSION:
        raise ExtensionError(f"Ekstensi ini memakai API {api!r}; aplikasi ini mendukung API {API_VERSION}.")
    version = _text(data.get("version"), 32) or "0"
    min_app = _text(data.get("min_app"), 32)
    if min_app and _version_tuple(min_app) > _version_tuple(__version__):
        raise ExtensionError(f"Membutuhkan Sorot {min_app} atau lebih baru (terpasang {__version__}).")

    manifest = Manifest(ext_id, name, version, author=_text(data.get("author"), 80), description=_text(data.get("description"), 600),
                        license=_text(data.get("license"), 40))
    homepage = _text(data.get("homepage"), 300)
    if homepage:
        parsed = urlparse(homepage)
        if parsed.scheme == "https" and parsed.netloc:
            manifest.homepage = homepage
        else:
            manifest.problems.append("homepage diabaikan: harus URL https.")

    entry = data.get("entry")
    if entry is not None:
        if not isinstance(entry, str) or not entry.endswith(".py"):
            raise ExtensionError("Field “entry” harus berupa nama berkas .py.")
        parts = Path(entry).parts
        if Path(entry).is_absolute() or ".." in parts or "\\" in entry or not parts:
            raise ExtensionError("Field “entry” tidak boleh keluar dari folder ekstensi.")
        if root is not None and not (root / entry).is_file():
            raise ExtensionError(f"Berkas entry “{entry}” tidak ditemukan.")
        manifest.entry = entry

    permissions = data.get("permissions", [])
    if isinstance(permissions, list):
        clean = [p for p in permissions if isinstance(p, str)]
        unknown = [p for p in clean if p not in KNOWN_PERMISSIONS]
        if unknown:
            manifest.problems.append(f"izin tak dikenal diabaikan: {', '.join(unknown[:3])}")
        manifest.permissions = tuple(dict.fromkeys(p for p in clean if p in KNOWN_PERMISSIONS))

    contributes = data.get("contributes", {})
    if isinstance(contributes, dict):
        _parse_contributions(manifest, contributes)
    if not manifest.has_code and not (manifest.themes or manifest.presets or manifest.ai_tasks or manifest.templates or manifest.profiles):
        manifest.problems.append("tidak menyumbangkan apa pun (tanpa entry dan tanpa contributes).")
    return manifest


def _items(contributes: dict, key: str, manifest: Manifest) -> list[dict]:
    value = contributes.get(key, [])
    if not isinstance(value, list):
        manifest.problems.append(f"contributes.{key} harus berupa daftar.")
        return []
    if len(value) > MAX_ITEMS:
        manifest.problems.append(f"contributes.{key}: hanya {MAX_ITEMS} entri pertama dipakai.")
    return [item for item in value[:MAX_ITEMS] if isinstance(item, dict)]


def _parse_contributions(manifest: Manifest, contributes: dict) -> None:
    seen: set[str] = set()
    for item in _items(contributes, "themes", manifest):
        theme_id, name = item.get("id"), _text(item.get("name"), 60)
        colors = item.get("colors")
        base = item.get("base", "dark")
        if not (isinstance(theme_id, str) and ITEM_ID_PATTERN.fullmatch(theme_id) and name and isinstance(colors, dict)) or base not in ("dark", "light"):
            manifest.problems.append(f"tema diabaikan (tidak valid): {name or theme_id!r}")
            continue
        valid = {k: v.upper() for k, v in colors.items() if k in PALETTE_KEYS and isinstance(v, str) and HEX_COLOR.fullmatch(v)}
        if len(valid) != len([k for k in colors if k in PALETTE_KEYS]) or not valid:
            manifest.problems.append(f"tema {name!r}: warna tidak valid diabaikan.")
        if theme_id in seen or not valid:
            continue
        seen.add(theme_id)
        manifest.themes.append(ThemeDef(theme_id, name, base, valid))
    for item in _items(contributes, "overlay_presets", manifest):
        name = _text(item.get("name"), 60)
        text, background, opacity = item.get("text_color"), item.get("background_color"), item.get("background_opacity", 70)
        ok = (name and isinstance(text, str) and HEX_COLOR.fullmatch(text) and isinstance(background, str)
              and HEX_COLOR.fullmatch(background) and isinstance(opacity, int) and not isinstance(opacity, bool) and 0 <= opacity <= 95)
        if not ok:
            manifest.problems.append(f"preset diabaikan (tidak valid): {name!r}")
            continue
        manifest.presets.append(PresetDef(name, str(text).upper(), str(background).upper(), int(opacity)))
    seen_profiles: set[str] = set()
    for item in _items(contributes, "display_profiles", manifest):
        label = _text(item.get("name"), 60)
        try:
            profile = make_profile(item.get("name"), item.get("values"), item.get("description", ""))
        except ProfileError as exc:
            manifest.problems.append(f"profil tampilan diabaikan ({label or '?'}): {exc}")
            continue
        if profile.name in seen_profiles:
            manifest.problems.append(f"profil tampilan ganda diabaikan: {profile.name!r}")
            continue
        seen_profiles.add(profile.name)
        if profile.ignored:
            manifest.problems.append(f"profil {profile.name!r}: kunci tak dikenal diabaikan ({', '.join(profile.ignored)})")
        manifest.profiles.append(profile)
    seen_tasks: set[str] = set()
    for item in _items(contributes, "ai_tasks", manifest):
        task_id, label, instruction = item.get("id"), _text(item.get("label"), 60), _text(item.get("instruction"), 1500)
        if not (isinstance(task_id, str) and ITEM_ID_PATTERN.fullmatch(task_id) and label and instruction) or task_id in seen_tasks:
            manifest.problems.append(f"tugas AI diabaikan (tidak valid atau ganda): {label or task_id!r}")
            continue
        seen_tasks.add(task_id)
        manifest.ai_tasks.append(AITaskDef(task_id, label, instruction))
    for item in _items(contributes, "templates", manifest):
        name, text = _text(item.get("name"), 80), item.get("text")
        if not name or not isinstance(text, str) or len(text) > MAX_TEMPLATE_CHARS:
            manifest.problems.append(f"templat diabaikan (tidak valid): {name!r}")
            continue
        manifest.templates.append(TemplateDef(name, text))


def load_manifest(directory: Path) -> Manifest:
    path = Path(directory) / MANIFEST_NAME
    try:
        if path.is_symlink() or not path.is_file():
            raise ExtensionError(f"{MANIFEST_NAME} tidak ditemukan.")
        if path.stat().st_size > MAX_MANIFEST_BYTES:
            raise ExtensionError("Manifest terlalu besar.")
        return parse_manifest(path.read_bytes(), Path(directory))
    except OSError as exc:
        raise ExtensionError(f"Manifest tidak dapat dibaca: {exc.strerror or exc}") from exc
