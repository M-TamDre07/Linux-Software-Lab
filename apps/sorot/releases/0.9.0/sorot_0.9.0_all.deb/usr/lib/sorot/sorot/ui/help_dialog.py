"""F1: a plain, readable list of every keyboard shortcut (text, so screen readers can read it line by line)."""
from __future__ import annotations

from PySide6.QtWidgets import QDialog, QDialogButtonBox, QLabel, QPlainTextEdit, QVBoxLayout, QWidget

from sorot.core.config import DEFAULT_SHORTCUTS, SHORTCUT_LABELS

FIXED_SHORTCUTS = (
    ("Ctrl+N", "Naskah baru"), ("Ctrl+O", "Buka naskah"), ("Ctrl+L", "Naskah lokal"), ("Ctrl+S", "Simpan"),
    ("Ctrl+Shift+S", "Simpan sebagai / ekspor"), ("Ctrl+Q", "Keluar"),
    ("Ctrl+1 … Ctrl+6", "Pindah ke halaman Naskah, Tampilan, Integrasi, Sistem, Ekstensi, Aksesibilitas"),
    ("Ctrl+Shift+A", "Buka halaman Aksesibilitas"), ("Ctrl+Shift+R", "Bacakan naskah dengan suara"),
    ("Ctrl+Shift+X", "Hentikan suara"), ("F1", "Daftar pintasan ini"),
    ("Tab / Shift+Tab", "Pindah ke kontrol berikutnya / sebelumnya"),
    ("Panah atas / bawah", "Ubah nilai pada kolom angka dan pilihan"),
)


def shortcut_lines(shortcuts: dict[str, str] | None = None) -> list[str]:
    configured = {**DEFAULT_SHORTCUTS, **(shortcuts or {})}
    lines = ["Pintasan overlay (dapat diubah di Sistem › Pintasan keyboard):"]
    lines += [f"  {configured[key]:<18} {SHORTCUT_LABELS[key]}" for key in DEFAULT_SHORTCUTS]
    lines += ["", "Pintasan tetap:"]
    lines += [f"  {keys:<18} {what}" for keys, what in FIXED_SHORTCUTS]
    lines += ["", "Catatan: pintasan overlay hanya bekerja saat jendela Sorot terfokus. Di atas aplikasi lain, pakai tombol di overlay (juga bisa dijangkau dengan Tab)."]
    return lines


class KeyboardHelpDialog(QDialog):
    def __init__(self, shortcuts: dict[str, str] | None = None, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Pintasan keyboard")
        self.setMinimumSize(560, 420)
        layout = QVBoxLayout(self)
        intro = QLabel("Semua fungsi Sorot dapat dijalankan dengan keyboard.")
        intro.setWordWrap(True)
        self.view = QPlainTextEdit("\n".join(shortcut_lines(shortcuts)))
        self.view.setObjectName("mono")
        self.view.setReadOnly(True)
        self.view.setAccessibleName("Daftar pintasan keyboard")
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(self.reject)
        layout.addWidget(intro)
        layout.addWidget(self.view, 1)
        layout.addWidget(buttons)
        self.view.setFocus()
