# Changelog

Format mengikuti [Keep a Changelog](https://keepachangelog.com/id/1.1.0/). Proyek ini masih beta; nomor versi belum menjamin kestabilan API internal.

## [0.7.3 Beta] — 2026-11-02

Rilis kredibilitas paket dan perbaikan tampilan. Tidak ada perubahan skema atau fitur aplikasi.

### Diperbaiki
- **Dialog "Dukung pengembangan" terpotong** (kartu GoPay terjepit, nomor dan tombol terpotong, terlihat pada KDE dengan font lebih besar). Tinggi minimum jendela dihitung tanpa memperhitungkan teks yang membungkus; kini dihitung dari `totalHeightForWidth`, dan baris pesan salin dicadangkan agar tata letak tidak berubah. Tes regresi dengan font diperbesar; gagal bila perbaikan dicabut.

### Ditambahkan
- **Metadata AppStream** (`sorot.metainfo.xml`): pengembang, lisensi MIT, deskripsi, kata kunci, tautan dukungan, dan riwayat rilis, dibaca Discover dan GNOME Software. Divalidasi dengan `appstreamcli`.
- **Ikon PNG** 64/128/256 px di samping SVG.
- **Verifikasi dan pembaruan:** `scripts/sign-release.sh` (tanda tangan `SHA256SUMS.asc`) dan `scripts/make-apt-repo.sh` (repositori apt bertanda tangan: `make apt-repo`) sehingga pembaruan dapat muncul di Discover dan `apt upgrade` tanpa menghapus versi lama. Kunci selalu milik pengelola; tidak ada yang diunggah. Diuji dengan apt sungguhan: repositori asli diterima, indeks yang dirusak dan kunci yang salah ditolak. Lihat [docs/VERIFY.md](docs/VERIFY.md).
- `release.py check` kini juga memeriksa versi, tanggal, dan lisensi di metainfo.

### Belum ada
- Alamat situs/repositori publik (`Homepage`, tautan bugtracker, tangkapan layar AppStream) belum diisi karena belum ditentukan; lihat docs/VERIFY.md.

## [0.7.2 Beta] — 2026-11-01

Rilis kestabilan dan integritas data. Tidak ada perubahan skema atau fitur.

### Diperbaiki
- **Sorot tidak menutup dengan rapi saat menerima sinyal.** `SIGTERM`/`SIGHUP` (logout, `kill`, penutupan sesi) mematikan proses tanpa menyimpan pengaturan terakhir dan tanpa menghentikan ekstensi; `SIGINT` (Ctrl+C di terminal) membuat aplikasi menggantung. Kini ketiganya menutup lewat jalur normal (simpan draf dan pengaturan, hentikan ekstensi, lepas kunci) tanpa dialog, keluar dengan kode 0; sinyal kedua keluar paksa. Modul baru `sorot.signals`.
- **Karakter pengganti sendirian (surrogate, mis. `"\ud800"` di JSON) membuat setiap penyimpanan gagal** dengan `UnicodeEncodeError` yang tidak tertangkap, sehingga penutupan jendela terhenti di tengah jalan. Teks pengaturan kini dibersihkan saat dibaca dan penulisan berkas tidak lagi gagal karena isi.
- **Menghentikan ekstensi yang menjalankan proses lain menunggu hingga 60 detik** dan membiarkan proses itu hidup. Ekstensi kini berjalan di grup prosesnya sendiri dan seluruh grup dimatikan saat berhenti.
- Cadangan `config.json.bak` ditulis lewat berkas sementara lalu di-rename, sehingga crash di tengah penyalinan tidak meninggalkan cadangan terpotong.

### Pengujian
- Tes baru memakai proses Sorot sungguhan (`tests/test_signals.py`: tiga sinyal; `test_ext_host.py`: proses turunan ekstensi) dan `tests/test_integrity.py`. Kecuali tes cadangan atomik, tiap tes diperiksa gagal bila perbaikannya dibatalkan.

## [0.7.1 Beta] — 2026-10-29

Rilis perbaikan dan penstabilan atas 0.7.0. Untuk pertama kalinya seluruh kode Qt 0.7.0 dijalankan pada Qt asli (PySide6 6.8.3 dan 6.12.0), dan itu menemukan bahwa **mode cermin tidak pernah berfungsi**. Tidak ada perubahan skema atau format data.

### Diperbaiki
- **Mode cermin (“Rig cermin”) tidak berfungsi di 0.7.0**: `FlipEffect.draw` membongkar tuple `(pixmap, offset)` yang tidak pernah dikembalikan PySide6, sehingga `TypeError` terjadi pada paint pertama. Kini offset dihitung dari bounding rect; hasilnya identik piksel demi piksel dengan cermin horizontal pada skala 1×, 1,5× dan 2×.
- **`config.json` berisi `1e999`, `Infinity` atau bilangan bulat raksasa membuat Sorot crash di setiap peluncuran** (bahkan `--diagnostics`) dan impor profil bernilai sama melempar `OverflowError` yang tidak tertangkap. Penyaring angka kini menolak nilai itu (memakai nilai bawaan), dan `ConfigStore.load()`/`restore_backup()` mengarantina berkas yang tetap gagal diproses alih-alih crash.
- Hitung mundur digambar langsung di atas teks naskah sehingga sulit dibaca; kini angka berada di atas latar hampir buram berwarna latar overlay.
- Halaman **Tampilan** membutuhkan lebar ±1000 px sehingga jendela bawaan (1100 px) terbuka dengan scrollbar horizontal dan kolom kanan terpotong. Tombol profil disusun dua baris dan label kotak centang dipersingkat (penjelasan pindah ke tooltip); kini tidak ada halaman yang bergulir ke samping pada ukuran bawaan.
- `Alamat API` yang tidak valid secara sintaks (mis. `http://[`) melempar `ValueError` mentah di slot UI; kini menjadi pesan konfigurasi yang jelas. Respons API berbentuk tak terduga (mis. `choices` berupa objek) kini dilaporkan sebagai “respons tidak dikenali”, bukan `KeyError`.
- Pemilih profil kini memakai indeks dari sinyal `activated`, bukan `currentData()` yang bisa tertinggal.
- **Crash acak (segfault) di Wayland**: pengumpul sampah Python dapat berjalan di thread pekerja saat Qt sedang menyentuh objek yang sama. Ditelusuri dengan `gdb` (C backtrace) hingga race pada traversal GC Shiboken. `sorot.gc_guard.MainThreadGC` kini mematikan GC otomatis dan menjalankannya hanya dari timer di thread utama. Bukti: ≈3 crash per 10 peluncuran weston baru sebelum perbaikan; 0 dari 12 sesudahnya (di bawah `gdb`); ada tes yang memastikan `app.main` memasang penjaga itu.
- Tanda centang tema kini berupa **PNG** (`check-*.png`, juga `@2x`), bukan SVG. Plugin SVG Qt bersifat opsional dan tidak ada di setiap pemasangan; tanpanya kotak centang tampil kosong. Sumber SVG ada di `packaging/check-icons/`, dibangkitkan ulang dengan `scripts/make-check-icons.py`. Tes membuktikan hasil render sama tanpa plugin SVG.
- Stylesheet tema memberi tanda kutip pada path ikon (path berisi spasi tidak lagi merusak aturan).
- `scripts/install-user.sh`: `${BUILD}[keyring]` (peringatan shellcheck SC1087).

### Pengujian
- Tes GUI 0.7.0 yang ditulis tetapi tidak pernah dijalankan kini dijalankan; ada tiga jenis kesalahan di dalamnya, semuanya diperbaiki: pernyataan versi `0.5.0` yang usang, tes yang meninggalkan naskah “belum disimpan” sehingga dialog konfirmasi tutup menggantung teardown tanpa batas, dan dua tes profil yang sebenarnya **hampa** (penangan tidak dipanggil dan tes tetap lulus).
- `test_install_files_layouts` tidak mungkin lulus di bawah pytest asli (fixture `HOME` terisolasi membuat `tmp_path/home`); diperbaiki.
- Tes regresi baru: paint cermin pixel-exact (widget biasa dan teks overlay), latar hitung mundur, tidak ada scroll horizontal di semua halaman, angka non-finite/raksasa pada konfigurasi dan profil (termasuk CLI), config yang gagal diproses, URL API cacat, bentuk respons API aneh. Tiap tes regresi diperiksa gagal bila perbaikannya dibatalkan.
- `ruff` dan `mypy` kini bersih (sebelumnya 1 dan 7 temuan). Tes diparametrisasi agar `QImage.flipped` (Qt ≥ 6.9) tidak dipakai di Qt 6.8.

### Diubah
- CI: ditambah `permissions: contents: read`, job GUI di X11 (Xvfb + openbox, backend `xcb`) dan job GUI di Wayland (weston headless). Secara lokal: `make test-x11` dan `make test-wayland`; tes memilih platform lewat `SOROT_TEST_QPA` dan tes penjaga memastikan platform yang diminta benar-benar dipakai.
- Dokumentasi memperbaiki klaim keliru: paket `.deb` **tidak dapat dipasang di Ubuntu 24.04** (hanya Debian 13); status pengujian di COMPATIBILITY/TEST-REPORT diperbarui sesuai bukti.

### Belum diuji
- Compositor desktop nyata (GNOME/KDE), selalu-di-atas di Wayland (weston headless tidak punya seat dan tidak menjamin itu), fokus keyboard/clipboard di Wayland (4 tes dilewati karena tanpa seat), `makepkg`/Arch, GitHub Actions, Debian 13 bersih lewat `apt`, penyedia AI dan rclone nyata, pembaca layar. Lihat docs/TEST-REPORT.md.

## [0.7.0 Beta] — 2026-10-27

Tampilan yang dapat dikendalikan penuh dan dibagikan: **Profil Tampilan**, mode cermin, dan hitung mundur ([docs/PROFILES.md](docs/PROFILES.md)).

### Ditambahkan
- **Profil Tampilan**: satu berkas JSON berisi seluruh tampilan teks (huruf, ketebalan, spasi baris, spasi huruf, warna, latar, perataan, margin, garis baca, progres, mode cermin, jeda mulai). Enam profil bawaan, profil milikmu (`~/.local/share/sorot/profiles/`), dan profil dari ekstensi. Panel *Tampilan → Profil tampilan* untuk memilih, menyimpan, mengimpor, mengekspor, dan menghapus; menerapkan profil hanya mengubah kunci yang tercantum dan tidak pernah menyentuh pengaturan di luar tampilan.
- Pengaturan baru: **ketebalan huruf** (normal/sedang/tebal), **spasi baris** (100–250 %), **spasi huruf** (0–30 %).
- **Mode cermin**: teks overlay dan pratinjau dibalik horizontal untuk rig beam-splitter (hanya tampilan; tombol dan jendela tidak dibalik).
- **Hitung mundur** besar di overlay selama “Jeda sebelum mulai” (sebelumnya jeda berjalan tanpa petunjuk visual); dapat dimatikan.
- Ekstensi deklaratif dapat menyumbang `display_profiles` (kunci non-tampilan ditolak dan dilaporkan). Contoh `contoh.tema-senja` kini menyertakan satu profil.
- CLI: `sorot --profiles`, `--export-profile NAMA|sekarang BERKAS`, `--import-profile BERKAS`.

### Diubah
- Skema pengaturan 3 → 4 (hanya menambah kunci dengan nilai bawaan yang mereproduksi tampilan lama; langkah migrasi 3 → 4 ditambahkan ke `MIGRATIONS`).
- Profil milikmu ikut dalam cadangan otomatis/manual.
- `scripts/release.py bump` kini juga memperbarui nama artefak di README dan docs; tes pengemasan tidak lagi menuliskan versi secara hardcode.

### Belum diuji
- Seluruh jalur tampilan Qt di versi ini (efek cermin, spasi baris/huruf, hitung mundur, panel profil) **belum dijalankan** pada Qt asli; lihat docs/TEST-REPORT.md.

## [0.6.0 Beta] — 2026-10-26

Jalur pembaruan, dukungan Arch Linux, dan perkakas rilis yang sistematis.

### Ditambahkan
- **Jalur pembaruan** ([docs/UPGRADING.md](docs/UPGRADING.md)): Sorot mencatat versi terakhir yang dijalankan; pada peluncuran pertama setelah versi berubah (naik atau turun, termasuk dari ≤0.5.x yang belum punya catatan) ia membuat cadangan otomatis terverifikasi sebelum menyimpan apa pun dan menampilkan satu pemberitahuan. Lima cadangan otomatis terbaru disimpan.
- Perintah `sorot --upgrade-info` (versi, cara pemasangan terdeteksi, perintah pembaruan yang sesuai, daftar cadangan), `sorot --backup [BERKAS|FOLDER]`, dan `sorot --restore BERKAS`. Pemulihan memeriksa struktur, nama berkas, dan SHA-256 tiap berkas; menolak jalur berbahaya; menolak berjalan saat aplikasi aktif; menyimpan kondisi sebelumnya dulu; bersifat aditif.
- **Arch Linux**: `packaging/arch/PKGBUILD.in`, `scripts/build-arch.sh` (menghasilkan `PKGBUILD` + `.SRCINFO` + arsip sumber dengan hash yang cocok; `--makepkg` untuk membangun paket di Arch). Belum dijalankan di mesin Arch.
- Wheel (`scripts/build-wheel.sh`), `Makefile` (`make help`), `scripts/install-files.sh` (satu definisi tata letak berkas untuk `.deb`, Arch, dan `make install`).
- `scripts/release.py`: `check` (versi, changelog, tanggal, kontak, aset, placeholder), `bump`, `srcinfo`. `tests/test_packaging.py` menjalankannya sehingga ketidakkonsistenan menggagalkan tes.
- Kontak profesional `muhammadandreatama@outlook.com` di dialog Tentang (disalin atau dibuka sebagai `mailto:` hanya saat tombol ditekan), paket Debian (Maintainer), `pyproject.toml`, man page, README, dan SECURITY.

### Diubah
- Migrasi skema pengaturan kini berupa registri langkah berurutan (`MIGRATIONS`); menaikkan `SCHEMA_VERSION` tanpa langkahnya menggagalkan tes. Perilaku untuk data yang ada tidak berubah (skema tetap 3).
- `scripts/build-deb.sh` hanya membangun `.deb`; arsip sumber dipindah ke `build-source.sh`, semuanya digabung oleh `build-all.sh` dengan satu `SHA256SUMS`. Man page memakai templat `@VERSION@`/`@DATE@`.
- `packaging/debian-changelog` kini memuat entri 0.5.0 dan 0.6.0 (sebelumnya entri teratas 0.4.0 padahal paket 0.5.0).

### Diperbaiki
- **Wheel tidak memuat aset SVG** (`check-dark.svg`, `check-light.svg`) sehingga pemasangan via pip/pipx kehilangan indikator kotak centang. Kini dideklarasikan sebagai package-data dan diperiksa oleh tes.
- Maintainer `.deb` bukan lagi placeholder `*.invalid`.

## [0.5.0 Beta] — 2026-10-18

Aplikasi berganti nama dari **Tama Prompter** menjadi **Sorot** dan mendapat tampilan serta mesin gulir baru.

### Diubah
- Nama, paket (`sorot`), perintah (`sorot`), folder data (`~/.config/sorot`, `~/.local/share/sorot`, `~/.local/state/sorot`), dan variabel lingkungan (`SOROT_QT_PLATFORM`, `SOROT_API_KEY`). Paket `.deb` menggantikan `tama-prompter`. Data 0.4.x dan 0.3.x diimpor otomatis saat pertama dijalankan (berkas lama tidak diubah); API key keyring lama tetap terbaca.
- Antarmuka dirancang ulang: rail navigasi, tema Studio gelap/Kertas terang/ikuti sistem, stepper, kontrol segmented, peta posisi overlay, readout waktu, penyorot markup. Skema konfigurasi naik ke versi 3 (pengguna lama tetap memakai mode piksel/detik).
- Model durasi memperhitungkan jeda koma, akhir kalimat, dan isyarat jeda.

### Ditambahkan
- Mesin gulir berbasis garis waktu: mode kata/menit, durasi target, piksel/detik; jam monotonik; mulai/berhenti halus; sinkron ulang saat digulir manual; garis baca, progres, dan sisa waktu.
- Isyarat naskah `// catatan` dan `[jeda N]`.
- Sistem ekstensi (deklaratif dan kode, proses terpisah, persetujuan berbasis hash, pemasang aman, entry point pip, CLI `--extensions` dan `--validate-extension`), dengan tiga contoh.
- Riwayat draf (snapshot), instance tunggal, penangan crash/thread, ukuran jendela diingat.
- Dialog *Dukung pengembangan* (Saweria dan GoPay), sukarela dan tidak pernah muncul sendiri; kredit pembuat dan hak cipta di aplikasi dan paket.

### Diperbaiki
- Menutup aplikasi tanpa mengedit memunculkan peringatan “belum disimpan” palsu (penyorot warna menandai dokumen berubah).
- Rekursi tak terbatas pada overlay dengan naskah kosong di mode durasi.
- Interval tick negatif dapat memicu overflow pada pelunakan kecepatan.

## [0.4.0 Beta] — 2026-10-18

Hasil audit menyeluruh terhadap 0.3.0. Detail temuan: [docs/AUDIT-0.3.0.md](docs/AUDIT-0.3.0.md).

### Diperbaiki
- Posisi overlay manual disimpan tetapi **tidak pernah dipulihkan** saat aplikasi dibuka kembali. Kini dipulihkan, dan jika posisi tersimpan berada di luar semua layar (mis. monitor dicabut) overlay memakai posisi preset.
- Mengganti naskah (buka berkas, buka dari Drive, hasil AI) memakai `setPlainText`, yang **menghapus riwayat undo**. Kini penggantian dapat dibatalkan dengan Ctrl+Z.
- Membuka berkas atau naskah Drive menimpa editor tanpa peringatan. Kini ada konfirmasi Simpan / Lanjutkan tanpa menyimpan / Batal, juga saat keluar.
- Menggeser overlay dengan `move()` manual tidak bekerja pada Wayland asli. Kini memakai fitur geser/ubah ukuran dari compositor.
- Permintaan AI mengikuti pengalihan (redirect) HTTP sehingga header `Authorization` dapat diteruskan ke host lain. Pengalihan kini ditolak.
- Permintaan AI tidak dapat dibatalkan dan dialog tidak bisa ditutup selama permintaan berjalan. Kini dapat dibatalkan dan tidak menahan aplikasi saat keluar.
- Menghapus centang “simpan di keyring” diam-diam menghapus API key yang tersimpan. Kini ada tombol “Hapus key tersimpan” yang eksplisit.
- Memaksa backend xcb ketika plugin Qt xcb tidak ada membuat Qt berhenti tanpa pesan. Kini plugin diperiksa dan aplikasi turun ke pilihan lain.
- `rclone cat` tidak dibatasi ukurannya dan `rclone lsf` menelusuri seluruh Drive tanpa batas kedalaman. Kini keduanya dibatasi, ada timeout, dan dapat dibatalkan.
- Penyegaran overlay pada setiap ketikan membuat naskah panjang lambat; kini di-debounce.

### Ditambahkan
- Pengaturan JSON berversi di `~/.config/tama-prompter/config.json` (validasi nilai, tulis atomik, cadangan `.bak`, berkas rusak dikarantina), impor sekali dari 0.3.x tanpa mengubah berkas lama.
- Draf naskah otomatis (pemulihan setelah crash) dan pustaka “Naskah lokal”.
- Overlay: jenis huruf, warna teks/latar kustom + tema siap pakai, perataan, margin, selalu-di-atas, mode tanpa bingkai, pegangan geser, pegangan ubah ukuran, bar kontrol (Mulai/Jeda, Awal, kecepatan, Tutup) saat kursor di atas overlay, pratinjau di tab Tampilan.
- Pintasan keyboard yang dapat dikonfigurasi (dengan deteksi bentrok), kecepatan gulir dari keyboard.
- Lapisan kompatibilitas: pilihan backend Qt yang dapat diuji, tabel kemampuan overlay per backend, diagnostik yang diperluas (`--diagnostics`).
- AI: uji koneksi (tanpa mengirim naskah), batas waktu yang dapat diatur, klasifikasi error (autentikasi, kuota/Retry-After, model tidak ditemukan, server), tugas “formal”, “santai”, dan “sesuaikan durasi”, konfirmasi tujuan pengiriman per layanan.
- Drive: pilihan remote bertipe, pencarian per folder dengan penyaring, pembatalan, progres.
- Logging dengan penyamaran rahasia ke `~/.local/state/tama-prompter/`.
- Suite tes otomatis (unit, integrasi dengan server/rclone palsu lokal, GUI offscreen), CI GitHub Actions (belum dijalankan), skrip build `.deb` yang reproducible.

### Diubah
- Lokasi data: pengaturan kini JSON di `~/.config/tama-prompter/`, naskah di `~/.local/share/tama-prompter/` (sebelumnya satu berkas QSettings `~/.config/TamaAndrea/TamaPrompter.conf`).
- Pintasan bawaan baru: `Ctrl+R` kembali ke atas, `Alt+Up`/`Alt+Down` kecepatan (kombinasi `Ctrl+Home/Up/Down` bentrok dengan editor).
- Pilihan konfirmasi privasi AI kini per host, bukan satu persetujuan global.

### Catatan peningkatan dari 0.3.0
Saat pertama dijalankan, pengaturan dan naskah terakhir diimpor otomatis. Berkas lama tidak diubah atau dihapus; hapus sendiri `~/.config/TamaAndrea/` setelah yakin (berkas itu menyimpan naskah terakhir tanpa enkripsi).

## [0.3.0 Beta]
Prototipe dasar (tidak ada riwayat perubahan terperinci pada materi yang diterima).
