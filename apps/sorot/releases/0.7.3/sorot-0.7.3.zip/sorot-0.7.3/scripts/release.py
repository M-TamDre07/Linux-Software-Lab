#!/usr/bin/env python3
"""Release tooling: one place that knows where the version lives and what must agree.

    python3 scripts/release.py version          print the version (single source: src/sorot/__init__.py)
    python3 scripts/release.py check            verify every file agrees; exit 1 on any problem
    python3 scripts/release.py bump X.Y.Z [--date YYYY-MM-DD]
                                                update the mechanical places and add changelog skeletons
    python3 scripts/release.py srcinfo PKGBUILD print a .SRCINFO for a (simple) PKGBUILD

Standard library only, so it runs on any distribution and inside the build scripts.
"""
from __future__ import annotations

import datetime as dt
import email.utils
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONTACT = "muhammadandreatama@outlook.com"
VERSION_RE = re.compile(r"\d+\.\d+\.\d+")
#: Documents that may mention an old placeholder because they describe history.
PLACEHOLDER_ALLOWED = {"docs/AUDIT-0.3.0.md"}
TEXT_SUFFIXES = {".py", ".md", ".sh", ".in", ".toml", ".yml", ".yaml", ".json", ".desktop", ".1", ".svg", ".txt", ""}
SKIP_DIRS = {".git", "dist", "build", ".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"}


def read(root: Path, rel: str) -> str:
    return (root / rel).read_text(encoding="utf-8")


def package_version(root: Path = ROOT) -> str:
    match = re.search(r'^__version__ = "([^"]+)"', read(root, "src/sorot/__init__.py"), re.M)
    if not match or not VERSION_RE.fullmatch(match.group(1)):
        raise SystemExit("src/sorot/__init__.py: __version__ tidak ditemukan atau bukan X.Y.Z")
    return match.group(1)


def _tracked_text_files(root: Path):
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if any(part in SKIP_DIRS or part.endswith(".egg-info") for part in rel.parts) or not path.is_file():
            continue
        if path.suffix in TEXT_SUFFIXES and path.stat().st_size < 2_000_000:
            yield rel.as_posix(), path


def check(root: Path = ROOT) -> list[str]:
    """Return a list of problems (empty == consistent)."""
    problems: list[str] = []
    version = package_version(root)
    init = read(root, "src/sorot/__init__.py")

    if f'VERSION_LABEL = "{version} Beta"' not in init:
        problems.append(f'src/sorot/__init__.py: VERSION_LABEL harus "{version} Beta"')
    if f'CONTACT_EMAIL = "{CONTACT}"' not in init:
        problems.append("src/sorot/__init__.py: CONTACT_EMAIL tidak sama dengan kontak resmi")

    release_date = read(root, "packaging/RELEASE_DATE").strip()
    try:
        date = dt.date.fromisoformat(release_date)
    except ValueError:
        problems.append("packaging/RELEASE_DATE: bukan tanggal ISO (YYYY-MM-DD)")
        date = None

    changelog = read(root, "CHANGELOG.md")
    head = re.search(r"^## \[([^\]]+)\] — (\S+)", changelog, re.M)
    if not head or head.group(1) != f"{version} Beta" or head.group(2) != release_date:
        problems.append(f"CHANGELOG.md: entri teratas harus '## [{version} Beta] — {release_date}'")

    debian = read(root, "packaging/debian-changelog")
    deb_head = re.match(r"sorot \(([^)]+)\) \S+; urgency=\w+\n(.*?)\n -- (.+?)  (.+)\n", debian, re.S)
    if not deb_head:
        problems.append("packaging/debian-changelog: format entri teratas tidak dikenali")
    else:
        if deb_head.group(1) != version:
            problems.append(f"packaging/debian-changelog: versi teratas {deb_head.group(1)} != {version}")
        if CONTACT not in deb_head.group(3):
            problems.append("packaging/debian-changelog: penandatangan bukan kontak resmi")
        parsed = email.utils.parsedate_to_datetime(deb_head.group(4)) if date else None
        if parsed is not None and parsed.date() != date:
            problems.append("packaging/debian-changelog: tanggal entri teratas != RELEASE_DATE")
    for name, text in (("CHANGELOG.md", changelog.split("\n## [", 2)[1] if "\n## [" in changelog else changelog), ("packaging/debian-changelog", debian.split("\n\nsorot (", 1)[0])):
        if "TODO" in text:
            problems.append(f"{name}: entri teratas masih berisi TODO")

    man = read(root, "packaging/sorot.1")
    if '.TH SOROT 1 "@DATE@" "@VERSION@"' not in man:
        problems.append("packaging/sorot.1: baris .TH harus memakai @DATE@ dan @VERSION@")

    metainfo = read(root, "packaging/sorot.metainfo.xml")
    first = re.search(r'<release version="([^"]+)" date="([^"]+)"', metainfo)
    if not first or first.group(1) != version or first.group(2) != release_date:
        problems.append(f'packaging/sorot.metainfo.xml: <release> teratas harus version="{version}" date="{release_date}"')
    if "TODO" in metainfo:
        problems.append("packaging/sorot.metainfo.xml: masih berisi TODO")
    if "<project_license>MIT</project_license>" not in metainfo:
        problems.append("packaging/sorot.metainfo.xml: lisensi proyek harus MIT")

    control = read(root, "packaging/control.in")
    if "Version: @VERSION@" not in control or f"Maintainer: Muhammad Andreatama <{CONTACT}>" not in control:
        problems.append("packaging/control.in: Version/Maintainer tidak sesuai")

    pkgbuild = read(root, "packaging/arch/PKGBUILD.in")
    for token in ("pkgver=@VERSION@", "@SHA256@", CONTACT):
        if token not in pkgbuild:
            problems.append(f"packaging/arch/PKGBUILD.in: tidak memuat {token}")

    readme = read(root, "README.md")
    if not readme.startswith(f"# Sorot {version} Beta"):
        problems.append(f"README.md: judul harus '# Sorot {version} Beta'")
    if f"sorot_{version}_all.deb" not in readme:
        problems.append(f"README.md: nama berkas .deb harus sorot_{version}_all.deb")
    for rel in ("README.md", "SECURITY.md", "packaging/copyright", "pyproject.toml"):
        if CONTACT not in read(root, rel):
            problems.append(f"{rel}: tidak memuat kontak resmi {CONTACT}")

    for rel, path in _tracked_text_files(root):
        if rel in PLACEHOLDER_ALLOWED or rel.startswith("tests/"):
            continue
        if re.search(r"@[\w.-]+\.invalid\b", path.read_text(encoding="utf-8", errors="replace")):
            problems.append(f"{rel}: masih memuat alamat placeholder *.invalid")

    # Every asset on disk must be declared as package data, or wheels silently omit it.
    pyproject = read(root, "pyproject.toml")
    assets = root / "src/sorot/ui/assets"
    if assets.is_dir() and any(assets.glob("*")) and 'assets/*.png' not in pyproject:
        problems.append("pyproject.toml: aset UI tidak dideklarasikan di [tool.setuptools.package-data]")
    for asset in sorted(assets.glob("*")) if assets.is_dir() else []:
        if asset.suffix != ".png":
            problems.append(f"{asset.name}: tipe aset tidak tercakup package-data (*.png)")
    return problems


# ----------------------------------------------------------------------------- bump
def bump(new: str, date: str, root: Path = ROOT) -> list[str]:
    if not VERSION_RE.fullmatch(new):
        raise SystemExit("Versi harus berbentuk X.Y.Z")
    dt.date.fromisoformat(date)
    old = package_version(root)
    notes: list[str] = []

    def edit(rel: str, fn) -> None:  # noqa: ANN001
        path = root / rel
        before = path.read_text(encoding="utf-8")
        after = fn(before)
        if after != before:
            path.write_text(after, encoding="utf-8")
            notes.append(f"diperbarui: {rel}")

    edit("src/sorot/__init__.py", lambda t: t.replace(f'__version__ = "{old}"', f'__version__ = "{new}"').replace(f'VERSION_LABEL = "{old} Beta"', f'VERSION_LABEL = "{new} Beta"'))
    edit("packaging/RELEASE_DATE", lambda t: date + "\n")
    edit("README.md", lambda t: t.replace(f"# Sorot {old} Beta", f"# Sorot {new} Beta", 1))
    notes.extend(rename_artifacts(old, new, root))
    edit(
        "packaging/sorot.metainfo.xml",
        lambda t: t.replace("<releases>\n", f'<releases>\n    <release version="{new}" date="{date}">\n      <description><p>TODO: ringkasan rilis</p></description>\n    </release>\n', 1),
    )
    stamp = dt.date.fromisoformat(date)
    rfc = email.utils.format_datetime(dt.datetime(stamp.year, stamp.month, stamp.day, tzinfo=dt.timezone.utc))
    edit("CHANGELOG.md", lambda t: re.sub(r"(?m)^## \[", f"## [{new} Beta] — {date}\n\n### Diubah\n- TODO: tulis ringkasan perubahan\n\n## [", t, count=1))
    edit(
        "packaging/debian-changelog",
        lambda t: f"sorot ({new}) stable; urgency=medium\n\n  * TODO: write the change summary\n\n -- Muhammad Andreatama <{CONTACT}>  {rfc.replace('-0000', '+0000')}\n\n" + t,
    )
    notes.append("TODO: isi entri baru di CHANGELOG.md dan packaging/debian-changelog (`check` gagal selama masih ada TODO)")
    notes.append("TODO: perbarui docs/UPGRADING.md dan docs/TEST-REPORT.md bila perilaku berubah")
    return notes


ARTIFACT_DOCS = ("README.md", "docs/UPGRADING.md", "docs/PACKAGING.md")


def rename_artifacts(old: str, new: str, root: Path = ROOT) -> list[str]:
    """Update artifact file names (sorot_X_all.deb, sorot-X-py3…, sorot-X.tar.gz, sorot-X-1-any…) in the docs."""
    done = []
    for rel in ARTIFACT_DOCS:
        path = root / rel
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8")
        new_text = text
        for pattern in (f"sorot_{old}_all.deb", f"sorot-{old}-py3", f"sorot-{old}.tar.gz", f"sorot-{old}.zip", f"sorot-{old}-1-any"):
            new_text = new_text.replace(pattern, pattern.replace(old, new))
        if new_text != text:
            path.write_text(new_text, encoding="utf-8")
            done.append(f"diperbarui: {rel} (nama artefak)")
    return done


# ----------------------------------------------------------------------------- .SRCINFO
_ARRAY = re.compile(r"^(\w+)=\(\s*(.*?)\s*\)\s*$", re.M | re.S)
_SCALAR = re.compile(r"^(\w+)=(?!\()(.+)$", re.M)
_QUOTED = re.compile(r"'([^']*)'|\"([^\"]*)\"")


def parse_pkgbuild(text: str) -> tuple[dict[str, str], dict[str, list[str]]]:
    """Parse the simple subset our PKGBUILD uses: scalars and arrays of quoted strings."""
    body = re.sub(r"(?m)^\s*#.*$", "", text)
    body = body.split("\nbuild()", 1)[0]  # variables come before the functions
    arrays = {m.group(1): [a or b for a, b in _QUOTED.findall(m.group(2))] for m in _ARRAY.finditer(body)}
    body_without_arrays = _ARRAY.sub("", body)
    scalars = {}
    for m in _SCALAR.finditer(body_without_arrays):
        value = m.group(2).strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "'\"":
            value = value[1:-1]
        scalars[m.group(1)] = value
    return scalars, arrays


def srcinfo(text: str) -> str:
    scalars, arrays = parse_pkgbuild(text)

    def expand(value: str) -> str:
        return value.replace("$pkgname", scalars["pkgname"]).replace("${pkgname}", scalars["pkgname"]).replace("$pkgver", scalars["pkgver"]).replace("${pkgver}", scalars["pkgver"])

    lines = [f"pkgbase = {scalars['pkgname']}", f"\tpkgdesc = {scalars['pkgdesc']}", f"\tpkgver = {scalars['pkgver']}", f"\tpkgrel = {scalars['pkgrel']}"]
    for key in ("arch", "license", "makedepends", "checkdepends", "depends", "optdepends", "source", "sha256sums"):
        for item in arrays.get(key, []):
            lines.append(f"\t{key if key != 'arch' else 'arch'} = {expand(item)}")
    lines += ["", f"pkgname = {scalars['pkgname']}", ""]
    return "\n".join(lines)


def main(argv: list[str]) -> int:
    command = argv[0] if argv else "check"
    if command == "version":
        print(package_version())
        return 0
    if command == "check":
        problems = check()
        for problem in problems:
            print(f"✗ {problem}", file=sys.stderr)
        print(f"{'✓ Rilis konsisten' if not problems else f'{len(problems)} masalah'} (versi {package_version()})")
        return 1 if problems else 0
    if command == "bump":
        if len(argv) < 2:
            print("Gunakan: release.py bump X.Y.Z [--date YYYY-MM-DD]", file=sys.stderr)
            return 2
        date = argv[argv.index("--date") + 1] if "--date" in argv else dt.date.today().isoformat()
        for note in bump(argv[1], date):
            print(note)
        return 0
    if command == "srcinfo":
        if len(argv) < 2:
            print("Gunakan: release.py srcinfo PKGBUILD", file=sys.stderr)
            return 2
        print(srcinfo(Path(argv[1]).read_text(encoding="utf-8")), end="")
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
