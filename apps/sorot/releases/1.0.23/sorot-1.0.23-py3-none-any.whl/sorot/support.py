"""Where people can support the author. Single source of truth for the UI and docs.

Support is voluntary: nothing in Sorot is locked behind it, nothing nags, and no
network request is made unless the user clicks a button.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

from sorot import AUTHOR, CONTACT_EMAIL, SOURCE_URL

SAWERIA_URL = "https://saweria.co/tamaandrea"
GOPAY_NUMBER = "081274852534"  # Indonesian mobile number registered with GoPay
SEABANK_NUMBER = "901725862955"  # SeaBank account number (digits only)
QRIS_MERCHANT = "TAMA ANDREA STUDIO"  # merchant name printed on (and encoded in) the QRIS
QRIS_NMID = "ID1026641026012"  # National Merchant ID printed on the QRIS poster
QRIS_ASSET = "qris.png"  # the full QRIS poster, shipped inside sorot/ui/assets
# The part of the poster that holds the QR code card (left, top, right, bottom in pixels of the 1200x1700 image).
QRIS_CARD_BOX = (100, 275, 1100, 1430)


def normalize_id_phone(raw: str) -> str:
    """Return an Indonesian mobile number in national form (``08…``).

    Accepts ``+62 812…``, ``62812…``, ``0812…`` and ``812…``; raises ``ValueError``
    for anything that is not a plausible mobile number (9–13 digits after the ``0``).
    """
    digits = re.sub(r"\D", "", raw or "")
    if digits.startswith("62"):
        digits = digits[2:]
    digits = digits.lstrip("0")
    if not re.fullmatch(r"8\d{8,11}", digits):
        raise ValueError("nomor ponsel Indonesia tidak valid")
    return "0" + digits


def format_id_phone(number: str) -> str:
    """``081274852534`` -> ``0812-7485-2534``."""
    national = normalize_id_phone(number)
    return f"{national[:4]}-{national[4:8]}-{national[8:]}"


def normalize_account_number(raw: str) -> str:
    """Digits of a bank account number; raises ``ValueError`` unless it has 8-16 digits."""
    digits = re.sub(r"[\s.-]", "", raw or "")
    if not re.fullmatch(r"\d{8,16}", digits):
        raise ValueError("nomor rekening tidak valid")
    return digits


def format_account_number(raw: str) -> str:
    """``901725862955`` -> ``9017 2586 2955`` (groups of four are easier to read and to check)."""
    digits = normalize_account_number(raw)
    return " ".join(digits[i : i + 4] for i in range(0, len(digits), 4))


def qris_asset_path() -> Path:
    """Where the shipped QRIS image lives (works from a source tree, a wheel and the .deb)."""
    return Path(__file__).parent / "ui" / "assets" / QRIS_ASSET


def international_id_phone(number: str) -> str:
    national = normalize_id_phone(number)
    return f"+62 {national[1:4]}-{national[4:8]}-{national[8:]}"


_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+")


def validate_email(address: str) -> str:
    """Return ``address`` if it is a plain, single e-mail address; raise ``ValueError`` otherwise."""
    if not _EMAIL_RE.fullmatch(address or ""):
        raise ValueError("alamat email tidak valid")
    return address


def contact_mailto(address: str = CONTACT_EMAIL, subject: str = "") -> str:
    """A ``mailto:`` URL for the contact address. Opened only when the user clicks a button."""
    from urllib.parse import quote

    url = f"mailto:{validate_email(address)}"
    return f"{url}?subject={quote(subject)}" if subject else url


@dataclass(frozen=True)
class SupportInfo:
    author: str
    saweria_url: str
    gopay_number: str
    contact_email: str = CONTACT_EMAIL
    seabank_number: str = SEABANK_NUMBER
    qris_merchant: str = QRIS_MERCHANT
    qris_nmid: str = QRIS_NMID

    @property
    def seabank_display(self) -> str:
        return format_account_number(self.seabank_number)

    @property
    def gopay_display(self) -> str:
        return format_id_phone(self.gopay_number)

    @property
    def gopay_international(self) -> str:
        return international_id_phone(self.gopay_number)

    def validate(self) -> None:
        parsed = urlparse(self.saweria_url)
        if parsed.scheme != "https" or not parsed.netloc:
            raise ValueError("tautan dukungan harus memakai https")
        normalize_id_phone(self.gopay_number)
        normalize_account_number(self.seabank_number)
        if not self.qris_merchant.strip() or not re.fullmatch(r"ID\d{10,20}", self.qris_nmid):
            raise ValueError("data QRIS tidak valid")
        validate_email(self.contact_email)


def support_info() -> SupportInfo:
    info = SupportInfo(AUTHOR, SAWERIA_URL, GOPAY_NUMBER)
    info.validate()
    return info


QRIS_NOTE = (
    "Pindai dengan aplikasi bank atau dompet digital apa pun yang mendukung QRIS. "
    "Pastikan nama penerima yang tampil di aplikasimu adalah {merchant}."
)
SEABANK_NOTE = "Transfer dari bank atau dompet digital mana pun. Periksa nama penerima di aplikasi sebelum mengirim."

DOCS_URL = f"{SOURCE_URL}/blob/main/apps/sorot/docs"
TUTORIAL_URL = f"{DOCS_URL}/TUTORIAL.md"
CREDIBILITY_URL = f"{DOCS_URL}/KREDIBILITAS.md"
STATUS_NOTE = (
    "Stabil untuk keluarga Debian (Debian, Ubuntu, Kali Linux) menurut uji manual pengelola. "
    "Distro lain belum dinyatakan didukung. Tidak ada telemetri; jaringan hanya dipakai saat kamu menekan tombol fitur opsional."
)

INTRO = (
    "Sorot gratis dan bebas dipakai. Jika aplikasi ini bermanfaat bagimu, dukunganmu membantu pemeliharaan, "
    "perbaikan bug, dan pengembangan fitur berikutnya."
)
CONTACT_NOTE = (
    "Kontak untuk pertanyaan profesional: kerja sama, pekerjaan, lisensi, atau dukungan khusus. "
    "Jangan melampirkan naskah pribadi atau kunci rahasia (API key) dalam email."
)
PROMISE = (
    "Dukungan bersifat sukarela. Tidak ada fitur yang dikunci, tidak ada pop-up yang mengganggu, dan tidak ada pelacakan. "
    "Aplikasi tidak menghubungi siapa pun sampai kamu menekan tombol di bawah."
)
