"""``sorotctl``: send one command to a running Sorot over its local control socket. Standard library only."""
from __future__ import annotations

import json
import socket
import sys
from pathlib import Path

from sorot import __version__
from sorot.services import control

HELP = f"""sorotctl {__version__}: kendalikan Sorot yang sedang berjalan.

Pemakaian: sorotctl [--socket JALUR] [--json] [--timeout DETIK] PERINTAH [ARGUMEN]

  ping | version | status        informasi (hanya baca)
  show | hide                    tampilkan / sembunyikan overlay
  play | pause | toggle | reset  gulir
  speed N                        ubah kecepatan N langkah (-10..10)
  recipes                        daftar resep otomasi
  run NAMA                       jalankan resep (Sorot meminta konfirmasi di jendelanya)

Soket kontrol harus diaktifkan di Sorot: halaman Otomasi → "Aktifkan soket kontrol".
Kode keluar: 0 berhasil, 1 ditolak Sorot, 2 salah pakai, 3 Sorot tidak terjangkau.
"""


def build_request(words: list[str]) -> dict:
    if not words:
        raise ValueError("Perintah belum diisi.")
    command, rest = words[0], words[1:]
    if command not in control.COMMANDS:
        raise ValueError(f"Perintah tidak dikenal: {command[:30]}")
    spec = control.COMMANDS[command]
    if spec is None:
        if rest:
            raise ValueError(f"“{command}” tidak memakai argumen.")
        return {"cmd": command}
    name, kind, _low, _high = spec
    if len(rest) != 1:
        raise ValueError(f"“{command}” butuh satu argumen ({name}).")
    if kind == "int":
        try:
            return {"cmd": command, "args": {name: int(rest[0])}}
        except ValueError as exc:
            raise ValueError(f"“{name}” harus bilangan bulat.") from exc
    return {"cmd": command, "args": {name: rest[0]}}


def send(path: Path, request: dict, timeout: float = 5.0) -> dict:
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
        sock.settimeout(timeout)
        sock.connect(str(path))
        sock.sendall((json.dumps(request) + "\n").encode("utf-8"))
        data = b""
        while b"\n" not in data:
            chunk = sock.recv(4096)
            if not chunk:
                break
            data += chunk
            if len(data) > 1_000_000:
                raise OSError("jawaban terlalu besar")
    return json.loads(data.split(b"\n", 1)[0].decode("utf-8"))


def _render(command: str, reply: dict) -> str:
    result = reply.get("result", {})
    if command == "recipes":
        return "\n".join(f"{item['name']}: {item.get('description', '')}".rstrip(": ") for item in result.get("recipes", [])) or "(tidak ada resep)"
    if isinstance(result, dict) and result.get("message"):
        return str(result["message"])
    return json.dumps(result, ensure_ascii=False) if result else "ok"


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if not args or "-h" in args or "--help" in args:
        print(HELP)
        return 0 if args else 2
    if "--version" in args:
        print(f"sorotctl {__version__}")
        return 0
    explicit: Path | None = None
    timeout = 5.0
    as_json = False
    words: list[str] = []
    it = iter(args)
    for item in it:
        if item == "--json":
            as_json = True
        elif item in ("--socket", "--timeout"):
            value = next(it, "")
            if item == "--socket":
                explicit = Path(value)
            else:
                try:
                    timeout = max(0.5, min(float(value), 60.0))
                except ValueError:
                    print("--timeout harus berupa angka.", file=sys.stderr)
                    return 2
        else:
            words.append(item)
    try:
        request = build_request(words)
    except ValueError as exc:
        print(f"sorotctl: {exc}", file=sys.stderr)
        return 2
    candidates = [explicit] if explicit else control.client_socket_candidates()
    if not candidates:
        print("sorotctl: XDG_RUNTIME_DIR tidak diatur; tidak ada tempat aman untuk mencari soket. Gunakan --socket.", file=sys.stderr)
        return 3
    last = ""
    for path in candidates:
        if path is None:
            continue
        try:
            reply = send(path, request, timeout)
        except (OSError, ValueError) as exc:
            last = str(exc)
            continue
        if as_json:
            print(json.dumps(reply, ensure_ascii=False))
        elif reply.get("ok"):
            print(_render(request["cmd"], reply))
        else:
            print(f"sorotctl: {reply.get('error', 'ditolak')}", file=sys.stderr)
        return 0 if reply.get("ok") else 1
    print("sorotctl: Sorot tidak terjangkau. Jalankan Sorot dan aktifkan soket kontrol di halaman Otomasi." + (f" ({last})" if last else ""), file=sys.stderr)
    return 3


if __name__ == "__main__":
    sys.exit(main())
