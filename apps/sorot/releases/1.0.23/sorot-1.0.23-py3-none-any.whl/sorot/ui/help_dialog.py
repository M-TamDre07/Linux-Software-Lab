"""F1: a plain, readable list of every keyboard shortcut (text, so screen readers can read it line by line)."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import QDialog, QDialogButtonBox, QHBoxLayout, QLabel, QPlainTextEdit, QVBoxLayout, QWidget

from sorot.core.config import DEFAULT_SHORTCUTS, SHORTCUT_LABELS

FIXED_SHORTCUTS = (
    ("Ctrl+N", "Naskah baru"), ("Ctrl+O", "Buka naskah"), ("Ctrl+L", "Naskah lokal"), ("Ctrl+S", "Simpan"),
    ("Ctrl+Shift+S", "Simpan sebagai / ekspor"), ("Ctrl+Q", "Keluar"),
    ("Ctrl+1 … Ctrl+6", "Pindah ke halaman Naskah, Tampilan, Integrasi, Sistem, Ekstensi, Aksesibilitas"),
    ("Ctrl+Shift+A", "Buka halaman Aksesibilitas"), ("Ctrl+Shift+R", "Bacakan naskah dengan suara"),
    ("Ctrl+Shift+X", "Hentikan suara"), ("F1", "Daftar pintasan ini"),
    ("Tab / Shift+Tab", "Pindah ke kontrol berikutnya / sebelumnya"),
    ("Panah atas / bawah", "Ubah nilai pada kolom angka dan pilihan"),
)


def shortcut_lines(shortcuts: dict[str, str] | None = None) -> list[str]:
    configured = {**DEFAULT_SHORTCUTS, **(shortcuts or {})}
    lines = ["Pintasan overlay (dapat diubah di Sistem › Pintasan keyboard):"]
    lines += [f"  {configured[key]:<18} {SHORTCUT_LABELS[key]}" for key in DEFAULT_SHORTCUTS]
    lines += ["", "Pintasan tetap:"]
    lines += [f"  {keys:<18} {what}" for keys, what in FIXED_SHORTCUTS]
    lines += ["", "Catatan: pintasan overlay hanya bekerja saat jendela Sorot terfokus. Di atas aplikasi lain, pakai tombol di overlay (juga bisa dijangkau dengan Tab)."]
    return lines


class KeyboardHelpDialog(QDialog):
    def __init__(self, shortcuts: dict[str, str] | None = None, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Pintasan keyboard")
        self.setMinimumSize(560, 420)
        layout = QVBoxLayout(self)
        intro = QLabel("Semua fungsi Sorot dapat dijalankan dengan keyboard.")
        intro.setWordWrap(True)
        self.view = QPlainTextEdit("\n".join(shortcut_lines(shortcuts)))
        self.view.setObjectName("mono")
        self.view.setReadOnly(True)
        self.view.setAccessibleName("Daftar pintasan keyboard")
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(self.reject)
        layout.addWidget(intro)
        layout.addWidget(self.view, 1)
        layout.addWidget(buttons)
        self.view.setFocus()


QUICK_START = (
    "Mulai cepat",
    "",
    "1. Tulis atau buka naskah di halaman Naskah (Ctrl+1). Ctrl+O membuka .txt, .md, Word, OpenDocument, RTF, HTML, dan PDF; berkas juga bisa diseret ke jendela.",
    "2. Isyarat naskah, satu baris sendiri: \"// catatan\" tidak tampil dan tidak dihitung; \"[jeda]\" menahan layar 2 detik, \"[jeda 5]\" menahan 5 detik.",
    "3. Atur kecepatan dan tampilan di halaman Tampilan (Ctrl+2): kata/menit, durasi target, atau piksel/detik; huruf, warna, transparansi, garis baca.",
    "4. Tampilkan overlay dengan Ctrl+Enter, mulai atau jeda dengan Ctrl+Space, ubah kecepatan dengan Alt+Atas/Bawah, sembunyikan dengan Esc.",
    "5. Geser overlay dengan pegangan Geser, lalu rekam dengan aplikasi perekam pilihanmu. Overlay tidak dijamin tersembunyi dari berbagi layar atau rekaman layar penuh.",
    "",
    "Bila ada yang tidak pas:",
    "  - Overlay tidak selalu di atas atau tidak bisa digeser di Wayland: jalankan  SOROT_QT_PLATFORM=xcb sorot",
    "  - Huruf terlalu kecil atau warna sulit dibedakan: halaman Aksesibilitas (Ctrl+Shift+A)",
    "  - Laporan lingkungan: terminal  sorot --diagnostics  dan  sorot --doctor",
    "  - Naskah hilang setelah crash: draf dan riwayat 20 snapshot ada di halaman Naskah; cadangan: sorot --upgrade-info",
    "",
    "Naskah dan pengaturan hanya disimpan di komputer ini. Tidak ada telemetri.",
)


class QuickStartDialog(QDialog):
    """Menu Bantuan: the first-run steps as plain text (readable by screen readers), with the full tutorial one copy away."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        from PySide6.QtWidgets import QPushButton

        from sorot.support import STATUS_NOTE, TUTORIAL_URL

        self.setWindowTitle("Panduan mulai cepat")
        self.setMinimumSize(560, 440)
        layout = QVBoxLayout(self)
        self.view = QPlainTextEdit("\n".join(QUICK_START))
        self.view.setReadOnly(True)
        self.view.setAccessibleName("Panduan mulai cepat")
        status = QLabel(STATUS_NOTE)
        status.setWordWrap(True)
        status.setProperty("role", "muted")
        link = QLabel(f"Tutorial lengkap: {TUTORIAL_URL}")
        link.setWordWrap(True)
        link.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        link.setProperty("role", "muted")
        row = QHBoxLayout()
        self.copy_link_btn = QPushButton("Salin tautan tutorial")
        self.copy_link_btn.clicked.connect(lambda: QGuiApplication.clipboard().setText(TUTORIAL_URL))
        close = QPushButton("Tutup")
        close.clicked.connect(self.accept)
        row.addWidget(self.copy_link_btn)
        row.addStretch(1)
        row.addWidget(close)
        layout.addWidget(self.view, 1)
        layout.addWidget(status)
        layout.addWidget(link)
        layout.addLayout(row)
        self.view.setFocus()
