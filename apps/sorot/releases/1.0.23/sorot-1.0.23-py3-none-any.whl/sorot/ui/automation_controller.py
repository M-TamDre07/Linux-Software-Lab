"""Glue between the Otomasi page, the control socket, recipes and the main window.

Everything that can drive the teleprompter goes through ``execute_command``, which uses only the window's own public
actions. Recipe runs and ``sorotctl run`` ask the person to confirm in the window first (unless the recipe says
otherwise); model-drafted recipes are never saved or run without a click.
"""
from __future__ import annotations

import logging
import os
from concurrent.futures import Future
from concurrent.futures import TimeoutError as FutureTimeout
from typing import TYPE_CHECKING, Any

from PySide6.QtCore import QObject, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QApplication, QMessageBox

from sorot import __version__
from sorot.core import paths, recipes
from sorot.services import ai_service, control, doctor, keyring_service, local_llm
from sorot.services import automation_planner as planner
from sorot.ui.automation_page import AutomationPage
from sorot.ui.task_worker import BackgroundTask

if TYPE_CHECKING:
    from sorot.ui.main_window import MainWindow

LOGGER = logging.getLogger(__name__)
MAIN_THREAD_TIMEOUT = 4.0
OLLAMA_COMMAND = "docker compose -f ollama.compose.yaml up -d"


class _MainThreadCall(QObject):
    """Run a callable on the GUI thread on behalf of the socket's worker threads and hand back its result."""

    _requested = Signal(object)

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._requested.connect(self._run)  # emitted from another thread, so Qt queues it onto the GUI thread

    def call(self, function, timeout: float = MAIN_THREAD_TIMEOUT):  # noqa: ANN001, ANN201
        future: Future = Future()
        self._requested.emit((function, future))
        try:
            return future.result(timeout)
        except FutureTimeout as exc:
            raise control.ControlError("Sorot sedang sibuk (mungkin ada dialog terbuka). Coba lagi.") from exc

    def _run(self, payload: tuple) -> None:
        function, future = payload
        try:
            future.set_result(function())
        except BaseException as exc:  # noqa: BLE001 - delivered to the waiting thread
            future.set_exception(exc)


class AutomationController(QObject):
    def __init__(self, window: MainWindow, page: AutomationPage) -> None:
        super().__init__(window)
        self.window = window
        self.page = page
        self.server: control.ControlServer | None = None
        self._bridge = _MainThreadCall(self)
        self._runner: recipes.RecipeRunner | None = None
        self._tasks: list[BackgroundTask] = []
        self._recipes: list[recipes.Recipe] = []
        self._proposal: recipes.Recipe | None = None
        page.discoverRequested.connect(self.discover)
        page.useServerRequested.connect(self.use_server)
        page.controlToggled.connect(self.set_control_enabled)
        page.runRecipeRequested.connect(self.request_run)
        page.planRequested.connect(self.plan)
        page.saveProposalRequested.connect(self.save_proposal)
        page.openFolderRequested.connect(self.open_folder)
        page.copyContainerRequested.connect(self.copy_container_command)
        page.doctorRequested.connect(self.run_doctor)

    # ------------------------------------------------------------------ lifecycle
    def start(self) -> None:
        self.reload_recipes()
        if self.window.config.control_enabled:
            self._start_server()
        self._show_control_state()

    def shutdown(self) -> None:
        if self._runner is not None:
            self._runner.cancel()
        for task in self._tasks:
            task.cancel()
        self._stop_server()

    # ------------------------------------------------------------------ control socket
    def set_control_enabled(self, on: bool) -> None:
        self.window.config.control_enabled = on
        self.window._schedule_config_save()
        if on:
            self._start_server()
        else:
            self._stop_server()
        self._show_control_state()

    def _start_server(self) -> None:
        path = control.socket_path()
        if path is None:
            self.window._set_status("Soket kontrol tidak dibuka: XDG_RUNTIME_DIR tidak diatur, jadi tidak ada tempat aman untuk soket.")
            return
        self._stop_server()
        server = control.ControlServer(path, self._dispatch_from_thread)
        try:
            server.start()
        except control.ControlError as exc:
            self.window._set_status(f"Soket kontrol tidak dibuka: {exc}")
            return
        self.server = server
        self.window._set_status("Soket kontrol aktif. Gunakan `sorotctl status` dari terminal.")

    def _stop_server(self) -> None:
        if self.server is not None:
            self.server.stop()
            self.server = None

    def _show_control_state(self) -> None:
        running = self.server is not None and self.server.running
        enabled = self.window.config.control_enabled
        if running and self.server is not None:
            text = f"Aktif di {self.server.path}"
        elif enabled:
            text = "Diaktifkan, tetapi soket tidak dapat dibuka (lihat bilah status)."
        else:
            text = "Nonaktif."
        self.page.set_control(enabled, text)

    def _dispatch_from_thread(self, command: str, args: dict[str, Any]) -> Any:
        return self._bridge.call(lambda: self.execute_command(command, args))

    # ------------------------------------------------------------------ commands (GUI thread)
    def execute_command(self, command: str, args: dict[str, Any]) -> dict[str, Any]:
        w = self.window
        if command == "ping":
            return {"message": "pong"}
        if command == "version":
            return {"version": __version__, "message": f"Sorot {__version__}"}
        if command == "status":
            scrolling = bool(w.overlay.is_scrolling())
            return {
                "overlay_visible": bool(w.overlay.isVisible()), "scrolling": scrolling, "speed_mode": w.config.speed_mode,
                "message": ("menggulir" if scrolling else ("jeda" if w.overlay.isVisible() else "overlay tersembunyi")),
            }
        if command == "recipes":
            return {"recipes": [{"name": r.name, "description": r.description, "confirm": r.confirm} for r in self._recipes]}
        if command == "run":
            return self._run_by_name(args["name"], from_socket=True)
        step = recipes.Step(command, float(args["steps"])) if command == "speed" else recipes.Step(command)
        problem = self.apply_step(step)
        if problem:
            raise control.ControlError(problem)
        return {"message": "ok"}

    def apply_step(self, step: recipes.Step) -> str | None:
        """Do one step with the window's own actions. Returns an error message or ``None``."""
        w = self.window
        try:
            if step.command == "show":
                if not w.overlay.isVisible():
                    w.show_overlay()  # this starts scrolling (or a start delay); "show" means visible but paused, so undo that
                    w._cancel_start_delay()
                    w.overlay.pause_scrolling()
                    w._update_tally()
            elif step.command == "hide":
                w.hide_overlay()
            elif step.command == "play":
                if not w.overlay.isVisible():
                    w.show_overlay()
                elif not w.overlay.is_scrolling():
                    w.toggle_scroll()
            elif step.command == "pause":
                if w.overlay.is_scrolling():
                    w.toggle_scroll()
            elif step.command == "toggle":
                w.toggle_scroll()
            elif step.command == "reset":
                w.reset_scroll()
            elif step.command == "speed":
                w.adjust_speed(int(step.value or 0))
            else:
                return f"perintah “{step.command}” tidak dikenal"
        except Exception as exc:  # noqa: BLE001
            LOGGER.warning("Langkah otomasi %s gagal: %s", step.command, type(exc).__name__)
            return f"langkah “{step.command}” gagal"
        return None

    # ------------------------------------------------------------------ recipes
    def reload_recipes(self) -> None:
        self._recipes, problems = recipes.load_recipes(paths.automation_dir())
        self.page.set_recipes(self._recipes, problems)

    def _find(self, name: str) -> recipes.Recipe | None:
        return next((r for r in self._recipes if r.name.casefold() == name.casefold()), None)

    def request_run(self, name: str) -> None:
        result = self._run_by_name(name, from_socket=False)
        if result.get("message"):
            self.window._set_status(result["message"])

    def _run_by_name(self, name: str, *, from_socket: bool) -> dict[str, Any]:
        recipe = self._find(name)
        if recipe is None:
            raise control.ControlError(f"Resep “{name[:40]}” tidak ditemukan.")
        if self._runner is not None and not self._runner.finished:
            raise control.ControlError("Resep lain sedang berjalan.")
        if recipe.confirm:
            # Ask in the window, never inside the socket's request: the client gets its answer right away.
            QTimer.singleShot(0, lambda: self._confirm_and_run(recipe, from_socket))
            return {"message": f"Menunggu konfirmasi di jendela Sorot untuk resep “{recipe.name}”."}
        self._start_runner(recipe)
        return {"message": f"Resep “{recipe.name}” dimulai."}

    def _confirm_and_run(self, recipe: recipes.Recipe, from_socket: bool) -> None:
        box = QMessageBox(self.window)
        box.setIcon(QMessageBox.Icon.Question)
        box.setWindowTitle("Jalankan resep otomasi?")
        origin = "Permintaan datang dari `sorotctl`. " if from_socket else ""
        box.setText(f"{origin}Resep “{recipe.name}” akan menjalankan:")
        box.setInformativeText("\n".join(f"{i}. {s.describe()}" for i, s in enumerate(recipe.steps, start=1)))
        run = box.addButton("Jalankan", QMessageBox.ButtonRole.AcceptRole)
        cancel = box.addButton("Batal", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(cancel)
        box.setEscapeButton(cancel)
        box.exec()
        if box.clickedButton() is run:
            self._start_runner(recipe)
        else:
            self.window._set_status("Resep dibatalkan.")

    def _start_runner(self, recipe: recipes.Recipe) -> None:
        def schedule(seconds: float, callback) -> None:  # noqa: ANN001
            QTimer.singleShot(max(0, int(seconds * 1000)), callback)

        self._runner = recipes.RecipeRunner(recipe, self.apply_step, schedule, self.window._set_status)
        self.window._set_status(f"Menjalankan resep “{recipe.name}”…")
        self._runner.start()

    # ------------------------------------------------------------------ local servers
    def _task(self, function, on_ok, on_fail) -> BackgroundTask:  # noqa: ANN001
        task = BackgroundTask(function, self)
        task.succeeded.connect(on_ok)
        task.failed.connect(on_fail)
        task.cancelled.connect(lambda: None)
        self._tasks = [t for t in self._tasks if t.running] + [task]
        task.start()
        return task

    def discover(self) -> None:
        self.page.set_busy_discover(True)

        def done(servers: list[local_llm.LocalServer]) -> None:
            self.page.set_busy_discover(False)
            self.page.set_servers(servers)

        def failed(message: str) -> None:
            self.page.set_busy_discover(False)
            self.page.llm_state.setText(message)

        self._task(lambda _t: local_llm.discover(), done, failed)

    def use_server(self, base_url: str, model: str) -> None:
        c = self.window.config
        c.ai_base_url, c.ai_model = base_url, model
        self.window._schedule_config_save()
        self.window._set_status(f"Layanan AI diarahkan ke server lokal ({model}). Naskah tidak keluar dari komputer ini.")

    def copy_container_command(self) -> None:
        folder = doctor.containers_dir()
        where = f"cd {folder} && " if folder else ""
        QApplication.clipboard().setText(where + OLLAMA_COMMAND)
        self.window._set_status("Perintah disalin. Jalankan di terminal; Sorot tidak menjalankan kontainer.")

    # ------------------------------------------------------------------ planner
    def _ai_config(self) -> ai_service.AIConfig:
        c = self.window.config
        key = os.environ.get("SOROT_API_KEY", "").strip() or self.window.session_api_key or ""
        if not key and not ai_service.is_loopback(c.ai_base_url):
            key = keyring_service.get_api_key() or ""
        return ai_service.AIConfig(c.ai_base_url, c.ai_model, key, c.ai_timeout)

    def plan(self, request: str) -> None:
        config = self._ai_config()
        if not ai_service.is_loopback(config.base_url):
            self.page.show_proposal(None, "Penyusunan resep hanya memakai server lokal. Cari dan pilih server lokal di atas terlebih dahulu.")
            return
        try:
            planner.build_messages(request)
        except ai_service.AIError as exc:
            self.page.show_proposal(None, str(exc))
            return
        self.page.set_planning(True)

        def done(recipe: recipes.Recipe) -> None:
            self.page.plan_btn.setEnabled(True)
            self._proposal = recipe
            self.page.show_proposal(recipe)

        def failed(message: str) -> None:
            self.page.plan_btn.setEnabled(True)
            self.page.show_proposal(None, message)

        def work(token):  # noqa: ANN001, ANN202
            try:
                return planner.plan_recipe(config, request, cancel=token)
            except recipes.RecipeError as exc:
                raise ai_service.AIError(ai_service.AIErrorKind.INVALID_RESPONSE, f"Usulan model ditolak: {exc}") from exc

        self._task(work, done, failed)

    def save_proposal(self) -> None:
        recipe = self._proposal
        if recipe is None:
            return
        taken = {r.name.casefold() for r in self._recipes}
        name, counter = recipe.name, 2
        while name.casefold() in taken:
            name, counter = f"{recipe.name} {counter}", counter + 1
        saved = recipes.Recipe(name, recipe.steps, recipe.description, True, "")  # model drafts always ask before running
        try:
            target = recipes.save_recipe(paths.automation_dir(), saved)
        except OSError as exc:
            self.page.show_proposal(None, f"Resep tidak dapat disimpan: {exc.strerror or exc}")
            return
        self._proposal = None
        self.reload_recipes()
        self.page.show_proposal(None, f"Disimpan sebagai {target.name}. Resep ini selalu meminta konfirmasi sebelum berjalan.")

    def open_folder(self) -> None:
        folder = paths.automation_dir()
        try:
            folder.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder))):
            QApplication.clipboard().setText(str(folder))
            self.window._set_status(f"Folder tidak dapat dibuka dari sini; jalurnya disalin: {folder}")

    # ------------------------------------------------------------------ doctor
    def run_doctor(self) -> None:
        self.page.doctor_btn.setEnabled(False)
        self.page.doctor_out.setText("Memeriksa…")
        config = self.window.config

        def work(_t):  # noqa: ANN001, ANN202
            return doctor.format_report(doctor.run(config, probe_llm=True, env={**os.environ}))

        def failed(message: str) -> None:
            self.page.show_doctor(f"Pemeriksaan gagal: {message}")

        self._task(work, self.page.show_doctor, failed)
