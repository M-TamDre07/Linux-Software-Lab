"""Small helpers that make Qt widgets readable by assistive technology without repeating names by hand."""
from __future__ import annotations

from PySide6.QtWidgets import QFormLayout, QLabel, QLayout, QWidget


def _label_text(label: QLabel) -> str:
    return " ".join(label.text().replace("&", "").split()).rstrip(":")


def name_form_fields(root: QWidget) -> int:
    """Give every form field that has no accessible name the text of its row label. Returns how many it named.

    ``QFormLayout.addRow("Text", widget)`` already sets the label's buddy, but compound widgets (a ``Stepper`` is a frame around
    a line edit) expose the inner widget to the screen reader, so the name has to be copied onto the field itself."""
    named = 0
    layouts: list[QFormLayout] = list(root.findChildren(QFormLayout))
    own = root.layout()
    if isinstance(own, QFormLayout):
        layouts.append(own)
    for form in layouts:
        for row in range(form.rowCount()):
            label_item = form.itemAt(row, QFormLayout.ItemRole.LabelRole)
            field_item = form.itemAt(row, QFormLayout.ItemRole.FieldRole)
            label = label_item.widget() if label_item is not None else None
            if not isinstance(label, QLabel) or field_item is None:
                continue
            text = _label_text(label)
            targets: list[QWidget] = []
            widget = field_item.widget()
            if widget is not None:
                targets.append(widget)
            inner = field_item.layout()
            if isinstance(inner, QLayout):  # rows such as "Warna teks · latar" hold a layout of several controls
                continue
            for target in targets:
                if text and not target.accessibleName():
                    target.setAccessibleName(text)
                    named += 1
    return named
