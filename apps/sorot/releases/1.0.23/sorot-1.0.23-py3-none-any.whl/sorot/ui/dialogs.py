"""Small utility dialogs: keyboard shortcuts and the local script library."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QEvent, QStandardPaths, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QGuiApplication, QKeySequence
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QInputDialog,
    QKeySequenceEdit,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from sorot.core.config import DEFAULT_SHORTCUTS, SHORTCUT_LABELS
from sorot.core.fileio import ScriptFileError
from sorot.core.scripts import ScriptLibrary, format_modified

# Keys the text editor (or the File menu) already uses; a window shortcut on them
# would either be swallowed by the editor or hide the editing behaviour.
RESERVED_SEQUENCES = frozenset({
    "Ctrl+A", "Ctrl+C", "Ctrl+V", "Ctrl+X", "Ctrl+Z", "Ctrl+Y", "Ctrl+H", "Ctrl+D", "Ctrl+K", "Ctrl+E", "Ctrl+B", "Ctrl+F",
    "Ctrl+Home", "Ctrl+End", "Ctrl+Up", "Ctrl+Down", "Ctrl+Left", "Ctrl+Right", "Ctrl+Backspace", "Ctrl+Delete",
    "Ctrl+N", "Ctrl+O", "Ctrl+L", "Ctrl+S", "Ctrl+Shift+S", "Ctrl+Q",
})


def shortcut_problem(sequence: str) -> str | None:
    """Why ``sequence`` cannot be used as an overlay shortcut, or ``None`` if it is fine."""
    if not sequence:
        return "tidak boleh kosong"
    if sequence in RESERVED_SEQUENCES:
        return "bentrok dengan penyuntingan teks atau menu Berkas"
    has_modifier = any(part in sequence.split("+")[:-1] for part in ("Ctrl", "Alt", "Meta"))
    if not has_modifier and not (sequence == "Esc" or (sequence.startswith("F") and sequence[1:].isdigit())):
        return "harus memakai Ctrl/Alt (tanpa itu tombol ini dipakai untuk mengetik)"
    return None


class ShortcutsDialog(QDialog):
    """Edit in-app shortcuts. These work only while a Sorot window has focus."""

    def __init__(self, shortcuts: dict[str, str], parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Pintasan keyboard")
        self.setMinimumWidth(460)
        layout = QVBoxLayout(self)
        note = QLabel(
            "Pintasan ini hanya bekerja ketika jendela utama Sorot sedang aktif. Pintasan global antar-aplikasi "
            "tidak tersedia secara andal di Wayland, jadi gunakan tombol pada overlay saat overlay berada di atas aplikasi lain."
        )
        note.setWordWrap(True)
        note.setObjectName("hint")
        layout.addWidget(note)
        form = QFormLayout()
        self.edits: dict[str, QKeySequenceEdit] = {}
        for key, label in SHORTCUT_LABELS.items():
            edit = QKeySequenceEdit(QKeySequence(shortcuts.get(key, DEFAULT_SHORTCUTS[key])))
            edit.setMaximumSequenceLength(1)
            edit.setAccessibleName(label)
            self.edits[key] = edit
            form.addRow(label, edit)
        layout.addLayout(form)
        self.error = QLabel("")
        self.error.setObjectName("warning")
        self.error.setWordWrap(True)
        self.error.hide()
        layout.addWidget(self.error)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        defaults = buttons.addButton("Kembalikan bawaan", QDialogButtonBox.ButtonRole.ResetRole)
        defaults.clicked.connect(self._reset)
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _reset(self) -> None:
        for key, edit in self.edits.items():
            edit.setKeySequence(QKeySequence(DEFAULT_SHORTCUTS[key]))

    def values(self) -> dict[str, str]:
        return {key: edit.keySequence().toString(QKeySequence.SequenceFormat.PortableText) for key, edit in self.edits.items()}

    def _accept(self) -> None:
        values = self.values()
        for key, value in values.items():
            problem = shortcut_problem(value)
            if problem:
                self._show_error(f"“{SHORTCUT_LABELS[key]}”: {problem}.")
                return
        seen: dict[str, str] = {}
        for key, value in values.items():
            if value in seen:
                self._show_error(f"Pintasan “{value}” dipakai ganda oleh “{SHORTCUT_LABELS[seen[value]]}” dan “{SHORTCUT_LABELS[key]}”.")
                return
            seen[value] = key
        self.accept()

    def _show_error(self, message: str) -> None:
        self.error.setText(message)
        self.error.show()


class ScriptLibraryDialog(QDialog):
    """Browse, save, open, and delete scripts stored privately on this computer."""

    openRequested = Signal(str)

    def __init__(self, library: ScriptLibrary, current_text: str, parent=None) -> None:
        super().__init__(parent)
        self.library = library
        self.current_text = current_text
        self.setWindowTitle("Naskah lokal")
        self.resize(520, 420)
        layout = QVBoxLayout(self)
        info = QLabel(f"Disimpan hanya di komputer ini:\n{library.directory}")
        info.setWordWrap(True)
        info.setObjectName("hint")
        layout.addWidget(info)
        self.list = QListWidget()
        self.list.setAccessibleName("Daftar naskah lokal")
        self.list.itemDoubleClicked.connect(lambda _item: self._open())
        layout.addWidget(self.list, 1)
        self.message = QLabel("")
        self.message.setObjectName("hint")
        layout.addWidget(self.message)
        row = QHBoxLayout()
        self.open_btn = QPushButton("Buka")
        self.open_btn.setObjectName("primary")
        self.save_btn = QPushButton("Simpan naskah saat ini…")
        self.delete_btn = QPushButton("Hapus…")
        self.folder_btn = QPushButton("Buka folder")
        close_btn = QPushButton("Tutup")
        for button in (self.open_btn, self.save_btn, self.delete_btn, self.folder_btn):
            row.addWidget(button)
        row.addStretch(1)
        row.addWidget(close_btn)
        layout.addLayout(row)
        self.open_btn.clicked.connect(self._open)
        self.save_btn.clicked.connect(self._save)
        self.delete_btn.clicked.connect(self._delete)
        self.folder_btn.clicked.connect(self._open_folder)
        close_btn.clicked.connect(self.accept)
        self.list.itemSelectionChanged.connect(self._update_buttons)
        self.refresh()

    def refresh(self, select: str | None = None) -> None:
        self.list.clear()
        for entry in self.library.list():
            item = QListWidgetItem(f"{entry.name}    ·    {format_modified(entry.modified)}    ·    {entry.size:,} B".replace(",", "."))
            item.setData(256, entry.name)
            self.list.addItem(item)
            if select == entry.name:
                self.list.setCurrentItem(item)
        if self.list.count() and self.list.currentRow() < 0:
            self.list.setCurrentRow(0)
        self.message.setText("" if self.list.count() else "Belum ada naskah tersimpan.")
        self._update_buttons()

    def _selected(self) -> str | None:
        item = self.list.currentItem()
        return item.data(256) if item else None

    def _update_buttons(self) -> None:
        has = self._selected() is not None
        self.open_btn.setEnabled(has)
        self.delete_btn.setEnabled(has)
        self.save_btn.setEnabled(bool(self.current_text.strip()))

    def _open(self) -> None:
        name = self._selected()
        if name:
            self.openRequested.emit(name)
            self.accept()

    def _save(self) -> None:
        name, ok = QInputDialog.getText(self, "Simpan naskah lokal", "Nama naskah:", text="Naskah baru")
        if not ok or not name.strip():
            return
        try:
            if self.library.exists(name) and QMessageBox.question(
                self, "Timpa naskah?", f"Naskah “{name.strip()}” sudah ada. Timpa isinya?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No,
            ) != QMessageBox.StandardButton.Yes:
                return
            path = self.library.save(name, self.current_text)
        except ScriptFileError as exc:
            QMessageBox.warning(self, "Naskah lokal", str(exc))
            return
        self.refresh(select=path.stem)
        self.message.setText(f"Tersimpan: {path.name}")

    def _delete(self) -> None:
        name = self._selected()
        if not name:
            return
        if QMessageBox.warning(
            self, "Hapus naskah?", f"Hapus naskah “{name}” dari komputer ini? Tindakan ini tidak dapat dibatalkan.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No,
        ) != QMessageBox.StandardButton.Yes:
            return
        try:
            self.library.delete(name)
        except ScriptFileError as exc:
            QMessageBox.warning(self, "Naskah lokal", str(exc))
        self.refresh()

    def _open_folder(self) -> None:
        self.library.directory.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.library.directory)))


class SnapshotDialog(QDialog):
    """Roll back to an earlier automatic snapshot of the working draft."""

    restoreRequested = Signal(str)

    def __init__(self, draft, parent=None) -> None:  # noqa: ANN001
        super().__init__(parent)
        self.draft = draft
        self.setWindowTitle("Riwayat draf")
        self.resize(560, 440)
        layout = QVBoxLayout(self)
        note = QLabel("Salinan otomatis naskah kerja (maksimal 20) disimpan di komputer ini. Memulihkan hanya mengisi editor; tidak menghapus apa pun.")
        note.setWordWrap(True)
        note.setProperty("role", "muted")
        layout.addWidget(note)
        self.list = QListWidget()
        self.list.setAccessibleName("Daftar snapshot draf")
        layout.addWidget(self.list, 1)
        self.preview = QLabel("")
        self.preview.setWordWrap(True)
        self.preview.setProperty("role", "note")
        layout.addWidget(self.preview)
        row = QHBoxLayout()
        self.restore_btn = QPushButton("Pulihkan ke editor")
        self.restore_btn.setProperty("role", "primary")
        close_btn = QPushButton("Tutup")
        row.addWidget(self.restore_btn)
        row.addStretch(1)
        row.addWidget(close_btn)
        layout.addLayout(row)
        self.restore_btn.clicked.connect(self._restore)
        close_btn.clicked.connect(self.accept)
        self.list.currentItemChanged.connect(self._show_preview)
        self.list.itemDoubleClicked.connect(lambda _item: self._restore())
        for snap in draft.snapshots():
            item = QListWidgetItem(f"{format_modified(snap.modified)}    ·    {snap.size:,} B".replace(",", "."))
            item.setData(256, snap.name)
            self.list.addItem(item)
        if self.list.count():
            self.list.setCurrentRow(0)
        else:
            self.preview.setText("Belum ada snapshot. Salinan dibuat otomatis saat kamu berhenti mengetik dan sebelum naskah diganti.")
        self.restore_btn.setEnabled(self.list.count() > 0)

    def _show_preview(self, current, _previous=None) -> None:  # noqa: ANN001
        if current is None:
            return
        try:
            text = self.draft.load_snapshot(current.data(256))
        except ScriptFileError as exc:
            self.preview.setText(str(exc))
            return
        words = len(text.split())
        excerpt = " ".join(text.split())[:220]
        self.preview.setText(f"{words} kata — “{excerpt}{'…' if len(text) > 220 else ''}”")

    def _restore(self) -> None:
        item = self.list.currentItem()
        if item is not None:
            self.restoreRequested.emit(item.data(256))
            self.accept()


class ScrollableDialog(QDialog):
    """A dialog whose content scrolls and whose window never exceeds the screen.

    Qt computes label size hints before the stylesheet font is applied and ignores word-wrapped height in minimum
    sizes, so larger fonts or zoom squeezed word-wrapped labels and cut text off. Here the window is sized from the
    content's real height-for-width, capped to the screen, and the rest scrolls. Subclasses put content in
    ``content_layout`` and fixed footer widgets in ``self.layout()`` after the scroller; labels listed in
    ``measured_labels`` (single-line, large font) are given the exact size their text needs.
    """

    def __init__(self, parent: QWidget | None = None, min_width: int = 460) -> None:
        super().__init__(parent)
        self._base_min_width = min_width
        self.setMinimumWidth(min_width)
        self.measured_labels: list[QLabel] = []
        self._refit = QTimer(self)  # owned by the dialog, so a pending refit dies with it
        self._refit.setSingleShot(True)
        self._refit.setInterval(0)
        self._refit.timeout.connect(self._fit_size)
        outer = self.outer_layout = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)
        outer.setSpacing(8)
        self.scroller = QScrollArea()
        self.scroller.setWidgetResizable(True)
        self.scroller.setFrameShape(QFrame.Shape.NoFrame)
        self.scroller.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.content = QWidget()
        self.content.setObjectName("supportContent")  # transparent in theme.py so the dialog background shows through
        self.content.setAutoFillBackground(False)
        self.scroller.viewport().setAutoFillBackground(False)
        self.content_layout = QVBoxLayout(self.content)
        self.content_layout.setContentsMargins(0, 0, 6, 0)
        self.content_layout.setSpacing(8)
        self.scroller.setWidget(self.content)
        outer.addWidget(self.scroller, 1)

    def _fit_size(self) -> None:
        for label in self.measured_labels:
            label.ensurePolished()
            metrics = label.fontMetrics()
            label.setMinimumHeight(metrics.height() + 6)
            label.setMinimumWidth(metrics.horizontalAdvance(label.text()) + 8)
        outer = self.layout()
        if outer is None:
            return
        outer.activate()
        screen = self.screen() or QGuiApplication.primaryScreen()
        cap = int(screen.availableGeometry().height() * 0.92) if screen else 800
        wide = int(screen.availableGeometry().width() * 0.96) if screen else 1200
        bar = self.scroller.verticalScrollBar().sizeHint().width()
        need_w = min(wide, max(self._base_min_width, self.content.minimumSizeHint().width() + bar + 40))
        if self.minimumWidth() != need_w:
            self.setMinimumWidth(need_w)
        width = max(self.width(), need_w)
        inner_w = max(self.scroller.viewport().width(), width - 40)
        content_h = self.content_layout.totalHeightForWidth(inner_w)
        rest = outer.totalHeightForWidth(width) - self.scroller.sizeHint().height()
        wanted = min(cap, content_h + max(rest, 0) + 24)
        self.setMinimumHeight(min(wanted, cap))
        if self.height() < wanted:
            self.resize(width, wanted)

    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        self._fit_size()

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self._fit_size()

    def changeEvent(self, event) -> None:  # noqa: N802
        super().changeEvent(event)
        if event.type() in (QEvent.Type.FontChange, QEvent.Type.StyleChange):
            self._refit.start()


class AboutDialog(ScrollableDialog):
    """Name, version, credit, and licence."""

    supportRequested = Signal()

    def __init__(self, environment: str, parent=None) -> None:  # noqa: ANN001
        super().__init__(parent, 460)
        from sorot import APP_NAME, AUTHOR, CONTACT_EMAIL, COPYRIGHT, HOMEPAGE_URL, LICENSE_NAME, TAGLINE, VERSION_LABEL
        from sorot.support import CONTACT_NOTE

        self.contact_email = CONTACT_EMAIL
        self.setWindowTitle(f"Tentang {APP_NAME}")
        layout = self.content_layout
        outer = self.outer_layout
        title = QLabel(APP_NAME)
        title.setProperty("role", "title")
        layout.addWidget(title)
        sub = QLabel(f"{TAGLINE} · versi {VERSION_LABEL}")
        sub.setProperty("role", "muted")
        layout.addWidget(sub)
        layout.addSpacing(8)
        credit = QLabel(f"Dibuat oleh <b>{AUTHOR}</b>")
        layout.addWidget(credit)
        layout.addWidget(QLabel(COPYRIGHT))
        licence = QLabel(f"Perangkat lunak bebas berlisensi {LICENSE_NAME}. Naskah dan pengaturan tersimpan hanya di komputer ini; AI dan Google Drive bersifat opsional dan hanya berjalan atas tindakanmu.")
        licence.setWordWrap(True)
        licence.setProperty("role", "muted")
        layout.addWidget(licence)
        from sorot.support import CREDIBILITY_URL, STATUS_NOTE, TUTORIAL_URL

        status = QLabel(STATUS_NOTE)
        status.setWordWrap(True)
        layout.addWidget(status)
        docs = QLabel(f"Tutorial: {TUTORIAL_URL}\nKredibilitas dan hal yang belum terbukti: {CREDIBILITY_URL}")
        docs.setWordWrap(True)
        docs.setProperty("role", "muted")
        docs.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(docs)
        project = QLabel(f"Kode sumber dan laporan masalah: {HOMEPAGE_URL}")  # shown as text; nothing is opened or contacted unless the user copies it
        project.setWordWrap(True)
        project.setProperty("role", "muted")
        project.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(project)
        layout.addSpacing(6)
        contact_head = QLabel("KONTAK PROFESIONAL")
        contact_head.setProperty("role", "caps")
        layout.addWidget(contact_head)
        self.email_label = QLabel(CONTACT_EMAIL)
        self.email_label.setProperty("role", "mono")
        self.email_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.email_label.setAccessibleName("Alamat email kontak")
        layout.addWidget(self.email_label)
        contact_note = QLabel(CONTACT_NOTE)
        contact_note.setWordWrap(True)
        contact_note.setProperty("role", "muted")
        layout.addWidget(contact_note)
        contact_row = QHBoxLayout()
        self.copy_email_btn = QPushButton("Salin email")
        self.send_email_btn = QPushButton("Tulis email…")
        self.copy_email_btn.clicked.connect(self._copy_email)
        self.send_email_btn.clicked.connect(self._open_mailto)
        contact_row.addWidget(self.copy_email_btn)
        contact_row.addWidget(self.send_email_btn)
        contact_row.addStretch(1)
        layout.addLayout(contact_row)
        self.contact_feedback = QLabel("")
        self.contact_feedback.setProperty("role", "muted")
        layout.addWidget(self.contact_feedback)
        env = QLabel(environment)
        env.setProperty("role", "mono")
        env.setWordWrap(True)
        layout.addSpacing(6)
        layout.addWidget(env)
        row = QHBoxLayout()
        self.support_btn = QPushButton("Dukung pengembangan…")
        self.support_btn.setProperty("role", "ghost")
        self.support_btn.clicked.connect(self.supportRequested.emit)
        close_btn = QPushButton("Tutup")
        close_btn.clicked.connect(self.accept)
        row.addWidget(self.support_btn)
        row.addStretch(1)
        row.addWidget(close_btn)
        outer.addLayout(row)

    def _copy_email(self) -> None:
        from PySide6.QtGui import QGuiApplication

        QGuiApplication.clipboard().setText(self.contact_email)
        self.contact_feedback.setText("Alamat email disalin.")

    def _open_mailto(self) -> None:
        # Only ever runs from a button click; nothing is contacted or opened before that.
        from sorot.support import contact_mailto

        QDesktopServices.openUrl(QUrl(contact_mailto(self.contact_email, "Sorot")))
        self.contact_feedback.setText("Membuka aplikasi email…")


class SupportDialog(ScrollableDialog):
    """A calm, optional page with the ways to support the author (Saweria, GoPay, SeaBank, QRIS).

    The content scrolls and the window never grows taller than the screen, so nothing is cut off on
    small displays or with large fonts. Nothing is opened or copied until the person clicks a button.
    """

    QR_WIDTH = 300  # logical pixels; the QR stays reliably scannable from another phone at this size

    def __init__(self, parent=None) -> None:  # noqa: ANN001
        super().__init__(parent, 520)
        from sorot import APP_NAME
        from sorot.support import INTRO, PROMISE, QRIS_NOTE, SEABANK_NOTE, support_info

        self.info = support_info()
        self.setWindowTitle(f"Dukung pengembangan {APP_NAME}")
        outer = self.outer_layout
        layout = self.content_layout
        self.scroller.setAccessibleName("Daftar cara mendukung")
        title = QLabel("Dukung pengembangan")
        title.setProperty("role", "title")
        layout.addWidget(title)
        intro = QLabel(INTRO)
        intro.setWordWrap(True)
        layout.addWidget(intro)
        promise = QLabel(PROMISE)
        promise.setWordWrap(True)
        promise.setProperty("role", "note")
        layout.addWidget(promise)
        layout.addSpacing(6)

        saweria = QFrame()
        saweria.setProperty("role", "panel")
        sl = QVBoxLayout(saweria)
        sl.setContentsMargins(14, 10, 14, 12)
        head = QLabel("SAWERIA")
        head.setProperty("role", "caps")
        sl.addWidget(head)
        url = QLabel(self.info.saweria_url)
        url.setProperty("role", "mono")
        url.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        sl.addWidget(url)
        row = QHBoxLayout()
        self.open_btn = QPushButton("Buka Saweria")
        self.open_btn.setProperty("role", "primary")
        self.copy_link_btn = QPushButton("Salin tautan")
        row.addWidget(self.open_btn)
        row.addWidget(self.copy_link_btn)
        row.addStretch(1)
        sl.addLayout(row)
        layout.addWidget(saweria)

        gopay, self.number_label, self.copy_number_btn = self._account_panel(
            "GOPAY", self.info.gopay_display, "Nomor GoPay", "Salin nomor",
            f"Atas nama {self.info.author}. Periksa nama penerima di aplikasi sebelum mengirim.",
        )
        layout.addWidget(gopay)
        seabank, self.seabank_label, self.copy_seabank_btn = self._account_panel(
            "SEABANK", self.info.seabank_display, "Nomor rekening SeaBank", "Salin nomor rekening", SEABANK_NOTE,
        )
        layout.addWidget(seabank)
        self.measured_labels = [self.number_label, self.seabank_label]

        qris = QFrame()
        qris.setProperty("role", "panel")
        ql = QVBoxLayout(qris)
        ql.setContentsMargins(14, 10, 14, 12)
        qhead = QLabel("QRIS")
        qhead.setProperty("role", "caps")
        ql.addWidget(qhead)
        self.qris_label = QLabel()
        self.qris_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.qris_label.setAccessibleName(f"Kode QRIS atas nama {self.info.qris_merchant}")
        self.qris_label.setAccessibleDescription(
            "Gambar kode QR untuk pembayaran. Pembaca layar tidak dapat membacanya; "
            "gunakan nomor rekening atau tautan Saweria di atas, atau simpan gambarnya."
        )
        self._load_qris_pixmap()
        ql.addWidget(self.qris_label)
        qnote = QLabel(QRIS_NOTE.format(merchant=self.info.qris_merchant))
        qnote.setProperty("role", "muted")
        qnote.setWordWrap(True)
        ql.addWidget(qnote)
        qrow = QHBoxLayout()
        self.qris_large_btn = QPushButton("Perbesar")
        self.qris_save_btn = QPushButton("Simpan gambar QRIS…")
        qrow.addWidget(self.qris_large_btn)
        qrow.addWidget(self.qris_save_btn)
        qrow.addStretch(1)
        ql.addLayout(qrow)
        layout.addWidget(qris)
        layout.addStretch(1)

        self.feedback = QLabel("")
        self.feedback.setProperty("role", "muted")
        self.feedback.setWordWrap(True)
        self.feedback.setAccessibleName("Status")
        outer.addWidget(self.feedback)
        footer = QHBoxLayout()
        thanks = QLabel("Terima kasih sudah memakai Sorot.")
        thanks.setProperty("role", "muted")
        footer.addWidget(thanks)
        footer.addStretch(1)
        close_btn = QPushButton("Tutup")
        close_btn.clicked.connect(self.accept)
        footer.addWidget(close_btn)
        outer.addLayout(footer)

        self.open_btn.clicked.connect(self._open_saweria)
        self.copy_link_btn.clicked.connect(lambda: self._copy(self.info.saweria_url, "Tautan Saweria disalin."))
        self.copy_number_btn.clicked.connect(lambda: self._copy(self.info.gopay_number, "Nomor GoPay disalin."))
        self.copy_seabank_btn.clicked.connect(lambda: self._copy(self.info.seabank_number, "Nomor rekening SeaBank disalin."))
        self.qris_large_btn.clicked.connect(self._show_large)
        self.qris_save_btn.clicked.connect(self._save_qris)

    # ------------------------------------------------------------- building
    def _account_panel(self, caption: str, shown: str, accessible: str, copy_text: str, hint: str):  # noqa: ANN202
        panel = QFrame()
        panel.setProperty("role", "panel")
        pl = QVBoxLayout(panel)
        pl.setContentsMargins(14, 10, 14, 12)
        head = QLabel(caption)
        head.setProperty("role", "caps")
        pl.addWidget(head)
        number = QLabel(shown)
        number.setProperty("role", "stat")
        number.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        number.setAccessibleName(accessible)
        pl.addWidget(number)
        note = QLabel(hint)
        note.setProperty("role", "muted")
        note.setWordWrap(True)
        pl.addWidget(note)
        row = QHBoxLayout()
        button = QPushButton(copy_text)
        row.addWidget(button)
        row.addStretch(1)
        pl.addLayout(row)
        return panel, number, button

    def _qris_card_pixmap(self):  # noqa: ANN202
        """The QR card cut out of the poster (the part people scan), or an empty pixmap if the asset is missing."""
        from PySide6.QtCore import QRect
        from PySide6.QtGui import QPixmap

        from sorot.support import QRIS_CARD_BOX, qris_asset_path

        full = QPixmap(str(qris_asset_path()))
        if full.isNull():
            return full
        left, top, right, bottom = QRIS_CARD_BOX
        return full.copy(QRect(left, top, right - left, bottom - top))

    def _load_qris_pixmap(self) -> None:
        card = self._qris_card_pixmap()
        if card.isNull():
            self.qris_label.setText("Gambar QRIS tidak ditemukan. Pakai Saweria atau nomor rekening di atas.")
            self.qris_label.setWordWrap(True)
            return
        dpr = self.devicePixelRatioF() or 1.0
        scaled = card.scaledToWidth(round(self.QR_WIDTH * dpr), Qt.TransformationMode.SmoothTransformation)
        scaled.setDevicePixelRatio(dpr)
        self.qris_label.setPixmap(scaled)
        self.qris_label.setFixedSize(scaled.deviceIndependentSize().toSize())

    # -------------------------------------------------------------- actions
    def _open_saweria(self) -> None:
        QDesktopServices.openUrl(QUrl(self.info.saweria_url))
        self.feedback.setText("Membuka Saweria di browser…")

    def _copy(self, text: str, message: str) -> None:
        QGuiApplication.clipboard().setText(text)
        self.feedback.setText(message)

    def _build_viewer(self) -> QDialog:
        """A larger view of the QR card, sized to fit the screen."""
        viewer = QDialog(self)
        viewer.setWindowTitle(f"QRIS {self.info.qris_merchant}")
        box = QVBoxLayout(viewer)
        image = QLabel()
        image.setAlignment(Qt.AlignmentFlag.AlignCenter)
        image.setAccessibleName(f"Kode QRIS atas nama {self.info.qris_merchant}, ukuran besar")
        card = self._qris_card_pixmap()
        screen = self.screen() or QGuiApplication.primaryScreen()
        area = screen.availableGeometry() if screen else None
        side = min(area.height() - 160, area.width() - 80, 760) if area else 600
        if not card.isNull():
            image.setPixmap(card.scaledToHeight(max(side, 240), Qt.TransformationMode.SmoothTransformation))
        box.addWidget(image)
        close = QPushButton("Tutup")
        close.clicked.connect(viewer.accept)
        box.addWidget(close, 0, Qt.AlignmentFlag.AlignRight)
        return viewer

    def _show_large(self) -> None:
        self._build_viewer().exec()

    def save_qris_to(self, destination: str) -> bool:
        """Copy the shipped QRIS image to ``destination``; reports the outcome in the status line."""
        import shutil
        from pathlib import Path

        from sorot.support import qris_asset_path

        try:
            target = Path(destination).expanduser()
            if target.suffix.lower() != ".png":
                target = target.with_suffix(".png")
            shutil.copyfile(qris_asset_path(), target)
        except OSError as exc:
            self.feedback.setText(f"Gambar QRIS belum tersimpan: {exc.strerror or exc}")
            return False
        self.feedback.setText(f"Gambar QRIS disimpan di {target}.")
        return True

    def _save_qris(self) -> None:
        default = Path(QStandardPaths.writableLocation(QStandardPaths.StandardLocation.PicturesLocation) or str(Path.home()))
        chosen, _ = QFileDialog.getSaveFileName(self, "Simpan gambar QRIS", str(default / "sorot-qris.png"), "Gambar PNG (*.png)")
        if chosen:
            self.save_qris_to(chosen)
