"""The Aksesibilitas page: themes for low vision and colour blindness, interface zoom, contrast readout,
screen-reader support, and the optional read-aloud feature.

The page only edits ``AppConfig`` values and asks the window to apply them; it never touches the overlay itself.
"""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFormLayout,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from sorot.core import colorvision
from sorot.core.config import THEME_LABELS, UI_SCALES, AppConfig
from sorot.ui import theme
from sorot.ui.widgets import Stepper, caps, role

# (display label, config value) for the colour-vision preview.
VISION_CHOICES = (("Penglihatan normal", "normal"), *((colorvision.KIND_LABELS[k], k) for k in colorvision.KINDS))
PROFILE_BUTTONS = (
    ("Aman buta warna", "Terapkan tampilan “Aman buta warna”"),
    ("Penglihatan rendah", "Terapkan tampilan “Penglihatan rendah”"),
    ("Ramah disleksia", "Terapkan tampilan “Ramah disleksia”"),
)


def _panel(title: str) -> tuple[QFrame, QVBoxLayout]:
    frame = QFrame()
    role(frame, "panel")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(16, 12, 16, 14)
    layout.setSpacing(8)
    layout.addWidget(caps(title))
    return frame, layout


def _note(text: str) -> QLabel:
    label = QLabel(text)
    role(label, "muted")
    label.setWordWrap(True)
    return label


class StateChips(QWidget):
    """The three state colours of the interface, shown the way a person with the chosen colour-vision deficiency sees them.
    Each chip also carries a shape and a word, because colour alone must never be the only signal."""

    CHIPS = (("●", "Menggulir", "live"), ("◐", "Siap", "accent"), ("✓", "Berhasil", "ok"))

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(8)
        self._labels: list[tuple[QLabel, str]] = []
        for glyph, word, key in self.CHIPS:
            label = QLabel(f"{glyph}  {word}")
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            label.setMinimumHeight(34)
            label.setAccessibleName(f"Contoh status {word}")
            row.addWidget(label, 1)
            self._labels.append((label, key))
        self._kind = "normal"
        self._cvd = False
        self.refresh()

    def set_mode(self, kind: str, cvd_safe: bool) -> None:
        self._kind, self._cvd = kind, cvd_safe
        self.refresh()

    def refresh(self) -> None:
        base = theme.PALETTES.get(theme.palette().name, theme.DARK)
        p = theme.cvd_safe(base) if self._cvd else base
        for label, key in self._labels:
            color = getattr(p, key)
            shown = color if self._kind == "normal" else colorvision.simulate(color, self._kind)
            ink = "#000000" if colorvision.contrast_ratio("#000000", shown) >= colorvision.contrast_ratio("#FFFFFF", shown) else "#FFFFFF"
            label.setStyleSheet(f"background: {shown}; color: {ink}; border-radius: 3px; font-weight: 700; padding: 4px 8px;")


class AccessibilityPage(QWidget):
    changed = Signal()  # any setting edited by the user
    profileRequested = Signal(str)
    readAloudRequested = Signal()
    stopReadingRequested = Signal()
    shortcutsRequested = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("page")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(26, 18, 26, 12)
        layout.setSpacing(10)
        head = QLabel("Aksesibilitas")
        role(head, "title")
        layout.addWidget(head)
        sub = QLabel("Sorot dapat dipakai dengan buta warna, penglihatan rendah, pembaca layar, dan keyboard saja.")
        role(sub, "muted")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        # ---- vision
        vision, vl = _panel("Penglihatan dan antarmuka")
        form = QFormLayout()
        form.setHorizontalSpacing(14)
        form.setVerticalSpacing(8)
        self.theme_combo = QComboBox()
        for key, label in THEME_LABELS.items():
            self.theme_combo.addItem(label, key)
        self.theme_combo.setAccessibleName("Tema antarmuka")
        self.cvd_check = QCheckBox("Warna status aman untuk buta warna")
        self.cvd_check.setToolTip("Mengganti warna merah, hijau, dan kuning pada tanda status dengan set yang tetap terbedakan bagi penderita buta warna.")
        self.scale_combo = QComboBox()
        for value in UI_SCALES:
            self.scale_combo.addItem(f"{value}%" + (" (normal)" if value == 100 else ""), value)
        self.scale_combo.setAccessibleName("Ukuran antarmuka")
        self.vision_combo = QComboBox()
        for vision_label, vision_value in VISION_CHOICES:
            self.vision_combo.addItem(vision_label, vision_value)
        self.vision_combo.setAccessibleName("Lihat contoh warna sebagai")
        self.chips = StateChips()
        form.addRow("Tema", self.theme_combo)
        form.addRow("Ukuran antarmuka", self.scale_combo)
        form.addRow("", self.cvd_check)
        form.addRow("Pratinjau penglihatan", self.vision_combo)
        vl.addLayout(form)
        vl.addWidget(self.chips)
        vl.addWidget(_note("Setiap status juga memakai bentuk dan kata (● menggulir, ◐ siap, ✓ berhasil), bukan warna saja."))
        layout.addWidget(vision)

        # ---- overlay readability
        read, rl = _panel("Keterbacaan overlay")
        self.contrast_label = QLabel("")
        self.contrast_label.setWordWrap(True)
        self.contrast_label.setAccessibleName("Kontras warna overlay")
        rl.addWidget(self.contrast_label)
        rl.addWidget(_note("Pilih satu tampilan siap pakai. Semuanya bisa diubah lagi di halaman Tampilan."))
        grid = QGridLayout()
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(8)
        self.profile_buttons: dict[str, QPushButton] = {}
        for index, (name, tip) in enumerate(PROFILE_BUTTONS):
            button = QPushButton(name)
            button.setToolTip(tip)
            button.setAccessibleName(tip)
            role(button, "ghost")
            button.clicked.connect(lambda _c=False, n=name: self.profileRequested.emit(n))
            grid.addWidget(button, 0, index)
            self.profile_buttons[name] = button
        rl.addLayout(grid)
        layout.addWidget(read)

        # ---- screen reader and speech
        speech, sl = _panel("Pembaca layar dan suara")
        self.announce_check = QCheckBox("Umumkan status ke pembaca layar")
        self.force_check = QCheckBox("Paksa aksesibilitas Qt aktif (perlu restart)")
        self.force_check.setToolTip("Gunakan jika Orca tidak membaca Sorot. Menyetel QT_ACCESSIBILITY=1 saat aplikasi dimulai.")
        self.rate_spin = Stepper(-50, 50, step=5)
        self.rate_spin.setAccessibleName("Kecepatan suara")
        rate_form = QFormLayout()
        rate_form.addRow("Kecepatan suara", self.rate_spin)
        buttons = QHBoxLayout()
        self.read_btn = QPushButton("Bacakan naskah")
        self.stop_btn = QPushButton("Hentikan suara")
        role(self.read_btn, "primary")
        role(self.stop_btn, "ghost")
        buttons.addWidget(self.read_btn)
        buttons.addWidget(self.stop_btn)
        self.system_label = QLabel("")
        role(self.system_label, "mono")
        self.system_label.setWordWrap(True)
        self.system_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByKeyboard | Qt.TextInteractionFlag.TextSelectableByMouse)
        self.system_label.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.system_label.setAccessibleName("Status teknologi bantu pada sistem ini")
        sl.addWidget(self.announce_check)
        sl.addWidget(self.force_check)
        sl.addLayout(rate_form)
        sl.addLayout(buttons)
        sl.addWidget(self.system_label)
        layout.addWidget(speech)

        # ---- keyboard
        keys, kl = _panel("Keyboard")
        kl.addWidget(_note("Semua fungsi bisa dijalankan tanpa mouse: Tab dan Shift+Tab berpindah kontrol, Ctrl+1 sampai Ctrl+6 berpindah halaman, F1 membuka daftar pintasan."))
        self.shortcuts_btn = QPushButton("Daftar pintasan (F1)")
        self.shortcuts_btn.setAccessibleName("Buka daftar pintasan keyboard")
        role(self.shortcuts_btn, "ghost")
        kl.addWidget(self.shortcuts_btn)
        layout.addWidget(keys)
        layout.addStretch(1)

        for combo in (self.theme_combo, self.scale_combo):
            combo.currentIndexChanged.connect(self._edited)
        for check in (self.cvd_check, self.announce_check, self.force_check):
            check.toggled.connect(self._edited)
        self.rate_spin.valueChanged.connect(self._edited)
        self.vision_combo.currentIndexChanged.connect(self._preview_changed)
        self.cvd_check.toggled.connect(self._preview_changed)
        self.read_btn.clicked.connect(self.readAloudRequested)
        self.stop_btn.clicked.connect(self.stopReadingRequested)
        self.shortcuts_btn.clicked.connect(self.shortcutsRequested)
        self._loading = False

    # ------------------------------------------------------------ config <-> widgets
    def load(self, c: AppConfig) -> None:
        self._loading = True
        try:
            self.theme_combo.setCurrentIndex(max(0, self.theme_combo.findData(c.theme)))
            self.scale_combo.setCurrentIndex(max(0, self.scale_combo.findData(min(UI_SCALES, key=lambda v: abs(v - c.ui_scale)))))
            self.cvd_check.setChecked(c.cvd_safe)
            self.announce_check.setChecked(c.announce_status)
            self.force_check.setChecked(c.force_accessibility)
            self.rate_spin.setValue(c.speech_rate)
        finally:
            self._loading = False
        self._preview_changed()

    def read(self, c: AppConfig) -> None:
        c.theme = self.theme_combo.currentData() or c.theme
        c.ui_scale = int(self.scale_combo.currentData() or 100)
        c.cvd_safe = self.cvd_check.isChecked()
        c.announce_status = self.announce_check.isChecked()
        c.force_accessibility = self.force_check.isChecked()
        c.speech_rate = self.rate_spin.value()

    def _edited(self, *_args) -> None:
        if not self._loading:
            self.changed.emit()

    def _preview_changed(self, *_args) -> None:
        self.chips.set_mode(self.vision_combo.currentData() or "normal", self.cvd_check.isChecked())

    def refresh_palette(self) -> None:
        self.chips.refresh()

    # ---------------------------------------------------------------- readouts
    def show_contrast(self, text: str, background: str, opacity: int) -> None:
        plain = colorvision.contrast_ratio(text, background)
        blended = colorvision.effective_contrast(text, background, opacity)
        verdict = colorvision.contrast_grade(min(plain, blended))
        low = min(plain, blended) < 3.0
        role(self.contrast_label, "warn" if low else "mono")
        shown = f"{plain:.1f}".replace(".", ",")
        worst = f"{blended:.1f}".replace(".", ",")
        advice = " Naikkan kontras: pilih teks lebih terang atau latar lebih gelap, atau kurangi transparansi." if low else ""
        self.contrast_label.setText(
            f"Kontras teks dan latar: {shown} : 1 — {verdict}. Di atas latar abu-abu (transparansi): {worst} : 1.{advice}"
        )

    def show_system(self, lines: list[str]) -> None:
        self.system_label.setText("\n".join(lines))
        self.read_btn.setEnabled(not any("tidak ada" in line and "Mesin suara" in line for line in lines))
