"""The Otomasi page: local language-model servers, the control socket, automation recipes, and the system check.

The page is a view. It raises signals; the window decides what happens (and asks the person to confirm anything
that would drive the teleprompter). It never starts a container or runs a program.
"""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from sorot.core.recipes import Recipe
from sorot.services.local_llm import LocalServer
from sorot.ui.widgets import caps, role


def _panel(title: str) -> tuple[QFrame, QVBoxLayout]:
    frame = QFrame()
    role(frame, "panel")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(16, 12, 16, 14)
    layout.setSpacing(8)
    layout.addWidget(caps(title))
    return frame, layout


def _note(text: str) -> QLabel:
    label = QLabel(text)
    role(label, "muted")
    label.setWordWrap(True)
    return label


def _readout(name: str) -> QLabel:
    label = QLabel("")
    role(label, "mono")
    label.setWordWrap(True)
    label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByKeyboard | Qt.TextInteractionFlag.TextSelectableByMouse)
    label.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
    label.setAccessibleName(name)
    return label


class AutomationPage(QWidget):
    discoverRequested = Signal()
    useServerRequested = Signal(str, str)  # base_url, model
    controlToggled = Signal(bool)
    runRecipeRequested = Signal(str)
    planRequested = Signal(str)
    saveProposalRequested = Signal()
    openFolderRequested = Signal()
    copyContainerRequested = Signal()
    doctorRequested = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("page")
        self._servers: list[LocalServer] = []
        self._recipes: list[Recipe] = []
        layout = QVBoxLayout(self)
        layout.setContentsMargins(26, 18, 26, 12)
        layout.setSpacing(10)
        head = QLabel("Otomasi")
        role(head, "title")
        layout.addWidget(head)
        layout.addWidget(_note("Model bahasa di komputer Anda sendiri, kendali dari luar lewat soket lokal, dan resep langkah yang selalu meminta konfirmasi. Tidak ada yang dijalankan tanpa Anda."))

        # ---- local LLM
        llm, ll = _panel("Server LLM lokal")
        row = QHBoxLayout()
        self.discover_btn = QPushButton("Cari server lokal")
        role(self.discover_btn, "primary")
        self.discover_btn.setAccessibleName("Cari server LLM di komputer ini")
        row.addWidget(self.discover_btn)
        row.addStretch(1)
        ll.addLayout(row)
        self.server_list = QListWidget()
        self.server_list.setAccessibleName("Server LLM yang ditemukan")
        self.server_list.setMaximumHeight(110)
        ll.addWidget(self.server_list)
        pick = QHBoxLayout()
        self.model_combo = QComboBox()
        self.model_combo.setAccessibleName("Model")
        self.use_btn = QPushButton("Pakai server dan model ini")
        self.use_btn.setEnabled(False)
        role(self.use_btn, "ghost")
        pick.addWidget(self.model_combo, 1)
        pick.addWidget(self.use_btn)
        ll.addLayout(pick)
        self.llm_state = _readout("Status server LLM lokal")
        ll.addWidget(self.llm_state)
        ll.addWidget(_note("Ollama, LM Studio, dan llama.cpp dicari di 127.0.0.1 saja. Tanpa API key; naskah tidak keluar dari komputer ini. Belum punya server? Resep kontainer tersedia."))
        self.container_btn = QPushButton("Salin perintah kontainer Ollama")
        self.container_btn.setAccessibleName("Salin perintah untuk menjalankan server Ollama dalam kontainer")
        role(self.container_btn, "ghost")
        ll.addWidget(self.container_btn)
        layout.addWidget(llm)

        # ---- control socket
        ctl, cl = _panel("Kendali dari luar (sorotctl)")
        self.control_check = QCheckBox("Aktifkan soket kontrol")
        self.control_check.setToolTip("Membuka soket Unix pribadi (hanya pengguna ini) agar `sorotctl` dapat menggulir, menjeda, dan menjalankan resep.")
        self.control_state = _readout("Status soket kontrol")
        cl.addWidget(self.control_check)
        cl.addWidget(self.control_state)
        cl.addWidget(_note("Mati secara bawaan. Hanya perintah dari daftar tetap (gulir, jeda, kecepatan, resep); tidak bisa membaca berkas, mengganti naskah, atau menjalankan program."))
        layout.addWidget(ctl)

        # ---- recipes
        rec, rl = _panel("Resep otomasi")
        self.recipe_list = QListWidget()
        self.recipe_list.setAccessibleName("Daftar resep otomasi")
        self.recipe_list.setMaximumHeight(120)
        rl.addWidget(self.recipe_list)
        self.recipe_detail = _readout("Langkah resep terpilih")
        rl.addWidget(self.recipe_detail)
        buttons = QHBoxLayout()
        self.run_btn = QPushButton("Jalankan resep")
        self.run_btn.setEnabled(False)
        role(self.run_btn, "primary")
        self.folder_btn = QPushButton("Buka folder resep")
        role(self.folder_btn, "ghost")
        buttons.addWidget(self.run_btn)
        buttons.addWidget(self.folder_btn)
        buttons.addStretch(1)
        rl.addLayout(buttons)
        self.plan_input = QLineEdit()
        self.plan_input.setPlaceholderText("Contoh: mulai dari awal, tunggu 3 detik, lalu gulir pelan")
        self.plan_input.setAccessibleName("Minta model lokal menyusun resep")
        self.plan_btn = QPushButton("Usulkan resep dengan AI lokal")
        role(self.plan_btn, "ghost")
        plan_row = QHBoxLayout()
        plan_row.addWidget(self.plan_input, 1)
        plan_row.addWidget(self.plan_btn)
        rl.addLayout(plan_row)
        self.proposal = _readout("Usulan resep dari model")
        self.save_btn = QPushButton("Simpan usulan")
        self.save_btn.setEnabled(False)
        role(self.save_btn, "ghost")
        rl.addWidget(self.proposal)
        rl.addWidget(self.save_btn)
        rl.addWidget(_note("Model hanya mengusulkan. Usulan diperiksa ketat (hanya langkah dari daftar tetap) dan baru disimpan atau dijalankan setelah Anda setuju."))
        layout.addWidget(rec)

        # ---- doctor
        doc, dl = _panel("Pemeriksaan sistem")
        self.doctor_btn = QPushButton("Jalankan pemeriksaan")
        role(self.doctor_btn, "ghost")
        self.doctor_out = _readout("Hasil pemeriksaan sistem")
        dl.addWidget(self.doctor_btn)
        dl.addWidget(self.doctor_out)
        layout.addWidget(doc)
        layout.addStretch(1)

        self.discover_btn.clicked.connect(self.discoverRequested)
        self.server_list.currentRowChanged.connect(self._server_chosen)
        self.use_btn.clicked.connect(self._use)
        self.container_btn.clicked.connect(self.copyContainerRequested)
        self.control_check.toggled.connect(self._control_toggled)
        self.recipe_list.currentRowChanged.connect(self._recipe_chosen)
        self.run_btn.clicked.connect(self._run)
        self.folder_btn.clicked.connect(self.openFolderRequested)
        self.plan_btn.clicked.connect(lambda: self.planRequested.emit(self.plan_input.text()))
        self.plan_input.returnPressed.connect(lambda: self.planRequested.emit(self.plan_input.text()))
        self.save_btn.clicked.connect(self.saveProposalRequested)
        self.doctor_btn.clicked.connect(self.doctorRequested)
        self._loading = False

    # ------------------------------------------------------------ local servers
    def set_servers(self, servers: list[LocalServer]) -> None:
        self._servers = list(servers)
        self.server_list.clear()
        for server in servers:
            mark = "ada" if server.reachable else "tidak ada"
            item = QListWidgetItem(f"{server.label} — {mark} ({server.base_url})")
            self.server_list.addItem(item)
        found = [i for i, s in enumerate(servers) if s.reachable]
        if found:
            self.server_list.setCurrentRow(found[0])
            self.llm_state.setText(f"{len(found)} server lokal ditemukan.")
        else:
            self.model_combo.clear()
            self.use_btn.setEnabled(False)
            self.llm_state.setText("Tidak ada server lokal yang menjawab. Jalankan Ollama, LM Studio, atau llama.cpp, atau pakai resep kontainer.")

    def _server_chosen(self, row: int) -> None:
        self.model_combo.clear()
        server = self._servers[row] if 0 <= row < len(self._servers) else None
        if server is None or not server.reachable:
            self.use_btn.setEnabled(False)
            if server is not None:
                self.llm_state.setText(server.detail)
            return
        for model in server.models:
            self.model_combo.addItem(model, model)
        self.use_btn.setEnabled(bool(server.models))
        self.llm_state.setText(server.detail)

    def _use(self) -> None:
        row = self.server_list.currentRow()
        if 0 <= row < len(self._servers) and self.model_combo.currentData():
            self.useServerRequested.emit(self._servers[row].base_url, str(self.model_combo.currentData()))

    def set_busy_discover(self, busy: bool) -> None:
        self.discover_btn.setEnabled(not busy)
        if busy:
            self.llm_state.setText("Mencari server di 127.0.0.1…")

    # ------------------------------------------------------------ control socket
    def _control_toggled(self, on: bool) -> None:
        if not self._loading:
            self.controlToggled.emit(on)

    def set_control(self, enabled: bool, text: str) -> None:
        self._loading = True
        try:
            self.control_check.setChecked(enabled)
        finally:
            self._loading = False
        self.control_state.setText(text)

    # ------------------------------------------------------------ recipes
    def set_recipes(self, recipes: list[Recipe], problems: list[str]) -> None:
        self._recipes = list(recipes)
        self.recipe_list.clear()
        for recipe in recipes:
            self.recipe_list.addItem(f"{recipe.name}" + (f" — {recipe.description}" if recipe.description else ""))
        if recipes:
            self.recipe_list.setCurrentRow(0)
        if problems:
            self.recipe_detail.setText("Resep ditolak: " + "; ".join(problems[:3]))

    def selected_recipe(self) -> Recipe | None:
        row = self.recipe_list.currentRow()
        return self._recipes[row] if 0 <= row < len(self._recipes) else None

    def _recipe_chosen(self, _row: int) -> None:
        recipe = self.selected_recipe()
        self.run_btn.setEnabled(recipe is not None)
        if recipe is not None:
            steps = "\n".join(f"{i}. {s.describe()}" for i, s in enumerate(recipe.steps, start=1))
            self.recipe_detail.setText(steps + ("\n(meminta konfirmasi sebelum berjalan)" if recipe.confirm else ""))

    def _run(self) -> None:
        recipe = self.selected_recipe()
        if recipe is not None:
            self.runRecipeRequested.emit(recipe.name)

    def show_proposal(self, recipe: Recipe | None, message: str = "") -> None:
        if recipe is None:
            self.proposal.setText(message)
            self.save_btn.setEnabled(False)
            return
        steps = "\n".join(f"{i}. {s.describe()}" for i, s in enumerate(recipe.steps, start=1))
        self.proposal.setText(f"{recipe.name}: {recipe.description}\n{steps}".strip())
        self.save_btn.setEnabled(True)

    def set_planning(self, busy: bool) -> None:
        self.plan_btn.setEnabled(not busy)
        if busy:
            self.proposal.setText("Model lokal sedang menyusun usulan…")

    # ------------------------------------------------------------ doctor
    def show_doctor(self, text: str) -> None:
        self.doctor_out.setText(text)
        self.doctor_btn.setEnabled(True)
