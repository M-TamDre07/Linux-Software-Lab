"""Automation recipes: a short, validated list of steps that drive the teleprompter.

A recipe can only use the commands in ``STEP_COMMANDS``; there is no shell, no file access, no network and no
way to run another program. The same strict validator checks recipes written by hand, loaded from disk, and
drafted by a language model, so a model can never smuggle in a step the user could not have written.
"""
from __future__ import annotations

import json
import re
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

MAX_STEPS = 20
MAX_WAIT_SECONDS = 30.0
MAX_TOTAL_WAIT = 120.0
MAX_RECIPES = 50
MAX_FILE_BYTES = 64 * 1024
NAME_RE = re.compile(r"^[\w][\w .\-]{0,59}$")

#: command -> (argument name or None, minimum, maximum, human description)
STEP_COMMANDS: dict[str, tuple[str | None, float, float, str]] = {
    "show": (None, 0, 0, "Tampilkan overlay (dijeda)"),
    "hide": (None, 0, 0, "Sembunyikan overlay"),
    "play": (None, 0, 0, "Mulai menggulir"),
    "pause": (None, 0, 0, "Jeda"),
    "toggle": (None, 0, 0, "Mulai atau jeda"),
    "reset": (None, 0, 0, "Kembali ke awal naskah"),
    "speed": ("steps", -10, 10, "Ubah kecepatan sebanyak N langkah"),
    "wait": ("seconds", 0.1, MAX_WAIT_SECONDS, "Tunggu N detik"),
}


class RecipeError(ValueError):
    """A recipe is not acceptable; the message says why, in words a person can act on."""


@dataclass(frozen=True)
class Step:
    command: str
    value: float | None = None

    def describe(self) -> str:
        label = STEP_COMMANDS[self.command][3]
        return label.replace("N", f"{self.value:g}") if self.value is not None else label

    def to_dict(self) -> dict[str, Any]:
        spec = STEP_COMMANDS[self.command]
        return {"cmd": self.command, spec[0]: self.value} if spec[0] else {"cmd": self.command}


@dataclass(frozen=True)
class Recipe:
    name: str
    steps: tuple[Step, ...]
    description: str = ""
    confirm: bool = True
    source: str = field(default="", compare=False)

    def total_wait(self) -> float:
        return sum(s.value or 0.0 for s in self.steps if s.command == "wait")

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "description": self.description, "confirm": self.confirm, "steps": [s.to_dict() for s in self.steps]}


def _number(value: object, where: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise RecipeError(f"{where}: nilainya harus berupa angka.")
    number = float(value)
    if number != number or number in (float("inf"), float("-inf")):
        raise RecipeError(f"{where}: angka tidak valid.")
    return number


def parse_step(raw: object, index: int = 1) -> Step:
    where = f"Langkah {index}"
    if not isinstance(raw, dict):
        raise RecipeError(f"{where}: harus berupa objek JSON.")
    command = raw.get("cmd")
    if not isinstance(command, str) or command not in STEP_COMMANDS:
        shown = command if isinstance(command, str) and command.isprintable() else "?"
        raise RecipeError(f"{where}: perintah “{shown[:30]}” tidak diizinkan. Yang boleh: {', '.join(STEP_COMMANDS)}.")
    arg, low, high, _label = STEP_COMMANDS[command]
    extra = set(raw) - {"cmd", *([arg] if arg else [])}
    if extra:
        raise RecipeError(f"{where}: isian tak dikenal untuk “{command}”.")
    if arg is None:
        return Step(command)
    if arg not in raw:
        raise RecipeError(f"{where}: “{command}” butuh isian “{arg}”.")
    value = _number(raw[arg], where)
    if not low <= value <= high:
        raise RecipeError(f"{where}: “{arg}” harus antara {low:g} dan {high:g}.")
    if command == "speed":
        value = float(round(value))
    return Step(command, value)


def validate_recipe(data: object, *, source: str = "") -> Recipe:
    if not isinstance(data, dict):
        raise RecipeError("Resep harus berupa objek JSON.")
    name = data.get("name")
    if not isinstance(name, str) or not NAME_RE.match(name.strip()):
        raise RecipeError("Nama resep wajib diisi (1–60 karakter: huruf, angka, spasi, titik, minus, garis bawah).")
    description = data.get("description", "")
    if not isinstance(description, str) or len(description) > 300 or not description.isprintable():
        raise RecipeError("Deskripsi harus teks pendek (maksimal 300 karakter).")
    confirm = data.get("confirm", True)
    if not isinstance(confirm, bool):
        raise RecipeError("“confirm” harus true atau false.")
    steps_raw = data.get("steps")
    if not isinstance(steps_raw, list) or not steps_raw:
        raise RecipeError("Resep butuh daftar “steps” yang tidak kosong.")
    if len(steps_raw) > MAX_STEPS:
        raise RecipeError(f"Resep terlalu panjang (maksimal {MAX_STEPS} langkah).")
    unknown = set(data) - {"name", "description", "confirm", "steps"}
    if unknown:
        raise RecipeError("Resep memuat isian tak dikenal.")
    steps = tuple(parse_step(item, i) for i, item in enumerate(steps_raw, start=1))
    recipe = Recipe(name.strip(), steps, description.strip(), confirm, source)
    if recipe.total_wait() > MAX_TOTAL_WAIT:
        raise RecipeError(f"Total waktu tunggu terlalu lama (maksimal {MAX_TOTAL_WAIT:g} detik).")
    return recipe


# ------------------------------------------------------------------ storage
BUILTIN_RECIPES: tuple[Recipe, ...] = (
    Recipe("Mulai rekaman", (Step("reset"), Step("show"), Step("wait", 3), Step("play")), "Dari awal naskah: tampilkan overlay, tunggu 3 detik, lalu gulir.", True, "bawaan"),
    Recipe("Selesai", (Step("pause"), Step("hide")), "Jeda dan sembunyikan overlay.", False, "bawaan"),
    Recipe("Pelan lalu mulai", (Step("speed", -2), Step("show"), Step("play")), "Turunkan kecepatan dua langkah, lalu mulai.", True, "bawaan"),
)


def load_recipes(folder: Path) -> tuple[list[Recipe], list[str]]:
    """Built-in recipes plus every valid ``*.json`` in ``folder``. Problems are returned, never raised."""
    recipes = list(BUILTIN_RECIPES)
    problems: list[str] = []
    names = {r.name.casefold() for r in recipes}
    try:
        files = sorted(folder.glob("*.json"))[:MAX_RECIPES]
    except OSError:
        return recipes, problems
    for path in files:
        try:
            if path.stat().st_size > MAX_FILE_BYTES:
                raise RecipeError("berkas terlalu besar")
            recipe = validate_recipe(json.loads(path.read_text(encoding="utf-8")), source=path.name)
            if recipe.name.casefold() in names:
                raise RecipeError(f"nama “{recipe.name}” sudah dipakai")
        except (OSError, UnicodeDecodeError, ValueError, RecipeError) as exc:
            problems.append(f"{path.name}: {exc}")
            continue
        names.add(recipe.name.casefold())
        recipes.append(recipe)
    return recipes, problems


def slug(name: str) -> str:
    return re.sub(r"[^\w.-]+", "-", name.strip().casefold()).strip("-.") or "resep"


def save_recipe(folder: Path, recipe: Recipe) -> Path:
    """Write ``recipe`` as ``folder/<slug>.json`` (never overwrites an existing file)."""
    folder.mkdir(parents=True, exist_ok=True)
    base = slug(recipe.name)
    target = folder / f"{base}.json"
    counter = 2
    while target.exists():
        target = folder / f"{base}-{counter}.json"
        counter += 1
    target.write_text(json.dumps(recipe.to_dict(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return target


# ------------------------------------------------------------------ running
class RecipeRunner:
    """Run a recipe one step at a time. ``execute(step)`` returns ``None`` on success or an error message;
    ``schedule(seconds, callback)`` calls ``callback`` later (a Qt timer in the app, a fake in tests)."""

    def __init__(self, recipe: Recipe, execute: Callable[[Step], str | None], schedule: Callable[[float, Callable[[], None]], object],
                 on_done: Callable[[str], None] | None = None) -> None:
        self.recipe = recipe
        self._execute, self._schedule, self._on_done = execute, schedule, on_done or (lambda _m: None)
        self._index = 0
        self._cancelled = False
        self.finished = False
        self.error = ""

    def start(self) -> None:
        self._advance()

    def cancel(self) -> None:
        self._cancelled = True

    def _finish(self, message: str) -> None:
        if not self.finished:
            self.finished = True
            self._on_done(message)

    def _advance(self) -> None:
        while not self.finished:
            if self._cancelled:
                self._finish("Resep dibatalkan.")
                return
            if self._index >= len(self.recipe.steps):
                self._finish(f"Resep “{self.recipe.name}” selesai.")
                return
            step = self.recipe.steps[self._index]
            self._index += 1
            if step.command == "wait":
                self._schedule(step.value or 0.0, self._advance)
                return
            problem = self._execute(step)
            if problem:
                self.error = problem
                self._finish(f"Resep berhenti di langkah {self._index}: {problem}")
                return
