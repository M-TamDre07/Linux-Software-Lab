"""Colour-vision helpers: WCAG contrast, colour-blindness simulation, and perceptual distance.

Everything here is pure arithmetic (no Qt), so it is cheap to test and safe to call from the UI.

* ``contrast_ratio`` follows WCAG 2.x (relative luminance in linear sRGB).
* ``simulate`` applies the Machado, Oliveira and Fernandes (2009) matrices for severity 1.0
  (dichromacy-like), in linear RGB, plus achromatopsia as luminance only.
* ``delta_e`` is the CIE76 distance in CIELAB (D65). It is deliberately simple: the tests use it
  only to check that two colours stay clearly apart after simulation, not as a calibrated metric.
"""
from __future__ import annotations

from collections.abc import Sequence

RGB = tuple[float, float, float]

#: Machado et al. (2009), severity 1.0, applied to *linear* RGB.
_MATRICES: dict[str, tuple[tuple[float, float, float], ...]] = {
    "protanopia": ((0.152286, 1.052583, -0.204868), (0.114503, 0.786281, 0.099216), (-0.003882, -0.048116, 1.051998)),
    "deuteranopia": ((0.367322, 0.860646, -0.227968), (0.280085, 0.672501, 0.047413), (-0.011820, 0.042940, 0.968881)),
    "tritanopia": ((1.255528, -0.076749, -0.178779), (-0.078411, 0.930809, 0.147602), (0.004733, 0.691367, 0.303900)),
}
KINDS = ("protanopia", "deuteranopia", "tritanopia", "achromatopsia")
KIND_LABELS = {
    "protanopia": "Protanopia (merah tidak terlihat)",
    "deuteranopia": "Deuteranopia (hijau tidak terlihat)",
    "tritanopia": "Tritanopia (biru tidak terlihat)",
    "achromatopsia": "Akromatopsia (hanya terang-gelap)",
}


def parse_hex(value: str) -> RGB:
    text = value.strip().lstrip("#")
    if len(text) != 6:
        raise ValueError(f"warna heksadesimal tidak valid: {value!r}")
    return tuple(int(text[i : i + 2], 16) / 255.0 for i in (0, 2, 4))  # type: ignore[return-value]


def to_hex(rgb: Sequence[float]) -> str:
    return "#" + "".join(f"{round(max(0.0, min(1.0, c)) * 255):02X}" for c in rgb)


def _to_linear(c: float) -> float:
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def _to_srgb(c: float) -> float:
    c = max(0.0, min(1.0, c))
    return c * 12.92 if c <= 0.0031308 else 1.055 * c ** (1 / 2.4) - 0.055


def luminance(color: str | Sequence[float]) -> float:
    r, g, b = (parse_hex(color) if isinstance(color, str) else tuple(color))
    return 0.2126 * _to_linear(r) + 0.7152 * _to_linear(g) + 0.0722 * _to_linear(b)


def contrast_ratio(foreground: str, background: str) -> float:
    """WCAG contrast ratio between two ``#RRGGBB`` colours (1.0 .. 21.0)."""
    a, b = luminance(foreground), luminance(background)
    high, low = (a, b) if a >= b else (b, a)
    return (high + 0.05) / (low + 0.05)


def effective_contrast(text: str, background: str, opacity_percent: int, behind: str = "#808080") -> float:
    """Contrast of ``text`` against a translucent panel over an unknown backdrop (``behind``).

    The overlay background is semi-transparent, so the real backdrop is partly whatever is under it.
    This blends the panel with a mid-grey (worst-ish case for both light and dark text)."""
    alpha = max(0, min(100, opacity_percent)) / 100.0
    panel, under = parse_hex(background), parse_hex(behind)
    blended = tuple(alpha * p + (1 - alpha) * u for p, u in zip(panel, under, strict=True))
    return contrast_ratio(text, to_hex(blended))


def contrast_grade(ratio: float, *, large: bool = True) -> str:
    """Plain-language verdict. The overlay text is always large (>= 12 pt), so the large-text thresholds apply
    by default: AA = 3:1, AAA = 4.5:1. Pass ``large=False`` for body text (4.5:1 and 7:1)."""
    aa, aaa = (3.0, 4.5) if large else (4.5, 7.0)
    if ratio >= aaa:
        return "sangat baik (AAA)"
    if ratio >= aa:
        return "cukup (AA)"
    return "kurang; sulit dibaca"


def simulate(color: str, kind: str) -> str:
    """How ``color`` looks to someone with the given colour-vision deficiency (as ``#RRGGBB``)."""
    rgb = parse_hex(color)
    lin = [_to_linear(c) for c in rgb]
    if kind == "achromatopsia":
        y = 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]
        return to_hex([_to_srgb(y)] * 3)
    matrix = _MATRICES[kind]
    out = [sum(row[i] * lin[i] for i in range(3)) for row in matrix]
    return to_hex([_to_srgb(c) for c in out])


def _lab(color: str) -> tuple[float, float, float]:
    r, g, b = (_to_linear(c) for c in parse_hex(color))
    x = (0.4124564 * r + 0.3575761 * g + 0.1804375 * b) / 0.95047
    y = 0.2126729 * r + 0.7151522 * g + 0.0721750 * b
    z = (0.0193339 * r + 0.1191920 * g + 0.9503041 * b) / 1.08883

    def f(t: float) -> float:
        return t ** (1 / 3) if t > 216 / 24389 else (24389 / 27 * t + 16) / 116

    fx, fy, fz = f(x), f(y), f(z)
    return 116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)


def delta_e(a: str, b: str) -> float:
    la, lb = _lab(a), _lab(b)
    return sum((p - q) ** 2 for p, q in zip(la, lb, strict=True)) ** 0.5


def distinguishable_under_all(a: str, b: str, minimum: float = 20.0) -> dict[str, float]:
    """``{kind: delta_e}`` of two colours after simulating each deficiency (plus ``normal``)."""
    result = {"normal": delta_e(a, b)}
    for kind in KINDS:
        result[kind] = delta_e(simulate(a, kind), simulate(b, kind))
    return result


# Okabe & Ito (2008) palette: designed to stay distinguishable for the common colour-vision deficiencies.
OKABE_ITO = {
    "black": "#000000", "orange": "#E69F00", "sky": "#56B4E9", "green": "#009E73",
    "yellow": "#F0E442", "blue": "#0072B2", "vermillion": "#D55E00", "purple": "#CC79A7",
}
