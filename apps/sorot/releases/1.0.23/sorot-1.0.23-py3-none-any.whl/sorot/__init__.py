"""Sorot — teleprompter overlay desktop untuk Linux."""

__version__ = "1.0.23"
VERSION_LABEL = "1.0.23"
APP_NAME = "Sorot"
ORG_NAME = "Sorot"
AUTHOR = "Muhammad Andreatama"
CONTACT_EMAIL = "muhammadandreatama@outlook.com"  # professional inquiries
COPYRIGHT = "Hak cipta © 2026 Muhammad Andreatama"
LICENSE_NAME = "MIT"
SOURCE_URL = "https://github.com/M-TamDre07/Linux-Software-Lab"  # repositori publik (katalog Linux Software Lab)
HOMEPAGE_URL = "https://github.com/M-TamDre07/Linux-Software-Lab/tree/main/apps/sorot"
ISSUES_URL = "https://github.com/M-TamDre07/Linux-Software-Lab/issues"
TAGLINE = "Teleprompter overlay untuk Linux"
