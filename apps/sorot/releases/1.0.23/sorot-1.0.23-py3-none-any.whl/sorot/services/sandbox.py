"""Is Sorot running inside a Flatpak sandbox, and what does that mean for its optional features?

Detection is read-only: ``/.flatpak-info`` is a small key-file that the Flatpak runtime places in every sandbox.
Nothing here asks the sandbox for more permissions; it only explains what is and is not reachable.
"""
from __future__ import annotations

import configparser
import os
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path

FLATPAK_INFO = Path("/.flatpak-info")


@dataclass(frozen=True)
class SandboxInfo:
    kind: str = "none"  # "flatpak" or "none"
    app_id: str = ""
    shared: tuple[str, ...] = ()
    sockets: tuple[str, ...] = ()
    filesystems: tuple[str, ...] = ()
    notes: list[str] = field(default_factory=list, compare=False)

    @property
    def sandboxed(self) -> bool:
        return self.kind != "none"

    @property
    def network(self) -> bool:
        """With ``--share=network`` a sandboxed app shares the host network namespace, so host loopback is reachable."""
        return not self.sandboxed or "network" in self.shared

    @property
    def home_access(self) -> bool:
        return not self.sandboxed or any(f.split(":")[0] in {"home", "host", "~"} or f.startswith("~/") for f in self.filesystems)


def _split(value: str) -> tuple[str, ...]:
    return tuple(part for part in (value or "").split(";") if part)


def detect(env: Mapping[str, str] | None = None, info_path: Path = FLATPAK_INFO) -> SandboxInfo:
    environ = os.environ if env is None else env
    if not info_path.is_file() and not environ.get("FLATPAK_ID"):
        return SandboxInfo()
    parser = configparser.ConfigParser(interpolation=None, strict=False)
    try:
        parser.read_string(info_path.read_text(encoding="utf-8", errors="replace")[:65_536])
    except (OSError, configparser.Error):
        pass
    app_id = parser.get("Application", "name", fallback="") or environ.get("FLATPAK_ID", "")
    context = parser["Context"] if parser.has_section("Context") else {}
    return SandboxInfo(
        kind="flatpak",
        app_id=app_id,
        shared=_split(context.get("shared", "")),
        sockets=_split(context.get("sockets", "")),
        filesystems=_split(context.get("filesystems", "")),
    )


def limits(info: SandboxInfo) -> list[str]:
    """Plain-language list of what the sandbox changes. Empty when not sandboxed."""
    if not info.sandboxed:
        return []
    notes = [
        "Sorot berjalan di dalam sandbox Flatpak: dialog Buka/Simpan memakai portal dan folder rumah tidak dibuka penuh.",
        "Integrasi Google Drive (rclone) tidak tersedia di dalam sandbox.",
    ]
    if not info.network:
        notes.append("Izin jaringan tidak diberikan: server LLM lokal dan layanan AI tidak dapat dihubungi. Beri izin `--share=network` (Flatseal atau `flatpak override`).")
    else:
        notes.append("Jaringan dibagikan dengan host, jadi server LLM lokal di 127.0.0.1 dapat dijangkau.")
    return notes
