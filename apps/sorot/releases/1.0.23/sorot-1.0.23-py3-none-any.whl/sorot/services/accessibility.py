"""What the desktop offers for assistive technology, and how Sorot talks to it.

Nothing here changes the system. ``detect`` only reads environment variables, sockets, and ``/proc``.
"""
from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path

SCREEN_READERS = ("orca", "nvda", "speakup", "brltty")


@dataclass(frozen=True)
class AccessibilityInfo:
    atspi_bus: bool  # the AT-SPI accessibility bus is reachable for this session
    screen_reader: str  # name of a running screen reader, or ""
    qt_forced: bool  # QT_ACCESSIBILITY / QT_LINUX_ACCESSIBILITY_ALWAYS_ON requests the tree explicitly
    qt_active: bool  # Qt is publishing the tree right now (needs a QGuiApplication)
    speech: str  # engine name or ""


def _running_screen_reader(proc: Path = Path("/proc")) -> str:
    try:
        for entry in proc.iterdir():
            if not entry.name.isdigit():
                continue
            try:
                comm = (entry / "comm").read_text(encoding="utf-8", errors="replace").strip().lower()
            except OSError:
                continue
            base = comm.split(".")[0]
            if base in SCREEN_READERS or comm in {"orca", "python3 orca"} or base == "orca":
                return base
    except OSError:
        pass
    return ""


def _atspi_bus(env: Mapping[str, str]) -> bool:
    if env.get("AT_SPI_BUS_ADDRESS"):
        return True
    runtime = env.get("XDG_RUNTIME_DIR", "")
    if runtime and any(Path(runtime, "at-spi").glob("bus*")):
        return True
    return bool(runtime and Path(runtime, "at-spi-bus").exists())


def detect(env: Mapping[str, str] | None = None, *, proc: Path = Path("/proc")) -> AccessibilityInfo:
    values = os.environ if env is None else env
    forced = values.get("QT_LINUX_ACCESSIBILITY_ALWAYS_ON", "") not in {"", "0"} or values.get("QT_ACCESSIBILITY", "") == "1"
    active = False
    try:
        from PySide6.QtGui import QAccessible, QGuiApplication

        if QGuiApplication.instance() is not None:
            active = bool(QAccessible.isActive())
    except Exception:  # noqa: BLE001 - detection must never break the report
        pass
    from sorot.services.speech import find_engine

    engine = find_engine()
    return AccessibilityInfo(_atspi_bus(values), _running_screen_reader(proc), forced, active, engine[0] if engine else "")


def startup_environment(config_force: bool, env: dict[str, str] | None = None) -> bool:
    """Set the Qt variables that publish the accessibility tree. Must run before ``QApplication`` exists.
    Returns True when it changed the environment. A user's own explicit ``QT_ACCESSIBILITY=0`` is respected."""
    target = os.environ if env is None else env
    if not config_force or target.get("QT_ACCESSIBILITY") == "0":
        return False
    target["QT_ACCESSIBILITY"] = "1"
    target["QT_LINUX_ACCESSIBILITY_ALWAYS_ON"] = "1"
    return True


def format_report(info: AccessibilityInfo) -> list[str]:
    def yes(value: bool) -> str:
        return "ya" if value else "tidak"

    return [
        f"Bus aksesibilitas (AT-SPI) : {yes(info.atspi_bus)}",
        f"Pembaca layar berjalan     : {info.screen_reader or 'tidak terdeteksi'}",
        f"Pohon aksesibilitas Qt     : {'aktif' if info.qt_active else 'belum aktif'}"
        + (" (dipaksa lewat variabel lingkungan)" if info.qt_forced else ""),
        f"Mesin suara (Bacakan)      : {info.speech or 'tidak ada (pasang speech-dispatcher atau espeak-ng)'}",
    ]


def announce(widget, message: str) -> bool:  # noqa: ANN001
    """Ask the screen reader to say ``message`` politely (does not interrupt). Returns False if nothing could be sent
    (no assistive technology listening, or the Qt build lacks announcements)."""
    if not message:
        return False
    try:
        from PySide6.QtGui import QAccessible, QAccessibleAnnouncementEvent

        if not QAccessible.isActive():
            return False
        event = QAccessibleAnnouncementEvent(widget, message)
        event.setPoliteness(QAccessible.AnnouncementPoliteness.Polite)
        QAccessible.updateAccessibility(event)
        return True
    except Exception:  # noqa: BLE001
        return False
