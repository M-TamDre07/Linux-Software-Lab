"""``sorot --doctor``: one readable checklist of what works, what does not, and the next step for each.

Read-only by design. It looks at files, environment variables, and (only when asked) loopback ports; it never
starts, stops, installs or configures anything, and it never runs a container tool.
"""
from __future__ import annotations

import os
import shutil
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path

from sorot import __version__
from sorot.core import paths, recipes
from sorot.core.config import AppConfig
from sorot.services import ai_service, control, local_llm, sandbox


class Level(StrEnum):
    OK = "ok"
    INFO = "info"
    WARN = "perhatian"
    FAIL = "gagal"


MARK = {Level.OK: "✓", Level.INFO: "•", Level.WARN: "!", Level.FAIL: "✗"}


@dataclass(frozen=True)
class Check:
    level: Level
    title: str
    detail: str = ""
    hint: str = ""

    def line(self) -> str:
        text = f"{MARK[self.level]} {self.title}" + (f": {self.detail}" if self.detail else "")
        return text + (f"\n    → {self.hint}" if self.hint else "")


def containers_dir(env: Mapping[str, str] | None = None) -> Path | None:
    """Where the container recipes were installed (system, Flatpak, or a source checkout)."""
    environ = os.environ if env is None else env
    candidates = [Path("/app/share/sorot/containers"), Path("/usr/share/sorot/containers"), Path("/usr/local/share/sorot/containers")]
    candidates.append(Path(__file__).resolve().parents[3] / "packaging" / "containers")
    extra = environ.get("SOROT_CONTAINERS_DIR", "").strip()
    if extra and os.path.isabs(extra):
        candidates.insert(0, Path(extra))
    return next((p for p in candidates if (p / "ollama.compose.yaml").is_file()), None)


def check_sandbox(info: sandbox.SandboxInfo) -> list[Check]:
    if not info.sandboxed:
        return [Check(Level.INFO, "Sandbox", "tidak berjalan di Flatpak (pemasangan biasa)")]
    checks = [Check(Level.INFO, "Sandbox", f"Flatpak ({info.app_id or 'ID tidak terbaca'})")]
    if not info.network:
        checks.append(Check(Level.WARN, "Jaringan di sandbox", "tidak diizinkan", "flatpak override --user --share=network " + (info.app_id or "ID.APLIKASI")))
    return checks


def check_llm(config: AppConfig, servers: list[local_llm.LocalServer] | None, info: sandbox.SandboxInfo) -> list[Check]:
    checks: list[Check] = []
    base = config.ai_base_url
    if ai_service.is_loopback(base):
        checks.append(Check(Level.INFO, "Layanan AI terpilih", f"server lokal ({base}); naskah tidak keluar dari komputer ini"))
    else:
        try:
            host = ai_service.api_host(base)
        except ai_service.AIError:
            host = "alamat tidak valid"
        checks.append(Check(Level.INFO, "Layanan AI terpilih", f"layanan jarak jauh ({host}); naskah dikirim lewat internet saat Anda memakainya"))
    if servers is None:
        checks.append(Check(Level.INFO, "Server LLM lokal", "belum dicari", "jalankan `sorot --doctor` tanpa --offline, atau tekan Cari di halaman Otomasi"))
        return checks
    found = [s for s in servers if s.reachable]
    if not found:
        hint = "Jalankan Ollama/LM Studio/llama.cpp, atau pakai resep kontainer di folder containers (lihat docs/OTOMASI.md)."
        if info.sandboxed and not info.network:
            hint = "Sandbox tidak punya izin jaringan, jadi server lokal pun tidak terjangkau. " + hint
        checks.append(Check(Level.WARN, "Server LLM lokal", "tidak ada yang menjawab di 127.0.0.1", hint))
    for server in found:
        if server.models:
            checks.append(Check(Level.OK, f"{server.label}", f"{len(server.models)} model: {', '.join(server.models[:3])}{' …' if len(server.models) > 3 else ''}"))
        else:
            checks.append(Check(Level.WARN, f"{server.label}", "menjawab tetapi belum ada model", "unduh model lebih dulu (mis. `ollama pull NAMA_MODEL`)"))
    return checks


def check_containers(which: Callable[[str], str | None] = shutil.which, env: Mapping[str, str] | None = None) -> list[Check]:
    runtimes = [name for name in ("docker", "podman") if which(name)]
    folder = containers_dir(env)
    checks = []
    if runtimes:
        checks.append(Check(Level.INFO, "Alat kontainer", f"{', '.join(runtimes)} terpasang (Sorot tidak pernah menjalankannya)"))
    else:
        checks.append(Check(Level.INFO, "Alat kontainer", "docker/podman tidak ditemukan", "hanya perlu jika ingin server LLM dalam kontainer"))
    checks.append(
        Check(Level.OK, "Resep kontainer", str(folder)) if folder else Check(Level.WARN, "Resep kontainer", "tidak ditemukan", "ada di packaging/containers pada sumber, atau /usr/share/sorot/containers")
    )
    return checks


def check_automation(config: AppConfig, env: Mapping[str, str] | None = None) -> list[Check]:
    checks: list[Check] = []
    path = control.socket_path(env)
    if not config.control_enabled:
        checks.append(Check(Level.INFO, "Soket kontrol", "nonaktif (bawaan)", "aktifkan di halaman Otomasi bila ingin memakai `sorotctl`"))
    elif path is None:
        checks.append(Check(Level.FAIL, "Soket kontrol", "diaktifkan tetapi XDG_RUNTIME_DIR tidak ada; tidak ada tempat aman untuk soket"))
    else:
        checks.append(Check(Level.OK if path.is_socket() else Level.WARN, "Soket kontrol", f"aktif di {path}" if path.is_socket() else f"diaktifkan, tetapi {path} belum ada (Sorot belum berjalan?)"))
    loaded, problems = recipes.load_recipes(paths.automation_dir())
    checks.append(Check(Level.OK, "Resep otomasi", f"{len(loaded)} resep ({len(loaded) - len(recipes.BUILTIN_RECIPES)} milik Anda)"))
    for problem in problems:
        checks.append(Check(Level.WARN, "Resep ditolak", problem, "perbaiki atau hapus berkas itu"))
    return checks


def run(config: AppConfig, *, probe_llm: bool = True, env: Mapping[str, str] | None = None,
        discover: Callable[[], list[local_llm.LocalServer]] = local_llm.discover) -> list[Check]:
    from sorot.services import platform_info

    info = sandbox.detect(env)
    checks = [Check(Level.INFO, "Sorot", __version__)]
    family = platform_info.distro_family(platform_info._read_os_release())
    checks.append(Check(Level.INFO, "Distro", f"keluarga {family}" if family != "unknown" else "keluarga tidak dikenali", platform_info.install_hint(family) if family != "unknown" else ""))
    checks += check_sandbox(info)
    checks += check_llm(config, discover() if probe_llm else None, info)
    checks += check_containers(env=env)
    checks += check_automation(config, env)
    return checks


def format_report(checks: list[Check]) -> str:
    warn = sum(c.level is Level.WARN for c in checks)
    fail = sum(c.level is Level.FAIL for c in checks)
    head = "Pemeriksaan Sorot (hanya membaca; tidak mengubah apa pun)"
    tail = f"\n{fail} gagal, {warn} perhatian." if (fail or warn) else "\nTidak ada masalah yang ditemukan."
    return head + "\n\n" + "\n".join(check.line() for check in checks) + tail
