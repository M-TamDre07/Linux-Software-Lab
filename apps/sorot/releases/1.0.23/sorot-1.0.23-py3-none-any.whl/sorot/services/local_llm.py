"""Find and check language-model servers running on this computer.

Ollama, LM Studio and the llama.cpp server all speak the OpenAI-compatible HTTP API that ``ai_service`` already
uses, so "using a local model" is just "a base URL on loopback". This module only *looks*: it probes a few well-known
loopback ports with ``GET /v1/models``, sends no script text, no credentials, and follows no redirects. It never
starts, stops or installs a server or a container; that stays with the user (see ``packaging/containers``).
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from collections.abc import Iterable
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass

from sorot import __version__
from sorot.services.ai_service import is_loopback

MAX_PROBE_BYTES = 1_000_000
MAX_MODELS = 200
LOOPBACK = "127.0.0.1"


@dataclass(frozen=True)
class ServerPreset:
    key: str
    label: str
    port: int
    path: str = "/v1"

    def base_url(self, host: str = LOOPBACK) -> str:
        return f"http://{host}:{self.port}{self.path}"


#: Default ports of the common local servers. Only a hint: any loopback URL can be used by hand.
PRESETS: tuple[ServerPreset, ...] = (
    ServerPreset("ollama", "Ollama", 11434),
    ServerPreset("lmstudio", "LM Studio", 1234),
    ServerPreset("llamacpp", "llama.cpp (llama-server)", 8080),
)
PRESETS_BY_KEY = {preset.key: preset for preset in PRESETS}


@dataclass(frozen=True)
class LocalServer:
    key: str
    label: str
    base_url: str
    reachable: bool
    models: tuple[str, ...] = ()
    detail: str = ""


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: ANN001
        return None


_OPENER = urllib.request.build_opener(_NoRedirect, urllib.request.ProxyHandler({}))  # a proxy must never see loopback traffic


def _clean_name(value: object) -> str:
    text = value if isinstance(value, str) else ""
    text = "".join(ch for ch in text if ch.isprintable()).strip()
    return text[:200]


def parse_models(raw: bytes) -> tuple[str, ...]:
    """Model ids from an OpenAI-style ``/models`` answer. Anything unexpected gives an empty tuple, never an exception."""
    try:
        data = json.loads(raw.decode("utf-8"))
        items = data.get("data", []) if isinstance(data, dict) else []
        names = [_clean_name(item.get("id")) for item in items[:MAX_MODELS * 2] if isinstance(item, dict)]
    except (ValueError, UnicodeDecodeError, AttributeError, TypeError):
        return ()
    return tuple(dict.fromkeys(name for name in names if name))[:MAX_MODELS]


def probe(base_url: str, *, key: str = "", label: str = "", timeout: float = 1.5) -> LocalServer:
    """Ask one loopback URL for its model list. Refuses anything that is not loopback."""
    label = label or base_url
    if not is_loopback(base_url):
        return LocalServer(key, label, base_url, False, detail="Hanya alamat di komputer ini (127.0.0.1, localhost, ::1) yang diperiksa.")
    request = urllib.request.Request(
        base_url.rstrip("/") + "/models",
        headers={"Accept": "application/json", "User-Agent": f"Sorot/{__version__}"},
        method="GET",
    )
    try:
        with _OPENER.open(request, timeout=timeout) as response:
            raw = response.read(MAX_PROBE_BYTES + 1)
    except urllib.error.HTTPError as exc:
        # Something answered but not with a model list (auth wall, other service on that port).
        return LocalServer(key, label, base_url, False, detail=f"Ada layanan di alamat ini tetapi menjawab HTTP {exc.code}, bukan daftar model.")
    except (urllib.error.URLError, OSError, ValueError):
        return LocalServer(key, label, base_url, False, detail="Tidak ada server yang menjawab.")
    if len(raw) > MAX_PROBE_BYTES:
        return LocalServer(key, label, base_url, False, detail="Jawaban terlalu besar; bukan server model yang dikenali.")
    models = parse_models(raw)
    if not models:
        try:
            ok = isinstance(json.loads(raw.decode("utf-8")), dict)
        except (ValueError, UnicodeDecodeError):
            ok = False
        if not ok:
            return LocalServer(key, label, base_url, False, detail="Jawaban bukan format daftar model OpenAI.")
        return LocalServer(key, label, base_url, True, (), "Server menjawab, tetapi belum ada model yang dimuat atau diunduh.")
    return LocalServer(key, label, base_url, True, models, f"{len(models)} model tersedia.")


def discover(presets: Iterable[ServerPreset] = PRESETS, *, host: str = LOOPBACK, timeout: float = 1.0) -> list[LocalServer]:
    """Probe every preset in parallel (one thread each; nothing leaves this computer)."""
    items = list(presets)
    if not items:
        return []
    with ThreadPoolExecutor(max_workers=min(8, len(items))) as pool:
        return list(pool.map(lambda p: probe(p.base_url(host), key=p.key, label=p.label, timeout=timeout), items))


def describe(servers: Iterable[LocalServer]) -> list[str]:
    lines = []
    for server in servers:
        mark = "ada" if server.reachable else "tidak ada"
        suffix = f": {', '.join(server.models[:4])}{' …' if len(server.models) > 4 else ''}" if server.models else ""
        lines.append(f"{server.label} ({server.base_url}) — {mark}{suffix}" + ("" if server.reachable or not server.detail else f" · {server.detail}"))
    return lines
