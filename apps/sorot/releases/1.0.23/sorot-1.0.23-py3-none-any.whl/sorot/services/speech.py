"""Optional read-aloud for the script, through the speech engine the desktop already has.

Sorot bundles no voice and adds no dependency. It looks for ``spd-say`` (Speech Dispatcher, which Orca also uses)
and falls back to ``espeak-ng``. The text goes to the engine through standard input, never through a shell or the
command line, so script content can neither inject options nor be cut off by the argument-length limit.
"""
from __future__ import annotations

import logging
import shutil
import subprocess
from collections.abc import Mapping

from sorot.core.script_markup import parse_script

LOGGER = logging.getLogger(__name__)
MAX_SPOKEN_CHARS = 200_000
ENGINES = ("spd-say", "espeak-ng")


def spoken_text(raw: str) -> str:
    """The text a listener should hear: notes are dropped, ``[jeda n]`` cues become a pause (blank line)."""
    parsed = parse_script(raw)
    lines = [("" if block.kind == "cue" else block.text) for block in parsed.blocks]
    return "\n".join(lines).strip()[:MAX_SPOKEN_CHARS]


def find_engine(path: str | None = None) -> tuple[str, str] | None:
    """``(name, executable)`` of the first available engine, or ``None``."""
    for name in ENGINES:
        found = shutil.which(name, path=path)
        if found:
            return name, found
    return None


def build_command(engine: tuple[str, str], rate: int, language: str = "") -> list[str]:
    """Argument list for the engine in stdin mode. ``rate`` is -50..50 (0 = the engine's normal speed)."""
    name, exe = engine
    rate = max(-50, min(50, int(rate)))
    lang = language if language.isalpha() and 2 <= len(language) <= 3 else ""
    if name == "spd-say":
        command = [exe, "-e", "-r", str(rate * 2)]  # spd-say takes -100..100
        if lang:
            command += ["-l", lang]
        return command
    command = [exe, "--stdin", "-s", str(175 + round(rate * 1.5))]
    if lang:
        command += ["-v", lang]
    return command


class Speaker:
    """Starts and stops one reading at a time."""

    def __init__(self, env_path: str | None = None) -> None:
        self._path = env_path
        self._process: subprocess.Popen[bytes] | None = None
        self._engine = find_engine(env_path)

    @property
    def engine_name(self) -> str:
        return self._engine[0] if self._engine else ""

    def available(self) -> bool:
        return self._engine is not None

    def is_speaking(self) -> bool:
        return self._process is not None and self._process.poll() is None

    def speak(self, raw_script: str, rate: int = 0, language: str = "") -> bool:
        """Read ``raw_script`` aloud. Returns False when there is nothing to read or no engine is installed."""
        text = spoken_text(raw_script)
        if not text or self._engine is None:
            return False
        self.stop()
        command = build_command(self._engine, rate, language)
        try:
            process = subprocess.Popen(  # noqa: S603 - fixed argv, no shell
                command, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True,
            )
            assert process.stdin is not None
            process.stdin.write(text.encode("utf-8", errors="replace") + b"\n")
            process.stdin.close()
        except (OSError, BrokenPipeError) as exc:
            LOGGER.warning("Suara gagal dimulai: %s", exc)
            return False
        self._process = process
        return True

    def stop(self) -> None:
        process, self._process = self._process, None
        if process is not None and process.poll() is None:
            try:
                process.terminate()
                process.wait(timeout=2)
            except (OSError, subprocess.TimeoutExpired):
                process.kill()
        if self._engine and self._engine[0] == "spd-say":  # also cancel what the server already queued
            try:
                subprocess.run([self._engine[1], "-C"], timeout=3, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)  # noqa: S603
            except (OSError, subprocess.TimeoutExpired):
                pass


def describe(engine: tuple[str, str] | None, env: Mapping[str, str] | None = None) -> str:
    if engine is None:
        return "Suara: tidak ada mesin (pasang speech-dispatcher atau espeak-ng untuk fitur Bacakan naskah)"
    return f"Suara: {engine[0]} ({engine[1]})"
