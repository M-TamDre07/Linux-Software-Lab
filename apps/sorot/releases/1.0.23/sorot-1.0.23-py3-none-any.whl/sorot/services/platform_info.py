"""Desktop-session detection, Qt backend selection, and overlay capability report.

This module never installs or modifies anything on the system. The capability
table describes what each Qt backend is *documented or generally known* to
allow; it is guidance, not proof that a feature works on a given compositor.
"""
from __future__ import annotations

import os
import platform
import re
import shutil
import time
from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path


class Support(StrEnum):
    SUPPORTED = "umumnya didukung"
    LIMITED = "terbatas"
    UNSUPPORTED = "tidak tersedia"
    UNKNOWN = "tidak diketahui"


@dataclass(frozen=True)
class CapabilityItem:
    key: str
    label: str
    support: Support
    note: str


# --------------------------------------------------------------------------
# Session and plugin detection
# --------------------------------------------------------------------------
def classify_session(env: Mapping[str, str] | None = None) -> str:
    """Detect session type from environment variables without importing Qt."""
    values = os.environ if env is None else env
    explicit = values.get("XDG_SESSION_TYPE", "").strip().lower()
    if explicit in {"wayland", "x11", "tty"}:
        return explicit
    if values.get("WAYLAND_DISPLAY"):
        return "wayland"
    if values.get("DISPLAY"):
        return "x11"
    return "tidak diketahui"


def _plugin_loadable(path: Path) -> bool:
    """Whether the plugin library and the system libraries it needs can be loaded.

    A plugin file can exist while a dependency (e.g. ``libxcb-cursor0``) is
    missing; Qt then aborts at startup. Loading it first lets us pick another
    backend instead.
    """
    try:
        from PySide6.QtCore import QLibrary

        library = QLibrary(str(path))
        ok = library.load()
        if ok:
            library.unload()
        return bool(ok)
    except Exception:
        return True  # cannot probe: do not block the choice


def available_qt_platforms(plugin_dir: Path | None = None) -> set[str] | None:
    """Names of *loadable* Qt platform plugins, or ``None`` if undeterminable."""
    try:
        if plugin_dir is None:
            from PySide6.QtCore import QLibraryInfo

            plugin_dir = Path(QLibraryInfo.path(QLibraryInfo.LibraryPath.PluginsPath)) / "platforms"
    except Exception:  # PySide6 missing or broken
        return None
    if not plugin_dir.is_dir():
        return None
    names: set[str] = set()
    for item in plugin_dir.glob("libq*.so*"):
        stem = item.name[len("libq"):].split(".so")[0]
        name = "wayland" if stem.startswith("wayland") else stem
        if name in names:
            continue
        # Only the two backends we may choose between are probed; others are listed as found.
        if name in {"xcb", "wayland"} and not _plugin_loadable(item):
            continue
        names.add(name)
    return names


def plugin_problems(plugin_dir: Path | None = None, family: str | None = None) -> list[str]:
    """For each platform plugin that exists but cannot load, say which system library is missing and which package provides it."""
    problems: list[str] = []
    try:
        if plugin_dir is None:
            from PySide6.QtCore import QLibraryInfo

            plugin_dir = Path(QLibraryInfo.path(QLibraryInfo.LibraryPath.PluginsPath)) / "platforms"
        from PySide6.QtCore import QLibrary
    except Exception:  # noqa: BLE001
        return problems
    fam = family or distro_family()
    if not plugin_dir.is_dir():
        return problems
    for item in sorted(plugin_dir.glob("libq*.so*")):
        stem = item.name[len("libq"):].split(".so")[0]
        if stem not in {"xcb", "wayland-egl", "wayland-generic"} and not stem.startswith("wayland"):
            continue
        library = QLibrary(str(item))
        if not library.load():
            hint = missing_library_hint(library.errorString(), fam)
            problems.append(f"Plugin Qt “{stem}” tidak bisa dimuat: {hint or library.errorString()[:160]}")
        else:
            library.unload()
    return problems


@dataclass(frozen=True)
class BackendChoice:
    platform: str | None  # value for QT_QPA_PLATFORM, or None to leave Qt's default
    description: str


def select_qt_platform(
    env: Mapping[str, str] | None = None,
    *,
    preference: str = "auto",
    available: set[str] | None = None,
) -> BackendChoice:
    """Decide which Qt platform plugin to request.

    Precedence: ``SOROT_QT_PLATFORM`` > configured preference > automatic policy.
    An explicit ``QT_QPA_PLATFORM`` from the user's environment is respected
    when the preference is ``auto``.
    """
    values = os.environ if env is None else env
    forced = values.get("SOROT_QT_PLATFORM", "").strip().lower()
    choice = forced if forced in {"auto", "xcb", "wayland"} else preference if preference in {"auto", "xcb", "wayland"} else "auto"
    source = "variabel SOROT_QT_PLATFORM" if forced in {"xcb", "wayland"} else "pengaturan"
    session = classify_session(values)

    def has(name: str) -> bool:
        return available is None or name in available

    if choice in {"xcb", "wayland"}:
        if has(choice):
            return BackendChoice(choice, f"{choice} (dipilih lewat {source})")
        fallback = BackendChoice(None, f"plugin Qt “{choice}” tidak ditemukan; Qt memilih backend sendiri")
        return fallback
    if values.get("QT_QPA_PLATFORM"):
        return BackendChoice(None, f"{values['QT_QPA_PLATFORM']} (dari lingkungan pengguna)")
    if session == "wayland":
        if values.get("DISPLAY") and has("xcb"):
            return BackendChoice("xcb", "xcb melalui XWayland (otomatis; posisi overlay lebih terkontrol)")
        if values.get("WAYLAND_DISPLAY") and has("wayland"):
            return BackendChoice("wayland", "wayland asli (otomatis; XWayland tidak tersedia)")
    return BackendChoice(None, "otomatis oleh Qt")


# --------------------------------------------------------------------------
# Capability table
# --------------------------------------------------------------------------
def _backend_family(backend: str) -> str:
    name = (backend or "").lower()
    if name.startswith("wayland"):
        return "wayland"
    if name in {"xcb", "offscreen", "minimal", "eglfs", "linuxfb", "vnc"}:
        return name
    return "other"


def detect_capabilities(backend: str, session: str = "", desktop: str = "") -> list[CapabilityItem]:
    """What the overlay can reasonably expect from ``backend``.

    Every entry is an expectation derived from Qt's documentation and general
    desktop behaviour. None of it replaces testing on the real session.
    """
    family = _backend_family(backend)
    s = Support
    if family == "xcb":
        return [
            CapabilityItem("transparency", "Transparansi latar", s.SUPPORTED, "Butuh compositing aktif; hampir semua desktop modern menyalakannya."),
            CapabilityItem("position", "Posisi jendela diatur aplikasi", s.SUPPORTED, "X11/XWayland mengizinkan posisi absolut."),
            CapabilityItem("always_on_top", "Selalu di atas", s.SUPPORTED, "Bergantung pada window manager; layar penuh eksklusif dapat menutupi overlay."),
            CapabilityItem("click_through", "Klik-tembus", s.SUPPORTED, "Memakai input shape X11."),
            CapabilityItem("drag_resize", "Geser dan ubah ukuran", s.SUPPORTED, "Memakai fitur geser/ubah ukuran sistem jika ada, atau cadangan manual."),
            CapabilityItem("multi_monitor", "Pilih monitor", s.SUPPORTED, "Posisi ditentukan relatif terhadap monitor terpilih."),
        ]
    if family == "wayland":
        return [
            CapabilityItem("transparency", "Transparansi latar", s.SUPPORTED, "Umumnya tersedia."),
            CapabilityItem("position", "Posisi jendela diatur aplikasi", s.UNSUPPORTED, "Protokol Wayland melarang aplikasi menentukan posisi absolut; compositor yang memutuskan. Preset posisi dan monitor mungkin diabaikan."),
            CapabilityItem("always_on_top", "Selalu di atas", s.LIMITED, "Tidak ada mekanisme standar; sebagian compositor (mis. GNOME) mengabaikan permintaan ini. Coba mode xcb jika perlu."),
            CapabilityItem("click_through", "Klik-tembus", s.UNKNOWN, "Umumnya memakai input region kosong, tetapi perilaku antar-compositor belum diverifikasi."),
            CapabilityItem("drag_resize", "Geser dan ubah ukuran", s.SUPPORTED, "Memakai permintaan geser/ubah ukuran dari compositor (Ctrl + seret, pegangan sudut)."),
            CapabilityItem("multi_monitor", "Pilih monitor", s.LIMITED, "Compositor yang menentukan di monitor mana jendela muncul."),
        ]
    note = "Backend ini bukan target utama aplikasi; perilaku overlay tidak diketahui."
    return [
        CapabilityItem(key, label, s.UNKNOWN, note)
        for key, label in (
            ("transparency", "Transparansi latar"), ("position", "Posisi jendela diatur aplikasi"),
            ("always_on_top", "Selalu di atas"), ("click_through", "Klik-tembus"),
            ("drag_resize", "Geser dan ubah ukuran"), ("multi_monitor", "Pilih monitor"),
        )
    ]


def capability(items: list[CapabilityItem], key: str) -> CapabilityItem:
    return next(item for item in items if item.key == key)


# --------------------------------------------------------------------------
# Distribution family and install hints (0.8.1)
# --------------------------------------------------------------------------
#: ``/etc/os-release`` ``ID`` or ``ID_LIKE`` token -> package family. Order matters only for ``ID_LIKE`` lists.
_FAMILY_BY_ID: dict[str, str] = {
    "debian": "debian", "ubuntu": "debian", "linuxmint": "debian", "pop": "debian", "raspbian": "debian", "kali": "debian",
    "zorin": "debian", "elementary": "debian", "neon": "debian", "mx": "debian", "devuan": "debian", "pureos": "debian",
    "fedora": "fedora", "rhel": "fedora", "centos": "fedora", "rocky": "fedora", "almalinux": "fedora", "ol": "fedora",
    "nobara": "fedora", "bazzite": "fedora", "amzn": "fedora",
    "arch": "arch", "archarm": "arch", "manjaro": "arch", "endeavouros": "arch", "garuda": "arch", "cachyos": "arch", "artix": "arch",
    "opensuse": "suse", "opensuse-leap": "suse", "opensuse-tumbleweed": "suse", "opensuse-microos": "suse", "sles": "suse", "suse": "suse",
    "alpine": "alpine", "postmarketos": "alpine", "void": "void", "gentoo": "gentoo", "nixos": "nixos", "solus": "solus",
}
FAMILY_LABELS = {
    "debian": "Debian dan turunannya", "fedora": "Fedora / RHEL dan turunannya", "arch": "Arch dan turunannya",
    "suse": "openSUSE / SUSE", "alpine": "Alpine", "void": "Void", "gentoo": "Gentoo", "nixos": "NixOS", "solus": "Solus",
    "unknown": "tidak dikenali",
}
#: Runtime packages as the package manager of each family names them. Names outside Debian are suggestions, not verified.
_RUNTIME_PACKAGES: dict[str, tuple[str, str]] = {
    "debian": ("sudo apt install", "python3-pyside6.qtwidgets libxcb-cursor0 speech-dispatcher"),
    "fedora": ("sudo dnf install", "python3-pyside6 xcb-util-cursor speech-dispatcher"),
    "arch": ("sudo pacman -S", "pyside6 xcb-util-cursor speech-dispatcher"),
    "suse": ("sudo zypper install", "python3-pyside6 libxcb-cursor0 speech-dispatcher"),
    "alpine": ("sudo apk add", "py3-pyside6 xcb-util-cursor speech-dispatcher"),
    "void": ("sudo xbps-install", "python3-PySide6 xcb-util-cursor speechd"),
    "gentoo": ("sudo emerge", "dev-python/pyside6 x11-libs/xcb-util-cursor app-accessibility/speech-dispatcher"),
    "nixos": ("nix-shell -p", "python3Packages.pyside6 xcb-util-cursor speechd"),
    "solus": ("sudo eopkg install", "python3-pyside6 xcb-util-cursor speech-dispatcher"),
}
#: Shared library -> package name per family, for the "plugin xcb cannot load" case.
_LIBRARY_PACKAGES: dict[str, dict[str, str]] = {
    "libxcb-cursor.so.0": {"debian": "libxcb-cursor0", "fedora": "xcb-util-cursor", "arch": "xcb-util-cursor", "suse": "libxcb-cursor0",
                           "alpine": "xcb-util-cursor", "void": "xcb-util-cursor", "gentoo": "x11-libs/xcb-util-cursor", "solus": "xcb-util-cursor"},
    "libxkbcommon-x11.so.0": {"debian": "libxkbcommon-x11-0", "fedora": "libxkbcommon-x11", "arch": "libxkbcommon-x11", "suse": "libxkbcommon-x11-0",
                              "alpine": "libxkbcommon-x11", "void": "libxkbcommon-x11", "gentoo": "x11-libs/libxkbcommon", "solus": "libxkbcommon-x11"},
    "libxcb-icccm.so.4": {"debian": "libxcb-icccm4", "fedora": "xcb-util-wm", "arch": "xcb-util-wm", "suse": "libxcb-icccm4",
                          "alpine": "xcb-util-wm", "void": "xcb-util-wm", "gentoo": "x11-libs/xcb-util-wm", "solus": "xcb-util-wm"},
    "libxcb-image.so.0": {"debian": "libxcb-image0", "fedora": "xcb-util-image", "arch": "xcb-util-image", "suse": "libxcb-image0",
                          "alpine": "xcb-util-image", "void": "xcb-util-image", "gentoo": "x11-libs/xcb-util-image", "solus": "xcb-util-image"},
    "libxcb-keysyms.so.1": {"debian": "libxcb-keysyms1", "fedora": "xcb-util-keysyms", "arch": "xcb-util-keysyms", "suse": "libxcb-keysyms1",
                            "alpine": "xcb-util-keysyms", "void": "xcb-util-keysyms", "gentoo": "x11-libs/xcb-util-keysyms", "solus": "xcb-util-keysyms"},
}


_CACHE: dict[str, tuple[float, object]] = {}


def _cached(key: str, ttl: float, produce):  # noqa: ANN001, ANN202
    """The window rebuilds the report on every setting change; hardware facts barely change, so reuse them for ``ttl`` seconds."""
    now = time.monotonic()
    hit = _CACHE.get(key)
    if hit is not None and now - hit[0] < ttl:
        return hit[1]
    value = produce()
    _CACHE[key] = (now, value)
    return value


def accessibility_info(env: Mapping[str, str] | None = None):  # noqa: ANN201
    """``accessibility.detect`` cached for a few seconds (it scans /proc)."""
    from sorot.services import accessibility

    return _cached("a11y", 3.0, lambda: accessibility.detect(env))


def clear_cache() -> None:
    _CACHE.clear()


def distro_family(release: Mapping[str, str] | None = None) -> str:
    """Package family from ``/etc/os-release`` values (``ID`` first, then each ``ID_LIKE`` word); ``unknown`` if none match."""
    values = _read_os_release() if release is None else release
    tokens = [values.get("ID", "").lower(), *values.get("ID_LIKE", "").lower().split()]
    for token in tokens:
        if token in _FAMILY_BY_ID:
            return _FAMILY_BY_ID[token]
    return "unknown"


def install_hint(family: str) -> str:
    """One line a user can copy to install what Sorot needs at run time. Empty for an unknown family."""
    entry = _RUNTIME_PACKAGES.get(family)
    return f"{entry[0]} {entry[1]}" if entry else ""


_SO_NAME = re.compile(r"(lib[\w+.-]+\.so(?:\.\d+)*)(?::| =>| cannot|\))")


def missing_library_hint(error: str, family: str) -> str:
    """Turn a dynamic-loader message ("libxcb-cursor.so.0: cannot open shared object file") into a package name."""
    match = _SO_NAME.search(error or "")
    if not match:
        return ""
    library = match.group(1)
    package = _LIBRARY_PACKAGES.get(library, {}).get(family)
    if package:
        return f"{library} belum ada; pasang paket {package}"
    return f"{library} belum ada; cari paket yang menyediakannya dengan pengelola paket distro kamu"


# --------------------------------------------------------------------------
# Graphics and input drivers (read-only, from sysfs and /proc)
# --------------------------------------------------------------------------
_PCI_VENDORS = {"0x10de": "NVIDIA", "0x1002": "AMD", "0x1022": "AMD", "0x8086": "Intel", "0x1af4": "Virtio (mesin virtual)",
                "0x15ad": "VMware (mesin virtual)", "0x1b36": "QEMU (mesin virtual)", "0x1234": "QEMU/Bochs (mesin virtual)",
                "0x1414": "Microsoft Hyper-V", "0x5143": "Qualcomm", "0x13b5": "ARM Mali", "0x14e4": "Broadcom"}
_KNOWN_KERNEL_DRIVERS = {
    "nvidia": "driver proprietari NVIDIA", "nouveau": "driver terbuka nouveau", "amdgpu": "driver terbuka amdgpu", "radeon": "driver radeon",
    "i915": "driver Intel i915", "xe": "driver Intel Xe", "virtio-pci": "virtio-gpu", "vmwgfx": "vmwgfx", "bochs-drm": "bochs", "simpledrm": "simpledrm (framebuffer sederhana)",
    "vc4": "Raspberry Pi vc4", "v3d": "Raspberry Pi v3d", "panfrost": "Mali panfrost", "msm": "Qualcomm msm", "hyperv_drm": "Hyper-V",
}


@dataclass(frozen=True)
class GraphicsDevice:
    vendor: str
    driver: str
    driver_note: str
    render_node: bool  # a /dev/dri/renderD* node this user can open (hardware acceleration is reachable)


def collect_graphics(sysfs: Path = Path("/sys/class/drm"), dev_dri: Path = Path("/dev/dri")) -> list[GraphicsDevice]:
    devices: list[GraphicsDevice] = []
    try:
        cards = sorted(p for p in sysfs.glob("card[0-9]*") if p.name[4:].isdigit())
    except OSError:
        return devices
    render_ok = False
    try:
        render_ok = any(os.access(node, os.R_OK | os.W_OK) for node in dev_dri.glob("renderD*"))
    except OSError:
        pass
    for card in cards:
        device = card / "device"
        try:
            vendor = (device / "vendor").read_text(encoding="utf-8").strip().lower()
        except OSError:
            continue
        driver = ""
        try:
            driver = (device / "driver").resolve().name
        except OSError:
            pass
        devices.append(GraphicsDevice(_PCI_VENDORS.get(vendor, f"vendor {vendor}"), driver or "tidak ada",
                                      _KNOWN_KERNEL_DRIVERS.get(driver, ""), render_ok))
    return devices


def graphics_warnings(devices: list[GraphicsDevice], session: str = "") -> list[str]:
    """Plain advice derived from what the kernel reports. Guidance, not a test result."""
    notes: list[str] = []
    if not devices:
        notes.append("Tidak ada perangkat grafis DRM terdeteksi (mesin virtual, kontainer, atau sysfs tidak terbaca): Qt memakai render perangkat lunak. Sorot memakai widget raster sehingga tidak butuh GPU, tetapi transparansi tetap butuh compositor.")
        return notes
    if any(d.driver == "nvidia" for d in devices) and session == "wayland":
        notes.append("Driver proprietari NVIDIA pada Wayland: jika overlay berkedip atau tidak transparan, coba backend xcb (Sistem › Backend Qt) atau perbarui driver.")
    if any(d.driver in {"vmwgfx", "virtio-pci", "bochs-drm", "simpledrm"} for d in devices):
        notes.append("Grafis mesin virtual: compositing dan transparansi bergantung pada hypervisor; aktifkan akselerasi 3D bila ada.")
    if not any(d.render_node for d in devices):
        notes.append("Tidak ada /dev/dri/renderD* yang dapat dibuka pengguna ini; tambahkan pengguna ke grup `render` jika kamu ingin akselerasi perangkat keras.")
    return notes


def collect_input_devices(proc_file: Path = Path("/proc/bus/input/devices")) -> list[str]:
    """Names of input devices the kernel lists (keyboards, mice, presenter remotes show up here). Read-only."""
    try:
        text = proc_file.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    names = re.findall(r'^N: Name="([^"]{1,80})"', text, flags=re.M)
    skip = ("Power Button", "Sleep Button", "Lid Switch", "Video Bus", "PC Speaker", "HDA ", "Intel HID", "AT Translated")
    return [n for n in names if not n.startswith(skip)][:12]


# --------------------------------------------------------------------------
# Diagnostics report
# --------------------------------------------------------------------------
def _read_os_release() -> dict[str, str]:
    values: dict[str, str] = {}
    try:
        with open("/etc/os-release", encoding="utf-8") as handle:
            for line in handle:
                if "=" in line:
                    key, value = line.rstrip().split("=", 1)
                    values[key] = value.strip().strip('"')
    except OSError:
        pass
    return values


@dataclass(frozen=True)
class PlatformInfo:
    os_name: str
    os_id: str
    os_version: str
    python_version: str
    qt_version: str
    kernel: str
    architecture: str
    desktop: str
    session_type: str
    display: str
    wayland_display: str
    qt_plugins: str
    rclone: str
    keyring: str
    backend: str


def collect_platform_info(qt_platform: str = "belum dimulai", env: Mapping[str, str] | None = None) -> PlatformInfo:
    values = os.environ if env is None else env
    release = _read_os_release()
    try:
        import PySide6

        qt_version = getattr(PySide6, "__version__", "terpasang")
    except Exception:
        qt_version = "tidak terdeteksi di interpreter ini"
    plugins = available_qt_platforms()
    try:
        from sorot.services import keyring_service

        keyring_text = keyring_service.backend_name() if keyring_service.is_available() else "tidak tersedia (API key tidak akan disimpan permanen)"
    except Exception:
        keyring_text = "tidak tersedia"
    rclone = shutil.which("rclone")
    return PlatformInfo(
        os_name=release.get("PRETTY_NAME", platform.platform()),
        os_id=release.get("ID", "tidak diketahui"),
        os_version=release.get("VERSION_ID", "tidak diketahui"),
        python_version=platform.python_version(),
        qt_version=qt_version,
        kernel=platform.release(),
        architecture=platform.machine(),
        desktop=values.get("XDG_CURRENT_DESKTOP") or values.get("DESKTOP_SESSION", "tidak diketahui"),
        session_type=classify_session(values),
        display=values.get("DISPLAY", "") or "tidak tersedia",
        wayland_display=values.get("WAYLAND_DISPLAY", "") or "tidak tersedia",
        qt_plugins=", ".join(sorted(plugins)) if plugins is not None else "tidak dapat ditentukan",
        rclone=rclone if rclone else "belum terpasang",
        keyring=keyring_text,
        backend=qt_platform,
    )


def format_platform_report(qt_platform: str = "belum dimulai", env: Mapping[str, str] | None = None) -> str:
    from sorot import VERSION_LABEL

    info = collect_platform_info(qt_platform, env)
    lines = [
        f"Sorot {VERSION_LABEL} — Diagnostik Sistem",
        "",
        f"Sistem operasi  : {info.os_name}",
        f"ID / versi      : {info.os_id} / {info.os_version}",
        f"Python          : {info.python_version}",
        f"PySide6         : {info.qt_version}",
        f"Kernel          : {info.kernel}",
        f"Arsitektur      : {info.architecture}",
        f"Desktop         : {info.desktop}",
        f"Sesi grafis     : {info.session_type}",
        f"Backend Qt      : {info.backend}",
        f"Plugin Qt       : {info.qt_plugins}",
        f"DISPLAY         : {info.display}",
        f"WAYLAND_DISPLAY : {info.wayland_display}",
        f"rclone          : {info.rclone}",
        f"Keyring         : {info.keyring}",
        "",
        "Kemampuan overlay yang diharapkan pada backend ini (panduan, BUKAN hasil uji pada perangkatmu):",
    ]
    for item in detect_capabilities(info.backend, info.session_type, info.desktop):
        lines.append(f"  - {item.label}: {item.support.value}. {item.note}")
    family = distro_family()
    lines += ["", "Distribusi dan paket:", f"  Keluarga distro : {FAMILY_LABELS[family]}"]
    try:
        from sorot.services import distro_status

        status = distro_status.summary_lines(_read_os_release())
        lines += [f"  Status Sorot    : {status[0]}", f"  {status[1]}", f"  {status[2]}", "  Laporan uji     : jalankan  sorot --distro-report"]
    except (OSError, ValueError, KeyError):
        lines.append("  Status Sorot    : data status distro tidak terbaca (pasang pip atau Flatpak bila ragu)")
    hint = install_hint(family)
    if hint:
        lines.append(f"  Pasang kebutuhan: {hint}" + ("" if family == "debian" else "  (nama paket belum diverifikasi di distro ini)"))
    for problem in _cached("plugin_problems", 60.0, lambda: plugin_problems(family=family)):
        lines.append(f"  ! {problem}")
    devices = _cached("graphics", 30.0, collect_graphics)
    lines += ["", "Grafis dan driver (hanya dibaca dari sistem, tidak diubah):"]
    if devices:
        for device in devices:
            extra = f" — {device.driver_note}" if device.driver_note else ""
            lines.append(f"  - {device.vendor}: modul kernel {device.driver}{extra}")
    else:
        lines.append("  - tidak terdeteksi")
    lines += [f"  * {note}" for note in graphics_warnings(devices, info.session_type)]
    inputs = _cached("inputs", 10.0, collect_input_devices)
    if inputs:
        lines += ["", "Perangkat input yang dikenali kernel:"] + [f"  - {name}" for name in inputs]
    try:
        from sorot.services import accessibility

        lines += ["", "Teknologi bantu:"] + [f"  {row}" for row in accessibility.format_report(accessibility_info(env))]
    except Exception:  # noqa: BLE001 - the report must always render
        pass
    return "\n".join(lines)
