"""Local control socket: lets ``sorotctl`` (and scripts you write) drive the running Sorot.

Design rules, each of them tested:

* **Off by default** (setting ``control_enabled``); nothing listens until the user turns it on.
* A **Unix socket** in a private directory (0700) with mode 0600, never TCP. Every connection is checked with
  ``SO_PEERCRED``: only the same user is served.
* **Line-delimited JSON**, one request per line, hard size limits, idle timeout, bounded connections.
* An **allow-list** of commands with typed arguments. There is no command that reads a file, runs a program,
  changes the script text, or reaches the network. Unknown or malformed input gets an error, never a crash.

This module has no Qt dependency; the window supplies a ``dispatch`` callable that runs on its own thread.
"""
from __future__ import annotations

import contextlib
import json
import os
import socket
import stat
import struct
import threading
from collections.abc import Callable, Mapping
from pathlib import Path
from typing import Any

from sorot.core.recipes import NAME_RE

MAX_LINE = 4096
MAX_REQUESTS_PER_CONNECTION = 100
MAX_CONNECTIONS = 8
IDLE_TIMEOUT = 5.0
SOCKET_NAME = "control.sock"
_SUN_PATH_LIMIT = 100  # sockaddr_un.sun_path is 108 bytes on Linux; stay clear of the edge

#: command -> argument spec (name, kind, low, high) or None
COMMANDS: dict[str, tuple[str, str, float, float] | None] = {
    "ping": None, "version": None, "status": None,
    "show": None, "hide": None, "play": None, "pause": None, "toggle": None, "reset": None,
    "speed": ("steps", "int", -10, 10),
    "recipes": None,
    "run": ("name", "name", 0, 0),
}
READ_ONLY = frozenset({"ping", "version", "status", "recipes"})


class ControlError(Exception):
    """A request was refused; ``str(error)`` is safe to send back to the client."""


def socket_path(env: Mapping[str, str] | None = None) -> Path | None:
    """Where the socket lives, or ``None`` when there is no safe place (no ``XDG_RUNTIME_DIR``). Never falls back to /tmp."""
    environ = os.environ if env is None else env
    value = environ.get("XDG_RUNTIME_DIR", "").strip()
    if not value or not os.path.isabs(value):
        return None
    flatpak_id = environ.get("FLATPAK_ID", "").strip()
    if flatpak_id and flatpak_id.replace(".", "").replace("_", "").replace("-", "").isalnum():
        return Path(value) / "app" / flatpak_id / SOCKET_NAME  # the app's own runtime dir, visible to the host side
    return Path(value) / "sorot" / SOCKET_NAME


def client_socket_candidates(env: Mapping[str, str] | None = None) -> list[Path]:
    """Places ``sorotctl`` should look, in order: the plain location, then any Flatpak app directory."""
    environ = os.environ if env is None else env
    base = environ.get("XDG_RUNTIME_DIR", "").strip()
    if not base or not os.path.isabs(base):
        return []
    root = Path(base)
    found = [root / "sorot" / SOCKET_NAME]
    with contextlib.suppress(OSError):
        found += sorted(root.glob(f"app/*[Ss]orot*/{SOCKET_NAME}"))
    return found


# ------------------------------------------------------------------ protocol
def parse_request(line: bytes) -> tuple[Any, str, dict[str, Any]]:
    """Validate one request line. Returns ``(id, command, args)`` or raises ``ControlError``."""
    if len(line) > MAX_LINE:
        raise ControlError("Permintaan terlalu besar.")
    try:
        data = json.loads(line.decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as exc:
        raise ControlError("Permintaan bukan JSON yang valid.") from exc
    if not isinstance(data, dict):
        raise ControlError("Permintaan harus berupa objek JSON.")
    request_id = data.get("id")
    if request_id is not None and (isinstance(request_id, bool) or not isinstance(request_id, (int, str)) or len(str(request_id)) > 64):
        raise ControlError("“id” harus angka atau teks pendek.")
    command = data.get("cmd")
    if not isinstance(command, str) or command not in COMMANDS:
        raise ControlError("Perintah tidak dikenal. Yang tersedia: " + ", ".join(COMMANDS) + ".")
    args = data.get("args", {})
    if not isinstance(args, dict):
        raise ControlError("“args” harus berupa objek.")
    spec = COMMANDS[command]
    if spec is None:
        if args:
            raise ControlError(f"“{command}” tidak memakai argumen.")
        return request_id, command, {}
    name, kind, low, high = spec
    if set(args) != {name}:
        raise ControlError(f"“{command}” butuh argumen “{name}”.")
    value = args[name]
    if kind == "int":
        if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
            raise ControlError(f"“{name}” harus bilangan bulat antara {int(low)} dan {int(high)}.")
    elif not isinstance(value, str) or not NAME_RE.match(value):
        raise ControlError(f"“{name}” bukan nama yang valid.")
    return request_id, command, {name: value}


def encode_response(request_id: Any, *, result: Any = None, error: str = "") -> bytes:
    body: dict[str, Any] = {"ok": not error}
    if request_id is not None:
        body["id"] = request_id
    if error:
        body["error"] = error
    else:
        body["result"] = result if result is not None else {}
    return (json.dumps(body, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")


# ------------------------------------------------------------------ server
def _check_directory(directory: Path, uid: int) -> None:
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    info = directory.lstat()
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISDIR(info.st_mode):
        raise ControlError(f"{directory} bukan folder biasa.")
    if info.st_uid != uid:
        raise ControlError(f"{directory} bukan milik pengguna ini.")
    if info.st_mode & 0o077:
        directory.chmod(0o700)


def _peer_uid(conn: socket.socket) -> int | None:
    try:
        _pid, uid, _gid = struct.unpack("3i", conn.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize("3i")))
    except (OSError, AttributeError, struct.error):
        return None
    return uid


class ControlServer:
    def __init__(self, path: Path, dispatch: Callable[[str, dict[str, Any]], Any], *, uid: int | None = None) -> None:
        self.path = Path(path)
        self._dispatch = dispatch
        self._uid = os.getuid() if uid is None else uid
        self._sock: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._slots = threading.BoundedSemaphore(MAX_CONNECTIONS)

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> None:
        if self.running:
            return
        if len(os.fsencode(self.path)) > _SUN_PATH_LIMIT:
            raise ControlError("Jalur soket terlalu panjang.")
        _check_directory(self.path.parent, self._uid)
        if self.path.exists() or self.path.is_symlink():
            info = self.path.lstat()
            if not stat.S_ISSOCK(info.st_mode) or info.st_uid != self._uid:
                raise ControlError(f"{self.path} sudah ada dan bukan soket milik pengguna ini; tidak diganti.")
            probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            probe.settimeout(0.5)
            try:
                probe.connect(str(self.path))
            except OSError:
                self.path.unlink()  # a socket nobody answers on: left behind by a crashed run
            else:
                raise ControlError("Soket kontrol sudah dipakai oleh salinan Sorot lain.")
            finally:
                probe.close()
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            sock.bind(str(self.path))
            self.path.chmod(0o600)
            sock.listen(MAX_CONNECTIONS)
        except OSError as exc:
            sock.close()
            raise ControlError(f"Soket kontrol tidak dapat dibuka: {exc.strerror or exc}") from exc
        sock.settimeout(0.25)
        self._sock = sock
        self._stop.clear()
        self._thread = threading.Thread(target=self._accept_loop, name="sorot-control", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2)
        if self._sock is not None:
            self._sock.close()
        self._sock = None
        self._thread = None
        with contextlib.suppress(OSError):
            if self.path.is_socket():
                self.path.unlink()

    def _accept_loop(self) -> None:
        assert self._sock is not None
        while not self._stop.is_set():
            try:
                conn, _ = self._sock.accept()
            except TimeoutError:
                continue
            except OSError:
                return
            if _peer_uid(conn) != self._uid or not self._slots.acquire(blocking=False):
                conn.close()
                continue
            threading.Thread(target=self._serve, args=(conn,), name="sorot-control-conn", daemon=True).start()

    def _serve(self, conn: socket.socket) -> None:
        try:
            conn.settimeout(IDLE_TIMEOUT)
            buffer = b""
            for _ in range(MAX_REQUESTS_PER_CONNECTION):
                while b"\n" not in buffer:
                    if len(buffer) > MAX_LINE:
                        conn.sendall(encode_response(None, error="Permintaan terlalu besar."))
                        return
                    chunk = conn.recv(1024)
                    if not chunk:
                        return
                    buffer += chunk
                line, _, buffer = buffer.partition(b"\n")
                conn.sendall(self.handle_line(line))
        except (OSError, TimeoutError):
            return
        finally:
            conn.close()
            self._slots.release()

    def handle_line(self, line: bytes) -> bytes:
        request_id = None
        try:
            request_id, command, args = parse_request(line.strip())
            return encode_response(request_id, result=self._dispatch(command, args))
        except ControlError as exc:
            return encode_response(request_id, error=str(exc))
        except Exception:  # noqa: BLE001 - nothing about the failure is worth leaking to a client
            return encode_response(request_id, error="Galat internal saat menjalankan perintah.")
