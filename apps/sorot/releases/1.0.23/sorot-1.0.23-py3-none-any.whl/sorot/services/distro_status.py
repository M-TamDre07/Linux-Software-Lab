"""What is actually known about Sorot on the user's distro, read from the packaged ``distros.json``.

``distros.json`` is the single place distro statuses are written (docs, the website and this module all read it), and a
status only changes when there is evidence. This module never claims more than the file says: a derivative such as
Linux Mint is reported as "derived from Ubuntu, not tested by itself".
"""
from __future__ import annotations

import json
import platform
from collections.abc import Mapping
from pathlib import Path
from typing import Any

DATA_FILE = Path(__file__).resolve().parent.parent / "distros.json"

#: ``os-release`` ``ID`` (or ``ID_LIKE`` word) -> ``id`` of the entry in distros.json.
_ENTRY_BY_OS_ID = {
    "debian": "debian", "ubuntu": "ubuntu", "kali": "kali",
    "fedora": "fedora", "rhel": "fedora", "centos": "fedora", "rocky": "fedora", "almalinux": "fedora",
    "arch": "arch", "manjaro": "arch", "endeavouros": "arch", "archarm": "arch",
    "opensuse": "opensuse", "opensuse-leap": "opensuse", "opensuse-tumbleweed": "opensuse", "suse": "opensuse", "sles": "opensuse",
    "alpine": "alpine", "nixos": "nix",
}
#: Derivatives are matched through ID_LIKE; these first words say which tested distro they hang from.
_NOT_TESTED_NOTE = "belum ada catatan uji untuk distro ini sendiri"


def load(path: Path | None = None) -> dict[str, Any]:
    with open(path or DATA_FILE, encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict) or not isinstance(data.get("distros"), list):
        raise ValueError("distros.json tidak valid")
    return data


def entry_for(release: Mapping[str, str], data: Mapping[str, Any] | None = None) -> tuple[dict[str, Any], bool]:
    """``(entry, derived)`` for an ``/etc/os-release`` mapping. ``derived`` is true when only ID_LIKE matched."""
    data = data or load()
    by_id = {e["id"]: e for e in data["distros"]}
    own = release.get("ID", "").lower()
    if own in _ENTRY_BY_OS_ID:
        return by_id[_ENTRY_BY_OS_ID[own]], False
    for token in release.get("ID_LIKE", "").lower().split():
        if token in _ENTRY_BY_OS_ID:
            return by_id[_ENTRY_BY_OS_ID[token]], True
    return by_id["lainnya"], True


def status_label(entry: Mapping[str, Any], data: Mapping[str, Any]) -> str:
    return str(data["status_labels"][entry["status"]])


def summary_lines(release: Mapping[str, str], data: Mapping[str, Any] | None = None) -> list[str]:
    """Three plain lines for ``sorot --diagnostics``: status, evidence, what is not proven."""
    data = data or load()
    entry, derived = entry_for(release, data)
    name = release.get("PRETTY_NAME") or release.get("NAME") or platform.system()
    if derived:
        head = f"{name}: paling dekat dengan {entry['name']} ({status_label(entry, data)}), tetapi {_NOT_TESTED_NOTE}"
    else:
        head = f"{entry['name']}: {status_label(entry, data)}"
    return [head, f"Bukti: {entry['evidence']}", f"Belum terbukti: {entry['unproven']}"]


CHECKLIST = (
    "Sorot terpasang tanpa galat (`sorot --version`)",
    "Jendela utama terbuka dan teks terbaca jelas",
    "Naskah bisa diketik, disimpan, dan dibuka kembali (juga setelah aplikasi ditutup)",
    "Overlay tampil (Ctrl+Enter), bisa digeser, dan tetap di atas jendela lain",
    "Mulai/jeda (Ctrl+Space) dan ubah kecepatan (Alt+Atas/Bawah) bekerja",
    "Klik-tembus dan mode cermin (bila dipakai) bekerja",
    "Pasang ulang versi yang sama berhasil; data tidak hilang",
    "Hapus (`apt remove` / padanannya) bersih; naskah di folder rumah tetap ada",
)


def format_report(env: Mapping[str, str] | None = None, backend: str = "otomatis oleh Qt") -> str:
    """A Markdown report a tester can paste into an issue. Read-only: it prints, never sends anything."""
    from sorot import VERSION_LABEL
    from sorot.services import platform_info as pi

    info = pi.collect_platform_info(backend, env)
    data = load()
    release = pi._read_os_release()  # noqa: SLF001 - same module family, one reader of /etc/os-release
    lines = [
        f"## Laporan uji Sorot {VERSION_LABEL}",
        "",
        "Laporan ini hanya dibaca dari komputermu dan dicetak di sini; tidak ada yang dikirim ke mana pun. "
        "Periksa dan hapus bagian yang tidak ingin kamu bagikan sebelum menempelkannya.",
        "",
        "### Lingkungan",
        f"- Sistem operasi: {info.os_name} (ID `{info.os_id}`, versi `{info.os_version}`)",
        f"- Kernel / arsitektur: {info.kernel} / {info.architecture}",
        f"- Desktop / sesi: {info.desktop} / {info.session_type}",
        f"- Backend Qt: {info.backend} (plugin: {info.qt_plugins})",
        f"- Python / PySide6: {info.python_version} / {info.qt_version}",
        "- Cara memasang (isi sendiri): <!-- .deb / pipx / Flatpak / lainnya -->",
        "",
        "### Status yang tercatat untuk distro ini",
        *[f"- {line}" for line in summary_lines(release, data)],
        "",
        "### Hasil uji (beri tanda x bila berhasil; tulis catatan bila tidak)",
        *[f"- [ ] {item}" for item in CHECKLIST],
        "",
        "### Catatan",
        "<!-- Tuliskan apa yang aneh, pesan galat, atau hasil `sorot --diagnostics`. -->",
        "",
        "Status distro baru hanya dinaikkan pengelola bila bukti seperti ini ada; lihat docs/DISTRO-LAIN.md.",
    ]
    return "\n".join(lines)
