"""Qt user-interface components."""
