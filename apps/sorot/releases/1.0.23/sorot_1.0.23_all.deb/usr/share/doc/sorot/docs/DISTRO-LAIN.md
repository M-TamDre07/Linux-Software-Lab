# Distro lain: fondasi, bukan klaim

Fokus rilis ini adalah **keluarga Debian** (Debian, Ubuntu, Kali Linux), karena itu yang sudah diuji pengelola. Distro lain sengaja ditunda; yang ada hanya fondasi supaya nanti mudah dilanjutkan. Status di bawah dibaca dari `src/sorot/distros.json` (satu-satunya sumber kebenaran; README, situs, dan tes mengikutinya).

<!-- distro-table:start -->
| Distro | Status | Format | Bukti | Belum terbukti |
|---|---|---|---|---|
| **Debian** | Diuji manual oleh pengelola | sorot_X_all.deb (apt) | Laporan pengelola: pemasangan dan pemakaian diuji manual berulang kali (sekitar 30 uji, November 2026). Versi Debian yang tepat belum dicatat; laporan lapangan tertulis 0.4.0 pada Debian 13 KDE Plasma (lewat XWayland). | Overlay selalu-di-atas dan klik-tembus pada Wayland asli belum dicatat per compositor. |
| **Ubuntu** | Diuji manual oleh pengelola | wheel (pipx) atau .deb bila PySide6 tersedia | Laporan pengelola: berjalan baik di Ubuntu. Versi dan jalur pemasangan belum dicatat. Pemeriksaan apt terpisah: .deb tidak dapat dipasang di Ubuntu 24.04 karena python3-pyside6.qtwidgets tidak ada di repositorinya. | Rilis Ubuntu lain dan Linux Mint belum dicatat. |
| **Kali Linux** | Diuji manual oleh pengelola | sorot_X_all.deb (apt) | Laporan pengelola: berjalan baik di Kali Linux. Versi belum dicatat. | Belum ada catatan sesi desktop (Xfce/GNOME/KDE) maupun jalur pemasangan. |
| **Fedora / RHEL** | Paket dibangun, belum dipasang di distro sasaran | sorot-X-1.noarch.rpm | RPM noarch dibangun dan isinya dijalankan di host Ubuntu dengan RPM_NODEPS=1. | Belum dipasang di Fedora; rpmlint belum dijalankan. |
| **Arch Linux** | Paket dibangun, belum dipasang di distro sasaran | PKGBUILD + .SRCINFO | PKGBUILD dan .SRCINFO dihasilkan dan divalidasi sintaksnya. | makepkg dan namcap belum pernah dijalankan. |
| **Flatpak** | Paket dibangun, belum dipasang di distro sasaran | manifes dari make flatpak | Manifes dihasilkan dan terbaca flatpak-builder. | Belum dibangun penuh; integrasi Google Drive tidak tersedia di sandbox. |
| **openSUSE** | Hanya kerangka, belum dibangun atau diuji | kerangka di packaging/experimental/ | Kerangka ada. | Tidak dibangun, tidak diuji; nama paket belum diverifikasi. |
| **Alpine** | Hanya kerangka, belum dibangun atau diuji | kerangka di packaging/experimental/ | Kerangka ada. | Tidak dibangun, tidak diuji. |
| **NixOS / Nix** | Hanya kerangka, belum dibangun atau diuji | kerangka di packaging/experimental/ | Kerangka ada. | Tidak dibangun, tidak diuji. |
| **Void, Gentoo, Solus, dan lainnya** | Hanya deteksi dan petunjuk umum | wheel (pipx) atau make install | Sorot mengenali keluarga distro dari os-release dan memberi petunjuk umum. | Tidak ada paket; tidak diuji. |
<!-- distro-table:end -->

## Cara menaikkan status sebuah distro

Status baru hanya boleh ditulis **bila ada bukti**, dan bukti dicatat di `evidence`:

1. **kerangka → dibangun**: skrip build menghasilkan artefak dan `release.py check` lulus.
2. **dibangun → diuji-pengelola**: seseorang memasang artefak di distro itu, menjalankan `sorot --diagnostics`, membuka naskah, menampilkan overlay, dan mencatat versi distro, desktop, sesi (X11/Wayland), serta jalur pemasangannya.
3. Catat yang **belum** terbukti di `unproven`. Jangan menghapusnya tanpa uji.

## Daftar uji manual untuk satu distro baru

```bash
sorot --version
sorot --distro-report   # laporan Markdown siap tempel: lingkungan, status tercatat, dan daftar uji
sorot --diagnostics     # simpan keluarannya
sorot --doctor --offline
```

`--distro-report` hanya membaca sistem dan mencetak ke layar; tidak ada yang dikirim. Aplikasi sendiri memakai berkas status yang sama: `sorot --diagnostics` menyebut status distro yang kamu pakai, dan turunan (mis. Linux Mint) dilaporkan sebagai "paling dekat dengan Ubuntu, belum ada catatan uji untuk distro ini sendiri". Lalu: buka dan simpan naskah, tampilkan overlay, geser, mulai/jeda, ubah kecepatan, tutup dan buka lagi (draf pulih), pasang ulang versi yang sama, hapus. Tempel hasilnya di isu repositori beserta isi `/etc/os-release`.

## Yang sudah ada sebagai landasan

* Status per distro ikut terpasang di dalam aplikasi (`src/sorot/distros.json`) dan dibaca oleh `--diagnostics`, `--distro-report`, README, situs, dan tes; satu sumber.
* Deteksi keluarga distro dari `os-release` (`ID`, lalu `ID_LIKE`) dan petunjuk pustaka yang hilang per keluarga (`sorot --diagnostics`).
* Paket: `.deb`, `.rpm` (noarch), `PKGBUILD`, manifes Flatpak, kerangka openSUSE/Alpine/Nix (`packaging/experimental/`), wheel.
* Satu definisi tata letak berkas (`scripts/install-files.sh`) dan satu sumber versi, sehingga format baru tidak menyalin daftar berkas.

Rincian pengemasan: [PACKAGING.md](PACKAGING.md), [DISTRIBUSI.md](DISTRIBUSI.md).
