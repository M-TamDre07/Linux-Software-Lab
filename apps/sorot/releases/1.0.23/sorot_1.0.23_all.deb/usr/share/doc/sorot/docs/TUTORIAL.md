# Tutorial: dari pemasangan sampai merekam

Panduan ini untuk keluarga Debian (Debian, Ubuntu, Kali Linux). Setiap langkah bisa dicek sendiri: tidak ada yang perlu dipercaya begitu saja. Untuk distro lain lihat [DISTRO-LAIN.md](DISTRO-LAIN.md).

> **Catatan jujur:** pengelola melaporkan Sorot berjalan baik di Debian, Ubuntu, dan Kali Linux. Versi distro yang tepat belum dicatat. Jika di komputermu ada yang berbeda, buka [Pemecahan masalah](TROUBLESHOOTING.md) atau laporkan lewat [Kontak](../README.md#kontak).

## 1. Pasang

Unduh dua berkas dari rilis: `sorot_1.0.23_all.deb` dan `SHA256SUMS`. Lalu, di folder unduhan:

```bash
sha256sum -c --ignore-missing SHA256SUMS     # harus tertulis: sorot_1.0.23_all.deb: OK
sudo apt install ./sorot_1.0.23_all.deb
```

Awalan `./` penting: tanpa itu `apt` mencari paket bernama `sorot` di internet. Langkah pertama memastikan berkas yang kamu unduh sama persis dengan yang diterbitkan; lihat [VERIFY.md](VERIFY.md) bila rilis juga bertanda tangan GPG.

Bila `apt` melapor `python3-pyside6.qtwidgets` tidak ditemukan (terjadi di Ubuntu 24.04), pakai wheel:

```bash
sudo apt install pipx
pipx install ./sorot-1.0.23-py3-none-any.whl
```

Wheel menarik PySide6 dari PyPI, jadi butuh internet satu kali saat memasang.

## 2. Jalankan

Cari **Sorot** di menu aplikasi, atau ketik `sorot` di terminal. Cek cepat bahwa semuanya terpasang benar:

```bash
sorot --version
sorot --diagnostics   # laporan lingkungan: Qt, backend layar, GPU, perangkat input (tanpa jendela, hanya membaca)
sorot --distro-report # laporan uji siap tempel untuk isu GitHub (hanya mencetak; tidak mengirim apa pun)
sorot --doctor        # pemeriksaan fitur opsional: server LLM lokal, kontainer, soket kontrol, resep (hanya membaca)
```

## 3. Tulis atau buka naskah

Di halaman **Naskah** (`Ctrl+1`) ketik langsung, atau `Ctrl+O` untuk membuka `.txt`, `.md`, dan juga Word/OpenDocument/RTF/HTML/PDF. Bisa pula menyeret berkas ke jendela.

Dua isyarat yang berguna:

| Tulis | Hasil |
|---|---|
| `// catatan untuk diriku` | tidak tampil dan tidak dihitung |
| `[jeda]` atau `[jeda 5]` (satu baris sendiri) | layar benar-benar berhenti: tanpa angka 2 detik, dengan angka sebanyak itu detik (0,5 sampai 120) |

Naskah otomatis disimpan sebagai draf dan ada riwayat 20 snapshot, jadi tidak hilang bila aplikasi tertutup mendadak.

## 4. Atur gulir dan tampilan

Halaman **Tampilan** (`Ctrl+2`):

1. Pilih mode kecepatan: *kata/menit* (paling alami untuk berbicara), *durasi target* (selesai tepat m:ss), atau *piksel/detik*.
2. Atur huruf, warna, transparansi, dan margin. Ada tema siap pakai dan profil yang bisa diekspor.
3. Nyalakan *garis baca* agar mata tahu baris yang sedang dibaca.

Latihan satu kali tanpa merekam: tekan `Ctrl+Enter` untuk menampilkan overlay, `Ctrl+Space` untuk mulai/jeda.

## 5. Rekam

1. Buka aplikasi perekam kamu (OBS, SimpleScreenRecorder, kamera, atau aplikasi rapat).
2. Tampilkan overlay (`Ctrl+Enter`), geser ke dekat lensa kamera dengan pegangan **Geser**.
3. Mulai membaca dengan `Ctrl+Space`. Ubah kecepatan dengan `Alt+↑` / `Alt+↓`.
4. `Esc` menyembunyikan overlay.

Pintasan global antar-aplikasi tidak tersedia secara andal di Wayland. Saat overlay berada di atas aplikasi lain, pakai tombol di overlay (arahkan kursor ke sana).

> **Overlay tidak menjamin tersembunyi dari berbagi layar atau rekaman.** Jika kamu merekam layar penuh, overlay ikut terekam kecuali aplikasi perekammu hanya menangkap satu jendela.

## 6. Bila ada yang tidak pas

| Gejala | Coba |
|---|---|
| Overlay tidak selalu di atas / tidak bisa digeser di Wayland | `SOROT_QT_PLATFORM=xcb sorot` (memakai XWayland) |
| Huruf terlalu kecil | Aksesibilitas (`Ctrl+Shift+A`): zoom antarmuka hingga 200% |
| Ingin tahu apa yang dibaca Sorot dari sistemmu | `sorot --diagnostics` dan `sorot --doctor` |
| Setelah pembaruan, ingin kembali | `sorot --upgrade-info` menampilkan cadangan; `sorot --restore FILE.zip` memulihkan |

Selengkapnya: [TROUBLESHOOTING.md](TROUBLESHOOTING.md) dan [COMPATIBILITY.md](COMPATIBILITY.md).

## 7. Perbarui dan hapus

Memasang `.deb` versi baru di atas versi lama sudah cukup; data dicadangkan otomatis saat peluncuran pertama. Menghapus program:

```bash
sudo apt remove sorot            # naskah dan pengaturanmu di ~ tidak dihapus
```

## 8. Fitur opsional (boleh dilewati)

* **Asisten AI**: perbaiki bahasa, ringkas, terjemahkan, lewat API milikmu. Atau tanpa internet: **LLM lokal** di halaman Otomasi ([OTOMASI.md](OTOMASI.md)). Naskah hanya dikirim saat kamu menekan **Proses naskah**.
* **Google Drive** lewat rclone milikmu sendiri.
* **Ekstensi** ([EXTENSIONS.md](EXTENSIONS.md)): pasang hanya dari sumber yang kamu percaya.

## 9. Dukung bila bermanfaat

Sukarela. Tombol *Dukung Sorot* di rail kiri membuka Saweria, GoPay, SeaBank, dan QRIS. Tidak ada fitur yang dikunci.
