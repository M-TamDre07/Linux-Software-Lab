# Checklist rilis

Bagian otomatis dijalankan oleh `make release-check` (dan oleh tes `tests/test_packaging.py`); yang tersisa adalah hal yang hanya bisa diputuskan atau diuji manusia di mesin nyata.

## Otomatis (jangan dicentang manual)

```bash
python3 scripts/release.py bump X.Y.Z --date YYYY-MM-DD   # satu perintah untuk semua nomor versi
make release-check test                                    # versi, changelog, tanggal, kontak, aset, placeholder
make dist                                                  # .deb, wheel, sumber, arch/, SHA256SUMS
```

`release-check` memastikan: `__version__` = `VERSION_LABEL` = changelog teratas = changelog Debian = README = PKGBUILD; tanggal rilis valid dan cocok; tidak ada `TODO` di entri teratas; kontak resmi ada di metadata; tidak ada alamat `*.invalid`; setiap aset UI tercakup `package-data`.

## Manual

- [ ] Isi entri `CHANGELOG.md` dan `packaging/debian-changelog` (kata `TODO` membuat `check` gagal)
- [ ] Jika skema pengaturan naik: langkah baru di `MIGRATIONS` + tes; jika format cadangan berubah: tetap baca format lama
- [ ] Perbarui `docs/UPGRADING.md` bila jalur versi atau perilaku pembaruan berubah
- [x] `Source:`, `Homepage:`, `url=`, metainfo dan `pyproject` sudah memakai alamat repositori (dijaga `release.py check`)
- [ ] Aktifkan *Private vulnerability reporting* di tab Security repositori GitHub, lalu perbarui `SECURITY.md`
- [ ] Pastikan lisensi: akar repositori berlisensi GPL-3.0 sedangkan Sorot MIT; letakkan `apps/sorot/LICENSE` (MIT) dan nyatakan lisensi per aplikasi di README repositori
- [ ] CI GitHub Actions hijau (matriks Python 3.11/3.12/3.13, job `gui-x11`, `package`, dan Arch) — workflow belum pernah dijalankan; semua langkahnya sudah dijalankan manual secara lokal (lihat [TEST-REPORT.md](TEST-REPORT.md))
- [ ] **Debian 13 bersih** (pengelola melaporkan uji manual berulang di Debian, Ubuntu, Kali; catat versi dan hasil `sorot --diagnostics` supaya bisa dijadikan bukti) (bukan Ubuntu: `.deb` tidak dapat dipasang di Ubuntu 24.04): `apt install ./sorot_X_all.deb`, jalankan, `remove` dan `purge`; periksa dependensi `python3-pyside6.qtwidgets` dan apakah tanda centang tema (PNG) tampil; siklus `dpkg` dengan `--force-depends` sudah dijalankan di Ubuntu
- [ ] **Arch Linux bersih** (mis. `archlinux:base-devel` atau VM): `makepkg -si` dari `dist/arch`, `namcap PKGBUILD` dan `namcap *.pkg.tar.zst`, jalankan, `pacman -Rns`
- [ ] **Skenario pembaruan nyata di desktop**: sudah dijalankan lewat CLI/wheel (0.7.0 → 0.7.1, lihat TEST-REPORT); ulangi dengan aplikasi yang berjalan penuh di desktop nyata
- [ ] [Pengujian manual](MANUAL-TESTING.md) minimal baris 1 dan 3; perbarui `docs/COMPATIBILITY.md`
- [ ] **Wayland** (GNOME dan KDE) dan **compositor nyata**: overlay transparan, selalu-di-atas, klik-tembus, dan **mode cermin** terlihat benar di layar fisik / beam-splitter; yang sudah diverifikasi hanya X11 tanpa compositor dan Wayland di weston headless
- [ ] Uji integrasi Drive dengan rclone asli dan akun uji; uji AI dengan satu penyedia nyata
- [ ] Uji ekstensi contoh pada desktop nyata dan pasang satu ekstensi dari ZIP
- [ ] Konfirmasi nomor GoPay, rekening SeaBank, QRIS (`src/sorot/support.py`, `src/sorot/ui/assets/qris.png`), tautan Saweria, dan alamat email kontak benar (coba scan QRIS dari aplikasi pembayaran sungguhan); sadari semuanya menjadi publik di repositori dan paket
- [ ] Periksa nama “Sorot” belum dipakai produk lain di bidang yang sama (pemeriksaan merek dagang belum dilakukan)
- [ ] Tag git, unggah artefak + `SHA256SUMS` — **hanya setelah persetujuan eksplisit pemilik**

## Tambahan 0.8.0 (tindakan pengelola)
- [ ] Simpan `dist/latest.json` (`make update-manifest BASE=…`) sebagai `apps/sorot/latest.json` hanya setelah berkas rilis diunggah dan hash cocok
- [ ] Di Fedora nyata: `make rpm` tanpa `RPM_NODEPS`, `sudo dnf install`, jalankan, `rpmlint`
- [ ] Di mesin dengan Flatpak: `scripts/build-flatpak.sh --build`, jalankan, lalu ajukan ke Flathub (konfirmasi ID aplikasi)
- [ ] Buka berkas `.docx`, `.odt`, `.pdf` milikmu sendiri lewat Buka dan seret-lepas; periksa hasilnya
- [ ] Bantuan → Periksa pembaruan: harus menampilkan "Belum ada informasi pembaruan" sebelum `latest.json` diterbitkan

## Tambahan 1.0.23 (tindakan pengelola)
- [ ] Tentukan lisensi akhir dan samakan di `LICENSE`, `pyproject.toml`, `packaging/copyright`, `packaging/sorot.metainfo.xml`, dan dialog Tentang (saat ini MIT; repositori induk GPL-3.0)
- [ ] Pindai QRIS dari layar aplikasi Sorot dengan aplikasi bank/e-wallet nyata; kirim donasi uji kecil ke SeaBank dan pastikan nama penerima
- [ ] Catat versi Debian, Ubuntu, Kali, desktop, dan sesi (X11/Wayland) yang kamu uji ke `src/sorot/distros.json` (`evidence`), lalu `make distro-table`
- [ ] `make site BASE=https://alamat-situsmu/` lalu periksa `dist/site/`; **unggah hanya setelah persetujuan eksplisit**. Daftarkan sitemap di Google Search Console setelah situs hidup
