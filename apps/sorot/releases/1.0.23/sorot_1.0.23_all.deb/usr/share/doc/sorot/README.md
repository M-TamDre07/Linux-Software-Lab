# Sorot 1.0.23

Teleprompter overlay untuk Linux (Debian, Ubuntu, Kali): aplikasi gratis dan bebas untuk membaca naskah saat merekam video, presentasi, atau siaran langsung. Naskah tampil dalam jendela transparan yang menggulir **mengikuti kecepatan bicaramu**, di atas aplikasi lain. Naskah dan pengaturan **hanya disimpan di komputermu**; aplikasi berfungsi penuh tanpa internet, tanpa akun, dan tanpa API key.

Dibuat oleh **Muhammad Andreatama** · Hak cipta © 2026 Muhammad Andreatama · Lisensi MIT · Kontak profesional: [muhammadandreatama@outlook.com](mailto:muhammadandreatama@outlook.com)

> **Status: stabil dan siap dipakai untuk keluarga Debian** (Debian, Ubuntu, Kali Linux). Pengelola melaporkan pengujian manual berulang (sekitar 30 kali) di ketiganya dan menilainya stabil; versi distro dan jalur pemasangan tiap uji belum dicatat. Logika juga diuji otomatis ([laporan tes](docs/TEST-REPORT.md)). Distro lain (Fedora, Arch, Flatpak, dan seterusnya) **sengaja ditunda**: paketnya ada sebagai fondasi tetapi belum dipasang di sistem sungguhan. Yang belum terbukti ditulis terang di [KREDIBILITAS.md](docs/KREDIBILITAS.md). Sorot dulu bernama *Tama Prompter* (0.3–0.4); data lama diimpor otomatis.

## Fitur utama

**Gulir yang mengikuti pembicara.** Tiga mode: *kata/menit* (gulir mengikuti laju bicara, dengan jeda napas pada koma dan akhir kalimat), *durasi target* (selesai tepat dalam m:ss), dan *piksel/detik* (konstan). Mulai dan berhenti dihaluskan; jika kamu menggulir dengan roda mouse saat berjalan, waktu otomatis menyesuaikan posisimu; mengubah kecepatan di tengah jalan tidak membuat teks melompat.

**Isyarat naskah.** Baris `// catatan` tidak tampil dan tidak dihitung. Baris `[jeda]` atau `[jeda 5]` benar-benar menahan layar. Penyorot warna di editor menandai keduanya.

**Overlay.** Garis baca (baris yang sedang dibaca), garis progres dan sisa waktu, jenis huruf, warna teks/latar (tema siap pakai atau kustom), transparansi, perataan, margin, posisi lewat peta layar, selalu-di-atas, tanpa bingkai, klik-tembus. Arahkan kursor ke overlay untuk tombol Mulai/Jeda, Awal, kecepatan, Tutup, pegangan **Geser**, dan pegangan ubah ukuran. Roda mouse menggulir manual.

**Profil Tampilan.** Seluruh tampilan teks (huruf, ketebalan, spasi baris dan huruf, warna, latar, perataan, margin, garis baca, **mode cermin**, hitung mundur) tersimpan sebagai satu berkas JSON yang dapat dipilih, disimpan, diekspor, dan dibagikan. Ada enam profil bawaan; ekstensi dapat menambah profil. Lihat [docs/PROFILES.md](docs/PROFILES.md).

**Naskah.** Buka/simpan/ekspor `.txt` dan `.md`, pustaka “Naskah lokal”, draf otomatis untuk pemulihan setelah crash, **riwayat draf** (20 snapshot, termasuk sebelum naskah diganti), peringatan sebelum perubahan hilang, estimasi durasi.

**Ekstensi.** Tema, preset warna, profil tampilan, tugas AI, templat naskah (deklaratif), serta perintah Python (transformasi, aksi, impor/ekspor, pendengar event) yang berjalan di proses terpisah dan **wajib kamu setujui**. Lihat [docs/EXTENSIONS.md](docs/EXTENSIONS.md). Ini bukan sandbox: pasang hanya dari sumber yang kamu percaya.

**Asisten AI (opsional)** — perbaiki bahasa, ringkas, terjemahkan, sesuaikan durasi, dan lainnya lewat API milikmu (format OpenAI Chat Completions). Hasil tampil sebagai pratinjau; tidak menimpa naskah sampai kamu memilih. **Google Drive (opsional)** lewat rclone buatanmu sendiri.

**Pintasan** (dapat diubah, aktif saat jendela utama terfokus): `Ctrl+Enter` tampilkan, `Ctrl+Space` mulai/jeda, `Esc` sembunyikan, `Ctrl+R` ke awal, `Alt+↑/↓` kecepatan.

## Instalasi

Rilis dibagikan sebagai berkas (belum ada repositori apt/AUR atau PyPI). Pilih satu cara; semua memakai data yang sama di `~`.

| Sistem | Cara |
|---|---|
| **Debian, Kali Linux** | `sudo apt install ./sorot_1.0.23_all.deb` |
| **Ubuntu** | Bila `apt` melapor `python3-pyside6.qtwidgets` tidak ada (Ubuntu 24.04), pakai wheel: `pipx install ./sorot-1.0.23-py3-none-any.whl` |
| **Distro mana pun, lewat pip** | `pipx install ./sorot-1.0.23-py3-none-any.whl` |
| **Tanpa root, ke `~/.local`** | `./scripts/install-user.sh` (butuh `python3-venv` dan akses PyPI) |
| **Pengembangan** | `make dev` lalu `sorot` |

Langkah demi langkah (dengan pemeriksaan hash): **[docs/TUTORIAL.md](docs/TUTORIAL.md)**. Fedora, Arch, Flatpak, openSUSE, Alpine, dan Nix belum dinyatakan didukung; statusnya per distro:

<!-- distro-table:start -->
| Distro | Status | Format | Bukti | Belum terbukti |
|---|---|---|---|---|
| **Debian** | Diuji manual oleh pengelola | sorot_X_all.deb (apt) | Laporan pengelola: pemasangan dan pemakaian diuji manual berulang kali (sekitar 30 uji, November 2026). Versi Debian yang tepat belum dicatat; laporan lapangan tertulis 0.4.0 pada Debian 13 KDE Plasma (lewat XWayland). | Overlay selalu-di-atas dan klik-tembus pada Wayland asli belum dicatat per compositor. |
| **Ubuntu** | Diuji manual oleh pengelola | wheel (pipx) atau .deb bila PySide6 tersedia | Laporan pengelola: berjalan baik di Ubuntu. Versi dan jalur pemasangan belum dicatat. Pemeriksaan apt terpisah: .deb tidak dapat dipasang di Ubuntu 24.04 karena python3-pyside6.qtwidgets tidak ada di repositorinya. | Rilis Ubuntu lain dan Linux Mint belum dicatat. |
| **Kali Linux** | Diuji manual oleh pengelola | sorot_X_all.deb (apt) | Laporan pengelola: berjalan baik di Kali Linux. Versi belum dicatat. | Belum ada catatan sesi desktop (Xfce/GNOME/KDE) maupun jalur pemasangan. |
| **Fedora / RHEL** | Paket dibangun, belum dipasang di distro sasaran | sorot-X-1.noarch.rpm | RPM noarch dibangun dan isinya dijalankan di host Ubuntu dengan RPM_NODEPS=1. | Belum dipasang di Fedora; rpmlint belum dijalankan. |
| **Arch Linux** | Paket dibangun, belum dipasang di distro sasaran | PKGBUILD + .SRCINFO | PKGBUILD dan .SRCINFO dihasilkan dan divalidasi sintaksnya. | makepkg dan namcap belum pernah dijalankan. |
| **Flatpak** | Paket dibangun, belum dipasang di distro sasaran | manifes dari make flatpak | Manifes dihasilkan dan terbaca flatpak-builder. | Belum dibangun penuh; integrasi Google Drive tidak tersedia di sandbox. |
| **openSUSE** | Hanya kerangka, belum dibangun atau diuji | kerangka di packaging/experimental/ | Kerangka ada. | Tidak dibangun, tidak diuji; nama paket belum diverifikasi. |
| **Alpine** | Hanya kerangka, belum dibangun atau diuji | kerangka di packaging/experimental/ | Kerangka ada. | Tidak dibangun, tidak diuji. |
| **NixOS / Nix** | Hanya kerangka, belum dibangun atau diuji | kerangka di packaging/experimental/ | Kerangka ada. | Tidak dibangun, tidak diuji. |
| **Void, Gentoo, Solus, dan lainnya** | Hanya deteksi dan petunjuk umum | wheel (pipx) atau make install | Sorot mengenali keluarga distro dari os-release dan memberi petunjuk umum. | Tidak ada paket; tidak diuji. |
<!-- distro-table:end -->

Dependensi: Python ≥ 3.11 dan PySide6 ≥ 6.8 (`python3-pyside6.qtwidgets` di Debian, `pyside6` di Arch). Opsional: `qt6-wayland`, `xwayland`, `rclone`, keyring. Menjalankan: cari “Sorot” di menu aplikasi atau jalankan `sorot`. Menghapus: `sudo apt remove sorot` / `./scripts/uninstall-user.sh` (data pengguna tidak dihapus). Paket `.deb` menggantikan `tama-prompter` jika terpasang.

Rincian pengemasan ada di [PACKAGING.md](docs/PACKAGING.md) dan [DISTRO-LAIN.md](docs/DISTRO-LAIN.md).

**Memverifikasi unduhan dan memperbarui tanpa menghapus:** setiap rilis punya `SHA256SUMS` (dan `SHA256SUMS.asc` bila ditandatangani); memasang `.deb` versi baru di atas versi lama otomatis menaikkan versi dan membuat cadangan data. Bila pengelola menyediakan repositori apt bertanda tangan, pembaruan juga muncul di Discover dan `apt upgrade`. Langkahnya ada di [docs/VERIFY.md](docs/VERIFY.md).

### Memperbarui

```bash
sorot --upgrade-info     # versi, cara pemasangan, perintah pembaruan yang sesuai, daftar cadangan
sorot --backup           # cadangan manual (ZIP terverifikasi)
sorot --restore FILE.zip # pulihkan (aplikasi harus tertutup)
```

Setelah versi berubah, peluncuran pertama membuat **cadangan otomatis** sebelum menyimpan apa pun. Data 0.3.x, 0.4.x, dan 0.5.x semuanya didukung; lihat [docs/UPGRADING.md](docs/UPGRADING.md).

## Data dan privasi

| Data | Lokasi | Catatan |
|---|---|---|
| Pengaturan | `~/.config/sorot/config.json` | tanpa rahasia; cadangan `.bak` |
| Draf, riwayat, pustaka naskah | `~/.local/share/sorot/` | izin `0600`, **tidak dienkripsi** |
| Cadangan | `~/.local/share/sorot/backups/` | izin `0600`, berisi naskahmu, **tidak dienkripsi** |
| Catatan versi | `~/.local/state/sorot/version.json` | hanya nomor versi dan skema |
| Ekstensi dan datanya | `~/.local/share/sorot/extensions/`, `extension-data/` | |
| Log | `~/.local/state/sorot/` | rahasia disamarkan; isi naskah tidak dicatat |
| API key | keyring sistem (jika dicentang) atau memori sesi | tidak pernah ke berkas |

Tidak ada telemetri. Naskah hanya dikirim ke penyedia AI saat kamu menekan **Proses naskah** dan menyetujui tujuannya. Biaya API bergantung pada penyedia. Overlay tidak menjamin tersembunyi dari berbagi layar atau rekaman.

## Diagnostik

```bash
sorot --diagnostics                      # laporan lingkungan tanpa jendela
sorot --upgrade-info                     # versi, cara pemasangan, cara memperbarui, cadangan
sorot --profiles                         # profil tampilan (bawaan, milikmu, ekstensi)
sorot --extensions                       # ekstensi yang ditemukan dan statusnya
sorot --validate-extension FOLDER        # periksa ekstensi buatanmu
SOROT_QT_PLATFORM=xcb sorot              # paksa backend sementara (auto|xcb|wayland)
```

## Dukung pengembangan

Sorot gratis dan bebas dipakai. Jika bermanfaat, dukunganmu membantu pemeliharaan dan fitur berikutnya. Dukungan **sukarela**: tidak ada fitur yang dikunci, tidak ada pop-up, tidak ada pelacakan.

* **Saweria:** https://saweria.co/tamaandrea
* **GoPay:** 0812-7485-2534 (periksa nama penerima di aplikasi sebelum mengirim)
* **SeaBank (transfer):** 9017 2586 2955 (periksa nama penerima di aplikasi bank sebelum mengirim)
* **QRIS:** pindai dari aplikasi bank atau dompet digital apa pun; penerima **TAMA ANDREA STUDIO**. Gambarnya ada di aplikasi (*Simpan gambar QRIS…*) dan di [`src/sorot/ui/assets/qris.png`](src/sorot/ui/assets/qris.png).

Di aplikasi: tombol *Dukung Sorot* di rail kiri, atau menu Bantuan → Dukung pengembangan.

## Kontak

Pertanyaan profesional (kerja sama, pekerjaan, lisensi, dukungan khusus): **muhammadandreatama@outlook.com**. Alamat ini juga tampil di Tentang → *Kontak profesional* (email hanya dibuka jika kamu menekan tombolnya). Jangan mengirim naskah pribadi atau API key lewat email. Untuk kerentanan keamanan, lihat [SECURITY.md](SECURITY.md).

## Dokumentasi

[Tutorial](docs/TUTORIAL.md) · [Kredibilitas](docs/KREDIBILITAS.md) · [Distro lain](docs/DISTRO-LAIN.md) · [Pihak ketiga](docs/PIHAK-KETIGA.md) · [Otomasi dan LLM lokal](docs/OTOMASI.md) · [Profil Tampilan](docs/PROFILES.md) · [Memperbarui](docs/UPGRADING.md) · [Pengemasan](docs/PACKAGING.md) · [Verifikasi dan repositori](docs/VERIFY.md) · [Distribusi](docs/DISTRIBUSI.md) · [Peta jalan 1.0](docs/ROADMAP.md) · [Ekstensi](docs/EXTENSIONS.md) · [Kompatibilitas](docs/COMPATIBILITY.md) · [Arsitektur](docs/ARCHITECTURE.md) · [Pengujian manual](docs/MANUAL-TESTING.md) · [Pemecahan masalah](docs/TROUBLESHOOTING.md) · [Audit 0.3.0](docs/AUDIT-0.3.0.md) · [Laporan tes](docs/TEST-REPORT.md) · [Checklist rilis](docs/RELEASE-CHECKLIST.md) · [CHANGELOG](CHANGELOG.md) · [CONTRIBUTING](CONTRIBUTING.md) · [SECURITY](SECURITY.md)
