# Pihak ketiga

Sorot sendiri hanya berisi kode dan aset buatan pengelola. Pustaka di bawah ini **tidak disertakan** di dalam paket Sorot; ia dipasang terpisah oleh pengelola paket distro atau `pip`. Lisensinya ditulis menurut pengetahuan pengelola proyek; **lisensi yang berlaku adalah yang tertera pada paket yang terpasang di komputermu** (`dpkg -L python3-pyside6.qtwidgets`, `pip show -f PySide6-Essentials`).

| Komponen | Dipakai untuk | Wajib? | Lisensi (umum diketahui) |
|---|---|---|---|
| Python | bahasa pemrograman | ya | PSF License |
| PySide6 / Qt for Python dan Qt 6 | antarmuka grafis | ya | LGPL-3.0 (juga tersedia GPL-3.0 dan komersial) |
| keyring | menyimpan API key di keyring sistem | tidak | MIT |
| pypdf | membuka naskah PDF | tidak | BSD-3-Clause |
| rclone | Google Drive, dijalankan sebagai program terpisah milikmu | tidak | MIT |
| Ollama, LM Studio, llama.cpp | LLM lokal; Sorot hanya berbicara ke API-nya di loopback | tidak | masing-masing sendiri; tidak disertakan |

Pengembangan dan pengujian memakai pytest, pytest-qt, ruff, mypy, PyYAML, OpenCV (hanya untuk memeriksa pembacaan QRIS pada tes), semuanya tidak dikirim ke pengguna.

## Aset gambar

* **Ikon Sorot** (`packaging/sorot.svg` dan turunannya): buatan pengelola.
* **Gambar QRIS** (`src/sorot/ui/assets/qris.png`): kode QRIS milik pengelola sendiri (merchant TAMA ANDREA STUDIO) sebagaimana diterbitkan penyedianya, dipadatkan tanpa mengubah isi kodenya. Logo GoPay, QRIS, GPN, dan bank pada poster itu adalah merek dagang pemiliknya masing-masing dan hanya tampil sebagai bagian dari kode pembayaran; tidak ada afiliasi atau dukungan yang dinyatakan.
* **Jenis huruf:** tidak ada yang disertakan; Sorot memakai huruf sistem.
