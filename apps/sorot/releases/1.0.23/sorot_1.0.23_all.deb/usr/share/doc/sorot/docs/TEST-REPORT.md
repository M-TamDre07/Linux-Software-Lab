# Laporan tes — Sorot 0.8.0 Beta

Tanggal: 2026-10-29 s.d. 11-01 (0.7.1 sampai 0.8.0) · Lingkungan: Ubuntu 24.04.5 x86_64 (container), akses jaringan lewat proxy. **Bukan Debian 13, bukan Arch Linux, bukan desktop nyata dengan compositor.**

> **Berbeda dari laporan 0.7.0:** kali ini PySide6, pytest, pytest-qt, ruff, mypy, lintian, desktop-file-validate, shellcheck, Xvfb dan window manager (openbox) **tersedia**, sehingga kode Qt 0.7.0 yang sebelumnya tidak pernah dijalankan akhirnya dijalankan pada Qt asli. Hasilnya: **mode cermin di 0.7.0 tidak berfungsi sama sekali**, dan ditemukan beberapa cacat lain (lihat CHANGELOG 0.7.1). Semua temuan itu sudah diperbaiki dan dijaga tes regresi.

## Hasil

| Pemeriksaan | Hasil |
|---|---|
| Suite lengkap, Python 3.13.18 + PySide6 6.12.0, Qt `offscreen` | **652 lulus**, 1 dilewati (tes penjaga platform; hanya aktif bila `SOROT_TEST_QPA` diatur) |
| Suite lengkap, Python 3.11.18 + PySide6 6.8.3 (batas bawah yang dinyatakan) | **652 lulus**, 1 dilewati |
| 135 tes GUI di **X11 nyata** (Xvfb + openbox, backend `xcb`, `make test-x11`) | **135 lulus**; tes penjaga membuktikan platform memang `xcb` |
| 135 tes GUI di **Wayland asli** (weston headless, backend `wayland`, `make test-wayland`) | **131 lulus**, 4 dilewati (fokus keyboard/clipboard: compositor tanpa seat) |
| Tes non-GUI saja | 518 lulus |
| `ruff check src tests`, `mypy src` (47 berkas) | bersih (sebelumnya 1 dan 7 temuan) |
| `scripts/release.py check` | konsisten (0.7.1) |
| `lintian` (level bawaan), `desktop-file-validate`, `shellcheck`, `dash -n` pada skrip maintainer, `groff -ww` pada man page | bersih |
| Build dua kali (`.deb`, `.tar.gz`, `.zip`, wheel, `PKGBUILD`, `.SRCINFO`) | `SHA256SUMS` identik; `sha256sum -c` OK |
| Fuzz 60.000 input acak pada parser konfigurasi, profil, naskah; 75.000 pada manifest ekstensi, protokol, respons AI, rclone | 0 crash tersisa (3 cacat nyata ditemukan dan diperbaiki: angka non-finite/raksasa pada konfigurasi dan profil, URL API cacat, bentuk respons API aneh; satu temuan lain ternyata positif palsu) |
| Naskah 2 MB (305.000 kata) | statistik dihitung dalam 0,05 dtk |

Catatan menjalankan: tes pengemasan memanggil `python3` dari `PATH`, jadi jalankan dengan venv aktif (`make test`). Tanpa window manager, tes fokus keyboard gagal di Xvfb; gunakan `make test-x11`.

## Tambahan 0.9.0 (otomasi, LLM lokal, kontainer, Flatpak)

Tanggal: 2026-11-17 · lingkungan sama (Ubuntu 24.04 container, Qt `offscreen`). `flatpak` 1.14.6 dan `flatpak-builder` ada tetapi **tanpa remote**; CLI `docker` ada tetapi **tanpa daemon**; Flathub, ghcr, Docker Hub, dan ollama.com tidak terjangkau.

| Pemeriksaan | Hasil |
|---|---|
| Suite lengkap | **854 lulus**, 1 dilewati; `ruff` dan `mypy src` (64 berkas) bersih |
| Soket kontrol | 41 tes: izin 0700/0600, `SO_PEERCRED`, protokol, 3000 baris acak, batas ukuran, soket basi vs hidup, symlink, jalur panjang, pemilik folder, kode keluar `sorotctl` |
| Resep otomasi | validator terhadap 19 mutasi jahat, pemuat berkas rusak/besar/ganda, runner (urutan, wait tanpa memblokir, galat, batal) |
| Planner | terhadap server model palsu lokal: draf valid (juga dalam pagar kode), langkah terlarang, bukan JSON, kosong, permintaan tak valid tanpa jaringan |
| LLM lokal | penemuan terhadap server palsu: daftar model, kosong, tak ada pendengar, bukan-loopback ditolak tanpa menyambung, pengalihan tidak diikuti, 401, sampah, jawaban raksasa, bypass proxy |
| Resep kontainer | YAML, port semua `127.0.0.1`, tanpa privilege/host namespace/`cap_add`, `docker compose config` untuk keempat kombinasi |
| Manifes Flatpak | izin dalam daftar yang disetujui, resep kontainer ikut terpasang, `flatpak-builder --show-manifest` menerima |
| GUI | halaman Otomasi: pencarian server, pakai model, soket hidup-mati, `sorotctl` ke jendela hidup, konfirmasi resep (batal dan setuju), wait, usulan model disimpan hanya saat klik |

Dua cacat nyata ditemukan tes dan diperbaiki sebelum rilis (nama resep duplikat bertanda kurung ditolak validator; tes dialog AI mengasumsikan semua alamat butuh kunci).

**Tidak diuji:** build Flatpak, menjalankan kontainer, model lokal sungguhan, soket lintas sandbox (host ke Flatpak), Orca nyata, desktop nyata.

## Tambahan 0.8.1 (aksesibilitas, start-up, diagnostik)

Tanggal: 2026-11-14 · lingkungan sama (Ubuntu 24.04 container, Qt `offscreen`, tanpa GPU).

| Pemeriksaan | Hasil |
|---|---|
| Suite lengkap Python 3.13 + PySide6 | **719 lulus**, 1 dilewati (sebelumnya 652); `ruff` dan `mypy src` (55 berkas) bersih |
| Warna buta warna | 18 tes: kontras WCAG, simulasi Machado, ΔE ≥ 25 antar status di setiap tema dan jenis (protan/deutan/tritan); pasangan merah/hijau lama terbukti dekat dan set baru memperbaikinya |
| Nama aksesibel | tes menelusuri semua halaman dan gagal bila ada kontrol interaktif tanpa nama |
| Gulir ke samping | tes pada 100/150/200 %; **menemukan cacat nyata** (halaman Tampilan pada 150–200 %, tombol bilah bawah terpotong) yang diperbaiki dan kini dijaga tes |
| Suara | tes memakai skrip mesin suara tiruan: teks hanya lewat stdin, tidak pernah di argumen |
| Start-up (offscreen, tanpa GPU) | impor UI 167 ms, jendela 143 ms, RSS 100 MB. Bukan angka mesin nyata |
| Tangkapan layar | diperiksa mata: tema kontras tinggi pada 200 %, kontras terang pada 150 %, terang + warna aman |

**Tidak diuji:** Orca atau pembaca layar nyata, penderita buta warna nyata, Wayland/X11 nyata untuk fitur baru (suite X11/Wayland tidak dijalankan ulang), distro selain Ubuntu, driver GPU nyata (sysfs dibaca dari struktur tiruan).

## Tambahan 0.8.0 (fleksibilitas berkas, distribusi)

| Pemeriksaan | Hasil |
|---|---|
| Impor `.docx/.odt/.rtf/.html/.pdf` dan encoding | Tes dengan berkas nyata yang dibuat di tes (PDF ditulis tangan, lalu dibaca `pypdf`); XML ber-DOCTYPE/ENTITY ditolak; zip raksasa (40 MB terdekompresi dari <1 MB) ditolak sebelum dibaca; hasil >5 MB ditolak |
| Fuzz pemuat dokumen | 8.000 berkas rusak acak (rtf/html/txt/docx/odt/pdf) + 20.000 berkas dengan BOM acak: **0 crash**. Tes GUI lama menemukan satu crash nyata (BOM UTF-16 rusak) sebelum fuzz; diperbaiki |
| Seret-lepas | Tes mengirim `QDragEnterEvent/QDropEvent` sungguhan; berkas tak didukung dan banyak berkas diabaikan; penjaga dibuktikan gagal bila dicabut |
| Periksa pembaruan | 30 tes: parser ketat (13 manifes jahat), server HTTP lokal nyata (User-Agent generik, tanpa cookie/referer, redirect/404/jawaban raksasa ditolak, HTTP jarak jauh ditolak), dan **tes yang memastikan tak ada kode lain yang memanggilnya** (tetap opt-in). Logika versi dibuktikan gagal bila dicabut |
| RPM Fedora | Spec dibangun menjadi RPM noarch, identik di dua build; isi dijalankan (`sorot --version`), shebang `/usr/bin/python3`, dependensi `python3-pyside6` saja. **Dibangun dengan `--nodeps` di Ubuntu; belum dipasang di Fedora; `rpmlint` tidak dapat dijalankan** (modul `rpm` rusak di host) |
| Flatpak | Manifes JSON dihasilkan dari rilis nyata, hash cocok, terbaca `flatpak-builder --show-manifest`; metainfo/desktop hasil penggantian nama lolos validator. **Tidak dibangun** (Flathub tidak terjangkau) |
| `latest.json` | Dibangkitkan dari berkas nyata dan divalidasi parser aplikasi sendiri |
| Terlihat di dunia nyata | Tangkapan layar pengguna (KDE Plasma Wayland/xcb, 0.7.2): `.deb` terpasang, upgrade 0.7.0→0.7.2 dengan cadangan otomatis, jendela dan dialog tampil |

## Tambahan 0.7.3 (kredibilitas paket)

| Pemeriksaan | Hasil |
|---|---|
| Dialog Dukung terpotong (tangkapan layar pengguna di KDE) | Direproduksi dengan font diperbesar (tinggi 444 < 524 yang dibutuhkan; 4 label terpotong); kini tidak terpotong. Tes gagal bila perbaikan dicabut |
| Metadata AppStream | `appstreamcli validate --pedantic`: 0 galat; 3 peringatan yang disengaja/lingkungan (ID bukan domain terbalik, homepage belum ada, URL tak terjangkau dari lingkungan ini) |
| Repositori apt bertanda tangan (kunci uji sekali pakai, apt sungguhan, `file://`) | `apt-get update` menerima repositori asli dan `apt-cache policy` melihat kandidat; **menolak** indeks `Packages` yang dirusak (hash tidak cocok) dan kunci yang salah ("not signed"). Tes dibuktikan tidak hampa (indeks benar-benar berubah) dan gagal bila penandatanganan dilepas |
| `.deb` memuat `usr/share/metainfo/sorot.metainfo.xml` dan ikon PNG 64/128/256 | Diperiksa dengan `dpkg -c`, `appstreamcli validate-tree`, lintian bersih |
| **Belum diuji:** tampilan di Discover dengan metadata baru, repositori di hosting nyata dari mesin lain, kunci GPG asli milik pengelola | — |

## Tambahan 0.7.2 (kestabilan dan integritas)

| Cacat | Bukti |
|---|---|
| `SIGTERM`/`SIGHUP` mematikan Sorot tanpa menyimpan; `SIGINT` (Ctrl+C) membuatnya menggantung | Direproduksi pada proses sungguhan (kode keluar 143/129, SIGINT menggantung sampai timeout); kini keluar kode 0, pengaturan tersimpan. 3 tes proses nyata, gagal bila `SignalBridge` dicabut |
| Karakter surrogate sendirian (`"\ud800"` di JSON) lolos ke konfigurasi lalu **setiap** penyimpanan melempar `UnicodeEncodeError` tak tertangkap (menghentikan `closeEvent` di tengah jalan) | Direproduksi; kini dibersihkan saat dibaca dan penulisan tak lagi gagal karena isi. Tes gagal bila perbaikan dicabut |
| `stop()` ekstensi menunggu 60 dtk dan membiarkan proses turunan hidup | Direproduksi dengan ekstensi nyata yang memanggil subproses; kini grup proses dimatikan (stop < 10 dtk, proses turunan mati). Tes gagal bila `start_new_session` dicabut |
| `config.json.bak` disalin langsung (crash di tengah menyisakan cadangan terpotong) | Diperbaiki dengan salin-lalu-rename; **tidak** diperiksa lewat mutasi (hanya diuji hasil akhirnya) |
| Tes sinyal awalnya memakai `python -I` sehingga gagal di venv 3.11 tanpa sorot terpasang | Ditemukan oleh tes di Python 3.11; diperbaiki |

## Cacat yang ditemukan dan diperbaiki (semua punya tes regresi yang terbukti gagal tanpa perbaikannya)

| Cacat | Bukti |
|---|---|
| Mode cermin: `TypeError` pada paint pertama | Dijalankan pada Qt asli; kini identik piksel dengan cermin horizontal pada skala 1×, 1,5×, 2× dan pada Qt 6.8.3 |
| `1e999` / `Infinity` / bilangan raksasa di `config.json` membuat aplikasi crash tiap peluncuran (juga `--diagnostics`); impor profil bernilai sama | Direproduksi dari ujung ke ujung; kini aplikasi mulai dan memakai nilai bawaan |
| Hitung mundur tak terbaca (digambar di atas teks) | Tangkapan layar sebelum/sesudah |
| Halaman Tampilan bergulir ke samping pada jendela bawaan 1100 px (butuh ±1000 px konten) | Diukur: konten 997 → 858 px |
| Alamat API cacat (`http://[`) melempar `ValueError` mentah di UI; respons API berbentuk aneh melempar `KeyError` | Ditemukan fuzz, direproduksi |
| Tes: 3 jenis kesalahan di tes GUI 0.7.0 (versi usang, teardown menggantung oleh dialog tak terjawab, 2 tes hampa), 1 tes pengemasan yang mustahil lulus, 1 tes `drift` rapuh | Dijalankan |
| Dokumentasi: README menyebut `.deb` untuk Ubuntu padahal tidak bisa dipasang di Ubuntu 24.04 | `apt-get install -s` gagal: `python3-pyside6.qtwidgets` tidak ada |
| Segfault acak di Wayland (≈3 dari 10 peluncuran weston baru) | Ditelusuri dengan `gdb` ke race GC Python vs. thread pekerja Qt; `MainThreadGC` memperbaikinya: 0 crash dalam 12 putaran di bawah `gdb`. Tes regresi memastikan `app.main` memasang penjaga (dengan penjaga dilepas, tes gagal) |
| Tanda centang tema bergantung pada plugin SVG Qt yang opsional | Diganti PNG; tes subproses tanpa plugin SVG membandingkan piksel dan gagal bila perbaikan dibatalkan |

## Pengujian di luar suite

| Pengujian | Hasil |
|---|---|
| **Pembaruan nyata**: wheel 0.7.0 yang dibagikan dipasang di venv Python 3.12 → data dibuat (konfigurasi, naskah, profil milikmu) → upgrade ke wheel 0.7.1 | Cadangan otomatis dibuat sebelum menyimpan apa pun; pemberitahuan "baru diperbarui"; naskah, pengaturan, dan profil utuh |
| Rollback: naskah dihapus dan `config.json` dirusak lalu `sorot --restore` cadangan | Keduanya pulih; kondisi sebelum pemulihan disimpan sebagai `…-pre-restore-…zip` |
| `.deb` 0.7.0 yang dibagikan → `.deb` 0.7.1 → `remove` → `purge` (`dpkg`, `--force-depends`) | Skrip maintainer berjalan, versi naik, `remove` dan `purge` bersih |
| `apt-get install -s` `.deb` di Ubuntu 24.04 | **Gagal** (dependensi tidak ada) — hanya Debian 13 yang menyediakannya; didokumentasikan |
| Wheel dipasang di venv Python 3.12 (Ubuntu) | `sorot --version`, `--upgrade-info` berjalan; aset PNG ikut terpasang |
| Overlay di **X11 nyata dengan window manager** (Xvfb + openbox) | `_NET_WM_STATE_ABOVE` aktif; dekorasi mati (Motif hints); posisi dan ukuran sama dengan perhitungan aplikasi; *input shape* kosong saat klik-tembus aktif, penuh saat dimatikan (dibaca langsung dari server X lewat ekstensi SHAPE) |
| Aplikasi penuh (`app.main`) dijalankan 6 dtk di `offscreen` tanpa error di log; hook pembaruan jalan | OK |

## BELUM DIUJI

- **Desktop nyata** (GNOME, KDE, Xfce, Cinnamon) baik Wayland maupun XWayland. Yang sudah dibuktikan di weston headless: aplikasi jalan, overlay tak berbingkai, latar transparan terkomposit (dibaca dari tangkapan compositor), dan 124 tes GUI lulus. Yang tidak dapat dibuktikan di sana: selalu-di-atas, posisi (compositor yang memutuskan), fokus keyboard dan clipboard (tanpa seat).
- **Arch Linux**: `makepkg`, `namcap`, nama paket `pyside6`; job `arch` di CI belum pernah dijalankan. `PKGBUILD` dan `.SRCINFO` hanya diperiksa konsistensi dan reproduktibilitasnya.
- **Mirror Debian dan Arch tidak dapat dijangkau dari lingkungan ini** (kebijakan egress memblokirnya), jadi dua item di bawah tidak dapat diuji di sini apa pun usahanya.
- **Debian 13 bersih lewat `apt`** (dependensi `python3-pyside6.qtwidgets` ada di Debian 13 menurut situs paket Debian, tetapi pemasangan nyata di Debian 13 belum dilakukan; `.deb` hanya dipasang dengan `--force-depends` di Ubuntu) dan menjalankan aplikasi dari paket itu dengan PySide6 dari apt (6.8.2.1).
- **GitHub Actions**: workflow (termasuk job `gui-x11` baru) belum pernah dijalankan; YAML hanya divalidasi sintaksnya.
- Pratinjau di pengaturan (tinggi tetap 112 px) memotong baris pada spasi baris besar; hanya dilihat, tidak dianggap cacat.
- Penyedia AI nyata, rclone/Drive nyata, ekstensi pihak ketiga, keyring nyata, pembaca layar, HiDPI pada layar fisik.
- Pintasan global dan dialog yang membutuhkan interaksi manusia (lihat [MANUAL-TESTING.md](MANUAL-TESTING.md)).

## Cakupan terdahulu
Laporan 0.5.0 dan 0.6.0 tetap menjadi acuan untuk area yang tidak disentuh 0.7.1 (ekstensi, Drive, AI).

## Tambahan 1.0.23 (dialog Dukung, tutorial, situs SEO, fondasi distro)

Tanggal: 2026-11-18 s.d. 11-19 · lingkungan sama (Ubuntu 24.04 container, Qt `offscreen`, Python 3.13, PySide6 6.12.0). **Tidak ada pengujian di Debian, Ubuntu, atau Kali sungguhan di lingkungan ini**: status "diuji" untuk ketiganya berasal dari laporan manual pengelola (sekitar 30 kali uji; versi distro dan jalur pemasangan tidak dicatat), bukan dari tes di bawah.

| Pemeriksaan | Hasil |
|---|---|
| Suite lengkap | **903 lulus**, 2 dilewati (tes penjaga platform; tes dekode QR yang butuh OpenCV, yang tidak ada di venv uji: dekode dijalankan terpisah dengan OpenCV sistem, lihat baris QRIS) |
| `ruff check src tests scripts`, `mypy src` (65 berkas) | bersih |
| `scripts/release.py check` | konsisten (1.0.23); kini juga memeriksa tabel distro, dokumen wajib, dan classifier `Production/Stable` |
| `lintian` pada `.deb` 1.0.23 | tanpa temuan |
| `appstreamcli validate --no-net` | lolos; satu peringatan gaya lama (ID bukan rDNS) |
| `groff -ww` pada `sorot.1` | bersih |
| `dist/SHA256SUMS` | `sha256sum -c` OK untuk `.deb`, `.tar.gz`, `.zip`, wheel, `PKGBUILD`, `.SRCINFO` |
| `.deb` diekstrak dan dijalankan di luar pohon sumber | `sorot.__version__` dan `sorot --distro-report` jalan dari `/usr/lib/sorot` |
| QRIS | berkas yang dikirim, kartu QR hasil render di dialog (300 px), dan tampilan *Perbesar* terbaca OpenCV dengan isi **identik** dengan gambar asli (kode EMV valid, merchant TAMA ANDREA STUDIO); belum dipindai oleh aplikasi bank/e-wallet nyata |
| Dialog Dukung dan Tentang | tidak ada label terpotong pada huruf +0/+4/+8 pt; tinggi ≤ layar; tanpa gulir menyamping; tangkapan layar pada zoom 100/150/200% |
| Situs statis | 18 tes (satu `h1`, canonical, OpenGraph, JSON-LD valid, sitemap, robots, `security.txt`, tanpa JavaScript dan tanpa permintaan pihak ketiga, semua tautan dan anchor internal ada, tanpa klaim "100%"); dilihat di Chromium 1100 px dan 390 px, terang dan gelap, tanpa gulir menyamping |

Cacat nyata yang ditemukan tes/pemeriksaan sebelum rilis:
- **Dialog Tentang memotong teks** pada semua ukuran (label berbungkus kata lebih pendek dari teksnya). Dialog Tentang dan Dukung kini memakai dasar `ScrollableDialog`.
- **`distros.json` tidak ikut ke dalam `.deb`** (skrip hanya menyalin `*.py` dan `*.png`); ditemukan saat memeriksa isi paket, kini dijaga tes `test_deb_ships_every_runtime_data_file`.
- Penghitung waktu `singleShot` pada dialog dapat berjalan setelah dialog dihapus (`RuntimeError` antar-tes); kini pewaktu dimiliki dialog.
- `release.py bump` tidak ikut menaikkan nama berkas di `docs/TUTORIAL.md`; kini ikut.
- Pernyataan lama "pemasangan bersih di Debian 13 belum dibuktikan" di `--diagnostics` sudah kedaluwarsa dan diganti status dari `distros.json`.

**Tidak diuji / tidak bisa diuji di sini:** Debian, Ubuntu, Kali sungguhan; pemindaian QRIS oleh aplikasi pembayaran; pembaca layar nyata; Wayland asli; distro non-Debian; situs di server (hanya dibangun sebagai berkas).
