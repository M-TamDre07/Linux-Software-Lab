# Kredibilitas: apa yang bisa kamu periksa sendiri

Halaman ini sengaja berisi hal yang **dapat dicek**, bukan janji. Tiap klaim disertai cara memeriksanya, dan di akhir ada daftar hal yang **belum terbukti**.

## Siapa di balik Sorot

* Pengelola: **Muhammad Andreatama** (Tama Andrea Studio). Kontak profesional: muhammadandreatama@outlook.com.
* Kode sumber publik: https://github.com/M-TamDre07/Linux-Software-Lab (folder `apps/sorot/`).
* Penerima donasi di aplikasi, README, dan situs semuanya sama: Saweria `tamaandrea`, GoPay, SeaBank, dan QRIS atas nama **TAMA ANDREA STUDIO**. Aplikasi hanya menampilkan data ini; tidak mengirim apa pun sendiri. Selalu cocokkan nama penerima di aplikasi banking-mu sebelum mengirim.

## Klaim privasi dan cara memeriksanya

| Klaim | Cara memeriksa |
|---|---|
| Tidak ada telemetri, tidak ada akun | Cari sendiri: kode yang membuka koneksi hanya ada di `services/ai_service.py`, `services/local_llm.py`, `services/update_service.py`, dan soket lokal `services/control.py`, `ctl.py`. `grep -rn "urllib.request\|socket\." src/sorot` |
| Jaringan hanya dipakai saat kamu menekan tombol | Jalankan Sorot, pakai seperti biasa, lalu `ss -tpn \| grep -i sorot` atau `lsof -i -a -c python`: tidak ada koneksi keluar. Fitur AI, periksa pembaruan, dan Drive hanya aktif saat diklik |
| Naskah tidak dikirim ke mana pun tanpa persetujuan | Fitur AI menampilkan tujuan dan meminta persetujuan sebelum mengirim; hasilnya pratinjau dan tidak menimpa naskah. Lihat [SECURITY.md](../SECURITY.md) |
| LLM lokal tidak keluar dari komputermu | Hanya alamat loopback (`127.0.0.1`, `::1`) yang diterima tanpa API key; tanpa proxy dan tanpa pengalihan. Diuji di `tests/test_local_llm.py` |
| Soket kontrol dimatikan secara bawaan | Pengaturan `control_enabled` bawaan mati; bila dinyalakan, soket berizin `0600` di folder `0700` dan memeriksa UID pemanggil. Diuji di `tests/test_control.py` |
| API key tidak ditulis ke berkas | Diuji di `tests/test_ai_service.py`; periksa sendiri `~/.config/sorot/config.json` |
| Aplikasi tidak memasang apa pun dan tidak mengubah sistem | Paket `.deb` hanya berisi berkas program: `dpkg -L sorot`, dan `dpkg -c sorot_*.deb` sebelum memasang |

## Integritas unduhan

* Setiap rilis punya `SHA256SUMS`: `sha256sum -c --ignore-missing SHA256SUMS`.
* Build dapat diulang: dua build dari sumber yang sama menghasilkan berkas identik (`SOURCE_DATE_EPOCH` diturunkan dari `packaging/RELEASE_DATE`). Periksa dengan `make dist` dua kali dan bandingkan.
* Tanda tangan GPG (`SHA256SUMS.asc`) **baru ada bila pengelola sudah memiliki kunci**; lihat [VERIFY.md](VERIFY.md).

## Bukti pengujian

* **Otomatis:** `make test` menjalankan ruff, mypy, dan seluruh pytest (GUI memakai Qt offscreen; ada juga jalur X11 dan Wayland). Angka terbaru ada di [TEST-REPORT.md](TEST-REPORT.md), lengkap dengan apa yang tidak dapat diuji secara otomatis.
* **Manual oleh pengelola:** pengelola melaporkan pengujian berulang (sekitar 30 kali) di **Debian, Ubuntu, dan Kali Linux** dan menilainya stabil. Ini laporan pengelola; versi distro dan jalur pemasangan tiap uji belum dicatat. Detailnya ada di [DISTRO-LAIN.md](DISTRO-LAIN.md) dan `src/sorot/distros.json`, yang menjadi satu-satunya sumber status distro; `sorot --diagnostics` memberi tahu status distro yang kamu pakai.
* **Kualitas paket:** `lintian` bersih untuk `.deb`; metadata AppStream lolos `appstreamcli validate` (satu peringatan gaya tentang ID bukan rDNS).

## Yang belum terbukti (ditulis terang-terangan)

* Distro di luar keluarga Debian: Fedora, Arch, Flatpak, dan lainnya belum dipasang di sistem sungguhan. Kerangkanya ada, tetapi tidak diklaim berjalan.
* Perilaku overlay (selalu-di-atas, klik-tembus, geser) pada **Wayland asli** per compositor belum dicatat. Backend XWayland yang dipilih otomatis lebih terkontrol.
* Pembaca layar nyata (Orca) belum diuji; dukungan aksesibilitas diuji lewat API Qt, bukan dengan pengguna tunanetra.
* Model bahasa lokal dan resep kontainer belum dijalankan terhadap server sungguhan di lingkungan pengujian otomatis.
* Tidak ada audit keamanan pihak ketiga. Model ancaman ada di [SECURITY.md](../SECURITY.md).

## Lisensi

Lihat berkas `LICENSE` dan bagian Tentang di aplikasi. Pustaka pihak ketiga dan lisensinya ada di [PIHAK-KETIGA.md](PIHAK-KETIGA.md).

## Melaporkan masalah

* Bug biasa: https://github.com/M-TamDre07/Linux-Software-Lab/issues
* Kerentanan: jangan buka isu publik; ikuti [SECURITY.md](../SECURITY.md).
