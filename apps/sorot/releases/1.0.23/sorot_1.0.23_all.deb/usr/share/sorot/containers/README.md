# Server LLM lokal dalam kontainer

Sorot dapat memakai model bahasa yang berjalan **di komputer Anda sendiri** (naskah tidak meninggalkan mesin ini).
Berkas di folder ini menjalankan server seperti itu dalam kontainer. **Sorot tidak pernah menjalankan, menghentikan, atau memasang kontainer**; Anda yang menjalankannya.

| Berkas | Isi |
|---|---|
| `ollama.compose.yaml` | Ollama (CPU). Port `127.0.0.1:11434` |
| `ollama.gpu-nvidia.yaml` | tambahan GPU NVIDIA (butuh NVIDIA Container Toolkit) |
| `ollama.gpu-amd.yaml` | tambahan GPU AMD (citra ROCm, perangkat `/dev/kfd` dan `/dev/dri`) |
| `llamacpp.compose.yaml` | llama.cpp (`llama-server`) dengan berkas GGUF Anda. Port `127.0.0.1:8080` |

## Memakai
```bash
docker compose -f ollama.compose.yaml up -d            # atau: podman compose -f ...
docker compose -f ollama.compose.yaml exec ollama ollama pull NAMA_MODEL
```
Lalu di Sorot buka halaman **Otomasi → Cari server lokal** dan pilih server serta modelnya. Tidak perlu API key.

## Aturan keamanan yang dijaga tes
* Port hanya diterbitkan di `127.0.0.1`: tidak terjangkau dari jaringan.
* Tanpa `privileged`, tanpa jaringan/PID host, tanpa `cap_add`, `no-new-privileges`, semua capability dibuang.
* Tidak menyentuh soket Docker, `/etc`, atau folder rumah; folder model llama.cpp dipasang hanya-baca.
* `restart: "no"`: tidak menyala sendiri saat boot.

## Jujur soal status
* Berkas ini lolos `docker compose config` dan tes aturan di atas, **tetapi tidak pernah dijalankan** (lingkungan pembuatan tidak punya daemon kontainer dan registry tidak terjangkau). Nama citra, tag, dan dukungan GPU tertentu belum diverifikasi.
* Model besar butuh RAM/VRAM besar; batas memori bawaan 8 GB dapat diubah (`OLLAMA_MEM_LIMIT`).
* Dari dalam Flatpak, server di `127.0.0.1` dapat dijangkau hanya jika Sorot memegang izin `--share=network` (sudah ada di manifes).
