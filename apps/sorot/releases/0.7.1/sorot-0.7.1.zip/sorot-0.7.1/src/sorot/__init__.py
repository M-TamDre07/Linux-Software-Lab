"""Sorot — teleprompter overlay desktop untuk Linux."""

__version__ = "0.7.1"
VERSION_LABEL = "0.7.1 Beta"
APP_NAME = "Sorot"
ORG_NAME = "Sorot"
AUTHOR = "Muhammad Andreatama"
CONTACT_EMAIL = "muhammadandreatama@outlook.com"  # professional inquiries
COPYRIGHT = "Hak cipta © 2026 Muhammad Andreatama"
LICENSE_NAME = "MIT"
TAGLINE = "Teleprompter overlay untuk Linux"
